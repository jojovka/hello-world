package kz.eub.rm.security;

import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import kz.eub.rm.entity.dwh.ExceptionalPozProductsDictionary;
import kz.eub.rm.entity.dwh.TriggerDictionary;

@ResourceRole(name = "CommonDictionariesUserRole", code = "common-dictionaries-user-role")
public interface CommonDictionariesUserRole {
    @MenuPolicy(menuIds = {"rm_ExceptionalPozProductsDictionary.browse", "rm_TriggerDictionary.browse"})
    @ScreenPolicy(screenIds = {"rm_ExceptionalPozProductsDictionary.browse", "rm_TriggerDictionary.browse"})
    void screens();

    @EntityAttributePolicy(entityClass = ExceptionalPozProductsDictionary.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = ExceptionalPozProductsDictionary.class, actions = EntityPolicyAction.READ)
    void exceptionalPozProductsDictionary();

    @EntityAttributePolicy(entityClass = TriggerDictionary.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = TriggerDictionary.class, actions = EntityPolicyAction.READ)
    void triggerDictionary();
}