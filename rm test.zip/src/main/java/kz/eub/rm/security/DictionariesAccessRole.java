package kz.eub.rm.security;

import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.security.role.annotation.SpecificPolicy;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import kz.eub.rm.entity.CustomPropertyFilterCondition;
import kz.eub.rm.entity.PnzPledge;
import kz.eub.rm.entity.User;
import kz.eub.rm.entity.dwh.*;

@ResourceRole(name = "DictionariesAccessRole", code = "dictionaries-access-role")
public interface DictionariesAccessRole {
    @MenuPolicy(menuIds = {"rm_CreditContractsDictionary.browse", "rm_PledgesDictionary.browse", "rm_SourceSystemsDictionary.browse", "rm_ProductReferenceDictionary.browse", "rm_PozDictionary.browse", "rm_PozSegmentationDictionary.browse", "rm_BorrowerDealRatingDictionary.browse", "rm_ExceptionalPozProductsDictionary.browse", "rm_PozMacroAdjustmentDictionary.browse", "rm_PnzMacroAdjustmentDictionary.browse", "rm_AlphaCoefficientDictionary.browse", "rm_PozMapping.browse", "rm_LiquidityCoefficientDictionary.browse", "rm_TriggerDictionary.browse", "rm_PdPnzHistory.browse", "rm_PnzCredit.browse", "rm_PnzPledge.browse"})
    @ScreenPolicy(screenIds = {"rm_CreditContractsDictionary.browse", "rm_PledgesDictionary.browse", "rm_SourceSystemsDictionary.browse", "rm_ProductReferenceDictionary.browse", "rm_PozDictionary.browse", "rm_PozSegmentationDictionary.browse", "rm_BorrowerDealRatingDictionary.browse", "rm_ExceptionalPozProductsDictionary.browse", "rm_PozMacroAdjustmentDictionary.browse", "rm_PnzMacroAdjustmentDictionary.browse", "rm_AlphaCoefficientDictionary.browse", "rm_PozMapping.browse", "rm_PozMacroAdjustmentDictionary.edit", "rm_PozMapping.edit", "rm_SourceSystemsDictionary.edit", "rm_ProductReferenceDictionary.edit", "rm_CreditContractsDictionary.edit", "rm_PledgesDictionary.edit", "rm_AlphaCoefficientDictionary.edit", "rm_BorrowerDealRatingDictionary.edit", "rm_ExceptionalPozProductsDictionary.edit", "rm_PnzMacroAdjustmentDictionary.edit", "rm_PozDictionary.edit", "rm_PozSegmentationDictionary.edit", "rm_LiquidityCoefficientDictionary.browse", "rm_LiquidityCoefficientDictionary.edit", "rm_MainScreen", "rm_TriggerDictionary.browse", "rm_TriggerDictionary.edit", "ui_PropertyFilterCondition.edit", "ui_JpqlFilterCondition.edit", "ui_GroupFilterCondition.edit", "rm_CustomPropertyFilterCondition.edit", "ui_FilterConfigurationModel.fragment", "ui_UiDataFilterConfigurationModel.fragment", "ui_AddConditionScreen", "rm_PdPnzHistory.browse", "rm_PnzCredit.browse", "rm_PnzPledge.browse"})
    void screens();

    @EntityAttributePolicy(entityClass = AlphaCoefficientDictionary.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = AlphaCoefficientDictionary.class, actions = EntityPolicyAction.ALL)
    void alphaCoefficientDictionary();

    @EntityAttributePolicy(entityClass = PledgesDictionary.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = PledgesDictionary.class, actions = EntityPolicyAction.ALL)
    void pledgesDictionary();

    @EntityAttributePolicy(entityClass = PnzMacroAdjustmentDictionary.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = PnzMacroAdjustmentDictionary.class, actions = EntityPolicyAction.ALL)
    void pnzMacroAdjustmentDictionary();

    @EntityAttributePolicy(entityClass = PozDictionary.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = PozDictionary.class, actions = EntityPolicyAction.ALL)
    void pozDictionary();

    @EntityAttributePolicy(entityClass = PozMacroAdjustmentDictionary.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = PozMacroAdjustmentDictionary.class, actions = EntityPolicyAction.ALL)
    void pozMacroAdjustmentDictionary();

    @EntityAttributePolicy(entityClass = PozMappingDictionary.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = PozMappingDictionary.class, actions = EntityPolicyAction.ALL)
    void pozMappingDictionary();

    @EntityAttributePolicy(entityClass = PozSegmentationDictionary.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = PozSegmentationDictionary.class, actions = EntityPolicyAction.ALL)
    void pozSegmentationDictionary();

    @EntityAttributePolicy(entityClass = ProductReferenceDictionary.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = ProductReferenceDictionary.class, actions = EntityPolicyAction.ALL)
    void productReferenceDictionary();

    @EntityAttributePolicy(entityClass = SourceSystemsDictionary.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = SourceSystemsDictionary.class, actions = EntityPolicyAction.ALL)
    void sourceSystemsDictionary();

    @EntityAttributePolicy(entityClass = User.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = User.class, actions = EntityPolicyAction.READ)
    void user();

    @EntityAttributePolicy(entityClass = BorrowerDealRatingDictionary.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = BorrowerDealRatingDictionary.class, actions = EntityPolicyAction.ALL)
    void borrowerDealRatingDictionary();

    @EntityAttributePolicy(entityClass = CreditContractsDictionary.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = CreditContractsDictionary.class, actions = EntityPolicyAction.ALL)
    void creditContractsDictionary();

    @EntityAttributePolicy(entityClass = CustomPropertyFilterCondition.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = CustomPropertyFilterCondition.class, actions = EntityPolicyAction.ALL)
    void customPropertyFilterCondition();

    @EntityAttributePolicy(entityClass = ExceptionalPozProductsDictionary.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = ExceptionalPozProductsDictionary.class, actions = EntityPolicyAction.ALL)
    void exceptionalPozProductsDictionary();

    @EntityAttributePolicy(entityClass = LiquidityCoefficientDictionary.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = LiquidityCoefficientDictionary.class, actions = EntityPolicyAction.ALL)
    void liquidityCoefficientDictionary();

    @MenuPolicy(menuIds = {"pozMappingDictionaryItem","creditContractsDictionaryItem", "pledgesDictionaryItem"})
    void beanMenuItems();

    @EntityAttributePolicy(entityClass = CreditContractsId.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = CreditContractsId.class, actions = EntityPolicyAction.READ)
    void creditContractsId();

    @EntityAttributePolicy(entityClass = TriggerDictionary.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = TriggerDictionary.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE, EntityPolicyAction.CREATE})
    void triggerDictionary();

    @SpecificPolicy(resources = {"ui.filter.modifyConfiguration", "ui.filter.modifyJpqlCondition"})
    void specific();

    @EntityAttributePolicy(entityClass = PnzCredit.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = PnzCredit.class, actions = EntityPolicyAction.READ)
    void pnzCredit();

    @EntityAttributePolicy(entityClass = PnzPledge.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = PnzPledge.class, actions = EntityPolicyAction.READ)
    void pnzPledge();
}