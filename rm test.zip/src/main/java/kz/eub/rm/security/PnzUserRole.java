package kz.eub.rm.security;

import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.security.role.annotation.SpecificPolicy;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import kz.eub.rm.entity.PnzPdHistory;
import kz.eub.rm.entity.PnzPledge;
import kz.eub.rm.entity.PnzRedZone;
import kz.eub.rm.entity.PnzRunHistory;
import kz.eub.rm.entity.dwh.BorrowerDealRatingDictionary;
import kz.eub.rm.entity.dwh.PnzCredit;
import kz.eub.rm.entity.dwh.PnzMacroAdjustmentDictionary;

@ResourceRole(name = "PnzUserRole", code = "pnz-user-role")
public interface PnzUserRole {
    @MenuPolicy(menuIds = {"rm_PnzCredit.browse", "rm_PnzPledge.browse", "rm_BorrowerDealRatingDictionary.browse", "rm_PnzMacroAdjustmentDictionary.browse", "rm_PnzCalculationsScreen", "rm_DrPnzBaseReportScreen", "rm_PnzPdHistory.browse", "rm_PnzRedZone.browse", "rm_AvailabilityAnalysisReportScreen", "rm_PnzAvgrrReportScreen"})
    @ScreenPolicy(screenIds = {"rm_PnzCredit.browse", "rm_PnzPledge.browse", "rm_BorrowerDealRatingDictionary.browse", "rm_PnzMacroAdjustmentDictionary.browse", "rm_PnzCalculationsScreen", "rm_PnzCalculationsViewFragment", "rm_PnzRunCalculationFragment", "rm_DrPnzBaseReportScreen", "rm_PnzPdHistory.browse", "rm_PdDrCalculationScreen", "rm_PnzRedZone.browse", "rm_PnzRedZone.edit", "rm_AvailabilityAnalysisReportScreen", "rm_PnzAvgrrReportScreen"})
    void screens();

    @SpecificPolicy(resources = "main.pnz.run.filter")
    void specific();

    @EntityAttributePolicy(entityClass = BorrowerDealRatingDictionary.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = BorrowerDealRatingDictionary.class, actions = EntityPolicyAction.READ)
    void borrowerDealRatingDictionary();

    @EntityAttributePolicy(entityClass = PnzMacroAdjustmentDictionary.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = PnzMacroAdjustmentDictionary.class, actions = EntityPolicyAction.READ)
    void pnzMacroAdjustmentDictionary();

    @EntityAttributePolicy(entityClass = PnzCredit.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = PnzCredit.class, actions = EntityPolicyAction.READ)
    void pnzCredit();

    @EntityAttributePolicy(entityClass = PnzPledge.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = PnzPledge.class, actions = EntityPolicyAction.READ)
    void pnzPledge();

    @EntityAttributePolicy(entityClass = PnzRunHistory.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = PnzRunHistory.class, actions = EntityPolicyAction.READ)
    void pnzRunHistory();

    @EntityAttributePolicy(entityClass = PnzPdHistory.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = PnzPdHistory.class, actions = EntityPolicyAction.READ)
    void pnzPdHistory();

    @EntityAttributePolicy(entityClass = PnzRedZone.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = PnzRedZone.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void pnzRedZone();

}