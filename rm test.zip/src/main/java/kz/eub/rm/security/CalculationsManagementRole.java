package kz.eub.rm.security;

import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import kz.eub.rm.entity.RunHistory;
import kz.eub.rm.entity.dwh.RunStage;

import javax.annotation.Nonnull;

@Nonnull
@ResourceRole(name = "CalculationsManagementRole", code = "calculations-management-role")
public interface CalculationsManagementRole {
    @MenuPolicy(menuIds = "rm_CalculationsScreen")
    @ScreenPolicy(screenIds = {"rm_CalculationsScreen", "rm_CalculationsViewFragment", "rm_RunCalculationFragment"})
    void screens();

    @EntityAttributePolicy(entityClass = RunHistory.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = RunHistory.class, actions = EntityPolicyAction.READ)
    void runHistory();

    @EntityAttributePolicy(entityClass = RunStage.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = RunStage.class, actions = EntityPolicyAction.READ)
    void runStage();
}