package kz.eub.rm.security.specific;

import io.jmix.core.accesscontext.SpecificOperationAccessContext;

public class BulkRoleAssignment extends SpecificOperationAccessContext {

    public static final String NAME = "bulkRoleAssignment";

    public BulkRoleAssignment() {
        super(NAME);
    }
}
