package kz.eub.rm.screen.pozuserfriendlyreport;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.screen.abstractuserfriendlyreport.AbstractUserFriendlyReportScreen;
import kz.eub.rm.service.PozRunGlobalFilterConfigurationService;
import org.springframework.beans.factory.annotation.Autowired;

/*
 то же самое, что в AbstractUserFriendlyReportScreen, только runid берется для ПОЗ
 */
@UiController("rm_PozUserFriendlyReportScreen")
@UiDescriptor("poz-user-friendly-report-screen.xml")
public abstract class PozUserFriendlyReportScreen extends AbstractUserFriendlyReportScreen {
    @Autowired
    protected PozRunGlobalFilterConfigurationService pozRunGlobalFilterConfigurationService;

    @Override
    protected String fetchRunId() {
        return pozRunGlobalFilterConfigurationService.getCurrent().getRunId();
    }
}