package kz.eub.rm.screen.pnzruncalculationfragment;

import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.screen.runcalculationfragment.RunCalculationFragment;
import kz.eub.rm.service.calculation.PnzCalculationService;
import kz.eub.rm.service.dto.CalculationLaunchResult;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;

@UiController("rm_PnzRunCalculationFragment")
@UiDescriptor("pnz-run-calculation-fragment.xml")
public class PnzRunCalculationFragment extends RunCalculationFragment {
    @Autowired
    protected PnzCalculationService calculationService;
    @Override
    protected CalculationLaunchResult prepareCalculationResult() {
        return calculationService.runCalculation(datePickerField.getValue(), () -> new ArrayList<>());
    }
}