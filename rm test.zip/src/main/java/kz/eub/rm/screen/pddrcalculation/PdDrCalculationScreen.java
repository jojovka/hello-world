package kz.eub.rm.screen.pddrcalculation;

import io.jmix.ui.Notifications;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.DateField;
import io.jmix.ui.component.ProgressBar;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.service.UserService;
import kz.eub.rm.service.calculation.PnzDrPdCalculationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

@UiController("rm_PdDrCalculationScreen")
@UiDescriptor("pd-dr-calculation-screen.xml")
public class PdDrCalculationScreen extends Screen {
    private static final Logger log = LoggerFactory.getLogger(PdDrCalculationScreen.class);
    @Autowired
    protected PnzDrPdCalculationService pnzDrPdCalculationService;
    @Autowired
    protected UserService userService;

    @Autowired
    protected Notifications notifications;

    @Autowired
    protected DateField<Date> dateFromField;
    @Autowired
    protected DateField<Date> dateToField;
    @Autowired
    protected ProgressBar circularProgressBar;
    @Autowired
    protected Button runCalculationButton;

    @Subscribe("runCalculationButton")
    public void onRunCalculationButtonClick(Button.ClickEvent event) {
        try {
            circularProgressBar.setVisible(true);
            pnzDrPdCalculationService.runCalculation(userService.getCurrentUser().getUsername(), dateFromField.getValue(), dateToField.getValue());
            circularProgressBar.setVisible(false);
            notifications.create().withDescription("Расчет успешно завершен").show();
        } catch (Exception e) {
            log.error("Exception during calculation run", e);
            circularProgressBar.setVisible(false);
            notifications.create().withDescription("Расчет завершился с ошибкой, обратитесь к администратору системы").show();
        }
    }
}