package kz.eub.rm.screen.filterapplydialog;

import io.jmix.ui.component.Button;
import io.jmix.ui.screen.*;
import kz.eub.rm.bean.SessionEventPublisher;
import kz.eub.rm.entity.PnzRunHistory;
import kz.eub.rm.entity.RunHistory;
import kz.eub.rm.event.GlobalConfigurationChangedEvent;
import kz.eub.rm.service.PnzRunGlobalFilterConfigurationService;
import kz.eub.rm.service.PozRunGlobalFilterConfigurationService;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("rm_FilterApplyDialog")
@UiDescriptor("filter-apply-dialog.xml")
public class FilterApplyDialog extends Screen {
    RunHistory pozRun;
    PnzRunHistory pnzRun;

    @Autowired
    private PnzRunGlobalFilterConfigurationService pnzRunGlobalFilterConfigurationService;
    @Autowired
    private PozRunGlobalFilterConfigurationService pozRunGlobalFilterConfigurationService;

    @Autowired
    private SessionEventPublisher sessionEventPublisher;

    @Subscribe
    public void onInit(InitEvent event) {
        applyOptions(event.getOptions());
    }

    private void applyOptions(ScreenOptions screenOptions) {
        if (screenOptions instanceof FilterApplyDialogOptions) {
            pozRun = ((FilterApplyDialogOptions) screenOptions).getPozRun();
            pnzRun = ((FilterApplyDialogOptions) screenOptions).getPnzRun();
        }
    }

    @Subscribe("applyButton")
    public void onApplyButtonClick(Button.ClickEvent event) {
        pozRunGlobalFilterConfigurationService.setCurrent(pozRun);
        pnzRunGlobalFilterConfigurationService.setCurrent(pnzRun);
        sessionEventPublisher.publish(new GlobalConfigurationChangedEvent(this));
        closeWithDefaultAction();
    }

    @Subscribe("cancelButton")
    public void onCancelButtonClick(Button.ClickEvent event) {
        closeWithDefaultAction();
    }

}