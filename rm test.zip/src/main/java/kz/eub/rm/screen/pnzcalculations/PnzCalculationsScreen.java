package kz.eub.rm.screen.pnzcalculations;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("rm_PnzCalculationsScreen")
@UiDescriptor("pnz-calculations-screen.xml")
public class PnzCalculationsScreen extends Screen {
}