package kz.eub.rm.screen.consolidateddatapozreport;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.screen.pozuserfriendlyreport.PozUserFriendlyReportScreen;

@UiController("rm_ConsolidatedDataPozReportScreen")
@UiDescriptor("consolidated-data-poz-report-screen.xml")
public class ConsolidatedDataPozReportScreen extends PozUserFriendlyReportScreen {
    @Override
    protected String getReportCode() {
        return "consolidated-data-poz-report";
    }
}