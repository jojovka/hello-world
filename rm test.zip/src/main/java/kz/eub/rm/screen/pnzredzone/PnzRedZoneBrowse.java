package kz.eub.rm.screen.pnzredzone;

import io.jmix.core.DataManager;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.PnzRedZone;
import kz.eub.rm.file.FileDownloadButtonFactory;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreen;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreenOptions;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;
import kz.eub.rm.ui.util.TableUtil;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

@UiController("rm_PnzRedZone.browse")
@UiDescriptor("pnz-red-zone-browse.xml")
@LookupComponent("pnzRedZonesTable")
public class PnzRedZoneBrowse extends StandardLookup<PnzRedZone> {
    @Autowired
    protected FileDownloadButtonFactory fileDownloadButtonFactory;

    @Autowired
    protected UiComponents uiComponents;
    @Autowired
    protected ScreenBuilders screenBuilders;
    @Autowired
    protected DataManager dataManager;

    @Autowired
    protected ButtonsPanel buttonsPanel;
    @Autowired
    protected GroupTable<PnzRedZone> pnzRedZonesTable;
    @Autowired
    protected CollectionLoader<PnzRedZone> pnzRedZonesDl;

    protected Button exportButton;

    @Subscribe
    public void onInit(InitEvent event) {
        setupExportButton();
    }

    private void setupExportButton() {
        exportButton = uiComponents.create(Button.class);
        exportButton.setAction(new BaseAction("download-simple-report").withHandler(actionPerformedEvent -> {
            screenBuilders.screen(this)
                    .withScreenClass(SimpleReportDownloadScreen.class)
                    .withOptions(generateReportDownloadScreenOptions())
                    .withOpenMode(OpenMode.DIALOG).build().show();
        }));
        exportButton.setCaption("Экспорт");
        buttonsPanel.add(exportButton);
    }

    private SimpleReportDownloadScreenOptions<PnzRedZone> generateReportDownloadScreenOptions() {
        List<String> propertiesToRender = TableUtil.getTablePropertiesPaths(pnzRedZonesTable);

        SimpleReportRenderConfiguration renderConfiguration =
                new SimpleReportRenderConfiguration(
                        1000000
                );
        SimpleReportDataConfiguration<PnzRedZone> selectedRowsDataConfiguration = pnzRedZonesTable.getSelected().isEmpty()?
                null:
                new SimpleReportDataConfiguration<>(
                        propertiesToRender,
                        () -> pnzRedZonesTable.getSelected().stream().collect(Collectors.toList())
                );
        SimpleReportDataConfiguration<PnzRedZone> allRowsDataConfiguration =
                new SimpleReportDataConfiguration<>(
                        propertiesToRender,
                        () -> dataManager.load(PnzRedZone.class).query(pnzRedZonesDl.getQuery()).condition(pnzRedZonesDl.getCondition()).parameters(pnzRedZonesDl.getParameters()).list()
                );
        return new SimpleReportDownloadScreenOptions<>(
                PnzRedZone.class,
                renderConfiguration,
                allRowsDataConfiguration,
                selectedRowsDataConfiguration
        );
    }

}