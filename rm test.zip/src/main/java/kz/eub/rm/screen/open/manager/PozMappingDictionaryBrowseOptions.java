package kz.eub.rm.screen.open.manager;

import io.jmix.ui.screen.ScreenOptions;

public class PozMappingDictionaryBrowseOptions implements ScreenOptions {
    private String filterConfiguration;
    public PozMappingDictionaryBrowseOptions(String filterConfiguration) {
        this.filterConfiguration = filterConfiguration;
    }

    public String getFilterConfiguration() {
        return filterConfiguration;
    }
}
