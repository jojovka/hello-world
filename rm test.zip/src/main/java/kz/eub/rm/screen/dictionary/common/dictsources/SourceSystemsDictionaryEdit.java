package kz.eub.rm.screen.dictionary.common.dictsources;

import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.SourceSystemsDictionary;

@UiController("rm_SourceSystemsDictionary.edit")
@UiDescriptor("dict-sources-edit.xml")
@EditedEntityContainer("dictSourcesDc")
public class SourceSystemsDictionaryEdit extends StandardEditor<SourceSystemsDictionary> {
}