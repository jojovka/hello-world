package kz.eub.rm.screen.pnzavgrrreport;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.screen.pnzsegmentchoicereport.PnzSegmentChoiceReportScreen;

@UiController("rm_PnzAvgrrReportScreen")
@UiDescriptor("pnz-avgrr-report-screen.xml")
public class PnzAvgrrReportScreen extends PnzSegmentChoiceReportScreen {
    @Override
    protected String getReportCode() {
        return "pnz-avgrr-report";
    }
}