package kz.eub.rm.screen.constant;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class BasketOptions {
    public static final List<BigDecimal> LIST = new ArrayList<>();
    static {
        LIST.add(BigDecimal.valueOf(2));
        LIST.add(BigDecimal.valueOf(3));
        LIST.add(BigDecimal.valueOf(4));
    }
}
