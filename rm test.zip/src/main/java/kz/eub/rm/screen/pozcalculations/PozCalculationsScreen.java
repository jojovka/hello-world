package kz.eub.rm.screen.pozcalculations;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("rm_PozCalculationsScreen")
@UiDescriptor("poz-calculations-screen.xml")
public class PozCalculationsScreen extends Screen {
}