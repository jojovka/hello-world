package kz.eub.rm.screen.liquiditycoefficientdictionary;

import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.LiquidityCoefficientDictionary;

@UiController("rm_LiquidityCoefficientDictionary.edit")
@UiDescriptor("liquidity-coefficient-dictionary-edit.xml")
@EditedEntityContainer("liquidityCoefficientDictionaryDc")
public class LiquidityCoefficientDictionaryEdit extends StandardEditor<LiquidityCoefficientDictionary> {
}