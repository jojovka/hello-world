package kz.eub.rm.screen.fixprovisionproduct;

import io.jmix.ui.component.CheckBox;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.FixProvisionProduct;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@UiController("rm_FixProvisionProduct.edit")
@UiDescriptor("fix-provision-product-edit.xml")
@EditedEntityContainer("fixProvisionProductDc")
public class FixProvisionProductEdit extends StandardEditor<FixProvisionProduct> {
    @Autowired
    private ComboBox<Integer> fppBasketComboBox;
    @Autowired
    private CheckBox fppIsActualField;

    @Subscribe
    public void onInit(final InitEvent event) {
        fppBasketComboBox.setOptionsList(new ArrayList<>(Arrays.asList(1,2,3,4)));
    }

    @Subscribe
    public void onBeforeCommitChanges(final BeforeCommitChangesEvent event) {
        if (!fppIsActualField.getValue()){
            getEditedEntity().setFppIsActual(false);
        }
    }



}