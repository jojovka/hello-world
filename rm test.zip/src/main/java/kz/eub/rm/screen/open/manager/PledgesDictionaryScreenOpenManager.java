package kz.eub.rm.screen.open.manager;

import io.jmix.ui.AppUI;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.screen.OpenMode;
import io.jmix.ui.screen.Screen;
import kz.eub.rm.entity.RunHistory;
import kz.eub.rm.screen.dictionary.credit.pledgesdictionary.PledgesDictionaryBrowse;
import kz.eub.rm.service.RunHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("rm_PledgesDictionaryScreenOpenManager")
public class PledgesDictionaryScreenOpenManager {
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    @Qualifier("rm_PozRunHistoryService")
    private RunHistoryService<RunHistory> runHistoryService;

    public void openBrowseScreen() {
        String idOfLatestRun = runHistoryService.getIdOfLatestRun();
        final Screen ownerFrame = AppUI.getCurrent().getTopLevelWindowNN().getFrameOwner();
        screenBuilders.screen(ownerFrame)
                .withScreenClass(PledgesDictionaryBrowse.class)
                .withOptions(new PledgesDictionaryBrowseOptions(idOfLatestRun))
                .withOpenMode(OpenMode.NEW_TAB)
                .build()
                .show();
    }
}
