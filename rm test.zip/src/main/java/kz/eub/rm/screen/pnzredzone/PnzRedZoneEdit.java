package kz.eub.rm.screen.pnzredzone;

import io.jmix.ui.screen.*;
import kz.eub.rm.entity.PnzRedZone;

@UiController("rm_PnzRedZone.edit")
@UiDescriptor("pnz-red-zone-edit.xml")
@EditedEntityContainer("pnzRedZoneDc")
public class PnzRedZoneEdit extends StandardEditor<PnzRedZone> {
}