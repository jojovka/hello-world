package kz.eub.rm.screen.dictionary.snp.pozdictionary;

import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.PozDictionary;

@UiController("rm_PozDictionary.edit")
@UiDescriptor("poz-dictionary-edit.xml")
@EditedEntityContainer("pozDictionaryDc")
public class PozDictionaryEdit extends StandardEditor<PozDictionary> {
}