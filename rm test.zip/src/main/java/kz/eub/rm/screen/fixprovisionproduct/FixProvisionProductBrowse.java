package kz.eub.rm.screen.fixprovisionproduct;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.Table;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.FixProvisionProduct;
import kz.eub.rm.entity.dwh.CreditContractsDictionary;
import kz.eub.rm.entity.dwh.SourceSystemsDictionary;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreen;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreenOptions;
import kz.eub.rm.simple.report.PropertiesToRender;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;
import kz.eub.rm.ui.util.TableUtil;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

@UiController("rm_FixProvisionProduct.browse")
@UiDescriptor("fix-provision-product-browse.xml")
@LookupComponent("fixProvisionProductsTable")
public class FixProvisionProductBrowse extends StandardLookup<FixProvisionProduct> {
    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private Table<FixProvisionProduct> fixProvisionProductsTable;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private FetchPlans fetchPlans;

    @Subscribe
    public void onInit(final InitEvent event) {
        setupDownloadReportButton();
    }

    public void setupDownloadReportButton() {
        Button button = uiComponents.create(Button.class);
        button.setCaption("Выгрузить");
        button.setAction(new BaseAction("download-simple-report").withHandler((actionPerformedEvent)->{
            SimpleReportDownloadScreenOptions<FixProvisionProduct> screenOptions = generateReportDownloadScreenOptions();
            screenBuilders.screen(this)
                    .withOptions(screenOptions)
                    .withScreenClass(SimpleReportDownloadScreen.class)
                    .withOpenMode(OpenMode.DIALOG)
                    .build()
                    .show();
        }));
        buttonsPanel.add(button);
    }

    private SimpleReportDownloadScreenOptions<FixProvisionProduct> generateReportDownloadScreenOptions() {
        List<String> propertiesToRender = TableUtil.getTablePropertiesPaths(fixProvisionProductsTable);

        SimpleReportRenderConfiguration renderConfiguration =
                new SimpleReportRenderConfiguration(
                        1000000
                );
        SimpleReportDataConfiguration<FixProvisionProduct> selectedRowsDataConfiguration = fixProvisionProductsTable.getSelected().isEmpty()?
                null:
                new SimpleReportDataConfiguration<>(
                        propertiesToRender,
                        () -> fixProvisionProductsTable.getSelected().stream().collect(Collectors.toList())
                );
        SimpleReportDataConfiguration<FixProvisionProduct> allRowsDataConfiguration =
                new SimpleReportDataConfiguration<>(
                        propertiesToRender,
                        () -> dataManager
                                .load(FixProvisionProduct.class)
                                .query("select p from rm_FixProvisionProduct p")
                                .fetchPlan(
                                        fetchPlans
                                                .builder(FixProvisionProduct.class)
                                                .addFetchPlan(FetchPlan.BASE)
                                                .build())
                                .list()
                );
        return new SimpleReportDownloadScreenOptions<>(
                FixProvisionProduct.class,
                renderConfiguration,
                allRowsDataConfiguration,
                selectedRowsDataConfiguration
        );
    }


}