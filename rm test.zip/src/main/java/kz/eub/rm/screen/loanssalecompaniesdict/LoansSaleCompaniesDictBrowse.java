package kz.eub.rm.screen.loanssalecompaniesdict;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.Table;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.LoansSaleCompaniesDict;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreen;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreenOptions;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;
import kz.eub.rm.ui.util.TableUtil;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

@UiController("rm_LoansSaleCompaniesDict.browse")
@UiDescriptor("loans-sale-companies-dict-browse.xml")
@LookupComponent("loansSaleCompaniesDictsTable")
public class LoansSaleCompaniesDictBrowse extends StandardLookup<LoansSaleCompaniesDict> {
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private Table<LoansSaleCompaniesDict> loansSaleCompaniesDictsTable;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private FetchPlans fetchPlans;

    @Subscribe
    public void onInit(final InitEvent event) {
        setupDownloadReportButton();
    }

    public void setupDownloadReportButton() {
        Button button = uiComponents.create(Button.class);
        button.setCaption("Выгрузить");
        button.setAction(new BaseAction("download-simple-report").withHandler((actionPerformedEvent)->{
            SimpleReportDownloadScreenOptions<LoansSaleCompaniesDict> screenOptions = generateReportDownloadScreenOptions();
            screenBuilders.screen(this)
                    .withOptions(screenOptions)
                    .withScreenClass(SimpleReportDownloadScreen.class)
                    .withOpenMode(OpenMode.DIALOG)
                    .build()
                    .show();
        }));
        buttonsPanel.add(button);
    }

    private SimpleReportDownloadScreenOptions<LoansSaleCompaniesDict> generateReportDownloadScreenOptions() {
        List<String> propertiesToRender = TableUtil.getTablePropertiesPaths(loansSaleCompaniesDictsTable);

        SimpleReportRenderConfiguration renderConfiguration =
                new SimpleReportRenderConfiguration(
                        1000000
                );
        SimpleReportDataConfiguration<LoansSaleCompaniesDict> selectedRowsDataConfiguration = loansSaleCompaniesDictsTable.getSelected().isEmpty()?
                null:
                new SimpleReportDataConfiguration<>(
                        propertiesToRender,
                        () -> loansSaleCompaniesDictsTable.getSelected().stream().collect(Collectors.toList())
                );
        SimpleReportDataConfiguration<LoansSaleCompaniesDict> allRowsDataConfiguration =
                new SimpleReportDataConfiguration<>(
                        propertiesToRender,
                        () -> dataManager
                                .load(LoansSaleCompaniesDict.class)
                                .query("select p from rm_LoansSaleCompaniesDict p")
                                .fetchPlan(
                                        fetchPlans
                                                .builder(LoansSaleCompaniesDict.class)
                                                .addFetchPlan(FetchPlan.BASE)
                                                .build())
                                .list()
                );
        return new SimpleReportDownloadScreenOptions<>(
                LoansSaleCompaniesDict.class,
                renderConfiguration,
                allRowsDataConfiguration,
                selectedRowsDataConfiguration
        );
    }

}