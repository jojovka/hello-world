package kz.eub.rm.screen.dictionary.snp.pozmappingdictionary;

import io.jmix.ui.component.*;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.PozMappingDictionary;
import kz.eub.rm.entity.dwh.ProductReferenceDictionary;

@UiController("rm_PozMapping.edit")
@UiDescriptor("poz-mapping-dictionary-edit.xml")
@EditedEntityContainer("pozMappingDictionaryDc")
public class PozMappingDictionaryEdit extends StandardEditor<PozMappingDictionary> {
    @Subscribe("prodNameField")
    public void onProdNameFieldValueChange(HasValue.ValueChangeEvent<ProductReferenceDictionary> event) {
        ProductReferenceDictionary value = event.getValue();
        getEditedEntity().setProdName(value.getName());
    }

}