package kz.eub.rm.screen.dictionary.snp.exceptionalpozproductsdictionary;

import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.ExceptionalPozProductsDictionary;

@UiController("rm_ExceptionalPozProductsDictionary.edit")
@UiDescriptor("exceptional-poz-products-dictionary-edit.xml")
@EditedEntityContainer("exceptionalPozProductsDictionaryDc")
public class ExceptionalPozProductsDictionaryEdit extends StandardEditor<ExceptionalPozProductsDictionary> {
}