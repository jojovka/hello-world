package kz.eub.rm.screen.pozruncalculationfragment;

import io.jmix.ui.component.CheckBox;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.screen.runcalculationfragment.RunCalculationFragment;
import kz.eub.rm.service.calculation.PozCalculationService;
import kz.eub.rm.service.dto.CalculationLaunchResult;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

@UiController("rm_PozRunCalculationFragment")
@UiDescriptor("poz-run-calculation-fragment.xml")
public class PozRunCalculationFragment extends RunCalculationFragment {
    @Autowired
    protected CheckBox needReloadCreditPortfolioCheckBox;

    @Autowired
    protected PozCalculationService calculationService;

    @Override
    protected CalculationLaunchResult prepareCalculationResult() {
        return calculationService.runCalculation(
                datePickerField.getValue(),
                () -> {
                    List<Object> additionalParameters = new ArrayList<>();
                    additionalParameters.add(needReloadCreditPortfolioCheckBox.isChecked());
                    return additionalParameters;
                });
    }
}