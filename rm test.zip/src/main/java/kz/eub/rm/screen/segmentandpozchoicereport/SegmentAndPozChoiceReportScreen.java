package kz.eub.rm.screen.segmentandpozchoicereport;

import io.jmix.ui.Notifications;
import io.jmix.ui.UiComponents;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.EntitySuggestionField;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.screen.Install;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.entity.dwh.PozDictionary;
import kz.eub.rm.entity.dwh.PozSegmentationDictionary;
import kz.eub.rm.file.FileGenerationButtonFactory;
import kz.eub.rm.file.MultipleReportsGenerationButtonConfiguration;
import kz.eub.rm.screen.pozsegmentchoicereport.PozSegmentChoiceReportScreen;
import kz.eub.rm.service.PozRunGlobalFilterConfigurationService;
import kz.eub.rm.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/*
 * добавляет еще один таб с полем выбора ПОЗ и кнопку генерации архива отчетов
 * добавляет в экшен отчета делегат-генератор параметров
 * сгенерированные параметры отчетов будут: runid и segment
 * runid во всех отчетах будет одинаковый(текущий глобальный runid для ПОЗ)
 * segment для каждого отчета будет уникальный (один из сегментов в выбранном ПОЗ)
 * кол-во отчетов будет равно кол-ву сегментов в выбранном ПОЗ
 */
@UiController("rm_PozSegmentChoiceReportScreen")
@UiDescriptor("segment-and-poz-choice-report-screen.xml")
public abstract class SegmentAndPozChoiceReportScreen extends PozSegmentChoiceReportScreen {
    protected Button pozReportsGenerationButton;

    @Autowired
    protected ButtonsPanel pozButtonsPanel;
    @Autowired
    protected EntitySuggestionField<PozDictionary> pozSuggestionField;

    @Autowired
    protected Notifications notifications;

    @Autowired
    protected UserService userService;
    @Autowired
    protected FileGenerationButtonFactory fileGenerationButtonFactory;
    @Autowired
    protected PozRunGlobalFilterConfigurationService pozRunGlobalFilterConfigurationService;

    @Subscribe
    public void onInit_segmentAndPozChoiceReportScreen(InitEvent event) {
        setupPozReportsGenerationButton();
    }

    @Subscribe("pozSuggestionField")
    public void onPozSuggestionFieldValueChange(HasValue.ValueChangeEvent<PozDictionary> event) {
        togglePozReportsGenerationButton(event.getValue()!=null);
    }

    private void togglePozReportsGenerationButton(boolean isEnabled) {
        pozReportsGenerationButton.setEnabled(isEnabled);
    }

    protected void setupPozReportsGenerationButton () {
        pozReportsGenerationButton = fileGenerationButtonFactory.createMultipleReportsZipGenerationButton(buildMultipleReportsZipGenerationButtonConfiguration());
        pozReportsGenerationButton.setEnabled(false);

        pozButtonsPanel.add(pozReportsGenerationButton);
    }

    protected MultipleReportsGenerationButtonConfiguration buildMultipleReportsZipGenerationButtonConfiguration() {
        return MultipleReportsGenerationButtonConfiguration
                .builder(notifications, getReportCode())
                .onClickParametersAdjustmentDelegate(this::generationButtonOnClickParametersAdjustmentDelegate)
                .blockingValueSupplier(() -> getReportCode().concat(pozSuggestionField.getValue().getPozName()))
                .build();
    }

    protected List<Map<String, Object>> generationButtonOnClickParametersAdjustmentDelegate() {
        List<Map<String, Object>> parametersMaps = new ArrayList<>();
        List<PozSegmentationDictionary> segments = dataManager
                .load(PozSegmentationDictionary.class)
                .query("select e from rm_PozSegmentationDictionary e where e.pozId.id=:pozId")
                .parameter("pozId", pozSuggestionField.getValue().getId())
                .list();
        for (PozSegmentationDictionary pozSegment: segments) {
            Map<String, Object> parameters = new HashMap<>();

            parameters.put("runid", pozRunGlobalFilterConfigurationService.getCurrent().getRunId());
            parameters.put("segment", pozSegment.getSegment());

            parametersMaps.add(parameters);
        }
        return parametersMaps;
    }

    @Install(to = "pozSuggestionField", subject = "searchExecutor")
    private List<PozDictionary> pozSuggestionFieldSearchExecutor(String searchString, Map<String, Object> searchParams) {
        return dataManager.load(PozDictionary.class)
                .query("select c from rm_PozDictionary c where lower(c.pozName) like lower(:searchString) escape '\\'")
                .parameter("searchString", "%"+searchString+"%").list()
                .stream()
                .distinct()
                .collect(Collectors.toList());
    }
}