package kz.eub.rm.screen.triggersreport;

import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.screen.pozuserfriendlyreport.PozUserFriendlyReportScreen;

@UiController("rm_TriggersReportScreen")
@UiDescriptor("triggers-report-screen.xml")
public class TriggersReportScreen extends PozUserFriendlyReportScreen {
    @Override
    protected String getReportCode() {
        return "triggers-report";
    }
}