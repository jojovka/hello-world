package kz.eub.rm.screen.portfolioreservepercentagereport;

import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.screen.pozuserfriendlyreport.PozUserFriendlyReportScreen;

@UiController("rm_PortfolioReservePercentageReportScreen")
@UiDescriptor("portfolio-reserve-percentage-report-screen.xml")
public class PortfolioReservePercentageReportScreen extends PozUserFriendlyReportScreen {
    @Override
    protected String getReportCode() {
        return "portfolio-reserve-percentage-report";
    }
}