package kz.eub.rm.screen.pnzpdhistory;

import io.jmix.core.DataManager;
import io.jmix.reportsui.runner.UiReportRunner;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.Table;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.PnzPdHistory;
import kz.eub.rm.file.FileDownloadButtonAppearance;
import kz.eub.rm.file.FileDownloadButtonFactory;
import kz.eub.rm.file.ReportDownloadButtonConfiguration;
import kz.eub.rm.screen.pddrcalculation.PdDrCalculationScreen;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreen;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreenOptions;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;
import kz.eub.rm.ui.util.TableUtil;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

@UiController("rm_PnzPdHistory.browse")
@UiDescriptor("pnz-pd-history-browse.xml")
@LookupComponent("pnzPdHistoriesTable")
public class PnzPdHistoryBrowse extends StandardLookup<PnzPdHistory> {
    @Autowired
    protected FileDownloadButtonFactory fileDownloadButtonFactory;

    @Autowired
    protected UiReportRunner uiReportRunner;
    @Autowired
    protected ScreenBuilders screenBuilders;
    @Autowired
    protected UiComponents uiComponents;
    @Autowired
    protected DataManager dataManager;

    protected Button downloadReportButton;
    protected Button showCalculationRunDialogButton;
    protected Button exportButton;

    @Autowired
    protected ButtonsPanel buttonsPanel;
    @Autowired
    protected GroupTable<PnzPdHistory> pnzPdHistoriesTable;
    @Autowired
    protected CollectionLoader<PnzPdHistory> pnzPdHistoriesDl;

    @Subscribe
    public void onInit(InitEvent event) {
        setupDownloadReportButton();
        setupRunCalculationButton();
        setupExportButton();
    }

    protected void setupDownloadReportButton() {
        downloadReportButton = fileDownloadButtonFactory.createForReport(
                ReportDownloadButtonConfiguration.builder(uiReportRunner, "pd-pnz-report")
                        .onClickParametersAdjustmentDelegate(
                                (parameters) -> {
                                    parameters.put("report_id", pnzPdHistoriesTable.getSingleSelected().getReportId());
                                }
                        )
                        .fileDownloadButtonAppearance(FileDownloadButtonAppearance.REPORT_FILE)
                        .build()
        );

        downloadReportButton.setEnabled(false);

        buttonsPanel.add(downloadReportButton);
    }

    protected void setupRunCalculationButton() {
        showCalculationRunDialogButton = uiComponents.create(Button.class);
        showCalculationRunDialogButton.setCaption("Новый расчет");
        showCalculationRunDialogButton.setAction(new BaseAction("show-calculation-run-screen").withHandler(actionPerformedEvent -> {
            screenBuilders.screen(this).withScreenClass(PdDrCalculationScreen.class).withOpenMode(OpenMode.DIALOG).build().show();
        }));
        buttonsPanel.add(showCalculationRunDialogButton);
    }

    @Subscribe("pnzPdHistoriesTable")
    public void onPnzPdHistoriesTableSelection(Table.SelectionEvent<PnzPdHistory> event) {
        toggleDownloadReportButton();
    }

    protected void toggleDownloadReportButton() {
        downloadReportButton.setEnabled(pnzPdHistoriesTable.getSingleSelected()!=null);
    }

    private void setupExportButton() {
        exportButton = uiComponents.create(Button.class);
        exportButton.setAction(new BaseAction("download-simple-report").withHandler(actionPerformedEvent -> {
            screenBuilders.screen(this)
                    .withScreenClass(SimpleReportDownloadScreen.class)
                    .withOptions(generateReportDownloadScreenOptions())
                    .withOpenMode(OpenMode.DIALOG).build().show();
        }));
        exportButton.setCaption("Экспорт");
        buttonsPanel.add(exportButton);
    }

    private SimpleReportDownloadScreenOptions<PnzPdHistory> generateReportDownloadScreenOptions() {
        List<String> propertiesToRender = TableUtil.getTablePropertiesPaths(pnzPdHistoriesTable);

        SimpleReportRenderConfiguration renderConfiguration =
                new SimpleReportRenderConfiguration(
                        1000000
                );
        SimpleReportDataConfiguration<PnzPdHistory> selectedRowsDataConfiguration = pnzPdHistoriesTable.getSelected().isEmpty()?
                null:
                new SimpleReportDataConfiguration<>(
                        propertiesToRender,
                        () -> pnzPdHistoriesTable.getSelected().stream().collect(Collectors.toList())
                );
        SimpleReportDataConfiguration<PnzPdHistory> allRowsDataConfiguration =
                new SimpleReportDataConfiguration<>(
                        propertiesToRender,
                        () -> dataManager.load(PnzPdHistory.class).query(pnzPdHistoriesDl.getQuery()).condition(pnzPdHistoriesDl.getCondition()).parameters(pnzPdHistoriesDl.getParameters()).list()
                );
        return new SimpleReportDownloadScreenOptions<>(
                PnzPdHistory.class,
                renderConfiguration,
                allRowsDataConfiguration,
                selectedRowsDataConfiguration
        );
    }



}