package kz.eub.rm.screen.pnzsegmentchoicereport;

import io.jmix.core.DataManager;
import io.jmix.ui.component.EntitySuggestionField;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.entity.dwh.PnzMacroAdjustmentDictionary;
import kz.eub.rm.entity.dwh.PozSegmentationDictionary;
import kz.eub.rm.screen.pnzuserfriendlyreport.PnzUserFriendlyReportScreen;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@UiController("rm_PnzSegmentChoiceReportScreen")
@UiDescriptor("pnz-segment-choice-report-screen.xml")
public abstract class PnzSegmentChoiceReportScreen extends PnzUserFriendlyReportScreen {
    @Autowired
    protected EntitySuggestionField<PnzMacroAdjustmentDictionary> segmentSuggestionField;
    @Autowired
    protected DataManager dataManager;

    @Subscribe
    public void onInit(final InitEvent event) {
        segmentSuggestionField.setSearchExecutor(this::segmentSuggestionFieldSearchExecutor);
    }

    @Override
    protected void adjustReportParameters(Map<String, Object> map) {
        super.adjustReportParameters(map);
        map.put("segment",segmentSuggestionField.getValue().getSegmentName());
    }

    @Override
    protected void toggleDownloadReportButton() {
        downloadReportButton.setEnabled((runId != null)&&(segmentSuggestionField.getValue()!=null));
    }

    @Subscribe("segmentSuggestionField")
    public void onSegmentEntityPickerValueChange(HasValue.ValueChangeEvent<PnzMacroAdjustmentDictionary> event) {
        toggleDownloadReportButton();
    }

    private List<PnzMacroAdjustmentDictionary> segmentSuggestionFieldSearchExecutor(String searchString, Map<String, Object> searchParams) {
        return dataManager.load(PnzMacroAdjustmentDictionary.class)
                .query("select c from rm_PnzMacroAdjustmentDictionary c where lower(c.segmentName) like lower(:searchString) escape '\\'")
                .parameter("searchString", "%"+searchString+"%").list()
                .stream()
                .distinct()
                .collect(Collectors.toList());
    }
}