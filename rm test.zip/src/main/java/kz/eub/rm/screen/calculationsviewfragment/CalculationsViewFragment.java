package kz.eub.rm.screen.calculationsviewfragment;

import io.jmix.ui.component.Button;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.Table;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.ScreenFragment;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("rm_CalculationsViewFragment")
@UiDescriptor("calculations-view-fragment.xml")
public abstract class CalculationsViewFragment<T> extends ScreenFragment {
    @Autowired
    protected CollectionLoader<T> runHistoryDl;
    @Autowired
    protected Button approveCalculationButton;
    @Autowired
    protected GroupTable<T> runHistoryTable;

    @Subscribe
    public void onInit(InitEvent event) {
        runHistoryDl.load();
    }

    @Subscribe("approveCalculationButton")
    public void onApproveCalculationButtonClick(Button.ClickEvent event) {
        handleApproveCalculationButtonClick(event);
    }

    @Subscribe("runHistoryTable")
    public void onRunHistoryTableSelection(Table.SelectionEvent<T> event) {
        handleRunHistoryTableSelection(event);
    }

    protected abstract void handleApproveCalculationButtonClick(Button.ClickEvent event);

    protected abstract void handleRunHistoryTableSelection(Table.SelectionEvent<T> event);

}