package kz.eub.rm.screen.bpm.customtask;

import com.google.common.base.Strings;
import io.jmix.bpm.data.form.FormData;
import io.jmix.bpm.data.form.FormField;
import io.jmix.bpm.processform.ProcessFormDataExtractor;
import io.jmix.bpmui.processform.ProcessFormScreens;
import io.jmix.bpmui.screen.dynamicform.DynamicProcessForm;
import io.jmix.bpmui.uicomponent.outcomespanel.OutcomesPanel;
import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.Component;
import io.jmix.ui.component.ComponentsHelper;
import io.jmix.ui.component.Form;
import io.jmix.ui.component.TextArea;
import io.jmix.ui.component.ValidationErrors;
import io.jmix.ui.screen.ScreenValidation;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import org.flowable.engine.TaskService;
import org.flowable.task.api.Task;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@UiController("rm_CustomTaskScreen")
@UiDescriptor("custom-task-screen.xml")
public class CustomTaskScreen extends DynamicProcessForm {

    public static final String FORM_FIELD_TYPE_STRING = "string";                       // createTextFieldString(formField);
    public static final String FORM_FIELD_TYPE_MULTILINE_STRING = "multilineString";    // createTextArea(formField);
    public static final String FORM_FIELD_TYPE_LONG = "long";                           // createTextFieldLong(formField);
    public static final String FORM_FIELD_TYPE_DOUBLE = "double";                       // createTextFieldDouble(formField);
    public static final String FORM_FIELD_TYPE_DATE = "date";                           // createDateField(formField, DateField.TYPE_DATE, DateField.Resolution.DAY);
    public static final String FORM_FIELD_TYPE_DATE_TIME = "dateTime";                  // createDateField(formField, DateField.TYPE_DATE, DateField.Resolution.MIN);
    public static final String FORM_FIELD_TYPE_LOCAL_DATE = "localdate";                // createDateField(formField, DateField.TYPE_LOCALDATE, DateField.Resolution.DAY);
    public static final String FORM_FIELD_TYPE_LOCAL_DATE_TIME = "localdatetime";       // createDateField(formField, DateField.TYPE_LOCALDATETIME, DateField.Resolution.MIN);
    public static final String FORM_FIELD_TYPE_BIG_DECIMAL = "bigDecimal";              // createTextFieldBigDecimal(formField);
    public static final String FORM_FIELD_TYPE_BOOLEAN = "boolean";                     // createBooleanField(formField);
    public static final String FORM_FIELD_TYPE_ENTITY = "entity";                       // createEntityField(formField);
    public static final String FORM_FIELD_TYPE_ENTITY_LIST = "entity-list";             // createEntityListField(formField);
    public static final String FORM_FIELD_TYPE_FILE = "file-description";               // createFileField(formField);
    public static final String FORM_FIELD_TYPE_ENUM = "enum";                           // createEnumField(formField);
    public static final String FORM_FIELD_TYPE_PLATFORM_ENUM = "platformEnum";          // createPlatformEnumField(formField);


    @Autowired
    private ProcessFormScreens processFormScreens;
    @Autowired
    private ProcessFormDataExtractor processFormDataExtractor;
    @Autowired
    protected Form form;
    @Autowired
    protected OutcomesPanel outcomesPanel;
    @Autowired
    protected TaskService taskService;
    @Autowired
    private CurrentUserSubstitution currentUserSubstitution;
    @Autowired
    private ScreenValidation screenValidation;
    @Autowired
    private Button claimAndResumeBtn;
    @Autowired
    private Button claimAndCloseBtn;


    protected Task task;
    protected FormData formData;
    protected String commentFieldId;


    public void setTask(Task task) {
        this.task = task;
        formData = processFormDataExtractor.getTaskFormData(task.getId());

        FormField commentField = new FormField();
        commentField.setCaption("Комментарий");
        commentFieldId = task.getTaskDefinitionKey() + "_" + task.getExecutionId() + "_comment";
        commentField.setId(commentFieldId);
        commentField.setEditable(true);
        commentField.setRequired(false);  // TODO get commentRequired field from taskData
        commentField.setType(FORM_FIELD_TYPE_MULTILINE_STRING);
        formData.getFields().add(commentField);

        if (formData != null) {
            initForm(form, formData);
        }

        if (!Strings.isNullOrEmpty(task.getAssignee())) {
            initOutcomesPanel(task, formData);
            claimAndResumeBtn.setVisible(false);
            claimAndCloseBtn.setVisible(false);
        } else {
            form.setEditable(false);
            outcomesPanel.setVisible(false);
        }
        getWindow().setCaption(Strings.isNullOrEmpty(task.getName()) ? task.getTaskDefinitionKey() : task.getName());
    }

    protected void initOutcomesPanel(Task task, @Nullable FormData formData) {
        outcomesPanel.createLayout(task, formData != null ? formData.getOutcomes() : new ArrayList<>());
        outcomesPanel.setProcessVariablesSupplier(() -> collectProcessVariables(formData));
        outcomesPanel.setBeforeTaskCompletedPredicate(outcome -> {
            TextArea commentField = getCommentField();
            if (outcome != null && (
                    outcome.getId().toLowerCase().trim().equals("reject")
                            || outcome.getId().toLowerCase().trim().equals("refuse")
                            || outcome.getId().toLowerCase().trim().equals("adjust")
                            || outcome.getId().toLowerCase().trim().equals("adjustment")
                            || outcome.getId().toLowerCase().trim().equals("rework")
                            || outcome.getId().toLowerCase().trim().equals("cancel")
                            || outcome.getId().toLowerCase().trim().equals("decline")
                            || outcome.getId().toLowerCase().trim().equals("negative"))) {
                commentField.setRequired(true);
            } else {
                commentField.setRequired(false);
            }
            ValidationErrors validationErrors = screenValidation.validateUiComponents(ComponentsHelper.getComponents(getWindow()));
            if (!validationErrors.isEmpty()) {
                screenValidation.showValidationErrors(this, validationErrors);
                return false;
            }
            saveTaskComment();
            return true;
        });
        outcomesPanel.setAfterTaskCompletedHandler(outcome -> close(WINDOW_COMMIT_AND_CLOSE_ACTION));
    }

    private TextArea getCommentField() {
//        TextArea commentFld = (TextArea) ComponentsHelper.getComponent(getWindow(), commentFieldId);
        List<Component> commentFields = getWindow().getComponents()
                .stream().filter(c -> c instanceof TextArea).collect(Collectors.toList());
//        return (TextArea) commentFields
//                .stream().filter(f -> Objects.equals(f.getId(), commentFieldId))
//                .findFirst().orElse(null);
        return commentFields.size() > 0 ? (TextArea) commentFields.get(commentFields.size()-1) : null;
    }

    private void saveTaskComment() {
        TextArea commentField = getCommentField();
        if (commentField == null)
            return;
        String comment = (String) commentField.getValue();
        if (comment == null
                || comment.trim().length() == 0)
            return;
        taskService.addComment(task.getId(), task.getProcessInstanceId(), comment);
    }

    @Subscribe("claimAndResumeBtn")
    protected void onClaimAndResumeBtnClick(Button.ClickEvent event) {
        taskService.claim(task.getId(), currentUserSubstitution.getEffectiveUser().getUsername());
        close(WINDOW_COMMIT_AND_CLOSE_ACTION);
        Task reloadedTask = taskService.createTaskQuery().taskId(this.task.getId()).singleResult();
        processFormScreens.createTaskProcessForm(reloadedTask, this)
                .show();
    }

    @Subscribe("claimAndCloseBtn")
    protected void onClaimAndCloseBtnClick(Button.ClickEvent event) {
        taskService.claim(task.getId(), currentUserSubstitution.getEffectiveUser().getUsername());
        close(WINDOW_COMMIT_AND_CLOSE_ACTION);
    }

}