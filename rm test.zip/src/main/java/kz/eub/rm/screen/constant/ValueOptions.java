package kz.eub.rm.screen.constant;

import java.util.ArrayList;
import java.util.List;

public class ValueOptions {
    public static final List<String> LIST = new ArrayList<>();
    static {
        LIST.add("Оздоровление");
        LIST.add("Дефолт");
        LIST.add("Полное оздоровление");
    }
}
