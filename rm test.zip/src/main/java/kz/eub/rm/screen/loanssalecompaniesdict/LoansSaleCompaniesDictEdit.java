package kz.eub.rm.screen.loanssalecompaniesdict;

import io.jmix.ui.component.CheckBox;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.LoansSaleCompaniesDict;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("rm_LoansSaleCompaniesDict.edit")
@UiDescriptor("loans-sale-companies-dict-edit.xml")
@EditedEntityContainer("loansSaleCompaniesDictDc")
public class LoansSaleCompaniesDictEdit extends StandardEditor<LoansSaleCompaniesDict> {
    @Autowired
    private CheckBox lscdIsActualField;

    @Subscribe
    public void onBeforeCommitChanges(final BeforeCommitChangesEvent event) {
        if (!lscdIsActualField.getValue()){
            getEditedEntity().setLscdIsActual(false);
        }
    }

}