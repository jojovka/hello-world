package kz.eub.rm.screen.open.manager;

import io.jmix.ui.screen.ScreenOptions;

public class PledgesDictionaryBrowseOptions implements ScreenOptions {
    private String idOfLatestRun;

    public PledgesDictionaryBrowseOptions(String idOfLatestRun) {
        this.idOfLatestRun = idOfLatestRun;
    }

    public String getIdOfLatestRun() {
        return idOfLatestRun;
    }

    public void setIdOfLatestRun(String idOfLatestRun) {
        this.idOfLatestRun = idOfLatestRun;
    }
}
