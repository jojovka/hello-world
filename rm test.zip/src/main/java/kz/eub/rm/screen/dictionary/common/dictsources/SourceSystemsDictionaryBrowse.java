package kz.eub.rm.screen.dictionary.common.dictsources;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.SourceSystemsDictionary;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreen;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreenOptions;
import kz.eub.rm.simple.report.PropertiesToRender;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.stream.Collectors;

@UiController("rm_SourceSystemsDictionary.browse")
@UiDescriptor("dict-sources-browse.xml")
@LookupComponent("dictSourcesTable")
public class SourceSystemsDictionaryBrowse extends StandardLookup<SourceSystemsDictionary> {
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private GroupTable<SourceSystemsDictionary> dictSourcesTable;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private FetchPlans fetchPlans;

    @Subscribe
    public void onInit(InitEvent event) {
        setupDownloadReportButton();
    }

    public void setupDownloadReportButton() {
        Button button = uiComponents.create(Button.class);
        button.setCaption("Выгрузить");
        button.setAction(new BaseAction("download-simple-report").withHandler((actionPerformedEvent)->{
            SimpleReportDownloadScreenOptions<SourceSystemsDictionary> screenOptions = generateReportDownloadScreenOptions();
            screenBuilders.screen(this)
                    .withOptions(screenOptions)
                    .withScreenClass(SimpleReportDownloadScreen.class)
                    .withOpenMode(OpenMode.DIALOG)
                    .build()
                    .show();
        }));
        buttonsPanel.add(button);
    }

    private SimpleReportDownloadScreenOptions<SourceSystemsDictionary> generateReportDownloadScreenOptions() {
        SimpleReportRenderConfiguration renderConfiguration =
                new SimpleReportRenderConfiguration(
                        1000000
                );
        SimpleReportDataConfiguration<SourceSystemsDictionary> selectedRowsDataConfiguration = dictSourcesTable.getSelected().isEmpty()?
                null:
                new SimpleReportDataConfiguration<>(
                        PropertiesToRender.SOURCE_SYSTEMS_DICTIONARY_PROPERTIES,
                        () -> dictSourcesTable.getSelected().stream().collect(Collectors.toList())
                );
        SimpleReportDataConfiguration<SourceSystemsDictionary> allRowsDataConfiguration =
                new SimpleReportDataConfiguration<>(
                        PropertiesToRender.SOURCE_SYSTEMS_DICTIONARY_PROPERTIES,
                        () -> dataManager
                                .load(SourceSystemsDictionary.class)
                                .query("select p from rm_SourceSystemsDictionary p")
                                .fetchPlan(
                                        fetchPlans
                                                .builder(SourceSystemsDictionary.class)
                                                .addFetchPlan(FetchPlan.BASE)
                                                .build())
                                .list()
                );
        return new SimpleReportDownloadScreenOptions<>(
                SourceSystemsDictionary.class,
                renderConfiguration,
                allRowsDataConfiguration,
                selectedRowsDataConfiguration
        );
    }
}