package kz.eub.rm.screen.liquiditycoefficientdictionary;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.LiquidityCoefficientDictionary;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreen;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreenOptions;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.stream.Collectors;

import static kz.eub.rm.simple.report.PropertiesToRender.LIQUIDITY_COEFFICIENT_DICTIONARY_PROPERTIES;

@UiController("rm_LiquidityCoefficientDictionary.browse")
@UiDescriptor("liquidity-coefficient-dictionary-browse.xml")
@LookupComponent("liquidityCoefficientDictionaryTable")
public class LiquidityCoefficientDictionaryBrowse extends StandardLookup<LiquidityCoefficientDictionary> {
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private FetchPlans fetchPlans;

    @Autowired
    private GroupTable<LiquidityCoefficientDictionary> liquidityCoefficientDictionaryTable;

    @Subscribe
    public void onInit(InitEvent event) {
        setupDownloadReportButton();
    }

    public void setupDownloadReportButton(){
        Button button = uiComponents.create(Button.class);
        button.setCaption("Выгрузить");
        button.setAction(new BaseAction("download-simple-report").withHandler((actionPerformedEvent)->{
            SimpleReportDownloadScreenOptions<LiquidityCoefficientDictionary> screenOptions = generateReportDownloadScreenOptions();
            screenBuilders.screen(this)
                    .withOptions(screenOptions)
                    .withScreenClass(SimpleReportDownloadScreen.class)
                    .withOpenMode(OpenMode.DIALOG)
                    .build()
                    .show();
        }));
        buttonsPanel.add(button);
    }

    public SimpleReportDownloadScreenOptions<LiquidityCoefficientDictionary> generateReportDownloadScreenOptions() {
        SimpleReportRenderConfiguration renderConfiguration =
                new SimpleReportRenderConfiguration(
                        1000000
                );
        SimpleReportDataConfiguration<LiquidityCoefficientDictionary> selectedRowsDataConfiguration = liquidityCoefficientDictionaryTable.getSelected().isEmpty()?
                null:
                new SimpleReportDataConfiguration<>(
                        LIQUIDITY_COEFFICIENT_DICTIONARY_PROPERTIES,
                        () -> liquidityCoefficientDictionaryTable.getSelected().stream().collect(Collectors.toList())
                );
        SimpleReportDataConfiguration<LiquidityCoefficientDictionary> allRowsDataConfiguration = new SimpleReportDataConfiguration<>(
                LIQUIDITY_COEFFICIENT_DICTIONARY_PROPERTIES,
                () -> dataManager
                        .load(LiquidityCoefficientDictionary.class)
                        .all().fetchPlan(
                                fetchPlans.builder(LiquidityCoefficientDictionary.class)
                                        .addFetchPlan(FetchPlan.BASE)
                                        .add("changerUser")
                                        .build()
                        ).list()
        );
        return new SimpleReportDownloadScreenOptions<>(
                LiquidityCoefficientDictionary.class,
                renderConfiguration,
                allRowsDataConfiguration,
                selectedRowsDataConfiguration

        );
    }
}