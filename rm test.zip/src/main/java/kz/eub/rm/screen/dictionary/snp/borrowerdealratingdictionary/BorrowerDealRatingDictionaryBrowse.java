package kz.eub.rm.screen.dictionary.snp.borrowerdealratingdictionary;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.BorrowerDealRatingDictionary;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreen;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreenOptions;
import kz.eub.rm.simple.report.PropertiesToRender;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.stream.Collectors;

@UiController("rm_BorrowerDealRatingDictionary.browse")
@UiDescriptor("borrower-deal-rating-dictionary-browse.xml")
@LookupComponent("borrowerDealRatingDictionariesTable")
public class BorrowerDealRatingDictionaryBrowse extends StandardLookup<BorrowerDealRatingDictionary> {
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private GroupTable<BorrowerDealRatingDictionary> borrowerDealRatingDictionariesTable;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private FetchPlans fetchPlans;

    @Subscribe
    public void onInit(InitEvent event) {
        setupDownloadReportButton();
    }

    public void setupDownloadReportButton() {
        Button button = uiComponents.create(Button.class);
        button.setCaption("Выгрузить");
        button.setAction(new BaseAction("download-simple-report").withHandler((actionPerformedEvent)->{
            SimpleReportDownloadScreenOptions<BorrowerDealRatingDictionary> screenOptions = generateReportDownloadScreenOptions();
            screenBuilders.screen(this)
                    .withOptions(screenOptions)
                    .withScreenClass(SimpleReportDownloadScreen.class)
                    .withOpenMode(OpenMode.DIALOG)
                    .build()
                    .show();
        }));
        buttonsPanel.add(button);
    }

    private SimpleReportDownloadScreenOptions<BorrowerDealRatingDictionary> generateReportDownloadScreenOptions() {
        SimpleReportRenderConfiguration renderConfiguration =
                new SimpleReportRenderConfiguration(
                        1000000
                );
        SimpleReportDataConfiguration<BorrowerDealRatingDictionary> selectedRowsDataConfiguration = borrowerDealRatingDictionariesTable.getSelected().isEmpty()?
                null:
                new SimpleReportDataConfiguration<>(
                        PropertiesToRender.BORROWER_DEAL_RATING_PROPERTIES,
                        () -> borrowerDealRatingDictionariesTable.getSelected().stream().collect(Collectors.toList())
                );
        SimpleReportDataConfiguration<BorrowerDealRatingDictionary> allRowsDataConfiguration =
                new SimpleReportDataConfiguration<>(
                        PropertiesToRender.BORROWER_DEAL_RATING_PROPERTIES,
                        () -> dataManager
                                .load(BorrowerDealRatingDictionary.class)
                                .query("select p from rm_BorrowerDealRatingDictionary p")
                                .fetchPlan(
                                        fetchPlans
                                                .builder(BorrowerDealRatingDictionary.class)
                                                .addFetchPlan(FetchPlan.BASE)
                                                .build())
                                .list()
                );
        return new SimpleReportDownloadScreenOptions<>(
                BorrowerDealRatingDictionary.class,
                renderConfiguration,
                allRowsDataConfiguration,
                selectedRowsDataConfiguration
        );
    }
}