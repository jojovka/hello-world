package kz.eub.rm.screen.dictionary.snp.triggerdictionary;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.TriggerDictionary;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreen;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreenOptions;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.stream.Collectors;

import static kz.eub.rm.simple.report.PropertiesToRender.TRIGGER_DICTIONARY_PROPERTIES;

@UiController("rm_TriggerDictionary.browse")
@UiDescriptor("trigger-dictionary-browse.xml")
@LookupComponent("triggerDictionariesTable")
public class TriggerDictionaryBrowse extends StandardLookup<TriggerDictionary> {
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private FetchPlans fetchPlans;

    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private GroupTable<TriggerDictionary> triggerDictionariesTable;

    @Subscribe
    public void onInit(InitEvent event) {
        setupDownloadReportButton();
    }



    public void setupDownloadReportButton(){
        Button button = uiComponents.create(Button.class);
        button.setCaption("Выгрузить");
        button.setAction(new BaseAction("download-simple-report").withHandler((actionPerformedEvent)->{
            SimpleReportDownloadScreenOptions<TriggerDictionary> screenOptions = generateReportDownloadScreenOptions();
            screenBuilders.screen(this)
                    .withOptions(screenOptions)
                    .withScreenClass(SimpleReportDownloadScreen.class)
                    .withOpenMode(OpenMode.DIALOG)
                    .build()
                    .show();
        }));
        buttonsPanel.add(button);
    }

    public SimpleReportDownloadScreenOptions<TriggerDictionary> generateReportDownloadScreenOptions() {
        SimpleReportRenderConfiguration renderConfiguration =
                new SimpleReportRenderConfiguration(
                        1000000
                );
        SimpleReportDataConfiguration<TriggerDictionary> selectedRowsDataConfiguration = triggerDictionariesTable.getSelected().isEmpty()?
                null:
                new SimpleReportDataConfiguration<>(
                        TRIGGER_DICTIONARY_PROPERTIES,
                        () -> triggerDictionariesTable.getSelected().stream().collect(Collectors.toList())
                );
        SimpleReportDataConfiguration<TriggerDictionary> allRowsDataConfiguration = new SimpleReportDataConfiguration<>(
                TRIGGER_DICTIONARY_PROPERTIES,
                () -> dataManager
                        .load(TriggerDictionary.class)
                        .all().fetchPlan(
                                fetchPlans.builder(TriggerDictionary.class)
                                        .addFetchPlan(FetchPlan.BASE)
                                        .build()
                        ).list()
        );
        return new SimpleReportDownloadScreenOptions<>(
                TriggerDictionary.class,
                renderConfiguration,
                allRowsDataConfiguration,
                selectedRowsDataConfiguration

        );
    }
}