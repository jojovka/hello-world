package kz.eub.rm.screen.reportsbundle;

import io.jmix.ui.component.Component;
import io.jmix.ui.download.Downloader;
import io.jmix.ui.navigation.Route;
import io.jmix.ui.screen.*;
import io.jmix.ui.widget.JmixFileDownloader;
import kz.eub.rm.entity.ReportsBundle;
import kz.eub.rm.file.FileDownloadButtonFactory;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("rm_ReportsBundle.browse")
@UiDescriptor("reports-bundle-browse.xml")
@LookupComponent("reportsBundlesTable")
@Route("reports/bundles")
public class ReportsBundleBrowse extends StandardLookup<ReportsBundle> {
    @Autowired
    private FileDownloadButtonFactory fileDownloadButtonFactory;

    @Autowired
    private Downloader downloader;

    @Install(to = "reportsBundlesTable.fileRef", subject = "columnGenerator")
    private Component reportsBundlesTableFileRefColumnGenerator(ReportsBundle reportsBundle) {
        return reportsBundle.getFileRef()!=null?fileDownloadButtonFactory.createForExistingFileDownload(reportsBundle.getFileRef(), downloader):null;
    }
}