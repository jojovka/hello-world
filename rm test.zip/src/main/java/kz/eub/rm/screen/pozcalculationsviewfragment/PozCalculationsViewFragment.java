package kz.eub.rm.screen.pozcalculationsviewfragment;

import io.jmix.ui.component.Button;
import io.jmix.ui.component.Table;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.entity.RunHistory;
import kz.eub.rm.screen.calculationsviewfragment.CalculationsViewFragment;
import kz.eub.rm.service.calculation.PozCalculationService;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("rm_PozCalculationsViewFragment")
@UiDescriptor("poz-calculations-view-fragment.xml")
public class PozCalculationsViewFragment extends CalculationsViewFragment<RunHistory> {
    @Autowired
    protected PozCalculationService calculationService;

    @Override
    protected void handleApproveCalculationButtonClick(Button.ClickEvent event) {
        calculationService.approveCalculation(runHistoryTable.getSingleSelected().getRunId());
    }

    @Override
    protected void handleRunHistoryTableSelection(Table.SelectionEvent<RunHistory> event) {
        RunHistory run = runHistoryTable.getSingleSelected();
        if (run == null) {
            approveCalculationButton.setEnabled(false);
        } else if (calculationService.isAllowedToApproveCalculation(run.getId())) {
            approveCalculationButton.setEnabled(true);
        } else {
            approveCalculationButton.setEnabled(false);
        }
    }
}