package kz.eub.rm.screen.dictionary.snp.pozmappingdictionary;

import com.vaadin.ui.ComboBox;
import io.jmix.core.DataManager;
import io.jmix.core.Messages;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.Filter;
import io.jmix.ui.component.GroupFilter;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.LogicalFilterComponent;
import io.jmix.ui.component.PropertyFilter;
import io.jmix.ui.component.filter.configuration.RunTimeConfiguration;
import io.jmix.ui.component.impl.ComboBoxImpl;
import io.jmix.ui.component.impl.PropertyFilterImpl;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.PozDictionary;
import kz.eub.rm.entity.dwh.PozMappingDictionary;
import kz.eub.rm.filter.CustomPropertyFilter;
import kz.eub.rm.filter.PropertyConditionUtils;
import kz.eub.rm.filter.SingleFilterSupport;
import kz.eub.rm.screen.open.manager.PozMappingDictionaryBrowseOptions;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreen;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreenOptions;
import kz.eub.rm.service.PozMappingDictionaryService;
import kz.eub.rm.simple.report.PropertiesToRender;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Calendar;
import java.util.Date;
import java.util.stream.Collectors;

@UiController("rm_PozMapping.browse")
@UiDescriptor("poz-mapping-dictionary-browse.xml")
@LookupComponent("pozMappingDictionaryTable")
public class PozMappingDictionaryBrowse extends StandardLookup<PozMappingDictionary> {
    public static final String DEFAULT_FILTER_CONFIGURATION = "customDefaultConfiguration";
    public static final String NON_FILLED_RECORDS_CONFIGURATION = "emptyRowsFilterConfiguration";
    @Autowired
    protected DataManager dataManager;
    @Autowired
    private Filter filter;
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private CollectionLoader<PozMappingDictionary> pozMappingDictionaryDl;
    @Autowired
    private GroupTable<PozMappingDictionary> pozMappingDictionaryTable;
    @Autowired
    private SingleFilterSupport singleFilterSupport;
    @Autowired
    private io.jmix.ui.component.propertyfilter.SingleFilterSupport jmixSingleFilterSupport;
    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private PozMappingDictionaryService pozMappingDictionaryService;
    @Autowired
    private Messages messages;
    @Autowired
    private ScreenBuilders screenBuilders;

    @Subscribe
    public void onAfterInit(AfterInitEvent event) {
        filter.loadConfigurationsAndApplyDefault();
        setupFilterConfigurations();
        setupCurrentFilterConfiguration(event);
        setupDownloadReportButton();
    }

    public void setupFilterConfigurations() {
        setupDefaultFilterConfiguration();
        setupNewNonFilledRecordsFilterConfiguration();
    }

    public void setupCurrentFilterConfiguration(AfterInitEvent event){
        if (event.getOptions() instanceof PozMappingDictionaryBrowseOptions) {
            String filterConfigurationName = ((PozMappingDictionaryBrowseOptions)event.getOptions()).getFilterConfiguration();
            if (filterConfigurationName != null) {
                filter.setCurrentConfiguration(filter.getConfiguration(filterConfigurationName));
            } else {
                filter.setCurrentConfiguration(filter.getConfiguration(DEFAULT_FILTER_CONFIGURATION));
            }
        } else {
            filter.setCurrentConfiguration(filter.getConfiguration(DEFAULT_FILTER_CONFIGURATION));
        }
    }

    public RunTimeConfiguration setupDefaultFilterConfiguration() {
        CustomPropertyFilter<PozDictionary> sdspIdNotSetFilter = createNotSetFilter("sdspId", null);
        PropertyFilter<Boolean> isActualFilter = createEqualsFilter("isActual", Boolean.TRUE);

        GroupFilter groupFilter = uiComponents.create(GroupFilter.class);
        groupFilter.setDataLoader(pozMappingDictionaryDl);
        groupFilter.add(sdspIdNotSetFilter);
        groupFilter.add(isActualFilter);

        RunTimeConfiguration customDefaultConfiguration = new RunTimeConfiguration(DEFAULT_FILTER_CONFIGURATION, groupFilter,filter);
        customDefaultConfiguration.setName(messages.getMessage("pozMappingDictionaryBrowse.defaultFilterConfiguration"));

        filter.addConfiguration(customDefaultConfiguration);
        return customDefaultConfiguration;
    }

    public void setupNewNonFilledRecordsFilterConfiguration() {
        boolean filtersDefaultState = true;
        CustomPropertyFilter<PozDictionary> pozForRiskMetricsCalculationNotSetFilter = createNotSetFilter("sdspId", filtersDefaultState);
        ((ComboBox)((ComboBoxImpl)pozForRiskMetricsCalculationNotSetFilter.getValueComponent()).getComponent()).setSelectedItem(filtersDefaultState);
        CustomPropertyFilter<PozDictionary> pozForReservePercentCalculationNotSetFilter = createNotSetFilter("pozForReservePercentCalculation", filtersDefaultState);
        ((ComboBox)((ComboBoxImpl)pozForReservePercentCalculationNotSetFilter.getValueComponent()).getComponent()).setSelectedItem(filtersDefaultState);
        Calendar now = Calendar.getInstance();
        now.set(Calendar.HOUR_OF_DAY, 0);
        now.set(Calendar.MINUTE, 0);
        now.set(Calendar.SECOND, 0);
        now.set(Calendar.MILLISECOND, 0);
        Date currentDateStartOfDay = now.getTime();
        PropertyFilter<Date> changeDateIsTodayFilter = createGreaterOrEqualsFilter("loadDate", currentDateStartOfDay);
        changeDateIsTodayFilter.getValueComponent().setValue(currentDateStartOfDay);

        PropertyFilter<Boolean> isActualFilter = createEqualsFilter("isActual", Boolean.TRUE);

        GroupFilter groupFilterOr = uiComponents.create(GroupFilter.class);
        groupFilterOr.setOperation(LogicalFilterComponent.Operation.OR);
        groupFilterOr.setDataLoader(pozMappingDictionaryDl);
        groupFilterOr.add(pozForRiskMetricsCalculationNotSetFilter);
        groupFilterOr.add(pozForReservePercentCalculationNotSetFilter);

        GroupFilter groupFilterAnd = uiComponents.create(GroupFilter.class);
        groupFilterAnd.setOperation(LogicalFilterComponent.Operation.AND);
        groupFilterAnd.setDataLoader(pozMappingDictionaryDl);
        groupFilterAnd.add(changeDateIsTodayFilter);
        groupFilterAnd.add(isActualFilter);
        groupFilterAnd.add(groupFilterOr);

        RunTimeConfiguration customDefaultConfiguration = new RunTimeConfiguration(NON_FILLED_RECORDS_CONFIGURATION, groupFilterAnd,filter);
        customDefaultConfiguration.setName(messages.getMessage("pozMappingDictionaryBrowse.nonFilledRecordsFilterConfiguration"));

        filter.addConfiguration(customDefaultConfiguration);
    }

    private <T>CustomPropertyFilter<T> createNotSetFilter(String property, Boolean defaultParameterValue) {
        CustomPropertyFilter<T> customPropertyFilter = uiComponents.create(CustomPropertyFilter.NAME);
        customPropertyFilter.setProperty(property);
        customPropertyFilter.setOperation(CustomPropertyFilter.Operation.IS_NOT_SET);
        customPropertyFilter.setDataLoader(pozMappingDictionaryDl);
        customPropertyFilter.setParameterName(PropertyConditionUtils.generateParameterName(customPropertyFilter.getProperty()));
        customPropertyFilter.setValueComponent(singleFilterSupport.generateValueComponent(
                pozMappingDictionaryDl.getContainer().getEntityMetaClass(),
                customPropertyFilter.getProperty(),
                customPropertyFilter.getOperation()
        ));
        customPropertyFilter.getQueryCondition().setParameterValue(defaultParameterValue);
        return customPropertyFilter;
    }

    private <T>PropertyFilter<T> createGreaterOrEqualsFilter(String property, Date date) {
        PropertyFilter<T> propertyFilter = uiComponents.create(PropertyFilter.NAME);
        propertyFilter.setProperty(property);
        propertyFilter.setOperation(PropertyFilter.Operation.GREATER_OR_EQUAL);
        propertyFilter.setDataLoader(pozMappingDictionaryDl);
        propertyFilter.setParameterName(io.jmix.core.querycondition.PropertyConditionUtils.generateParameterName(propertyFilter.getProperty()));
        propertyFilter.setValueComponent(jmixSingleFilterSupport.generateValueComponent(
                pozMappingDictionaryDl.getContainer().getEntityMetaClass(),
                propertyFilter.getProperty(),
                propertyFilter.getOperation()
        ));
        propertyFilter.getQueryCondition().setParameterValue(date);
        return propertyFilter;
    }

    private <T>PropertyFilter<T> createEqualsFilter(String property, T defaultValue) {
        PropertyFilter<T> equalsFilter = uiComponents.create(PropertyFilter.NAME);
        equalsFilter.setDataLoader(pozMappingDictionaryDl);
        equalsFilter.setProperty(property);
        equalsFilter.setOperation(PropertyFilter.Operation.EQUAL);
        equalsFilter.getQueryCondition().setParameterValue(defaultValue);
        equalsFilter.setValue(defaultValue);
        equalsFilter.setParameterName(io.jmix.core.querycondition.PropertyConditionUtils.generateParameterName(equalsFilter.getProperty()));

        return equalsFilter;
    }

    public void setupDownloadReportButton() {
        Button button = uiComponents.create(Button.class);
        button.setCaption("Выгрузить");
        button.setAction(new BaseAction("download-simple-report").withHandler((actionPerformedEvent)->{
            SimpleReportDownloadScreenOptions<PozMappingDictionary> screenOptions = generateReportDownloadScreenOptions();
            screenBuilders.screen(this)
                    .withOptions(screenOptions)
                    .withScreenClass(SimpleReportDownloadScreen.class)
                    .withOpenMode(OpenMode.DIALOG)
                    .build()
                    .show();
        }));
        buttonsPanel.add(button);
    }

    private SimpleReportDownloadScreenOptions<PozMappingDictionary> generateReportDownloadScreenOptions() {
        SimpleReportRenderConfiguration renderConfiguration =
                new SimpleReportRenderConfiguration(
                        1000000
                );
        SimpleReportDataConfiguration<PozMappingDictionary> selectedRowsDataConfiguration = pozMappingDictionaryTable.getSelected().isEmpty()?
                null:
                new SimpleReportDataConfiguration<>(
                        PropertiesToRender.POZ_MAPPING_DICTIONARY_PROPERTIES,
                        () -> pozMappingDictionaryTable.getSelected().stream().collect(Collectors.toList())
                );
        SimpleReportDataConfiguration<PozMappingDictionary> allRowsDataConfiguration =
                new SimpleReportDataConfiguration<>(
                        PropertiesToRender.POZ_MAPPING_DICTIONARY_PROPERTIES,
                        () -> dataManager
                                .load(PozMappingDictionary.class)
                                .condition(filter.getCurrentConfiguration().getQueryCondition())
                                .list()
//                        () -> pozMappingDictionaryService.getAllDataWithFetchedChildNames()
                );
        return new SimpleReportDownloadScreenOptions<>(
                PozMappingDictionary.class,
                renderConfiguration,
                allRowsDataConfiguration,
                selectedRowsDataConfiguration
        );
    }
}