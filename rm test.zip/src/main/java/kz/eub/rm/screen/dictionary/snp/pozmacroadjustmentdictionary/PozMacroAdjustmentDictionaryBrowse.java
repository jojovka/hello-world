package kz.eub.rm.screen.dictionary.snp.pozmacroadjustmentdictionary;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.PozMacroAdjustmentDictionary;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreen;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreenOptions;
import kz.eub.rm.simple.report.PropertiesToRender;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.stream.Collectors;

@UiController("rm_PozMacroAdjustmentDictionary.browse")
@UiDescriptor("poz-macro-adjustment-dictionary-browse.xml")
@LookupComponent("pozMacroAdjustmentDictionariesTable")
public class PozMacroAdjustmentDictionaryBrowse extends StandardLookup<PozMacroAdjustmentDictionary> {
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private GroupTable<PozMacroAdjustmentDictionary> pozMacroAdjustmentDictionariesTable;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private FetchPlans fetchPlans;

    @Subscribe
    public void onInit(InitEvent event) {
        setupDownloadReportButton();
    }

    public void setupDownloadReportButton() {
        Button button = uiComponents.create(Button.class);
        button.setCaption("Выгрузить");
        button.setAction(new BaseAction("download-simple-report").withHandler((actionPerformedEvent)->{
            SimpleReportDownloadScreenOptions<PozMacroAdjustmentDictionary> screenOptions = generateReportDownloadScreenOptions();
            screenBuilders.screen(this)
                    .withOptions(screenOptions)
                    .withScreenClass(SimpleReportDownloadScreen.class)
                    .withOpenMode(OpenMode.DIALOG)
                    .build()
                    .show();
        }));
        buttonsPanel.add(button);
    }

    private SimpleReportDownloadScreenOptions<PozMacroAdjustmentDictionary> generateReportDownloadScreenOptions() {
        SimpleReportRenderConfiguration renderConfiguration =
                new SimpleReportRenderConfiguration(
                        1000000
                );
        SimpleReportDataConfiguration<PozMacroAdjustmentDictionary> selectedRowsDataConfiguration = pozMacroAdjustmentDictionariesTable.getSelected().isEmpty()?
                null:
                new SimpleReportDataConfiguration<>(
                        PropertiesToRender.POZ_MACRO_ADJUSTMENTS_DICTIONARY_PROPERTIES,
                        () -> pozMacroAdjustmentDictionariesTable.getSelected().stream().collect(Collectors.toList())
                );
        SimpleReportDataConfiguration<PozMacroAdjustmentDictionary> allRowsDataConfiguration =
                new SimpleReportDataConfiguration<>(
                        PropertiesToRender.POZ_MACRO_ADJUSTMENTS_DICTIONARY_PROPERTIES,
                        () -> dataManager
                                .load(PozMacroAdjustmentDictionary.class)
                                .query("select p from rm_PozMacroAdjustmentDictionary p")
                                .fetchPlan(
                                        fetchPlans
                                                .builder(PozMacroAdjustmentDictionary.class)
                                                .addFetchPlan(FetchPlan.BASE)
                                                .add("pozDictionary")
                                                .add("changerUser")
                                                .build())
                                .list()
                );
        return new SimpleReportDownloadScreenOptions<>(
                PozMacroAdjustmentDictionary.class,
                renderConfiguration,
                allRowsDataConfiguration,
                selectedRowsDataConfiguration
        );
    }
}