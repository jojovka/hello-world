package kz.eub.rm.screen.open.manager;

import io.jmix.ui.AppUI;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.component.RootWindow;
import io.jmix.ui.screen.OpenMode;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.ScreenOptions;
import kz.eub.rm.screen.dictionary.snp.pozmappingdictionary.PozMappingDictionaryBrowse;
import kz.eub.rm.screen.main.MainScreen;
import kz.eub.rm.service.PozMappingDictionaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("rm_PozMappingDictionaryScreenOpenManager")
public class PozMappingDictionaryScreenOpenManager {
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private PozMappingDictionaryService pozMappingDictionaryService;
    public void openBrowseScreen() {
        final Screen ownerFrame = AppUI.getCurrent().getTopLevelWindowNN().getFrameOwner();
        Long nonFilledRecordsAmount = pozMappingDictionaryService.getAmountOfNonFilledRows();
        ((MainScreen)ownerFrame).updatePozMappingDictionaryCounterBadge(nonFilledRecordsAmount);
        if (nonFilledRecordsAmount.equals(0L)) {
            screenBuilders.screen(ownerFrame)
                    .withScreenClass(PozMappingDictionaryBrowse.class)
                    .withOpenMode(OpenMode.NEW_TAB)
                    .build()
                    .show();
        } else {
            screenBuilders.screen(ownerFrame)
                    .withScreenClass(PozMappingDictionaryBrowse.class)
                    .withOptions(new PozMappingDictionaryBrowseOptions(PozMappingDictionaryBrowse.NON_FILLED_RECORDS_CONFIGURATION))
                    .withOpenMode(OpenMode.NEW_TAB)
                    .build()
                    .show();
        }
    }
}
