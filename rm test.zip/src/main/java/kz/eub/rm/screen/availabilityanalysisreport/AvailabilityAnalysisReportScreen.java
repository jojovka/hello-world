package kz.eub.rm.screen.availabilityanalysisreport;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.screen.pnzuserfriendlyreport.PnzUserFriendlyReportScreen;

@UiController("rm_AvailabilityAnalysisReportScreen")
@UiDescriptor("availability-analysis-report-screen.xml")
public class AvailabilityAnalysisReportScreen extends PnzUserFriendlyReportScreen {
    @Override
    protected String getReportCode() {
        return "availability-analysis-report";
    }
}