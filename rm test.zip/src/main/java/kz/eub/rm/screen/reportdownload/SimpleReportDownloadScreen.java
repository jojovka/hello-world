package kz.eub.rm.screen.reportdownload;

import io.jmix.ui.component.Button;
import io.jmix.ui.component.VBoxLayout;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.file.FileDownloadButtonFactory;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("rm_SimpleReportDownloadScreen")
@UiDescriptor("simple-report-download-screen.xml")
public class SimpleReportDownloadScreen<T> extends Screen {
    @Autowired
    private VBoxLayout reportOptionsVBox;
    @Autowired
    private FileDownloadButtonFactory fileDownloadButtonFactory;

    @Subscribe
    public void onInit(InitEvent event) {
        setupReportOptionsButtons(event);
    }

    private void setupReportOptionsButtons(InitEvent event) {
        if (event.getOptions() instanceof SimpleReportDownloadScreenOptions) {
            SimpleReportDownloadScreenOptions<T> screenOptions = (SimpleReportDownloadScreenOptions<T>) event.getOptions();
            Class<T> entityClass = screenOptions.getEntityClass();
            SimpleReportRenderConfiguration renderConfiguration = screenOptions.getRenderConfiguration();
            if (entityClass!=null && renderConfiguration!=null) {
                SimpleReportDataConfiguration<T> selectedRowsDataConfiguration = screenOptions.getSelectedRowsDataConfiguration();
                if (selectedRowsDataConfiguration != null) {
                    setupDownloadSelectedRowsButton(entityClass, renderConfiguration, selectedRowsDataConfiguration);
                }
                SimpleReportDataConfiguration<T> allRowsDataConfiguration = screenOptions.getAllRowsDataConfiguration();
                if (allRowsDataConfiguration != null) {
                    setupDownloadAllRowsButton(entityClass, renderConfiguration, allRowsDataConfiguration);
                }
            }
        }
    }

    private void setupDownloadSelectedRowsButton(
            Class<T> entityClass,
            SimpleReportRenderConfiguration renderConfiguration,
            SimpleReportDataConfiguration<T> selectedRowsDataConfiguration
    ) {
        Button button = fileDownloadButtonFactory.createForSimpleReport(entityClass, selectedRowsDataConfiguration, renderConfiguration);
        button.setCaption("Выгрузить выбранные строки");
        reportOptionsVBox.add(button);
    }

    private void setupDownloadAllRowsButton(
            Class<T> entityClass,
            SimpleReportRenderConfiguration renderConfiguration,
            SimpleReportDataConfiguration<T> allRowsDataConfiguration
    ) {
        Button button = fileDownloadButtonFactory.createForSimpleReport(entityClass, allRowsDataConfiguration, renderConfiguration);
        button.setCaption("Выгрузить все строки");
        reportOptionsVBox.add(button);
    }
}