package kz.eub.rm.screen.tvreport;

import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.entity.dwh.PozSegmentationDictionary;
import kz.eub.rm.screen.segmentandpozchoicereport.SegmentAndPozChoiceReportScreen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@UiController("rm_TvReportScreen")
@UiDescriptor("tv-report-screen.xml")
public class TvReportScreen extends SegmentAndPozChoiceReportScreen {
    @Override
    protected String getReportCode() {
        return "tv-report";
    }
}