package kz.eub.rm.screen.macrocorrectionreport;

import io.jmix.core.Messages;
import io.jmix.reportsui.runner.UiReportRunner;
import io.jmix.ui.Notifications;
import io.jmix.ui.UiComponents;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.DateField;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.file.FileDownloadButtonFactory;
import kz.eub.rm.file.FileDownloadClickValidationResult;
import kz.eub.rm.file.ReportDownloadButtonConfiguration;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

@UiController("rm_MacrocorrectionReportScreen")
@UiDescriptor("macrocorrection-report-screen.xml")
public class MacrocorrectionReportScreen extends Screen {
    @Autowired
    private DateField<Date> dateField;
    @Autowired
    private ButtonsPanel buttonsPanel;

    protected Button downloadReportButton;

    @Autowired
    protected UiReportRunner uiReportRunner;
    @Autowired
    protected Messages messages;
    @Autowired
    protected Notifications notifications;

    @Autowired
    private FileDownloadButtonFactory fileDownloadButtonFactory;
    @Subscribe
    public void onInit(InitEvent event) {
        setupReportDownloadButton();
    }

    protected void setupReportDownloadButton() {
        downloadReportButton = fileDownloadButtonFactory.createForReport(
                ReportDownloadButtonConfiguration.builder(uiReportRunner, notifications, "macrocorrection-report")
                        .onClickAdditionalValidation(() -> {
                            LocalDate localDate = new LocalDate(dateField.getValue());
                            if (localDate.getYear() == 2023) {
                                return new FileDownloadClickValidationResult(FileDownloadClickValidationResult.Status.SUCCESS, null);
                            } else {
                                return new FileDownloadClickValidationResult(FileDownloadClickValidationResult.Status.ERROR, "нет данных");
                            }
                        })
                        .build()
        );
        buttonsPanel.add(downloadReportButton);
        downloadReportButton.setEnabled(false);
        downloadReportButton.setCaption(messages.getMessage("kz.eub.rm.screen.userfriendlyreportbase/userFriendlyReportBaseScreen.downloadReportButton"));
    }

    @Subscribe("dateField")
    public void onDateFieldValueChange(HasValue.ValueChangeEvent event) {
        toggleDownloadButton(event.getValue()!=null);
    }

    protected void toggleDownloadButton(boolean enable) {
        downloadReportButton.setEnabled(enable);
    }



}