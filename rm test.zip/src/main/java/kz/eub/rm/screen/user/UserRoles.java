package kz.eub.rm.screen.user;

import io.jmix.core.AccessManager;
import io.jmix.core.accesscontext.SpecificOperationAccessContext;
import io.jmix.security.model.ResourceRole;
import io.jmix.security.role.ResourceRoleRepository;
import io.jmix.securityui.model.ResourceRoleModel;
import io.jmix.securityui.model.RoleModelConverter;
import io.jmix.securityui.screen.rolefilter.RoleFilter;
import io.jmix.ui.Dialogs;
import io.jmix.ui.Notifications;
import io.jmix.ui.action.Action;
import io.jmix.ui.action.DialogAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.DataGrid;
import io.jmix.ui.component.EntityComboBox;
import io.jmix.ui.component.PopupView;
import io.jmix.ui.component.TextField;
import io.jmix.ui.component.TextInputField;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.LookupComponent;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.entity.User;
import kz.eub.rm.service.UserSecService;
import kz.eub.rm.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@UiController("rm_User.roles")
@UiDescriptor("user-roles.xml")
@LookupComponent("usersTable")
public class UserRoles extends StandardLookup<User> {

    @Autowired
    private CollectionContainer<ResourceRoleModel> roleModelsDc;
    @Autowired
    private ResourceRoleRepository roleRepository;
    @Autowired
    private RoleModelConverter roleModelConverter;

    @Autowired
    private EntityComboBox<ResourceRoleModel> rolesField;
    @Autowired
    private CollectionContainer<User> usersDc;

    private RoleFilter roleFilter = new RoleFilter();
    @Autowired
    private UserSecService employeeSecService;
    @Autowired
    private DataGrid<User> usersTable;
    @Autowired
    private Notifications notifications;
    @Autowired
    private Dialogs dialogs;
    @Autowired
    private CollectionLoader<User> usersDl;
    @Autowired
    private UserService userService;
    @Autowired
    private PopupView popupView;
    @Autowired
    private CollectionContainer<ResourceRoleModel> userRolesDc;
    @Autowired
    private TextField<String> searchFioFld;
    @Autowired
    private AccessManager accessManager;
    @Autowired
    private Button assignBtn;
    @Autowired
    private Button revokeBtn;

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        loadRoles();
        toggleAssignBtn();
        toggleDetachBtn();
    }

    private void toggleDetachBtn() {
        SpecificOperationAccessContext accessContext =
                new SpecificOperationAccessContext("bulkRoleDetachment");
        accessManager.applyRegisteredConstraints(accessContext);
        revokeBtn.setVisible(accessContext.isPermitted());
    }

    private void toggleAssignBtn() {
        SpecificOperationAccessContext accessContext =
                new SpecificOperationAccessContext("bulkRoleAssignment");
        accessManager.applyRegisteredConstraints(accessContext);
        assignBtn.setVisible(accessContext.isPermitted());
    }


    protected void loadRoles() {
        Collection<ResourceRole> roles = roleRepository.getAllRoles();
        List<ResourceRoleModel> roleModels = roles.stream()
                .filter(role -> roleFilter.matches(role))
                .map(roleModelConverter::createResourceRoleModel)
                .sorted(Comparator.comparing(ResourceRoleModel::getName))
                .collect(Collectors.toList());
        roleModelsDc.getMutableItems().clear();
        roleModelsDc.getMutableItems().addAll(roleModels);
    }

    @Subscribe("refreshBtn")
    public void onRefreshBtnClick(Button.ClickEvent event) {
        if (!searchByFio()) {
            loadUser();
        } else {
            searchByFio();
        }
    }

    private boolean searchByFio() {
        if (searchFioFld.getValue() == null
                || searchFioFld.getValue().isEmpty())
            return false;
        List<User> userList = userService.searchUser(searchFioFld.getValue().trim());
        resetUserList(userList);
        return true;
    }

    private void loadUser() {
        ResourceRoleModel role = rolesField.getValue();
        if (role == null) {
            usersDl.load();
            return;
        }
        List<User> employeeList = getEmployeesByRole(role);
        resetUserList(employeeList);
    }

    private void resetUserList(List<User> employeeList) {
        usersDc.getMutableItems().clear();
        usersDc.getMutableItems().addAll(employeeList);
    }

    private List<User> getEmployeesByRole(ResourceRoleModel role) {
        if (role == null) return Collections.emptyList();
        return employeeSecService.loadUsersHavingRole(role.getCode());
    }

    @Subscribe("assignBtn")
    public void onAssignBtnClick(Button.ClickEvent event) {
        ResourceRoleModel role = rolesField.getValue();
        if (role == null) {
            showWarningNotification("Выберите роль...");
            rolesField.focus();
            return;
        }
        dialogs.createOptionDialog()
                .withCaption("Потдвердите массовое назначение роли")
                .withMessage("Вы уверены что хотите назначить роль всем выбранным сотрудникам?")
                .withActions(
                        new DialogAction(DialogAction.Type.YES, Action.Status.PRIMARY)
                                .withHandler(e -> bulkRoleAssignment(role)),
                        new DialogAction(DialogAction.Type.NO)
                )
                .show();
    }

    private void bulkRoleAssignment(ResourceRoleModel role) {
        try {
            Set<User> employees = usersTable.getSelected();
            if (role == null || employees.size() == 0) {
                showWarningNotification("Выберите сотрудников...");
                return;
            }
            employeeSecService.bulkRoleAssignment(employees, role.getCode());
            loadUser();
        } catch (Exception e) {
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Ошибка")
                    .withDescription(e.getMessage())
                    .show();
        }
    }

    private void showHumanizedNotification(String message) {
        notifications.create(Notifications.NotificationType.HUMANIZED)
                .withCaption(message)
                .show();
    }

    private void showWarningNotification(String message) {
        notifications.create(Notifications.NotificationType.WARNING)
                .withCaption(message)
                .show();
    }

    @Subscribe("usersTable.showUserRoles")
    public void onEmployeesTableShowUserRoles(Action.ActionPerformedEvent event) {
        User user = usersTable.getSingleSelected();
        if (user == null) return;
        usersDc.setItem(user);
        userRolesDc.getMutableItems().clear();
        List<ResourceRoleModel> userRoles = employeeSecService.getUserRoles(user);
        userRolesDc.getMutableItems().addAll(userRoles);
        popupView.setVisible(true);
        popupView.setPopupVisible(true);
    }

    @Subscribe("revokeBtn")
    public void onRevokeBtnClick(Button.ClickEvent event) {
        ResourceRoleModel role = rolesField.getValue();
        if (role == null) {
            showWarningNotification("Выберите роль...");
            rolesField.focus();
            return;
        }
        dialogs.createOptionDialog()
                .withCaption("Потдвердите массовый отзыв роли")
                .withMessage("Вы уверены что хотите отозвать роль у всех выбранных сотрудников?")
                .withActions(
                        new DialogAction(DialogAction.Type.YES, Action.Status.PRIMARY)
                                .withHandler(e -> massRoleRevokation(role)),
                        new DialogAction(DialogAction.Type.NO)
                )
                .show();
    }

    private void massRoleRevokation(ResourceRoleModel role) {
        try {
            Set<User> employees = usersTable.getSelected();
            if (role == null || employees.size() == 0) {
                showWarningNotification("Выберите сотрудников...");
                return;
            }
            employeeSecService.bulkRoleRevocation(employees, role.getCode());
            loadUser();
        } catch (Exception e) {
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Ошибка")
                    .withDescription(e.getMessage())
                    .show();
        }
    }

    @Subscribe("searchFioFld")
    public void onSearchFioFldEnterPress(TextInputField.EnterPressEvent event) {
        searchByFio();
    }

}