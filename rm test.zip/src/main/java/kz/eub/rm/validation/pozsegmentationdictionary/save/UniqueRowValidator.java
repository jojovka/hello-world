package kz.eub.rm.validation.pozsegmentationdictionary.save;

import io.jmix.core.DataManager;
import kz.eub.dud.jmix.platform.validation.ConditionDoesNotMatchException;
import kz.eub.dud.jmix.platform.validation.SingleConditionMatchValidator;
import kz.eub.rm.entity.dwh.PozSegmentationDictionary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("rm_uniqueRowValidator")
public class UniqueRowValidator implements SingleConditionMatchValidator<PozSegmentationDictionary> {
    private Class<PozSegmentationDictionary> entityType;

    private DataManager dataManager;

    public UniqueRowValidator(@Autowired DataManager dataManager) {
        this.dataManager = dataManager;
        entityType = PozSegmentationDictionary.class;
    }
    @Override
    public void check(PozSegmentationDictionary entity) throws ConditionDoesNotMatchException {
        List<PozSegmentationDictionary> pozSegmentationDictionaryList = dataManager
                .load(PozSegmentationDictionary.class)
                .query("select s from rm_PozSegmentationDictionary as s " +
                        "where s.id <> :id and " +
                        "s.pozId = :pozId and " +
                        ":amountMin between s.amountMin and s.amountMax and " +
                        ":durationMin between s.durationMin and s.durationMax")
                .parameter("id", entity.getId())
                .parameter("pozId", entity.getPozId())
                .parameter("amountMin", entity.getAmountMin())
                .parameter("durationMin", entity.getDurationMin())
                .list();
        if (!pozSegmentationDictionaryList.isEmpty()) {
            StringBuilder stringBuilder = new StringBuilder();
            for (int i=0;i< pozSegmentationDictionaryList.size();i++) {
                stringBuilder.append(pozSegmentationDictionaryList.get(i).getSegment());
                if(i< pozSegmentationDictionaryList.size() - 1){
                    stringBuilder.append(',');
                }
            }
            throw new ConditionDoesNotMatchException(String.format("Сегменты с такими параметрами уже существуют: %s", stringBuilder.toString()));
        }
    }

    @Override
    public Class<PozSegmentationDictionary> getEntityType() {
        return entityType;
    }
}
