package kz.eub.rm.validation.pozsegmentationdictionary.save;

import io.jmix.core.Messages;
import kz.eub.dud.jmix.platform.validation.ConditionDoesNotMatchException;
import kz.eub.dud.jmix.platform.validation.SingleConditionMatchValidator;
import kz.eub.rm.entity.dwh.PozSegmentationDictionary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("rm_minMaxValuesDoNotIntersectValidator")
public class MinMaxValuesDoNotIntersectValidator implements SingleConditionMatchValidator<PozSegmentationDictionary> {
    private Messages messages;

    public MinMaxValuesDoNotIntersectValidator(@Autowired Messages messages) {
        this.messages = messages;
    }

    @Override
    public void check(PozSegmentationDictionary entity) throws ConditionDoesNotMatchException {
        if (entity.getAmountMin().compareTo(entity.getAmountMax())>0) {
            throw new ConditionDoesNotMatchException(String.format("%s < %s",
                    messages.getMessage(PozSegmentationDictionary.class,"PozSegmentationDictionary.amountMax"),
                    messages.getMessage(PozSegmentationDictionary.class,"PozSegmentationDictionary.amountMin")
            ));
        }
        if (entity.getDurationMin().compareTo(entity.getDurationMax())>0) {
            throw new ConditionDoesNotMatchException(String.format("%s < %s",
                    messages.getMessage(PozSegmentationDictionary.class,"PozSegmentationDictionary.durationMax"),
                    messages.getMessage(PozSegmentationDictionary.class,"PozSegmentationDictionary.durationMin")
            ));
        }
    }

    @Override
    public Class<PozSegmentationDictionary> getEntityType() {
        return PozSegmentationDictionary.class;
    }
}
