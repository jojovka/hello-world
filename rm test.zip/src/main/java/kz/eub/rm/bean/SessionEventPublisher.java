package kz.eub.rm.bean;

import com.vaadin.server.VaadinSession;
import io.jmix.ui.event.AppInitializedEvent;
import kz.eub.rm.event.GlobalConfigurationChangedEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import java.lang.ref.WeakReference;

@Component
@SessionScope
public class SessionEventPublisher {
    @Autowired
    private ApplicationEventPublisher applicationEventPublisher;

    public void publish(GlobalConfigurationChangedEvent event) {
        applicationEventPublisher.publishEvent(event);
    }
}
