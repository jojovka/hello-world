package kz.eub.rm.file;

import io.jmix.ui.Notifications;

import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class MultipleReportsGenerationButtonConfiguration {
    private String reportCode;

    private List<Map<String, Object>> parametersMaps;

    private boolean useDefaultTemplate;

    private FileDownloadButtonAppearance fileDownloadButtonAppearance;

    private Supplier<List<Map<String, Object>>> onClickParametersCreationDelegate;

    private Function<Void, String> onClickTemplateSelectionDelegate;

    private Supplier<FileDownloadClickValidationResult> onClickAdditionalValidation;

    private Supplier<String> blockingValueSupplier;

    private Notifications notifications;

    public static MultipleReportsGenerationButtonConfigurationBuilder builder(Notifications notifications, String templateCode) {
        return new MultipleReportsGenerationButtonConfigurationBuilder(notifications, templateCode);
    }

    protected MultipleReportsGenerationButtonConfiguration(){
    }

    public String getReportCode() {
        return reportCode;
    }

    public void setReportCode(String reportCode) {
        this.reportCode = reportCode;
    }

    public List<Map<String, Object>> getParametersMaps() {
        return parametersMaps;
    }

    public void setParametersMaps(List<Map<String, Object>> parametersMaps) {
        this.parametersMaps = parametersMaps;
    }

    public boolean isUseDefaultTemplate() {
        return useDefaultTemplate;
    }

    public void setUseDefaultTemplate(boolean useDefaultTemplate) {
        this.useDefaultTemplate = useDefaultTemplate;
    }

    public FileDownloadButtonAppearance getFileDownloadButtonAppearance() {
        return fileDownloadButtonAppearance;
    }

    public void setFileDownloadButtonAppearance(FileDownloadButtonAppearance fileDownloadButtonAppearance) {
        this.fileDownloadButtonAppearance = fileDownloadButtonAppearance;
    }

    public Supplier<List<Map<String, Object>>> getOnClickParametersCreationDelegate() {
        return onClickParametersCreationDelegate;
    }

    public void setOnClickParametersCreationDelegate(Supplier<List<Map<String, Object>>> onClickParametersCreationDelegate) {
        this.onClickParametersCreationDelegate = onClickParametersCreationDelegate;
    }

    public Function<Void, String> getOnClickTemplateSelectionDelegate() {
        return onClickTemplateSelectionDelegate;
    }

    public void setOnClickTemplateSelectionDelegate(Function<Void, String> onClickTemplateSelectionDelegate) {
        this.onClickTemplateSelectionDelegate = onClickTemplateSelectionDelegate;
    }

    public Supplier<FileDownloadClickValidationResult> getOnClickAdditionalValidation() {
        return onClickAdditionalValidation;
    }

    public void setOnClickAdditionalValidation(Supplier<FileDownloadClickValidationResult> onClickAdditionalValidation) {
        this.onClickAdditionalValidation = onClickAdditionalValidation;
    }

    public Notifications getNotifications() {
        return notifications;
    }

    public void setNotifications(Notifications notifications) {
        this.notifications = notifications;
    }

    public Supplier<String> getBlockingValueSupplier() {
        return blockingValueSupplier;
    }

    public void setBlockingValueSupplier(Supplier<String> blockingValueSupplier) {
        this.blockingValueSupplier = blockingValueSupplier;
    }
}
