package kz.eub.rm.file;

import io.jmix.core.FileRef;
import io.jmix.reportsui.runner.ParametersDialogShowMode;
import io.jmix.ui.Notifications;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ValidationException;
import io.jmix.ui.download.DownloadFormat;
import io.jmix.ui.download.Downloader;
import io.jmix.ui.icon.JmixIcon;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportGenerationService;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;

@Component
public class FileDownloadButtonFactory {
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private SimpleReportGenerationService simpleReportGenerationService;
    @Autowired
    private Downloader downloader;

    // todo переработать валидацию и попап, очень грязно сделано
    // создание кнопки генерации и выгрузки отчета
    public Button createForReport(ReportDownloadButtonConfiguration configuration) {
        Button button = uiComponents.create(Button.class);
        fillButtonWithAppearance(button, configuration.getFileDownloadButtonAppearance());
        if (configuration.isUseDefaultTemplate()) {
            button.setAction(
                    new BaseAction(configuration.getReportCode()).withHandler(actionPerformedEvent -> {
                        if (!validate(configuration.getOnClickAdditionalValidation(), configuration.getNotifications())) {
                            return;
                        }
                        configuration.getOnClickParametersAdjustmentDelegate().accept(configuration.getParameters());
                        configuration
                                .getUiReportRunner()
                                .byReportCode(configuration.getReportCode())
                                .withParams(configuration.getParameters())
                                .withParametersDialogShowMode(ParametersDialogShowMode.NO)
                                .runAndShow();
                    })
            );
        } else {
            button.setAction(
                    new BaseAction(configuration.getReportCode()).withHandler(actionPerformedEvent -> {
                        if (!validate(configuration.getOnClickAdditionalValidation(), configuration.getNotifications())) {
                            return;
                        }
                        configuration.getOnClickParametersAdjustmentDelegate().accept(configuration.getParameters());
                        configuration
                                .getUiReportRunner()
                                .byReportCode(configuration.getReportCode())
                                .withParams(configuration.getParameters())
                                .withTemplateCode(configuration.getOnClickTemplateSelectionDelegate().apply(null))
                                .withParametersDialogShowMode(ParametersDialogShowMode.NO)
                                .runAndShow();
                    })
            );
        }
        return button;
    }

    private boolean validate(Supplier<FileDownloadClickValidationResult> onClickAdditionalValidation, Notifications notifications) {
        if (notifications!=null) {
            FileDownloadClickValidationResult validationResult = onClickAdditionalValidation.get();
            if (!validationResult.getStatus().equals(FileDownloadClickValidationResult.Status.SUCCESS)) {
                notifications.create(Notifications.NotificationType.HUMANIZED).withCaption(validationResult.getMessage()).show();
                return false;
            }
        }
        return true;
    }

    // создание кнопки экспорта данных из таблицы в эксель
    // экспорт происходит не сразу, по нажатии всплывает экран с опциями
    public Button createForSimpleReport(
            Class cls,
            SimpleReportDataConfiguration simpleReportDataConfiguration,
            SimpleReportRenderConfiguration simpleReportRenderConfiguration
    ) {
        Button button = uiComponents.create(Button.class);
        fillButtonWithAppearance(button, FileDownloadButtonAppearance.REPORT_FILE);
        button.setAction(new BaseAction("simple-report-download-action").withHandler((actionPerformedEvent) -> {
            ByteArrayOutputStream outputStream = simpleReportGenerationService
                    .generate(cls, simpleReportDataConfiguration, simpleReportRenderConfiguration);
            downloader.download(outputStream.toByteArray(),"Отчет.xlsx", DownloadFormat.XLSX);
            try {
                outputStream.close();
            } catch (IOException e) {
                throw new RuntimeException("Error downloading report file", e);
            }
        }));
        return button;
    }

    private void fillButtonWithAppearance(Button button, FileDownloadButtonAppearance appearance){
        button.setIcon(appearance.getIcon().source());
        button.setCaption(appearance.getCaption());
    }

    // кнопка скачивания существующего в файловой системе файла
    public Button createForExistingFileDownload(FileRef fileRef, Downloader downloader) {
        Button button = uiComponents.create(Button.class);
        button.setCaption("Скачать");
        button.setIconFromSet(JmixIcon.DOWNLOAD);

        button.setAction(new BaseAction("download-report-bundle").withHandler(actionPerformedEvent -> {
            downloader.download(fileRef);
        }));

        return button;
    }
}
