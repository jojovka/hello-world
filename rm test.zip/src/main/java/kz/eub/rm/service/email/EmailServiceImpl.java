package kz.eub.rm.service.email;

import io.jmix.email.EmailException;
import io.jmix.emailtemplates.EmailTemplates;
import io.jmix.emailtemplates.exception.ReportParameterTypeChangedException;
import io.jmix.emailtemplates.exception.TemplateNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class EmailServiceImpl implements EmailService{
    private static final Logger log = LoggerFactory.getLogger(EmailServiceImpl.class);
    @Autowired
    private EmailTemplates emailTemplates;


    @Override
    public void sendEmail(EmailMessageTemplate emailMessageTemplate, String recipients, Map<String, Object> parameters) throws TemplateNotFoundException, EmailException, ReportParameterTypeChangedException {
        log.info("sending email from template {} to {}.......", emailMessageTemplate.getTemplateCode(), recipients);
        emailTemplates
                .buildFromTemplate(emailMessageTemplate.getTemplateCode()).setTo(recipients)
                .setBodyParameters(parameters)
                .sendEmail();
        log.info("email from template {} has been sent to {} successfully", emailMessageTemplate.getTemplateCode(), recipients);
    }
}

