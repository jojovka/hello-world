package kz.eub.rm.service;

import io.jmix.core.DataManager;
import kz.eub.rm.entity.PnzRunHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Date;
import java.util.List;

@Component("rm_PnzRunHistoryService")
public class PnzRunHistoryService implements RunHistoryService<PnzRunHistory> {
    @Autowired
    private DataManager dataManager;
    @PersistenceContext(unitName = "dwhstore")
    private EntityManager entityManager;

    @Override
    @Transactional("dwhstoreTransactionManager")
    public List<Integer> getRunNumbersForReportDate(Date reportDate) {
        return (List<Integer>) entityManager
                .createNativeQuery("select prh_run_number from dwh_risk.pnz_run_history2 where prh_report_date = ? order by prh_creation_date desc")
                .setParameter(1, reportDate)
                .getResultList();
    }

    @Override
    @Transactional("dwhstoreTransactionManager")
    public String getRunId(Date reportDate, Integer runNumber) {
        return (String) entityManager
                .createNativeQuery("select prh_run_id from dwh_risk.pnz_run_history2 where prh_report_date = ? and prh_run_number = ?")
                .setParameter(1, reportDate)
                .setParameter(2, runNumber)
                .getSingleResult();
    }

    @Override
    public String getIdOfLatestRun() {
        return (String) entityManager
                .createNativeQuery("select prh_run_id from dwh_risk.pnz_run_history2 order by prh_creation_date desc limit 1")
                .getSingleResult();
    }

    @Override
    public PnzRunHistory getLatestRun() {
        return dataManager.load(PnzRunHistory.class)
                .query("select e from rm_PnzRunHistory e order by e.creationDate desc")
                .maxResults(1).optional().orElse(null);
    }
}
