package kz.eub.rm.service;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.data.Sequence;
import io.jmix.data.Sequences;
import io.jmix.email.EmailException;
import io.jmix.emailtemplates.EmailTemplates;
import io.jmix.emailtemplates.exception.ReportParameterTypeChangedException;
import io.jmix.emailtemplates.exception.TemplateNotFoundException;
import kz.eub.rm.entity.Application;
import kz.eub.rm.entity.EApplicationStatus;
import kz.eub.rm.entity.User;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.runtime.ProcessInstance;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ApplicationGenericService<T extends Application> {

    private static final Logger log = org.slf4j.LoggerFactory.getLogger(ApplicationGenericService.class);
    private final Class<T> type;

    public ApplicationGenericService(Class<T> type) {
        this.type = type;
    }

    public static final String STATUS_UPDATE_EMAIL_NOTIF_TEMPL_CODE = "application-status-update";

    @Autowired
    private DataManager dataManager;
    @Autowired
    protected RuntimeService runtimeService;
    @Autowired
    private Sequences sequences;
    @Autowired
    private EmailTemplates emailTemplates;


    public String getApplicationSN() {
        long sn = sequences.createNextValue(Sequence.withName(Application.SEQUENCE_NAME));
        return String.format("%06d", sn);
    }

    public ProcessInstance startNewApplicationProcess(T application, String processDefinitionKey, Map<String, Object> variables) {
        if (variables == null)
            variables = new HashMap<>();
        variables.put("application", application);
        User employee = application.getAuthor();
        variables.put("employee", employee);
        variables.put("info", application.getInfo());
        ProcessInstance processInstance = runtimeService.startProcessInstanceByKey(
                processDefinitionKey,
                application.getSn(),
                variables);
        application.setProcId(processInstance.getId());
        updateApplicationProcId(application, processInstance);
        return processInstance;
    }

    private void updateApplicationProcId(T application, ProcessInstance procInstance) {
        application = reloadApplication(application);
        application.setProcId(procInstance.getId());
        dataManager.save(application);
    }

    public T updateStatus(T application, EApplicationStatus status) {
        if (application == null)
            throw new IllegalArgumentException("Заявка пустая...");
        if (status == null)
            throw new IllegalArgumentException("Передан пустой статус.");
        application = reloadApplication(application);
        if (application.getStatus() == null
                || !application.getStatus().equals(status)) {
            application.setStatus(status);
            application = dataManager.save(application);
            notifyEmployeeByEmailTemplate(application, application.getAuthor(), STATUS_UPDATE_EMAIL_NOTIF_TEMPL_CODE);
        }
        return application;
    }

    public T updateStatus(T application, String statusStr) {
        if (statusStr == null)
            throw new IllegalArgumentException("Передан пустой статус.");
        EApplicationStatus status = EApplicationStatus.fromId(statusStr);
        return updateStatus(application, status);
    }

    public T reloadApplication(T application) {
        if (application == null
                || application.getId() == null) return null;
        application = dataManager.load(type)
                .id(application.getId())
                .one();
        return application;
    }

    public T reloadApplication(T application, FetchPlan fetchPlan) {
        if (application == null
                || application.getId() == null) return null;
        application = dataManager.load(type)
                .id(application.getId())
                .fetchPlan(fetchPlan)
                .one();
        return application;
    }

    public void notifyEmployeeByEmailTemplate(T application, User employee, String templateCode) {
        Map<String, Object> params = new HashMap<>();
        params.put(Application.BPM_VARIABLE_NAME, application);
        params.put("employee", employee);
        params.put("status", application.getStatus());
        sendEmailTemplateWithParams(templateCode, employee.getEmail(), params);
    }

    private void sendEmailTemplateWithParams(String templateCode, String recipients, Map<String, Object> params) {
        try {
            emailTemplates.buildFromTemplate(templateCode)
                    .setTo(recipients)
                    .setBodyParameters(params)
                    .sendEmail();
        } catch (TemplateNotFoundException e) {
            throw new RuntimeException("Шаблон письма не найден: ", e);
        } catch (ReportParameterTypeChangedException e) {
            throw new RuntimeException("Тип параметра отчета изменен: ", e);
        } catch (EmailException e) {
            log.error("Ошибка при попытке отправить письмо: ", e);
        }
    }

    public T reloadApplication(UUID id) {
        return dataManager.load(type)
                .id(id)
                .optional().orElse(null);
    }

}