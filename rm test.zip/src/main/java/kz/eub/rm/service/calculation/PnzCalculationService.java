package kz.eub.rm.service.calculation;

import io.jmix.core.security.SystemAuthenticator;
import kz.eub.rm.service.UserService;
import kz.eub.rm.service.email.EmailService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

public class PnzCalculationService extends AbstractCalculationService {
    private static final Logger log = LoggerFactory.getLogger(PnzCalculationService.class);
    public PnzCalculationService(
            EntityManager entityManager,
            EntityManagerFactory entityManagerFactory,
            UserService userService,
            EmailService emailService,
            SystemAuthenticator systemAuthenticator
    ) {
        super(log, entityManager, entityManagerFactory, userService, emailService, systemAuthenticator);
    }

    @Override
    protected String getPrepareReportProcedureQuery() {
        return "select dwh_risk.pnz_prepare_report(?,?)";
    }

    @Override
    protected String getProcessReportProcedureQuery() {
        return "select dwh_risk.pnz_process_report(?)";
    }

    @Override
    protected String getSaveErrorQuery() {
        return "update dwh_risk.pnz_run_history2 set prh_error_text=? where prh_run_id=?";
    }

    @Override
    protected String getApproveReportQuery() {
        return "select dwh_risk.pnz_approve_report(?)";
    }

    @Override
    protected String getIsAllowedToApproveQuery() {
        return "select case when rh.prh_is_approved = false " +
                        "and not exists " +
                        "(select 1 from dwh_risk.pnz_run_history2 rh2 " +
                        "where date_trunc('month', rh2.prh_report_date) = date_trunc('month', rh.prh_report_date) " +
                        " and rh2.prh_is_approved = true) " +
                        " then true else false end approve_btn_enabled " +
                        " from dwh_risk.pnz_run_history2 rh " +
                        "where rh.prh_id = ?";
    }
}
