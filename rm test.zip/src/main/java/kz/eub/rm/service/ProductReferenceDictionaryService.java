package kz.eub.rm.service;

import kz.eub.rm.entity.dwh.ProductReferenceDictionary;

import java.util.List;


public interface ProductReferenceDictionaryService {
    public List<ProductReferenceDictionary> getAllDataWithFetchedChildNames();
}
