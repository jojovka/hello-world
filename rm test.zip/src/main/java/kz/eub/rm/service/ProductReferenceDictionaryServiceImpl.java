package kz.eub.rm.service;

import kz.eub.rm.entity.dwh.ProductReferenceDictionary;
import org.eclipse.persistence.config.QueryHints;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
public class ProductReferenceDictionaryServiceImpl implements ProductReferenceDictionaryService{
    @PersistenceContext(unitName = "dwhstore")
    protected EntityManager entityManager;

    @Override
    @Transactional("dwhstoreTransactionManager")
    public List<ProductReferenceDictionary> getAllDataWithFetchedChildNames() {
        return ((Stream<Object[]>)(entityManager
                .createNativeQuery("select " +
                        "pr.prd$id as prdId," + //0
                        " pr.prd$start_date as startDate," + //1
                        " pr.prd$end_date as endDate," + //2
                        " pr.prd$change_date as changeDate," + //3
                        " pr.prd$row_status as rowStatus," + //4
                        " pr.prd$source as prdSource," + //5
                        " pr.prd$source_pk as prdSourcePk," + //6
                        " pr.prd$audit_id as auditId," + //7
                        " pr.prd_gid as prdGid," + //8
                        " pr.prd_prnt_prd_gid as prntPrdGid," + //9
                        " pr.prd_code as code," + //10
                        " pr.prd_name as name," + //11
                        " pr.prd_cur_cd as curCd," + //12
                        " pr.prd_term as term," + //13
                        " pr.prd_prol_count as prolCount," + //14
                        " pr.prd_category as category," + //15
                        " pr.prd_subproduct as subProduct," + //16
                        " pr.prd_deal_type as dealType" + //17
                        " from dwh_dds.ref_product as pr")
                .setHint(QueryHints.JDBC_FETCH_SIZE, 1000000)
                .getResultStream())).map(v -> {
                    ProductReferenceDictionary productReferenceDictionary = new ProductReferenceDictionary();
                    productReferenceDictionary.setPrdId((Long) v[0]);
                    productReferenceDictionary.setStartDate((Date) v[1]);
                    productReferenceDictionary.setEndDate((Date) v[2]);
                    productReferenceDictionary.setChangeDate((Date) v[3]);
                    productReferenceDictionary.setRowStatus((String) v[4]);
                    productReferenceDictionary.setPrdSource((String) v[5]);
                    productReferenceDictionary.setPrdSourcePk((Integer) v[6]);
                    productReferenceDictionary.setAuditId((Integer) v[7]);
                    productReferenceDictionary.setPrdGid((Long) v[8]);
                    productReferenceDictionary.setPrntPrdGid((Long) v[9]);
                    productReferenceDictionary.setCode((String) v[10]);
                    productReferenceDictionary.setName((String) v[11]);
                    productReferenceDictionary.setCurCd((Long) v[12]);
                    productReferenceDictionary.setTerm((Integer) v[13]);
                    productReferenceDictionary.setProlCount((Integer) v[14]);
                    productReferenceDictionary.setCategory((String) v[15]);
                    productReferenceDictionary.setSubProduct((String) v[16]);
                    productReferenceDictionary.setDealType((String) v[17]);
                    return productReferenceDictionary;
                })
                .collect(Collectors.toList());
    }
}
