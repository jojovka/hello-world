package kz.eub.rm.service.calculation;

import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Date;

@Component
public class PnzDrPdCalculationServiceImpl implements PnzDrPdCalculationService{
    @PersistenceContext(unitName = "dwhstore")
    private EntityManager entityManager;

    @Override
    public void runCalculation(String username, Date dateFrom, Date dateTo) {
        entityManager
                .createNativeQuery("select dwh_risk.pnz_pd_process(?,?,?)")
                .setParameter(1,username)
                .setParameter(2,dateFrom)
                .setParameter(3,dateTo)
                .getSingleResult();
    }
}
