package kz.eub.rm.service.calculation;

import java.util.Date;

public interface PnzDrPdCalculationService {
    void runCalculation(String username, Date dateFrom, Date dateTo);
}
