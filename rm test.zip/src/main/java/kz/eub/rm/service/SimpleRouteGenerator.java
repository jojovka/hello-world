package kz.eub.rm.service;

public interface SimpleRouteGenerator {
    String generateForEditor(Object entity);

    String generateForBrowse(Object entity);
}
