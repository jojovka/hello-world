package kz.eub.rm.service;

import kz.eub.rm.entity.PnzPledge;
import kz.eub.rm.util.ExtractorCounter;
import org.eclipse.persistence.config.QueryHints;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class PnzPledgeServiceImpl implements PnzPledgeService{

    @Autowired
    @Qualifier("dwhstoreJdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<PnzPledge> getAllData() {
        return jdbcTemplate.query("SELECT \n" +
                "pc_report_date,\n" +
                "pc_id, \n" +
                "pc_dog_num,\n" +
                "pc_cur_code,\n" +
                "pc_clnt_name,\n" +
                "pc_cli_iin_bin,\n" +
                "pc_dprt_name,\n" +
                "dlpled_gid,\n" +
                "dlpled_dog_num,\n" +
                "dlpled_open_date,\n" +
                "dlpled_cur_cd,\n" +
                "clnt_full_name, \n" +
                "clnt_iin_bin, \n" +
                "lr_typename,\n" +
                "kind_ens,\n" +
                "date_nok,\n" +
                "price_ens,\n" +
                "price_kzt_ens,\n" +
                "date_mon,\n" +
                "dlpled_price,\n" +
                "dlpled_price_nat,\n" +
                "al_price,\n" +
                "coeff,\n" +
                "dlpled_status,\n" +
                "pc_state\n" +
                "FROM dwh_risk.pnz_pledges_view", new BeanPropertyRowMapper<PnzPledge>(PnzPledge.class));
    }
}
