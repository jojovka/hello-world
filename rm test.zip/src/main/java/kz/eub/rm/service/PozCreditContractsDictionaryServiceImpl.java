package kz.eub.rm.service;

import kz.eub.rm.entity.dwh.CreditContractsDictionary;
import kz.eub.rm.util.ExtractorCounter;
import org.eclipse.persistence.config.QueryHints;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
public class PozCreditContractsDictionaryServiceImpl implements PozCreditContractsDictionaryService {
//    @Autowired
//    @Qualifier("dwhstoreJdbcTemplate")
//    private JdbcTemplate jdbcTemplate;

    @PersistenceContext(unitName = "dwhstore")
    protected EntityManager entityManager;

//    @Override
//    public List<CreditContractsDictionary> getAllDataWithFetchedChildNames(String runId) {
//        String optionalFilterQueryPart = runId!=null?String.format("where cs_run_id='%s'",runId):"";
//        return jdbcTemplate.query("SELECT c_report_date," +
//                " c_source, " +
//                "c_id," +
//                " c_dog_num, " +
//                "transh," +
//                " c_cur_code," +
//                " c_dprt_name," +
//                " c_clnt_name, " +
//                "c_cgrp_name," +
//                " c_out_sum_od," +
//                " c_out_sum_od_delay," +
//                " c_out_sum_perc," +
//                " c_out_sum_perc_delay," +
//                " c_out_sum_perc_od," +
//                " c_out_sum_com," +
//                " c_out_sum_com_delay," +
//                " c_out_sum_pen_kzt," +
//                " c_out_sum_msfo_per," +
//                " c_out_sum_neg_corr, " +
//                "c_out_sum_dis_1434," +
//                " c_out_sum_dis_2794," +
//                " c_out_sum_corr_esp, " +
//                "c_out_sum_dev," +
//                " c_out_sum_mod_1435, " +
//                "c_out_sum_od_odd, " +
//                "c_out_sum_all_debt, " +
//                "c_msfo_rate, " +
//                "c_out_sum_msfo_1428, " +
//                "c_out_sum_prov_com_1845, " +
//                "c_out_sum_prov_1877_kzt, " +
//                "c_out_sum_debt_1860_kzt, " +
//                "c_out_sum_kik, " +
//                "c_out_sum_dz_1877_kzt, " +
//                "c_out_sum_od_odd_mon_beg, " +
//                "c_out_sum_all_debt_mon_beg, " +
//                "c_out_sum_reser_kzt, " +
//                "c_out_sum_outsys, " +
//                "c_out_sum_outsys_sum, " +
//                "c_out_sum_lesion, " +
//                "c_cr_rate_month_beg, " +
//                "c_cr_rate_rep_date, " +
//                "c_prod_name, " +
//                "c_tarif, " +
//                "cs_is_uniform, " +
//                "cs_poz_name, " +
//                "c_user_cred_type, " +
//                "c_cli_iin_bin, " +
//                "c_cli_type, " +
//                "c_sd_cd, " +
//                "c_kod_ip, " +
//                "c_exp_days, " +
//                "c_exp_days_op_perc, " +
//                "c_open_date, " +
//                "c_paym_date, " +
//                "c_oked, " +
//                "c_cli_oked_cd, " +
//                "c_problem, " +
//                "c_class, " +
//                "c_modif, " +
//                "c_mod_date, " +
//                "c_basket_mon_beg, " +
//                "cs_basket_rep_date," +
//                " c_rate, " +
//                "c_eff_rate, " +
//                "cs_trg_2, " +
//                "cs_trg_3, " +
//                "cs_trg_4, " +
//                "cs_recovery_ready, " +
//                "cs_default_date, " +
//                "cs_recovery_date, " +
//                "c_non_market_fl, " +
//                "c_all_sum, " +
//                "c_control_list, " +
//                "c_state, " +
//                "cs_run_id, " +
//                "cs_uuid, " +
//                "cs_segment, " +
//                "c_credit_dep, " +
//                "c_creditsum_kzt, " +
//                "c_duration, " +
//                "cs_segment_prov, " +
//                "cs_pd12ol, " +
//                "cs_pdltol, " +
//                "cs_pd12, " +
//                "cs_pdlt, " +
//                "cs_lgd " +
//                " FROM dwh_risk.credits_view " + optionalFilterQueryPart, new BeanPropertyRowMapper<CreditContractsDictionary>(CreditContractsDictionary.class));
//    }

    @Override
    @Transactional("dwhstoreTransactionManager")
    public List<CreditContractsDictionary> getAllDataWithFetchedChildNames(String runId) {
        String optionalFilterQueryPart = runId != null ? String.format("where cs_run_id='%s'", runId) : "";
        return ((Stream<Object[]>) (entityManager
                .createNativeQuery(
                        "SELECT c_report_date," +
                                " c_source, " +
                                "c_id," +
                                " c_dog_num, " +
                                "transh," +
                                " c_cur_code," +
                                " c_dprt_name," +
                                " c_clnt_name, " +
                                "c_cgrp_name," +
                                " c_out_sum_od," +
                                " c_out_sum_od_delay," +
                                " c_out_sum_perc," +
                                " c_out_sum_perc_delay," +
                                " c_out_sum_perc_od," +
                                " c_out_sum_com," +
                                " c_out_sum_com_delay," +
                                " c_out_sum_pen_kzt," +
                                " c_out_sum_msfo_per," +
                                " c_out_sum_neg_corr, " +
                                "c_out_sum_dis_1434," +
                                " c_out_sum_dis_2794," +
                                " c_out_sum_corr_esp, " +
                                "c_out_sum_dev," +
                                " c_out_sum_mod_1435, " +
                                "c_out_sum_od_odd, " +
                                "c_out_sum_all_debt, " +
                                "c_msfo_rate, " +
                                "c_out_sum_msfo_1428, " +
                                "c_out_sum_prov_com_1845, " +
                                "c_out_sum_prov_1877_kzt, " +
                                "c_out_sum_debt_1860_kzt, " +
                                "c_out_sum_kik, " +
                                "c_out_sum_dz_1877_kzt, " +
                                "c_out_sum_od_odd_mon_beg, " +
                                "c_out_sum_all_debt_mon_beg, " +
                                "c_out_sum_reser_kzt, " +
                                "c_out_sum_outsys, " +
                                "c_out_sum_outsys_sum, " +
                                "c_out_sum_lesion, " +
                                "c_cr_rate_month_beg, " +
                                "c_cr_rate_rep_date, " +
                                "c_prod_name, " +
                                "c_tarif, " +
                                "cs_is_uniform, " +
                                "cs_poz_name, " +
                                "c_user_cred_type, " +
                                "c_cli_iin_bin, " +
                                "c_cli_type, " +
                                "c_sd_cd, " +
                                "c_kod_ip, " +
                                "c_exp_days, " +
                                "c_exp_days_op_perc, " +
                                "c_open_date, " +
                                "c_paym_date, " +
                                "c_oked, " +
                                "c_cli_oked_cd, " +
                                "c_problem, " +
                                "c_class, " +
                                "c_modif, " +
                                "c_mod_date, " +
                                "c_basket_mon_beg, " +
                                "cs_basket_rep_date," +
                                " c_rate, " +
                                "c_eff_rate, " +
                                "cs_trg_2, " +
                                "cs_trg_3, " +
                                "cs_trg_4, " +
                                "cs_recovery_ready, " +
                                "cs_default_date, " +
                                "cs_recovery_date, " +
                                "c_non_market_fl, " +
                                "c_all_sum, " +
                                "c_control_list, " +
                                "c_state, " +
                                "cs_run_id, " +
                                "cs_uuid, " +
                                "cs_segment, " +
                                "c_credit_dep, " +
                                "c_creditsum_kzt, " +
                                "c_duration, " +
                                "cs_segment_prov, " +
                                "cs_pd12ol, " +
                                "cs_pdltol, " +
                                "cs_pd12, " +
                                "cs_pdlt, " +
                                "cs_lgd " +
                                " FROM dwh_risk.credits_view " + optionalFilterQueryPart)
                .setHint(QueryHints.JDBC_FETCH_SIZE, 250000)
                .getResultStream())).parallel().map(v -> mapToDictionaryRecord(v))
                .collect(Collectors.toList());
    }


    protected CreditContractsDictionary mapToDictionaryRecord(Object[] rawObjects) {
        ExtractorCounter c = new ExtractorCounter();
        CreditContractsDictionary creditContractsDictionary = new CreditContractsDictionary();
        creditContractsDictionary.setCReportDate((Date) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCSource((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCId((Integer) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCDogNum((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setTransh((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCCurCode((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCDprtName((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCClntName((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCCgrpName((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumOd((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumOdDelay((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumPerc((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumPercDelay((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumPercOd((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumCom((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumComDelay((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumPenKzt((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumMsfoPer((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumNegCorr((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumDis1434((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumDis2794((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumCorrEsp((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumDev((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumMod1435((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumOdOdd((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumAllDebt((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCMsfoRate((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumMsfo1428((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumProvCom1845((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumProv1877Kzt((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumDebt1860Kzt((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumKik((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumDz1877Kzt((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumOdOddMonBeg((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumAllDebtMonBeg((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumReserKzt((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumOutsys((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumOutsysSum((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOutSumLesion((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCCrRateMonthBeg((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCCrRateRepDate((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCProdName((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCTarif((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setIsUniform((Integer) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setPozName((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCUserCredType((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCCliIinBin((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCCliType((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCSdCd((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCKodIp((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCExpDays((Integer) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCExpDaysOpPerc((Integer) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOpenDate((Date) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCPaymDate((Date) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCOked((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCCliOkedCd((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCProblem((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCClass((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCModif((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCModDate((Date) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCBasketMonBeg((Integer) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setBasketOnReportDate((Integer) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCRate((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCEffRate((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setTrigger2((Boolean) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setTrigger3((Boolean) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setTrigger4((Boolean) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setRecoveryReady((Boolean) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setDefaultDate((java.util.Date) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setRecoveryDate((java.util.Date) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCNonMarketFl((Boolean) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCAllSum((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCControlList((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCState((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setRunId((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setUuid((UUID) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setSegment((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCreditDepartmentCode((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCreditSumKzt((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setDuration((Integer) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCsSegmentProv((String) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCsPd12ol((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCsPdltol((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCsPd12((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCsPdlt((BigDecimal) c.getWithCounterIncrease(rawObjects));
        creditContractsDictionary.setCsLgd((BigDecimal) c.getWithCounterIncrease(rawObjects));
        return creditContractsDictionary;
    }
}
