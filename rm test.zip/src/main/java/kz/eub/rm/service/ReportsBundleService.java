package kz.eub.rm.service;

import com.haulmont.yarg.reporting.ReportOutputDocument;
import kz.eub.rm.entity.User;

import java.util.Date;
import java.util.List;
import java.util.UUID;

public interface ReportsBundleService {
    void saveReportsAsZipBundle(List<ReportOutputDocument> documents, UUID reportsBundleId);

    void removeAll();
}
