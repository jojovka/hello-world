package kz.eub.rm.service.constant;

public class SessionDataKey {
    public static final String PNZ_RUN_KEY = "PNZ_RUN";
    public static final String POZ_RUN_KEY = "POZ_RUN";
}
