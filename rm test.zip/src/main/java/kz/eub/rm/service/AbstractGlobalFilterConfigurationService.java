package kz.eub.rm.service;

import io.jmix.core.DataManager;
import io.jmix.core.session.SessionData;
import kz.eub.rm.entity.dwh.HasId;


public abstract class AbstractGlobalFilterConfigurationService <T extends HasId> {

    private final SessionData sessionData;

    private final DataManager dataManager;

    private final Class<T> type;

    private final String attributeKey;

    public  AbstractGlobalFilterConfigurationService(SessionData sessionData, DataManager dataManager, Class<T> type, String attributeKey) {
        this.sessionData = sessionData;
        this.dataManager = dataManager;
        this.type = type;
        this.attributeKey = attributeKey;
    }

    public void setCurrent(T runHistory) {
        sessionData.setAttribute(attributeKey, runHistory);
    }

    public T reloadCurrent() {
        T current = (T) sessionData.getAttribute(attributeKey);
        if (current != null){
            try {
                sessionData.setAttribute(attributeKey, dataManager.load(type).id(current.getId()).one());
            } catch (IllegalStateException e) {
                sessionData.setAttribute(attributeKey, null);
                return null;
            }
        }
        return current;
    }

    public T getCurrent() {
        return (T) sessionData.getAttribute(attributeKey);
    }
}
