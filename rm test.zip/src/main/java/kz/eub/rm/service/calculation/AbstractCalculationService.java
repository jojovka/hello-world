package kz.eub.rm.service.calculation;

import io.jmix.core.security.SystemAuthenticator;
import kz.eub.rm.service.UserService;
import kz.eub.rm.service.constant.RunCalculationResultCode;
import kz.eub.rm.service.dto.CalculationLaunchResult;
import kz.eub.rm.service.email.EmailMessageTemplate;
import kz.eub.rm.service.email.EmailService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Supplier;

public abstract class AbstractCalculationService {
    private static final String CALCULATION_IN_PROGRESS_CODE = "OK";
    private static final String CALCULATION_SUCCESS_CODE = "DONE";
    private static final int CALCULATION_STEPS_CRITICAL_LIMIT = 100;
    private static final int CALCULATION_STEPS_NORMAL_LIMIT = 10;

    private final Logger log;

    private final EntityManager entityManager;

    private final EntityManagerFactory entityManagerFactory;

    private final UserService userService;

    private final EmailService emailService;

    
    private final SystemAuthenticator systemAuthenticator;

    AbstractCalculationService(
            Logger  log,
            EntityManager entityManager,
            EntityManagerFactory entityManagerFactory,
            UserService userService,
            EmailService emailService,
            SystemAuthenticator systemAuthenticator
    ) {
        this.log = log;
        this.entityManager = entityManager;
        this.entityManagerFactory = entityManagerFactory;
        this.userService = userService;
        this.emailService = emailService;
        this.systemAuthenticator = systemAuthenticator;
    }

    public CalculationLaunchResult runCalculation(Date date, Supplier<List<Object>> parametersAdjustmentSupplier) {
        ExecutorService singleThreadExecutor = Executors.newSingleThreadExecutor();
        String username = userService.getCurrentUser().getUsername();

        //запуск подготовительной функции перед началом расчета
        CalculationLaunchResult calculationLaunchResult = new CalculationLaunchResult();
        final List<Object> additionalParameters = parametersAdjustmentSupplier.get();
        String prepareCalculationOperationResult;
        try {
            Query query = entityManager
                    .createNativeQuery(getPrepareReportProcedureQuery())
                    .setParameter(1, date)
                    .setParameter(2, username);

//            int position = query.getParameters().size() + 1;
//            getParameters в реализации jmix кидает UnsupportedOperationException 🤡
//            так что кол-во первоначальных параметров захардкодил
            int position = 3;

            for (Object parameter : additionalParameters) {
                query.setParameter(position, parameter);
                position++;
            }

            log.info("report preparation: started report preparation with parameters date:{},username:{}, additional parameters:{}", date, username, additionalParameters);
            prepareCalculationOperationResult = (String) query.getSingleResult();
        } catch (Exception e) {
            log.error("report preparation: data base error:",e);
            calculationLaunchResult.setAdditionalResultInfo(e.getMessage());
            prepareCalculationOperationResult = RunCalculationResultCode.ERROR;
        }

        if (prepareCalculationOperationResult.startsWith(RunCalculationResultCode.ALREADY_IN_PROGRESS)
                ||prepareCalculationOperationResult.startsWith(RunCalculationResultCode.ERROR)
                ||prepareCalculationOperationResult.startsWith(RunCalculationResultCode.ERROR_LATER_REPORT_EXISTS)) {
            log.error("report preparation: unsuccessful operation: report preparation with parameters date:{},username:{}, additional parameters:{} has ended because of data base exception:{}",
                    date, username, additionalParameters, prepareCalculationOperationResult);
            calculationLaunchResult.setOperationResult(prepareCalculationOperationResult);
            return calculationLaunchResult;
        }

        calculationLaunchResult.setOperationResult(RunCalculationResultCode.PREPARE_SUCCESS);
        calculationLaunchResult.setAdditionalResultInfo(prepareCalculationOperationResult);
        log.info("report preparation: successful operation: prepared report with runId {}", prepareCalculationOperationResult);

        //запуск автономного потока, который проходит последовательные шаги расчета, вызывая функцию запуска шага расчета
        String runId = prepareCalculationOperationResult;
        final String email = new String(userService.getCurrentUser().getEmail());
        singleThreadExecutor.submit(() -> {
            log.info("calculation: started calculation with parameters runId:{}, date:{}, username:{}, additional parameters:{}",runId, date, username, additionalParameters);
            int i = 0;
            boolean isNoDatabaseExceptionsOccurred = true;
            for (; i < CALCULATION_STEPS_CRITICAL_LIMIT && isNoDatabaseExceptionsOccurred; i++) {
                try {
                    String result = (String) entityManager
                            .createNativeQuery(getProcessReportProcedureQuery())
                            .setParameter(1, runId)
                            .getSingleResult();
                    log.info("calculation: in progress: calculation with runId {}, executed step {}, status code {}", runId, i+1, result);
                    if (result.equals(CALCULATION_SUCCESS_CODE)) {
                        break;
                    } else if (!result.equals(CALCULATION_IN_PROGRESS_CODE)) {
                        log.error(String.format("calculation: unsuccessful operation: calculation with runId:%s, has failed on step:%s, error message:%s", runId, i + 1, result));
                        isNoDatabaseExceptionsOccurred=false;
                        sendCalculationResultEmail(email, runId, "Расчет завершился ошибкой");
                        break;
                    }
                } catch (Exception e) {
                    //сохраенение текста ошибки в запись в истории запусков (необходимо для пометки запуска, как завершившегося ошибкой)
                    log.error(String.format("calculation: unsuccessful operation: calculation with runId:%s has failed on step:%s with error message:%s", runId, i + 1, e.getMessage()));
                    isNoDatabaseExceptionsOccurred=false;
                    try {
                        saveError(e.getMessage(), runId);
                    } catch (Exception saveErrorException) {
                        log.error("save error exception ",saveErrorException);
                    }
                    sendCalculationResultEmail(email, runId, String.format("Расчет завершился ошибкой %s", e.getMessage()));
                }
            }
            if (isNoDatabaseExceptionsOccurred) {
                if (i == CALCULATION_STEPS_CRITICAL_LIMIT) {
                    log.error("calculation: operation with runId {} reached step {}", runId, i);
                    log.error("calculation: unsuccessful operation: calculation calculation with parameters date:{},username:{}, additional parameters:{} ran out of steps",
                            date, username, additionalParameters);
                    try {
                        saveError(String.format("calculation ran out of steps: %s while %s is limit",i,CALCULATION_STEPS_CRITICAL_LIMIT), runId);
                    } catch (Exception saveErrorException) {
                        log.error("save error exception ",saveErrorException);
                    }
                    sendCalculationResultEmail(email, runId, String.format("Расчет завершился ошибкой: превышен лимит шагов %s", CALCULATION_STEPS_CRITICAL_LIMIT));
                    throw new RuntimeException("calculation ran out of steps");
                } else if (i >= CALCULATION_STEPS_NORMAL_LIMIT) {
                    log.warn("calculation: operation with runId {} took more steps than expected, number of steps was {}, while normal is {}", runId, i+1, CALCULATION_STEPS_NORMAL_LIMIT);
                } else {
                    log.info("calculation: operation with runId {} has been successfully ended with {} steps", runId, i+1);
                }
                sendCalculationResultEmail(email, runId, "Расчет успешно завершен");
                log.info("calculation: successful operation: calculation with parameters date:{},username:{}, additional parameters:{} has ended", date, username, additionalParameters);
            }
        });
        return calculationLaunchResult;
    }


    protected void saveError(String errorText, String runId) {
        EntityManager entityManagerForCurrentThread = entityManagerFactory.createEntityManager();

        entityManagerForCurrentThread.getTransaction().begin();
        entityManagerForCurrentThread.createNativeQuery(getSaveErrorQuery())
                .setParameter(1,errorText)
                .setParameter(2,runId)
                .executeUpdate();
        entityManagerForCurrentThread.getTransaction().commit();
    }

    private void sendCalculationResultEmail(final String email, String runId, String result) {
        systemAuthenticator.withSystem(() -> {
            Map<String, Object> params = new HashMap<>();
            params.put("runId", runId);
            params.put("result", result);
            try {
                emailService.sendEmail(EmailMessageTemplate.CALCULATION_RESULT_TEMPLATE, email, params);
            } catch (Exception e) {
                log.error("failed to send notification email for calculation with runId:{}", runId);
                log.error(e.getMessage());
            }
            return null;
        });
    }

    public void approveCalculation(String runId) {
        ExecutorService singleThreadExecutor = Executors.newSingleThreadExecutor();
        singleThreadExecutor.submit(() -> {
            log.info("started approval for calculation with runId {}", runId);
            entityManager
                    .createNativeQuery(getApproveReportQuery())
                    .setParameter(1, runId)
                    .getSingleResult();
            log.info("approval for calculation with runId {} has ended", runId);
        });
    }

    public boolean isAllowedToApproveCalculation(UUID uuid) {
        return (boolean) entityManager.createNativeQuery(getIsAllowedToApproveQuery())
                .setParameter(1, uuid)
                .getSingleResult();
    }

    protected abstract String getPrepareReportProcedureQuery();

    protected abstract String getProcessReportProcedureQuery();

    protected abstract String getSaveErrorQuery();

    protected abstract String getApproveReportQuery();

    protected abstract String getIsAllowedToApproveQuery();
}
