package kz.eub.rm.service;

import kz.eub.rm.entity.dwh.PozDictionary;
import kz.eub.rm.entity.dwh.PozMappingDictionary;
import org.eclipse.persistence.config.QueryHints;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
public class PozMappingDictionaryServiceImpl implements PozMappingDictionaryService{
    @PersistenceContext(unitName = "dwhstore")
    protected EntityManager entityManager;

    @Override
    @Transactional("dwhstoreTransactionManager")
    public List<PozMappingDictionary> getAllDataWithFetchedChildNames() {
        return ((Stream<Object[]>)(entityManager
                .createNativeQuery("select " +
                        "pm.sdspm$change_date as changeDate," + //0
                        " pm.sdspm_prod_name as prodName," + //1
                        " poz.sdsp_poz_name as pozName," + //2
                        " pozFRPC.sdsp_poz_name as pozForReservePercentCalculationName" + //3
                        " from dwh_risk.s00_dict_snp_poz_mapping as pm" +
                        " left join dwh_risk.s00_dict_snp_poz as poz on poz.sdsp_uuid=pm.sdspm_poz_uuid" +
                        " left join dwh_risk.s00_dict_snp_poz as pozFRPC on pozFRPC.sdsp_uuid=pm.sdspm_poz_uuid_2")
                .setHint(QueryHints.JDBC_FETCH_SIZE, 1000000)
                .getResultStream())).map(v -> {
                    PozMappingDictionary pozMappingDictionary = new PozMappingDictionary();
                    pozMappingDictionary.setChangeDate((Date) v[0]);
                    pozMappingDictionary.setProdName((String) v[1]);
                    PozDictionary pozDictionary = new PozDictionary();
                    pozDictionary.setPozName((String) v[2]);
                    pozMappingDictionary.setSdspId(pozDictionary);
                    PozDictionary pozForReservePercentCalculation = new PozDictionary();
                    pozForReservePercentCalculation.setPozName((String) v[3]);
                    pozMappingDictionary.setPozForReservePercentCalculation(pozForReservePercentCalculation);
                    return pozMappingDictionary;
                })
                .collect(Collectors.toList());
    }

    @Override
    @Transactional("dwhstoreTransactionManager")
    public Long getAmountOfNonFilledRows() {
        return (Long) entityManager
                .createNativeQuery("select count(*) from dwh_risk.s00_dict_snp_poz_mapping where date_trunc('day',sdspm_load_date)=current_date and (sdspm_poz_uuid is null or sdspm_poz_uuid_2 is null)")
                .getSingleResult();
    }
}
