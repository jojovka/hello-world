package kz.eub.rm.service;

import kz.eub.rm.entity.dwh.PnzCredit;

import java.util.List;

public interface PnzCreditService {
    List<PnzCredit> getAllData();
}
