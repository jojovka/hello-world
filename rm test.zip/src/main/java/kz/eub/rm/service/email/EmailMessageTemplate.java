package kz.eub.rm.service.email;

public enum EmailMessageTemplate {
    CALCULATION_RESULT_TEMPLATE("calculation-result-message"),
    REPORTS_BUNDLE_GENERATION_FINISHED_TEMPLATE("reports-bundle-generation-finished");

    private String templateCode;

    EmailMessageTemplate(String templateCode){
        this.templateCode = templateCode;
    }

    public String getTemplateCode() {
        return templateCode;
    }
}