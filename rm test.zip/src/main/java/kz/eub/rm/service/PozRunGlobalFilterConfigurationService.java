package kz.eub.rm.service;

import com.vaadin.spring.annotation.UIScope;
import io.jmix.core.DataManager;
import io.jmix.core.session.SessionData;
import kz.eub.rm.entity.RunHistory;
import kz.eub.rm.service.constant.SessionDataKey;
import org.springframework.stereotype.Service;

@Service("PozRunGlobalFilterConfigurationService")
@UIScope
public class PozRunGlobalFilterConfigurationService extends AbstractGlobalFilterConfigurationService<RunHistory> {
    public PozRunGlobalFilterConfigurationService(SessionData sessionData, DataManager dataManager) {
        super(sessionData, dataManager, RunHistory.class, SessionDataKey.POZ_RUN_KEY);
    }
}
