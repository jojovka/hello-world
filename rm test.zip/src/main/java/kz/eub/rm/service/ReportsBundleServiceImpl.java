package kz.eub.rm.service;

import com.haulmont.yarg.reporting.ReportOutputDocument;
import io.jmix.core.*;
import io.jmix.reports.util.ReportZipUtils;
import kz.eub.rm.entity.ReportsBundle;
import kz.eub.rm.entity.ReportsBundleStatus;
import kz.eub.rm.entity.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Component
public class ReportsBundleServiceImpl implements ReportsBundleService {
    Logger log = LoggerFactory.getLogger(ReportsBundleServiceImpl.class);
    @Autowired
    private ReportZipUtils reportZipUtils;
    @Autowired
    private FileStorageLocator fileStorageLocator;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private FetchPlans fetchPlans;

    @Override
    public void saveReportsAsZipBundle(List<ReportOutputDocument> documents, UUID reportsBundleId) {
        ReportsBundle reportsBundle = dataManager.load(ReportsBundle.class).id(reportsBundleId).one();

        byte[] zipBytes = reportZipUtils.createZipArchive(documents);
        FileRef fileRef = fileStorageLocator.getDefault().saveStream(String.format("%s.zip",reportsBundle.getName()), new ByteArrayInputStream(zipBytes));
        log.info("successfully saved archive with name {}.zip",reportsBundle.getName());
        Date generatedDateTime = new Date();

        reportsBundle.setFileRef(fileRef);
        reportsBundle.setGeneratedDateTime(generatedDateTime);
        reportsBundle.setStatus(ReportsBundleStatus.SUCCESS);
        dataManager.save(reportsBundle);

        log.info("created entry for {} in database",reportsBundle.getName());
    }

    @Override
    public void removeAll() {
        List<ReportsBundle> reportsBundles = dataManager.load(ReportsBundle.class)
                .all()
                .fetchPlan(
                        fetchPlans
                                .builder(ReportsBundle.class)
                                .add("id")
                                .build()
                ).list();
        dataManager.remove(reportsBundles);
    }
}
