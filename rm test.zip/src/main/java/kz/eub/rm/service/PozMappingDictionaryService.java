package kz.eub.rm.service;

import kz.eub.rm.entity.dwh.PozMappingDictionary;

import java.util.List;


public interface PozMappingDictionaryService {
    public List<PozMappingDictionary> getAllDataWithFetchedChildNames();

    public Long getAmountOfNonFilledRows();
}
