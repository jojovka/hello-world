package kz.eub.rm.sql.access.function.uuid.generation;

import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.UUID;

@Service("rm_uuidGenerationServicePostgreSQLImpl")
public class UuidGenerationServicePostgreSQLImpl implements UuidGenerationService{
    @PersistenceContext(unitName = "dwhstore")
    private EntityManager entityManager;

    @Override
    public UUID generateBasedOn(Long id) {
        return UUID.fromString(
                entityManager
                        .createNativeQuery(String.format("select uuid_in(md5(%s ::text)::cstring)",id))
                        .getSingleResult()
                        .toString()
        );
    }
}
