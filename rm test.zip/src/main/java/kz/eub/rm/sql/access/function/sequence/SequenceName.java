package kz.eub.rm.sql.access.function.sequence;

public enum SequenceName {
    POZ_MACRO_CORRECT_SEQUENCE("dwh_draft.s00_dict_snp_poz_macrocorrect_seq"),
    PNZ_MACRO_CORRECT_SEQUENCE("dwh_draft.s00_dict_snp_pnz_macrocorrect_seq"),
    ALPHA_COEFFICIENT_SEQUENCE("dwh_draft.s00_dict_snp_alf_seq");

    private final String name;

    SequenceName(String name) {
        this.name = name;
    }

    public String get() {
        return name;
    }
}
