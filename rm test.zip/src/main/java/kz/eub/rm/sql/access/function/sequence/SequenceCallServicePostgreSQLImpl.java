package kz.eub.rm.sql.access.function.sequence;

import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Service("rm_SequenceCallServicePostgreSQLImpl")
public class SequenceCallServicePostgreSQLImpl implements SequenceCallService{
    @PersistenceContext(unitName = "dwhstore")
    private EntityManager entityManager;

    @Override
    public Long getLongFromSequence(SequenceName sequenceName) {
        return Long.parseLong(entityManager
                .createNativeQuery(String.format("select nextval('%s')",sequenceName.get()))
                .getSingleResult().toString());
    }
}
