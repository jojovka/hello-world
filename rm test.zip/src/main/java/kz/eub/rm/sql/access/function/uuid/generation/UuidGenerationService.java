package kz.eub.rm.sql.access.function.uuid.generation;

import java.util.UUID;

public interface UuidGenerationService {
    UUID generateBasedOn(Long id);
}
