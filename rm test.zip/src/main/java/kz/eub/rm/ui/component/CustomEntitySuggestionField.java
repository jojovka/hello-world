package kz.eub.rm.ui.component;

import io.jmix.ui.component.impl.EntitySuggestionFieldImpl;
import io.jmix.ui.executor.BackgroundTask;
import io.jmix.ui.executor.TaskLifeCycle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class CustomEntitySuggestionField<V> extends EntitySuggestionFieldImpl<V> {
    public static final String NAME = "customEntitySuggestionField";
    private static final Logger log = LoggerFactory.getLogger(CustomEntitySuggestionField.class);

    private Consumer<Void> onSearchStart;

    private Consumer<List<V>> onSearchDone;

    private Consumer<Void> onSearchCancelled;
    @Override
    protected BackgroundTask<Long, List<V>> getSearchSuggestionsTask(final String query) {
        if (this.searchExecutor == null)
            return null;

        final SearchExecutor<V> currentSearchExecutor = this.searchExecutor;

        Map<String, Object> params;
        if (currentSearchExecutor instanceof ParametrizedSearchExecutor) {
            params = ((ParametrizedSearchExecutor<?>) currentSearchExecutor).getParams();
        } else {
            params = Collections.emptyMap();
        }

        return new BackgroundTask<Long, List<V>>(0) {
            @Override
            public List<V> run(TaskLifeCycle<Long> taskLifeCycle) throws Exception {
                List<V> result;
                try {
                    taskLifeCycle.publish(0L);
                    result = asyncSearch(currentSearchExecutor, query, params);
                } catch (RuntimeException e) {
                    log.error("Error in async search thread", e);

                    result = Collections.emptyList();
                }

                return result;
            }

            @Override
            public void progress(List<Long> changes) {
                if (onSearchStart!=null) {
                    onSearchStart.accept(null);
                }
            }

            @Override
            public void done(List<V> result) {
                log.debug("Search results for '{}'", query);
                try {
                    if (onSearchDone !=null) {
                        onSearchDone.accept(result);
                    }
                    handleSearchResult(result);
                } catch (RuntimeException e) {
                    log.error("Error while processing search result", e);
                }
            }

            @Override
            public void canceled() {
                if (onSearchCancelled !=null) {
                    onSearchCancelled.accept(null);
                }
            }

            @Override
            public boolean handleException(Exception ex) {
                log.error("Error in async search thread", ex);
                return true;
            }
        };
    }

    public void setOnSearchStart(Consumer<Void> onSearchStart) {
        this.onSearchStart = onSearchStart;
    }

    public void setOnSearchDone(Consumer<List<V>> onSearchDone) {
        this.onSearchDone = onSearchDone;
    }

    public void setOnSearchCancelled(Consumer<Void> onSearchCancelled) {
        this.onSearchCancelled = onSearchCancelled;
    }
}
