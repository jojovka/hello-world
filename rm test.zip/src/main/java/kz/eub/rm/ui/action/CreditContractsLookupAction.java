package kz.eub.rm.ui.action;

import io.jmix.ui.action.ActionType;
import io.jmix.ui.action.entitypicker.EntityLookupAction;
import kz.eub.rm.entity.dwh.CreditContractsDictionary;
import kz.eub.rm.screen.dictionary.credit.creditcontractsdictionary.CreditContractsDictionaryBrowse;
import kz.eub.rm.screen.open.manager.CreditContractsDictionaryScreenOpenManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@ActionType(CreditContractsLookupAction.ID)
public class CreditContractsLookupAction extends EntityLookupAction<CreditContractsDictionary> {
    public static final String ID = "credit_contracts_lookup";

    @Autowired
    private CreditContractsDictionaryScreenOpenManager openManager;

    public CreditContractsLookupAction() {
        super(ID);
    }

    public CreditContractsLookupAction(String id) {
        super(id);
    }

    @Override
    public void execute() {
        CreditContractsDictionaryBrowse browseScreen = openManager.buildAsLookup(entityPicker);
        screenInitializer.initScreen(browseScreen);
        browseScreen.show();
    }
}
