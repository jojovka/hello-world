package kz.eub.rm.simple.report;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

public class SimpleReportDataConfiguration<T> {
    // проперти, которые надо положить в отчет (работает и через точечную нотацию)
    private List<String> propertiesToRender;

    // делегат загрузки данных, чтобы данные загружались в момент нажатия кнопки
    private Supplier<List<T>> dataLoadingDelegate;

    public SimpleReportDataConfiguration(List<String> propertiesToRender, Supplier<List<T>> dataLoadingDelegate){
        this.propertiesToRender = propertiesToRender;
        this.dataLoadingDelegate = dataLoadingDelegate;
    }

    public List<String> getPropertyPath(int index) {
        return Arrays.asList(propertiesToRender.get(index).split("\\."));
    }

    public Supplier<List<T>> getDataLoadingDelegate() {
        return dataLoadingDelegate;
    }

    public int getPropertiesNumber() {
        return propertiesToRender.size();
    }
}
