package kz.eub.rm.simple.report;

import java.util.Arrays;
import java.util.List;

public class PropertiesToRender {
    public static List<String> POZ_DICTIONARY_PROPERTIES;
    static {
        POZ_DICTIONARY_PROPERTIES = Arrays.asList("pozName","isMortgage","changeDate");
    }
    public static List<String> POZ_MAPPING_DICTIONARY_PROPERTIES;
    static {
        POZ_MAPPING_DICTIONARY_PROPERTIES = Arrays.asList("changeDate","sdspId.pozName","pozForReservePercentCalculation.pozName","prodName");
    }
    public static List<String> BASKET_TRIGGER_DICTIONARY_PROPERTIES;
    static {
        BASKET_TRIGGER_DICTIONARY_PROPERTIES = Arrays.asList(
                "code",
                "name",
                "tdLvl",
                "basket",
                "isUl",
                "isFl",
                "isUniform",
                "isNonUniform",
                "startDate",
                "endDate",
                "isActual",
                "changeDate",
                "changerFullName"
        );
    }
    public static List<String> DEFAULT_OR_RECOVERY_DICTIONARY_PROPERTIES;
    static {
        DEFAULT_OR_RECOVERY_DICTIONARY_PROPERTIES = Arrays.asList(
                "code",
                "name",
                "value",
                "startDate",
                "endDate",
                "isActual",
                "changeDate",
                "changerFullName"
        );
    }
    public static List<String> POZ_SEGMENTATION_DICTIONARY_PROPERTIES;
    static {
        POZ_SEGMENTATION_DICTIONARY_PROPERTIES = Arrays.asList(
                "changeDate",
                "pozId.pozName",
                "segment",
                "amountMin",
                "amountMax",
                "durationMin",
                "durationMax"
        );
    }

    public static List<String> BORROWER_DEAL_RATING_PROPERTIES;
    static {
        BORROWER_DEAL_RATING_PROPERTIES = Arrays.asList(
                "inValues",
                "outValues",
                "description"
        );
    }
    public static List<String> EXCEPTIONAL_POZ_PRODUCTS_PRODUCTS_PROPERTIES;
    static {
        EXCEPTIONAL_POZ_PRODUCTS_PRODUCTS_PROPERTIES = Arrays.asList(
                "changeDate",
                "startDate",
                "endDate",
                "rowStatus",
                "prdId.name",
                "user"
        );
    }
    public static List<String> POZ_MACRO_ADJUSTMENTS_DICTIONARY_PROPERTIES;
    static {
        POZ_MACRO_ADJUSTMENTS_DICTIONARY_PROPERTIES = Arrays.asList(
                "pozDictionary.pozName",
                "deltaPd12",
                "deltaPdlt",
                "isActual",
                "startDate",
                "endDate",
                "changeDate",
                "changerUser.fullName"
        );
    }
    public static List<String> PNZ_MACRO_ADJUSTMENTS_DICTIONARY_PROPERTIES;
    static {
        PNZ_MACRO_ADJUSTMENTS_DICTIONARY_PROPERTIES = Arrays.asList(
                "segmentName",
                "deltaCoefficient",
                "isActual",
                "startDate",
                "endDate",
                "changeDate",
                "changerUser.fullName"
        );
    }
    public static List<String> ALPHA_COEFFICIENT_DICTIONARY_PROPERTIES;
    static {
        ALPHA_COEFFICIENT_DICTIONARY_PROPERTIES = Arrays.asList(
                "pozSegment.segment",
                "depth",
                "pdltTerm",
                "modaPercent",
                "isActual",
                "startDate",
                "endDate",
                "alphaDrPeriod",
                "monthNumberRrForProvisions",
                "changeDate",
                "changerUser.fullName"
        );
    }
    public static List<String> SOURCE_SYSTEMS_DICTIONARY_PROPERTIES;
    static {
        SOURCE_SYSTEMS_DICTIONARY_PROPERTIES = Arrays.asList(
                "srcCd",
                "srcName",
                "srcDescription",
                "gidPref"
        );
    }
    public static List<String> PRODUCT_REFERENCE_DICTIONARY_PROPERTIES;
    static {
        PRODUCT_REFERENCE_DICTIONARY_PROPERTIES = Arrays.asList(
                "prdId",
                "startDate",
                "endDate",
                "changeDate",
                "rowStatus",
                "prdSource",
                "prdSourcePk",
                "auditId",
                "prdGid",
                "prntPrdGid",
                "code",
                "name",
                "curCd",
                "term",
                "prolCount",
                "category",
                "subProduct",
                "dealType"
        );
    }
    public static List<String> CREDIT_CONTRACTS_DICTIONARY_PROPERTIES;
    static {
        CREDIT_CONTRACTS_DICTIONARY_PROPERTIES = Arrays.asList(
                "dcsReportDate",
                "dscSourceUuid.srcName",
                "dscGid",
                "dscDogNum",
                "dscTranNum",
                "dscCrncCd",
                "departmentName",
                "dscClntGid",
                "dscCgrpGid",
                "dscOutSumKztOd",
                "dscOutSumKztOdDelay",
                "dscOutSumKztPerc",
                "dscOutSumKztPercDelay",
                "dscOutSumKztPercOd",
                "dscOutSumKztCom",
                "dscOutSumKztComDelay",
                "dscOutSumKztPen",
                "dscOutSumKztMsfoPer",
                "dscOutSumKztNegCorr",
                "dscOutSumKztDis1434",
                "dscOutSumKztDis2794",
                "dscOutSumKztCorrEsp",
                "dscOutSumKztDev",
                "dscOutSumKztMod1435",
                "dscOutSumKztOdOdd",
                "dscOutSumKztAllDebt",
                "dscMsfoRate",
                "dscOutSumKztMsfo1428",
                "dscOutSumKztProvCom1845",
                "dscOutSumKztProv1877",
                "dscOutSumKztDebt1860",
                "dscOutSumKztKik",
                "dscOutSumKztDz1877",
                "dscOutSumKztOdOddMonBeg",
                "dscOutSumKztAllDebtWithoutDis",
                "dscOutSumKztReser",
                "dscOutSumKztOutsys",
                "dscOutSumKztOutsysSum",
                "dscOutSumKztLesion",
                "dscCrRateMonthBeg",
                "dscCrRateRepDate",
                "productName",
                "dscTarif",
                "dscIsUniform",
                "dscPozId.pozName",
                "dscUserCredType",
                "dscDprtGid",
                "dscCliRatiIn",
                "dscCliRatiInDate",
                "dscDealRati",
                "dscDealRatiDate",
                "dscMonDate",
                "dscActFinDate",
                "dscMonPer",
                "dscLastFinDate",
                "dscCliRatiOut",
                "dscCliIinBin",
                "dscCliType",
                "dscSdCd",
                "dscKodIp",
                "dscMaxDelayDay",
                "dscMinDelayDay",
                "dscOpenDate",
                "dscPayDate",
                "dscOked",
                "dscCliOkedCd",
                "dscProblem",
                "dscClass",
                "dscModif",
                "dscModDate",
                "dscBasketMonBeg",
                "dscBasketRepDate",
                "dscRate",
                "dscGesvBeg",
                "dscTrg2",
                "dscTrg3",
                "dscTrg4",
                "dscRecovery",
                "dscDefoltDate",
                "dscRecoveryDate",
                "dscNonMarketFl",
                "dscAllSum",
                "dscControlList",
                "dscState"
        );
    }
    public static List<String> PLEDGES_DICTIONARY_PROPERTIES;
    static {
        PLEDGES_DICTIONARY_PROPERTIES = Arrays.asList(
                "dpsId",
                "dpsAuditId",
                "changeDate",
                "dpsReportDate",
                "dpsGid",
                "dpsDogNum",
                "dpsCurrCode",
                "dpsCliName",
                "dpsCliIinBin",
                "dpsDprtName",
                "dpsDoGid",
                "dpsDoDogNum",
                "dpsDoDate",
                "dpsDoCurrCode",
                "dpsPlgCliName",
                "dpsPlgCliIinBin",
                "dpsPlgType",
                "dpsPlgCateg",
                "dpsDateNok",
                "dpsSumCur",
                "dpsSumKzt",
                "dpsDateMon",
                "dpsSumMarCur",
                "dpsSumMarKzt",
                "dpsSumAlc",
                "dpsPropPerc",
                "dpsDoState",
                "dpsState"
        );
    }
    public static List<String> LIQUIDITY_COEFFICIENT_DICTIONARY_PROPERTIES;
    static {
        LIQUIDITY_COEFFICIENT_DICTIONARY_PROPERTIES = Arrays.asList(
                "pledgeType",
                "liquidityRatio",
                "name",
                "fullName",
                "isActual",
                "discountingTermMonths",
                "startDate",
                "endDate",
                "changerUser.fullName",
                "changeDate"
        );
    }

    public static List<String> TRIGGER_DICTIONARY_PROPERTIES;
    static {
        TRIGGER_DICTIONARY_PROPERTIES = Arrays.asList(
                "code",
                "name",
                "isActual",
                "startDate",
                "endDate",
                "changeDate",
                "isFl",
                "isUl",
                "isUniform",
                "isNonUniform",
                "basket",
                "definitionLevel",
                "triggerType"
        );
    }
}
