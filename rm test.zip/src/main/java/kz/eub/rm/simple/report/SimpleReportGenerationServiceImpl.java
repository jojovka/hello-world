package kz.eub.rm.simple.report;

import io.jmix.core.Messages;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@Component
public class SimpleReportGenerationServiceImpl implements SimpleReportGenerationService{
    private static final Logger log = LoggerFactory.getLogger(SimpleReportGenerationServiceImpl.class);

    private static final String SHEET_NAME_PREFIX = "Sheet";
    private static final int DATE_TIME_CELL_STYLE_INDEX = 0;
    private static final int DATE_CELL_STYLE_INDEX = 1;
    private static final int DOUBLE_CELL_STYLE_INDEX = 2;
    private static final int LONG_CELL_STYLE_INDEX = 3;

    @Autowired
    private Messages messages;

    @Override
    public <T> ByteArrayOutputStream generate(Class<T> cls,
                                              SimpleReportDataConfiguration dataConfiguration,
                                              SimpleReportRenderConfiguration renderConfiguration) {
        UUID processUuid = UUID.randomUUID();
        log.info("started simple report with uuid:{}",processUuid);

        SimpleReportData<T> reportData = new SimpleReportData<>(dataConfiguration);

        log.info("started data loading for report with uuid:{}",processUuid);
        reportData.loadData();
        log.info("ended data loading for report with uuid:{}",processUuid);

        SXSSFWorkbook workbook = new SXSSFWorkbook(1000);
        Map<Integer, CellStyle> stylesMap = createCellStyles(workbook);
        int sheetsNumber = 1;
        Sheet currentSheet = workbook.createSheet(SHEET_NAME_PREFIX+sheetsNumber);

        log.info("started excel file generation of report with uuid:{}",processUuid);
        createHeaderRow(cls,currentSheet, dataConfiguration);
        for (int i = 0; i < reportData.getDataRowsNumber(); i++) {
            if (currentSheet.getPhysicalNumberOfRows() >= renderConfiguration.getMaxRowsPerSheet()) {
                sheetsNumber++;
                currentSheet = workbook.createSheet(SHEET_NAME_PREFIX+sheetsNumber);
                createHeaderRow(cls, currentSheet, dataConfiguration);
            }
            createRow(currentSheet, currentSheet.getPhysicalNumberOfRows(), reportData, i, stylesMap);
        }
        log.info("ended excel file generation of report with uuid:{}",processUuid);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            log.info("started writing to output stream excel file of report with uuid:{}",processUuid);
            workbook.write(outputStream);
            workbook.close();
            workbook.dispose();
            log.info("ended writing to output stream excel file of report with uuid:{}",processUuid);
        } catch (IOException e) {
            log.error("failed to write to output stream excel file of report with uuid:{}",processUuid);
            throw new RuntimeException("An error occurred while writing result file", e);
        }
        log.info("ended simple report with uuid:{}",processUuid);
        return outputStream;
    }

    private Map<Integer, CellStyle> createCellStyles(Workbook workbook) {
        Map<Integer, CellStyle> result = new HashMap<>();

        CellStyle cellStyle0 = workbook.createCellStyle();
        cellStyle0.setDataFormat(
                workbook.getCreationHelper().createDataFormat().getFormat("d/m/yy h:mm")
        );
        result.put(DATE_TIME_CELL_STYLE_INDEX, cellStyle0);

        CellStyle cellStyle1 = workbook.createCellStyle();
        cellStyle1.setDataFormat(
                workbook.getCreationHelper().createDataFormat().getFormat("d/m/yy")
        );
        result.put(DATE_CELL_STYLE_INDEX, cellStyle1);

        CellStyle cellStyle2 = workbook.createCellStyle();
        cellStyle2.setDataFormat(HSSFDataFormat.getBuiltinFormat("#,##0.00"));
        result.put(DOUBLE_CELL_STYLE_INDEX, cellStyle2);

        CellStyle cellStyle3 = workbook.createCellStyle();
        cellStyle3.setDataFormat(HSSFDataFormat.getBuiltinFormat("0"));
        result.put(LONG_CELL_STYLE_INDEX, cellStyle3);

        return result;
    }

    private <T> Row createRow(Sheet sheet, int rowNumber, SimpleReportData<T> reportData, int rowDataNumber, Map<Integer, CellStyle> stylesMap) {
        Row row = sheet.createRow(rowNumber);
        for (int i = 0; i < reportData.getColumnsNumber(); i++) {
            Object cellValue = reportData.getPropertyValue(rowDataNumber,i);
            createCell(i, cellValue, row, stylesMap);
        }
        return row;
    }

    private <T>Cell createCell(int cellNumber, T cellValue, Row row, Map<Integer, CellStyle> stylesMap) {
        Cell cell = row.createCell(cellNumber);
        if (cellValue instanceof Boolean) {
            cell.setCellValue((Boolean)cellValue);
        } else if (cellValue instanceof Double) {
            cell.setCellValue((Double)cellValue);
            cell.setCellStyle(stylesMap.get(DOUBLE_CELL_STYLE_INDEX));
        } else if (cellValue instanceof Integer) {
            cell.setCellValue((Integer)cellValue);
            cell.setCellStyle(stylesMap.get(LONG_CELL_STYLE_INDEX));
        } else if (cellValue instanceof Long) {
            cell.setCellValue((Long)cellValue);
            cell.setCellStyle(stylesMap.get(LONG_CELL_STYLE_INDEX));
        } else if (cellValue instanceof String) {
            cell.setCellValue((String) cellValue);
        } else if (cellValue instanceof BigDecimal) {
            cell.setCellValue(((BigDecimal) cellValue).doubleValue());
            cell.setCellStyle(stylesMap.get(DOUBLE_CELL_STYLE_INDEX));
        } else if (cellValue instanceof Date) {
            cell.setCellValue((Date) cellValue);
            cell.setCellStyle(stylesMap.get(DATE_TIME_CELL_STYLE_INDEX));
        } else if (cellValue instanceof LocalDate) {
            cell.setCellValue((LocalDate) cellValue);
            cell.setCellStyle(stylesMap.get(DATE_CELL_STYLE_INDEX));
        } else if (cellValue instanceof LocalDateTime) {
            cell.setCellValue((LocalDateTime) cellValue);
            cell.setCellStyle(stylesMap.get(DATE_TIME_CELL_STYLE_INDEX));
        } else if (cellValue instanceof Enum) {
             String localizedMessage = messages.getMessage((Enum) cellValue);
             cell.setCellValue(localizedMessage);
        } else {
            cell.setCellValue(Optional.ofNullable(cellValue).map(Object::toString).orElse(null));
        }
        return cell;
    }

    protected void createHeaderRow(Class<?> entityClass, Sheet sheet, SimpleReportDataConfiguration simpleReportDataConfiguration) {
        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < simpleReportDataConfiguration.getPropertiesNumber(); i++) {
            sheet.setColumnWidth(i, 6000);
            Cell cell = headerRow.createCell(i);
            String packageName = entityClass.getPackageName();
            String className = entityClass.getSimpleName();
            String propertyName = (String) simpleReportDataConfiguration.getPropertyPath(i).get(0);
            cell.setCellValue(messages.getMessage(packageName + "/" + className + "." +propertyName));
        }
    }
}
