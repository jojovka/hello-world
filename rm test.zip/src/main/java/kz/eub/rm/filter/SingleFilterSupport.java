package kz.eub.rm.filter;
import io.jmix.core.metamodel.model.MetaClass;
import io.jmix.ui.component.ComponentGenerationContext;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.JpqlFilter;
import io.jmix.ui.component.UiComponentsGenerator;
import io.jmix.ui.component.factory.JpqlFilterComponentGenerationContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Nullable;

@Component("rm_SingleFilterSupport")
public class SingleFilterSupport {

    @Autowired
    protected UiComponentsGenerator uiComponentsGenerator;

    /**
     * Generates filter value component by given metaClass, entity property and operation.
     * In general case the value component is created for {@link CustomPropertyFilter}.
     *
     * @param metaClass an entity meta class associated with filter
     * @param property  an entity attribute associated with filter
     * @param operation an operation
     * @return a filter value component
     */
    public HasValue generateValueComponent(MetaClass metaClass,
                                           String property,
                                           CustomPropertyFilter.Operation operation) {
        ComponentGenerationContext context =
                new CustomPropertyFilterComponentGenerationContext(metaClass, property, operation);
        context.setTargetClass(CustomPropertyFilter.class);

        return ((HasValue) uiComponentsGenerator.generate(context));
    }

    /**
     * Generates filter value component by given metaClass and value type.
     * In general case the value component is created for {@link JpqlFilter}.
     *
     * @param metaClass       an entity meta class associated with filter
     * @param hasInExpression whether the query condition has an IN expression and the value is a collection
     * @param parameterClass  a value type
     * @return a filter value component
     */
    @SuppressWarnings({"rawtypes"})
    public HasValue generateValueComponent(MetaClass metaClass,
                                           boolean hasInExpression,
                                           @Nullable Class parameterClass) {
        ComponentGenerationContext context =
                new JpqlFilterComponentGenerationContext(metaClass, "", hasInExpression, parameterClass);
        context.setTargetClass(JpqlFilter.class);

        return ((HasValue) uiComponentsGenerator.generate(context));
    }

    /**
     * @return a value component name
     */
    public String getValueComponentName(HasValue<?> valueComponent) {
        try {
            return (String) valueComponent.getClass().getField("NAME").get(null);
        } catch (IllegalAccessException | NoSuchFieldException e) {
            throw new IllegalArgumentException(String.format("Class '%s' doesn't have NAME field",
                    valueComponent.getClass().getName()));
        }
    }
}
