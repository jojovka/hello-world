package kz.eub.rm.filter;

import io.jmix.ui.component.filter.registration.FilterComponentRegistration;
import io.jmix.ui.component.filter.registration.FilterComponentRegistrationBuilder;
import io.jmix.ui.sys.registration.ComponentRegistration;
import io.jmix.ui.sys.registration.ComponentRegistrationBuilder;
import kz.eub.rm.entity.CustomPropertyFilterCondition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FilterConfiguration {
    @Bean
    public FilterComponentRegistration registerPropertyFilter() {
        return FilterComponentRegistrationBuilder.create(CustomPropertyFilter.class,
                        CustomPropertyFilterCondition.class,
                        CustomPropertyFilterConverter.class)
                .withEditScreenId("rm_CustomPropertyFilterCondition.edit")
                .build();
    }

    @Bean
    public ComponentRegistration customPropertyFilter() {
        return ComponentRegistrationBuilder.create(CustomPropertyFilter.NAME)
                .withComponentClass(CustomPropertyFilterImpl.class)
                .withComponentLoaderClass(PropertyFilterLoader.class)
                .build();
    }
}
