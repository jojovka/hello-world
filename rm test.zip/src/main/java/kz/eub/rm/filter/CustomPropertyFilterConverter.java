package kz.eub.rm.filter;

import com.google.common.base.Strings;
import io.jmix.core.Metadata;
import io.jmix.core.MetadataTools;
import io.jmix.core.metamodel.model.MetaClass;
import io.jmix.core.metamodel.model.MetaPropertyPath;
import io.jmix.ui.UiComponents;
import io.jmix.ui.component.Filter;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.filter.converter.AbstractFilterComponentConverter;
import io.jmix.ui.entity.FilterValueComponent;
import kz.eub.rm.entity.CustomPropertyFilterCondition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.Nullable;
import java.util.Objects;

@Component("rm_PropertyFilterConverter")
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class CustomPropertyFilterConverter
        extends AbstractFilterComponentConverter<CustomPropertyFilter, CustomPropertyFilterCondition> {

    @Autowired
    protected PropertyFilterSupport propertyFilterSupport;
    @Autowired
    protected SingleFilterSupport singleFilterSupport;
    @Autowired
    protected UiComponents uiComponents;
    @Autowired
    protected Metadata metadata;
    @Autowired
    protected MetadataTools metadataTools;

    public CustomPropertyFilterConverter(Filter filter) {
        super(filter);
    }

    @SuppressWarnings("unchecked")
    @Override
    public CustomPropertyFilter<?> convertToComponent(CustomPropertyFilterCondition model) {
        CustomPropertyFilter customPropertyFilter = super.convertToComponent(model);
        customPropertyFilter.setCaption(model.getCaption());
        customPropertyFilter.setCaptionPosition(model.getCaptionPosition());
        customPropertyFilter.setRequired(model.getRequired());
        customPropertyFilter.setProperty(model.getProperty());
        customPropertyFilter.setOperation(model.getOperation());
        customPropertyFilter.setOperationEditable(model.getOperationEditable());
        customPropertyFilter.setOperationCaptionVisible(model.getOperationCaptionVisible());
        customPropertyFilter.setParameterName(model.getParameterName());

        HasValue valueComponent = convertValueComponentToComponent(model);
        customPropertyFilter.setValueComponent(valueComponent);
        Object defaultValue = convertDefaultValueToComponent(model);
        customPropertyFilter.setValue(defaultValue);

        return customPropertyFilter;
    }

    @Override
    public CustomPropertyFilterCondition convertToModel(CustomPropertyFilter customPropertyFilter) {
        CustomPropertyFilterCondition condition = super.convertToModel(customPropertyFilter);
        condition.setCaption(customPropertyFilter.getCaption());
        condition.setLocalizedCaption(getLocalizedModelCaption(customPropertyFilter));
        condition.setCaptionPosition(customPropertyFilter.getCaptionPosition());
        condition.setRequired(customPropertyFilter.isRequired());
        condition.setProperty(customPropertyFilter.getProperty());
        condition.setOperation(customPropertyFilter.getOperation());
        condition.setOperationEditable(customPropertyFilter.isOperationEditable());
        condition.setOperationCaptionVisible(customPropertyFilter.isOperationCaptionVisible());
        condition.setParameterName(customPropertyFilter.getParameterName());

        FilterValueComponent valueComponent = convertValueComponentToModel(customPropertyFilter);
        String modelDefaultValue = convertDefaultValueToModel(customPropertyFilter);
        valueComponent.setDefaultValue(modelDefaultValue);
        condition.setValueComponent(valueComponent);

        return condition;
    }

    @Override
    protected CustomPropertyFilter createComponent() {
        return uiComponents.create(CustomPropertyFilter.NAME);
    }

    @Override
    protected CustomPropertyFilterCondition createModel() {
        return metadata.create(CustomPropertyFilterCondition.class);
    }

    @Nullable
    @Override
    protected String getLocalizedModelCaption(CustomPropertyFilter component) {
        String caption = component.getCaption();
        if (Strings.isNullOrEmpty(caption)) {
            MetaClass metaClass = filter.getDataLoader().getContainer().getEntityMetaClass();
            return propertyFilterSupport.getPropertyFilterCaption(metaClass, component.getProperty(), component.getOperation(),
                    component.isOperationCaptionVisible() && !component.isOperationEditable());
        } else {
            return caption;
        }
    }

    protected HasValue generateValueComponent(CustomPropertyFilterCondition model) {
        MetaClass metaClass = filter.getDataLoader().getContainer().getEntityMetaClass();
        return singleFilterSupport.generateValueComponent(metaClass, model.getProperty(), model.getOperation());
    }

    protected HasValue convertValueComponentToComponent(CustomPropertyFilterCondition model) {
        HasValue valueComponent = generateValueComponent(model);
        FilterValueComponent filterValueComponent = model.getValueComponent();
        if (filterValueComponent != null) {
            String componentName = filterValueComponent.getComponentName();
            if (componentName != null) {
                String defaultName = singleFilterSupport.getValueComponentName(valueComponent);
                if (!Objects.equals(defaultName, componentName)) {
                    valueComponent = uiComponents.create(componentName);
                }
            }

            valueComponent.setId(filterValueComponent.getComponentId());
            valueComponent.setStyleName(filterValueComponent.getStyleName());
        }

        return valueComponent;
    }

    @Nullable
    protected Object convertDefaultValueToComponent(CustomPropertyFilterCondition model) {
        String modelDefaultValue = model.getValueComponent().getDefaultValue();
        Object value = null;
        if (model.getProperty() != null && model.getOperation() != null) {
            MetaClass metaClass = filter.getDataLoader().getContainer().getEntityMetaClass();
            MetaPropertyPath mpp = metadataTools.resolveMetaPropertyPathOrNull(metaClass, model.getProperty());
            if (mpp != null) {
                value = propertyFilterSupport.parseDefaultValue(mpp.getMetaProperty(),
                        model.getOperation().getType(), modelDefaultValue);
            }
        }

        return value;
    }

    protected FilterValueComponent convertValueComponentToModel(CustomPropertyFilter component) {
        HasValue<?> valueField = component.getValueComponent();

        FilterValueComponent valueComponent = metadata.create(FilterValueComponent.class);
        valueComponent.setComponentId(valueField.getId());
        valueComponent.setStyleName(valueField.getStyleName());
        valueComponent.setComponentName(singleFilterSupport.getValueComponentName(valueField));

        return valueComponent;
    }

    @Nullable
    protected String convertDefaultValueToModel(CustomPropertyFilter component) {
        Object defaultValue = component.getValue();
        MetaClass metaClass = filter.getDataLoader().getContainer().getEntityMetaClass();
        MetaPropertyPath mpp = metadataTools.resolveMetaPropertyPathOrNull(metaClass, component.getProperty());
        String modelDefaultValue = null;
        if (mpp != null) {
            modelDefaultValue = propertyFilterSupport.formatDefaultValue(mpp.getMetaProperty(),
                    component.getOperation().getType(), defaultValue);
        }

        return modelDefaultValue;
    }
}

