package kz.eub.rm.filter;

import com.google.common.base.Strings;
import org.apache.commons.lang3.RandomStringUtils;

import java.util.function.Function;

public class PropertyConditionUtils {

    /**
     * @param customPropertyCondition property condition
     * @return true if property condition operation is unary (doesn't require parameter value), e.g "is set"
     */
    public static boolean isUnaryOperation(CustomPropertyCondition customPropertyCondition) {
        String operation = customPropertyCondition.getOperation();
        return CustomPropertyCondition.Operation.IS_SET.equals(operation) || CustomPropertyCondition.Operation.IS_NOT_SET.equals(operation);
    }

    /**
     * @param customPropertyCondition property condition
     * @return true if property condition operation is collection (doesn't require parameter value), e.g "in list"
     */
    public static boolean isCollectionOperation(CustomPropertyCondition customPropertyCondition) {
        String operation = customPropertyCondition.getOperation();
        return CustomPropertyCondition.Operation.IN_LIST.equals(operation)
                || CustomPropertyCondition.Operation.NOT_IN_LIST.equals(operation);
    }

    /**
     * @param customPropertyCondition property condition
     * @return true if property condition operation is "in interval"
     */
    public static boolean isInIntervalOperation(CustomPropertyCondition customPropertyCondition) {
        String operation = customPropertyCondition.getOperation();
        return CustomPropertyCondition.Operation.IN_INTERVAL.equals(operation);
    }

    /**
     * @param property an entity property
     * @return a parameter name
     */
    public static String generateParameterName(String property) {
        return (Strings.nullToEmpty(property) + RandomStringUtils.randomAlphabetic(8))
                .replace(".", "_")
                .replace("+", "");
    }

    /**
     * @param condition property condition
     * @return a JPQL operation
     */
    public static String getJpqlOperation(CustomPropertyCondition condition) {
        switch (condition.getOperation()) {
            case CustomPropertyCondition.Operation.EQUAL:
                return "=";
            case CustomPropertyCondition.Operation.NOT_EQUAL:
                return "<>";
            case CustomPropertyCondition.Operation.GREATER:
                return ">";
            case CustomPropertyCondition.Operation.GREATER_OR_EQUAL:
                return ">=";
            case CustomPropertyCondition.Operation.LESS:
                return "<";
            case CustomPropertyCondition.Operation.LESS_OR_EQUAL:
                return "<=";
            case CustomPropertyCondition.Operation.CONTAINS:
            case CustomPropertyCondition.Operation.STARTS_WITH:
            case CustomPropertyCondition.Operation.ENDS_WITH:
                return "like";
            case CustomPropertyCondition.Operation.NOT_CONTAINS:
                return "not like";
            case CustomPropertyCondition.Operation.IN_LIST:
                return "in";
            case CustomPropertyCondition.Operation.NOT_IN_LIST:
                return "not in";
            case CustomPropertyCondition.Operation.IS_SET:
                return Boolean.TRUE.equals(condition.getParameterValue()) ? "is not null" : "is null";
            case CustomPropertyCondition.Operation.IS_NOT_SET:
                return Boolean.TRUE.equals(condition.getParameterValue()) ? "is  null" : "is not null";
            case CustomPropertyCondition.Operation.IN_INTERVAL:
                return getInIntervalJpqlOperation(condition);
        }
        throw new RuntimeException("Unknown PropertyCondition operation: " + condition.getOperation());
    }

    protected static String getInIntervalJpqlOperation(CustomPropertyCondition condition) {
        Object parameterValue = condition.getParameterValue();
        if (parameterValue == null) {
            throw new RuntimeException("Cannot build operation condition for date interval " +
                    "because parameter value is null");
        }

        //noinspection unchecked
        return ((Function<String, String>) parameterValue).apply(condition.getProperty());
    }
}
