package kz.eub.rm.filter;

import com.google.common.base.Strings;
import io.jmix.core.querycondition.Condition;
import io.jmix.core.querycondition.PropertyConditionUtils;
import org.apache.commons.collections4.CollectionUtils;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;

public class CustomPropertyCondition implements Condition {

    private String property;

    private String operation;

    private String parameterName;

    private Object parameterValue;

    public CustomPropertyCondition() {
    }

    /**
     * Creates property condition with the specified parameter name. The parameter value must be provided by
     * calling {@link #setParameterValue(Object)} method.
     *
     * @param property      entity attribute name
     * @param operation     comparison operation, see {@link CustomPropertyCondition.Operation} constants
     * @param parameterName parameter name
     */
    public static CustomPropertyCondition createWithParameterName(String property, String operation, String parameterName) {
        CustomPropertyCondition pc = new CustomPropertyCondition();
        pc.property = property;
        pc.operation = operation;
        pc.parameterName = parameterName;
        return pc;
    }

    /**
     * Creates a condition to compare the property with the provided value. A parameter name is generated based
     * on the property name.
     *
     * @param property       entity attribute name
     * @param operation      comparison operation, see {@link CustomPropertyCondition.Operation} constants.
     * @param parameterValue value to compare with
     */
    public static CustomPropertyCondition createWithValue(String property, String operation, Object parameterValue) {
        CustomPropertyCondition pc = new CustomPropertyCondition();
        pc.property = property;
        pc.operation = operation;
        pc.parameterValue = parameterValue;
        pc.parameterName = PropertyConditionUtils.generateParameterName(property);
        return pc;
    }

    /**
     * Creates a condition to compare the property with the given value.
     *
     * @param property  entity attribute name
     * @param operation comparison operation, see constants in {@link CustomPropertyCondition.Operation}
     * @param value     value to compare with
     */
    public static CustomPropertyCondition create(String property, String operation, Object value) {
        return createWithValue(property, operation, value);
    }

    /**
     * Creates "=" condition.
     */
    public static CustomPropertyCondition equal(String property, Object value) {
        return createWithValue(property, CustomPropertyCondition.Operation.EQUAL, value);
    }

    /**
     * Creates "!=" condition.
     */
    public static CustomPropertyCondition notEqual(String property, Object value) {
        return createWithValue(property, CustomPropertyCondition.Operation.NOT_EQUAL, value);
    }

    /**
     * Creates "&gt;" condition.
     */
    public static CustomPropertyCondition greater(String property, Object value) {
        return createWithValue(property, CustomPropertyCondition.Operation.GREATER, value);
    }

    /**
     * Creates "&gt;=" condition.
     */
    public static CustomPropertyCondition greaterOrEqual(String property, Object value) {
        return createWithValue(property, CustomPropertyCondition.Operation.GREATER_OR_EQUAL, value);
    }

    /**
     * Creates "&lt;" condition.
     */
    public static CustomPropertyCondition less(String property, Object value) {
        return createWithValue(property, CustomPropertyCondition.Operation.LESS, value);
    }

    /**
     * Creates "&lt;=" condition.
     */
    public static CustomPropertyCondition lessOrEqual(String property, Object value) {
        return createWithValue(property, CustomPropertyCondition.Operation.LESS_OR_EQUAL, value);
    }

    /**
     * Creates a condition that is translated to "like %value%".
     */
    public static CustomPropertyCondition contains(String property, Object value) {
        return createWithValue(property, CustomPropertyCondition.Operation.CONTAINS, value);
    }

    /**
     * Creates a condition that is translated to "like value%".
     */
    public static CustomPropertyCondition startsWith(String property, Object value) {
        return createWithValue(property, CustomPropertyCondition.Operation.STARTS_WITH, value);
    }

    /**
     * Creates a condition that is translated to "like %value".
     */
    public static CustomPropertyCondition endsWith(String property, Object value) {
        return createWithValue(property, CustomPropertyCondition.Operation.ENDS_WITH, value);
    }

    /**
     * Creates a condition that is translated to "is null" or "is not null"
     * depending on the parameter value.
     */
    public static CustomPropertyCondition isSet(String property, Object value) {
        return createWithValue(property, CustomPropertyCondition.Operation.IS_SET, value);
    }

    /**
     * Creates a condition that is translated to "in".
     */
    public static CustomPropertyCondition inList(String property, Object value) {
        return createWithValue(property, CustomPropertyCondition.Operation.IN_LIST, value);
    }

    /**
     * Creates a condition that is translated to "not in".
     */
    public static CustomPropertyCondition notInList(String property, Object value) {
        return createWithValue(property, CustomPropertyCondition.Operation.NOT_IN_LIST, value);
    }

    public String getProperty() {
        return property;
    }

    public void setProperty(String property) {
        this.property = property;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getParameterName() {
        return parameterName;
    }

    public void setParameterName(String parameterName) {
        this.parameterName = parameterName;
    }

    @Nullable
    public Object getParameterValue() {
        return parameterValue;
    }

    public void setParameterValue(@Nullable Object parameterValue) {
        this.parameterValue = parameterValue;
    }

    @Override
    public Collection<String> getParameters() {
        return Collections.singletonList(parameterName);
    }

    @Nullable
    @Override
    public Condition actualize(Set<String> actualParameters) {
        if (actualParameters.containsAll(getParameters())) {
            return this;
        }

        if (parameterValue != null) {
            if (parameterValue instanceof String) {
                if (!Strings.isNullOrEmpty((String) parameterValue)) {
                    return this;
                }
            } else if (parameterValue instanceof Collection) {
                if (CollectionUtils.isNotEmpty((Collection<?>) parameterValue)) {
                    return this;
                }
            } else {
                return this;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "[" + property + " " + operation + " " + (parameterName != null ? (":" + parameterName) : parameterValue) + "]";
    }

    @Override
    public CustomPropertyCondition copy() {
        CustomPropertyCondition pc = new CustomPropertyCondition();
        pc.setProperty(this.property);
        pc.setOperation(this.operation);
        pc.setParameterName(this.parameterName);
        pc.setParameterValue(this.parameterValue);
        return pc;
    }

    @Override
    public Set<String> getExcludedParameters(Set<String> actualParameters) {
        Set<String> excludedParameters = new TreeSet<>();
        if (actualParameters.containsAll(getParameters())) {
            return excludedParameters;
        }

        if (parameterValue != null) {
            if (parameterValue instanceof String) {
                if (!Strings.isNullOrEmpty((String) parameterValue)) {
                    return excludedParameters;
                }
            } else if (parameterValue instanceof Collection) {
                if (CollectionUtils.isNotEmpty((Collection<?>) parameterValue)) {
                    return excludedParameters;
                }
            } else {
                return excludedParameters;
            }
        }
        excludedParameters.add(parameterName);
        return excludedParameters;
    }

    /**
     * String constants defining comparison operations.
     */
    public static class Operation {
        public static final String EQUAL = "equal";
        public static final String NOT_EQUAL = "not_equal";
        public static final String GREATER = "greater";
        public static final String GREATER_OR_EQUAL = "greater_or_equal";
        public static final String LESS = "less";
        public static final String LESS_OR_EQUAL = "less_or_equal";
        public static final String CONTAINS = "contains";
        public static final String NOT_CONTAINS = "not_contains";
        public static final String IS_SET = "is_set";
        public static final String IS_NOT_SET = "is_not_set";
        public static final String STARTS_WITH = "starts_with";
        public static final String ENDS_WITH = "ends_with";
        public static final String IN_LIST = "in_list";
        public static final String NOT_IN_LIST = "not_in_list";
        public static final String IN_INTERVAL = "in_interval";
    }
}
