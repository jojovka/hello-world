package kz.eub.rm.filter;

import io.jmix.core.metamodel.model.MetaClass;
import io.jmix.ui.component.ComponentGenerationContext;

public class CustomPropertyFilterComponentGenerationContext extends ComponentGenerationContext {

    protected final CustomPropertyFilter.Operation operation;

    /**
     * Creates an instance of PropertyFilterComponentGenerationContext.
     *
     * @param metaClass the entity for which the component is created
     * @param property  the entity attribute for which the component is created
     * @param operation the property filter operation for which the component is created
     */
    public CustomPropertyFilterComponentGenerationContext(MetaClass metaClass, String property, CustomPropertyFilter.Operation operation) {
        super(metaClass, property);
        this.operation = operation;
    }

    public CustomPropertyFilter.Operation getOperation() {
        return operation;
    }
}
