package kz.eub.rm.listener;

import io.jmix.core.FileStorageLocator;
import kz.eub.rm.entity.ReportsBundle;
import io.jmix.core.event.EntityChangedEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import java.util.Objects;

@Component("rm_ReportsBundleEventListener")
public class ReportsBundleEventListener {
    @Autowired
    private FileStorageLocator fileStorageLocator;

    @TransactionalEventListener
    public void onReportsBundleChangedAfterCommit(EntityChangedEvent<ReportsBundle> event) {
        if (event.getType().equals(EntityChangedEvent.Type.DELETED)) {
            fileStorageLocator.getDefault().removeFile(Objects.requireNonNull(event.getChanges().getOldValue("fileRef")));
        }
    }
}