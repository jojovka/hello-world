package kz.eub.rm.listener;

import kz.eub.rm.entity.User;
import io.jmix.core.event.EntitySavingEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component("rm_UserEventListener")
public class UserEventListener {

    @EventListener
    public void onUserSaving(EntitySavingEvent<User> event) {
        generateAndSaveFullName(event);
    }

    private void generateAndSaveFullName(EntitySavingEvent<User> event) {
        User user = event.getEntity();
        user.setFullName(String.format("%s %s %s", user.getFirstName(), user.getMiddleName(), user.getLastName()));
    }
}