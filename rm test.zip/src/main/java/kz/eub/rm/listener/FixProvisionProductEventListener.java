package kz.eub.rm.listener;

import kz.eub.rm.entity.FixProvisionProduct;
import io.jmix.core.event.EntitySavingEvent;
import kz.eub.rm.entity.dwh.PozMappingDictionary;
import kz.eub.rm.entity.listener.support.ChangeDataMemorizingSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component("rm_FixProvisionProductEventListener")
public class FixProvisionProductEventListener {
    @Autowired
    private ChangeDataMemorizingSupport changeDataMemorizingSupport;

    @EventListener
    public void onFixProvisionProductSaving(final EntitySavingEvent<FixProvisionProduct> event) {
        PozMappingDictionary fppProduct = event.getEntity().getFppProductUuid();
        event.getEntity().setFppProduct(fppProduct.getProdName());
        changeDataMemorizingSupport.fillChangeDateWithCurrent(event.getEntity());
        changeDataMemorizingSupport.fillChangerUserId(event.getEntity());
    }
}