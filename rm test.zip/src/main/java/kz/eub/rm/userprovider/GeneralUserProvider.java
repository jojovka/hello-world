package kz.eub.rm.userprovider;

import io.jmix.bpm.provider.UserProvider;
import io.jmix.core.DataManager;
import kz.eub.rm.entity.User;
import kz.eub.rm.service.UserSecService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@UserProvider(value = "rm_GeneralUserProvider")
public class GeneralUserProvider {

    @Autowired
    protected DataManager dataManager;
    @Autowired
    private UserSecService userSecService;

    public List<User> getUsersByRoleCode(String roleCode) {
        return userSecService.loadUsersHavingRole(roleCode);
    }

}
