package kz.eub.rm;

public interface HasRefreshableContent {

    void refreshContent();

}
