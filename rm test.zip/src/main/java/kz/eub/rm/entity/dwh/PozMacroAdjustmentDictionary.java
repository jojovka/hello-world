package kz.eub.rm.entity.dwh;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.SystemLevel;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;
import io.jmix.core.metamodel.annotation.Store;
import kz.eub.rm.entity.User;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhstore")
@Table(name = "s00_dict_snp_poz_macrocorrect", schema = "dwh_risk", indexes = {
        @Index(name = "IDX_S00DICTSNPPOZM_SDSMPOZUUID", columnList = "sdsm_poz_uuid")
})
@Entity(name = "rm_PozMacroAdjustmentDictionary")
public class PozMacroAdjustmentDictionary implements StandardDictionaryEntity {

    @JoinColumn(name = "sdsm_poz_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private PozDictionary pozDictionary;

    @Column(name = "sdsm_delta_pd12", precision = 19, scale = 2)
    private BigDecimal deltaPd12;

    @Column(name = "sdsm_delta_pdlt", precision = 19, scale = 2)
    private BigDecimal deltaPdlt;

    @Column(name = "sdsm_is_actual")
    private Boolean isActual;

    @Column(name = "sdsm$start_date")
    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Column(name = "sdsm$end_date")
    @Temporal(TemporalType.DATE)
    private Date endDate;

    @Column(name = "sdsm$change_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date changeDate;

    @SystemLevel
    @Column(name = "sdsm_user_uuid")
    private UUID changerUserId;

    @Column(name = "sdsm_uuid", nullable = false)
    @JmixGeneratedValue
    @Id
    private UUID id;

    @DependsOnProperties({"changerUserId"})
    @JmixProperty
    @Transient
    private User changerUser;

    @Override
    public UUID getId() {
        return id;
    }

    @Override
    public void setId(UUID uuid) {
        this.id = uuid;
    }

    public User getChangerUser() {
        return changerUser;
    }

    public void setChangerUser(User changerUser) {
        this.changerUser = changerUser;
    }

    @Override
    public UUID getChangerUserId() {
        return changerUserId;
    }

    @Override
    public void setChangerUserId(UUID userId) {
        this.changerUserId = userId;
    }

    @Override
    public Date getChangeDate() {
        return changeDate;
    }

    @Override
    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Boolean getIsActual() {
        return isActual;
    }

    public void setIsActual(Boolean isActual) {
        this.isActual = isActual;
    }

    public BigDecimal getDeltaPdlt() {
        return deltaPdlt;
    }

    public void setDeltaPdlt(BigDecimal deltaPdlt) {
        this.deltaPdlt = deltaPdlt;
    }

    public BigDecimal getDeltaPd12() {
        return deltaPd12;
    }

    public void setDeltaPd12(BigDecimal deltaPd12) {
        this.deltaPd12 = deltaPd12;
    }

    public PozDictionary getPozDictionary() {
        return pozDictionary;
    }

    public void setPozDictionary(PozDictionary pozDictionary) {
        this.pozDictionary = pozDictionary;
    }

}