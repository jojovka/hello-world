package kz.eub.rm.entity.listener.support;

import io.jmix.core.event.EntitySavingEvent;
import kz.eub.rm.entity.dwh.StandardDictionaryEntityWithLongIdentifier;
import kz.eub.rm.sql.access.function.sequence.SequenceName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DictionaryRowWithLongIdentifierAdjustmentSupportImpl implements DictionaryRowWithLongIdentifierAdjustmentSupport {
    @Autowired
    private DictionaryRowAdjustmentSupport dictionaryRowAdjustmentSupport;
    @Autowired
    private IdentifierSupport identifierSupport;
    @Override
    public void adjustOnSave(EntitySavingEvent<? extends StandardDictionaryEntityWithLongIdentifier> event, SequenceName sequenceName) {
        dictionaryRowAdjustmentSupport.adjustOnSave(event);
        if (event.isNewEntity()) {
            identifierSupport.fillLongIdentifierFromSequence(event.getEntity(), sequenceName);
            identifierSupport.fillIdBasedOn(event.getEntity(), event.getEntity().getLongIdentifier());
        }
    }
}
