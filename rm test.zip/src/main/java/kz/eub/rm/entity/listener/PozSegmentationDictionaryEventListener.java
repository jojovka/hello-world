package kz.eub.rm.entity.listener;

import kz.eub.rm.entity.dwh.PozSegmentationDictionary;
import io.jmix.core.event.EntitySavingEvent;
import kz.eub.rm.entity.listener.support.ChangeDataMemorizingSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component("rm_PozSegmentationDictionaryEventListener")
public class PozSegmentationDictionaryEventListener {
    @Autowired
    private ChangeDataMemorizingSupport changeDataMemorizingSupport;

    @EventListener
    public void onPozSegmentationDictionarySaving(EntitySavingEvent<PozSegmentationDictionary> event) {
        //авто проставление даты изменения
        changeDataMemorizingSupport.fillChangeDateWithCurrent(event.getEntity());
    }
}