package kz.eub.rm.entity;

import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhstore")
@Table(name = "pnz_pd_history", schema = "dwh_risk")
@Entity(name = "rm_PnzPdHistory")
public class PnzPdHistory {

    @Column(name = "pph_uuid")
    @Id
    private UUID id;

    @Column(name = "pph_run_id", nullable = false)
    private String runId;

    @Column(name = "pph_user")
    private String user;

    @Column(name = "pph_date_from")
    @Temporal(TemporalType.DATE)
    private Date dateFrom;

    @Column(name = "pph_date_to")
    @Temporal(TemporalType.DATE)
    private Date dateTo;

    @Column(name = "pph_approved")
    private Boolean isApproved;

    @Column(name = "pph_approver")
    private String approver;

    @Column(name = "pph_approved_date")
    @Temporal(TemporalType.DATE)
    private Date approvedDate;

    @Column(name = "pph_report_id")
    private Integer reportId;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Integer getReportId() {
        return reportId;
    }

    public void setReportId(Integer reportId) {
        this.reportId = reportId;
    }

    public Date getApprovedDate() {
        return approvedDate;
    }

    public void setApprovedDate(Date approvedDate) {
        this.approvedDate = approvedDate;
    }

    public String getApprover() {
        return approver;
    }

    public void setApprover(String approver) {
        this.approver = approver;
    }

    public Boolean getIsApproved() {
        return isApproved;
    }

    public void setIsApproved(Boolean isApproved) {
        this.isApproved = isApproved;
    }

    public Date getDateTo() {
        return dateTo;
    }

    public void setDateTo(Date dateTo) {
        this.dateTo = dateTo;
    }

    public Date getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(Date dateFrom) {
        this.dateFrom = dateFrom;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getRunId() {
        return runId;
    }

    public void setRunId(String runId) {
        this.runId = runId;
    }
}