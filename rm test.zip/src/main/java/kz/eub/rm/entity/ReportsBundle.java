package kz.eub.rm.entity;

import io.jmix.core.FileRef;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "RM_REPORTS_BUNDLE", indexes = {
        @Index(name = "IDX_RMREPORTSBUNDLE_CREATEDBY", columnList = "CREATED_BY_ID")
})
@Entity(name = "rm_ReportsBundle")
public class ReportsBundle {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @InstanceName
    @Column(name = "NAME")
    private String name;

    @JoinColumn(name = "CREATED_BY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private User createdBy;

    @Column(name = "GENERATION_LAUNCH_DATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date generationLaunchDateTime;

    @Column(name = "GENERATED_DATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date generatedDateTime;

    @Column(name = "FILE_REF", length = 1024)
    private FileRef fileRef;

    @Column(name = "STATUS")
    private Integer status;

    @Column(name = "BLOCKING_VALUE")
    private String blockingValue;

    public void setBlockingValue(String blockingValue) {
        this.blockingValue = blockingValue;
    }

    public String getBlockingValue() {
        return blockingValue;
    }

    public ReportsBundleStatus getStatus() {
        return status == null ? null : ReportsBundleStatus.fromId(status);
    }

    public void setStatus(ReportsBundleStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public Date getGeneratedDateTime() {
        return generatedDateTime;
    }

    public void setGeneratedDateTime(Date generatedDateTime) {
        this.generatedDateTime = generatedDateTime;
    }

    public Date getGenerationLaunchDateTime() {
        return generationLaunchDateTime;
    }

    public void setGenerationLaunchDateTime(Date generationLaunchDateTime) {
        this.generationLaunchDateTime = generationLaunchDateTime;
    }

    public FileRef getFileRef() {
        return fileRef;
    }

    public void setFileRef(FileRef fileRef) {
        this.fileRef = fileRef;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}