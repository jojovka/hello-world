package kz.eub.rm.entity.listener.support;

import kz.eub.rm.entity.ChangeDateMemorizingEntity;
import kz.eub.rm.entity.ChangerFullNameMemorizingEntity;
import kz.eub.rm.entity.ChangerUserMemorizingEntity;

public interface ChangeDataMemorizingSupport {
    //заполнение даты изменения записи текущей датой
    void fillChangeDateWithCurrent(ChangeDateMemorizingEntity entity);

    //заполнение фио изменившего запись пользователя
    void fillChangerFullName(ChangerFullNameMemorizingEntity entity);

    void fillChangerUserId(ChangerUserMemorizingEntity entity);
}
