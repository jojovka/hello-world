package kz.eub.rm.entity.listener;

import io.jmix.core.DataManager;
import io.jmix.core.event.EntitySavingEvent;
import kz.eub.rm.entity.dwh.PozMappingDictionary;
import kz.eub.rm.entity.dwh.ProductReferenceDictionary;
import kz.eub.rm.entity.listener.support.ChangeDataMemorizingSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component("rm_PozMappingDictionaryEventListener")
public class PozMappingDictionaryEventListener {
    @Autowired
    private ChangeDataMemorizingSupport changeDataMemorizingSupport;

    @EventListener
    public void onPozMappingDictionarySaving(EntitySavingEvent<PozMappingDictionary> event) {
        //авто проставление даты изменения
        changeDataMemorizingSupport.fillChangeDateWithCurrent(event.getEntity());
    }
}