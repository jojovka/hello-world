package kz.eub.rm.entity.listener.support;

import io.jmix.core.event.EntitySavingEvent;
import kz.eub.rm.entity.ChangeMemorizingEntity;
import kz.eub.rm.entity.dwh.StandardDictionaryEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DictionaryRowAdjustmentSupportImpl implements DictionaryRowAdjustmentSupport {
    @Autowired
    private ChangeDataMemorizingSupport changeDataMemorizingSupport;

    @Override
    public void adjustOnSave(EntitySavingEvent<? extends ChangeMemorizingEntity> event) {
        changeDataMemorizingSupport.fillChangeDateWithCurrent(event.getEntity());
        changeDataMemorizingSupport.fillChangerUserId(event.getEntity());
    }
}
