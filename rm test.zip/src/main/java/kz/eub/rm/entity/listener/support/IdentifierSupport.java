package kz.eub.rm.entity.listener.support;

import kz.eub.rm.entity.dwh.HasId;
import kz.eub.rm.entity.dwh.HasLongIdentifier;
import kz.eub.rm.sql.access.function.sequence.SequenceName;

public interface IdentifierSupport {
    void fillLongIdentifierFromSequence(HasLongIdentifier entity, SequenceName sequenceName);
    void fillIdBasedOn(HasId entity, Long longIdentifier);
}
