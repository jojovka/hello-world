package kz.eub.rm.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@Store(name = "dwhstore")
@JmixEntity
@Table(name = "pnz_redzone_dict", schema = "dwh_risk")
@Entity(name = "rm_PnzRedZone")
public class PnzRedZone {
    @JmixGeneratedValue
    @Column(name = "prd_uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "prd_rating")
    private String rating;

    @Column(name = "prd_red_zone")
    private Boolean isRedZone;

    public Boolean getIsRedZone() {
        return isRedZone;
    }

    public void setIsRedZone(Boolean isRedZone) {
        this.isRedZone = isRedZone;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}