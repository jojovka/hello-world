package kz.eub.rm.entity.listener;

import kz.eub.rm.entity.dwh.AlphaCoefficientDictionary;
import io.jmix.core.event.EntitySavingEvent;
import kz.eub.rm.entity.listener.support.DictionaryRowAdjustmentSupport;
import kz.eub.rm.entity.listener.support.DictionaryRowWithLongIdentifierAdjustmentSupport;
import kz.eub.rm.sql.access.function.sequence.SequenceName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component("rm_AlphaCoefficientDictionaryEventListener")
public class AlphaCoefficientDictionaryEventListener {

    @Autowired
    private DictionaryRowAdjustmentSupport dictionaryRowAdjustmentSupport;

    @EventListener
    public void onAlphaCoefficientDictionarySaving(EntitySavingEvent<AlphaCoefficientDictionary> event) {
        dictionaryRowAdjustmentSupport.adjustOnSave(event);
    }
}