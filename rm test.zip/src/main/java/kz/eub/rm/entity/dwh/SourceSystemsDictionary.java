package kz.eub.rm.entity.dwh;

import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhstore")
@Table(name = "dict_sources", schema = "dwh_dds")
@Entity(name = "rm_SourceSystemsDictionary")
public class SourceSystemsDictionary {

    @Column(name = "src_uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "src_cd")
    private String srcCd;

    @InstanceName
    @Column(name = "src_name")
    private String srcName;

    @Column(name = "src_description")
    private String srcDescription;

    @Column(name = "src_gid_pref", precision = 19, scale = 2)
    private BigDecimal gidPref;

    public BigDecimal getGidPref() {
        return gidPref;
    }

    public String getSrcDescription() {
        return srcDescription;
    }

    public String getSrcName() {
        return srcName;
    }

    public void setSrcName(String srcName) {
        this.srcName = srcName;
    }

    public String getSrcCd() {
        return srcCd;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}