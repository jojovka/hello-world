package kz.eub.rm.entity.listener.support;

import kz.eub.rm.entity.dwh.HasId;
import kz.eub.rm.entity.dwh.HasLongIdentifier;
import kz.eub.rm.sql.access.function.sequence.SequenceCallService;
import kz.eub.rm.sql.access.function.sequence.SequenceName;
import kz.eub.rm.sql.access.function.uuid.generation.UuidGenerationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("rm_identifierSupportImpl")
public class IdentifierSupportImpl implements IdentifierSupport{
    @Autowired
    private SequenceCallService sequenceCallService;
    @Autowired
    private UuidGenerationService uuidGenerationService;

    @Override
    public void fillLongIdentifierFromSequence(HasLongIdentifier entity, SequenceName sequenceName) {
        entity.setLongIdentifier(sequenceCallService.getLongFromSequence(sequenceName));
    }

    @Override
    public void fillIdBasedOn(HasId entity, Long longIdentifier) {
        entity.setId(uuidGenerationService.generateBasedOn(longIdentifier));
    }
}
