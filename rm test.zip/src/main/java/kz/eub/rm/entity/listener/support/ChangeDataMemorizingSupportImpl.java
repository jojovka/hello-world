package kz.eub.rm.entity.listener.support;

import kz.eub.rm.entity.UserPersonalData;
import kz.eub.rm.entity.ChangeDateMemorizingEntity;
import kz.eub.rm.entity.ChangerFullNameMemorizingEntity;
import kz.eub.rm.entity.ChangerUserMemorizingEntity;
import kz.eub.rm.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class ChangeDataMemorizingSupportImpl implements ChangeDataMemorizingSupport{

    @Autowired
    private UserService userService;

    @Override
    public void fillChangeDateWithCurrent(ChangeDateMemorizingEntity entity) {
        entity.setChangeDate(new Date());
    }

    @Override
    public void fillChangerFullName(ChangerFullNameMemorizingEntity entity) {
        entity.setChangerFullName(((UserPersonalData) userService.getCurrentUser()).getFullName());
    }

    @Override
    public void fillChangerUserId(ChangerUserMemorizingEntity entity) {
        entity.setChangerUserId(userService.getCurrentUser().getId());
    }
}
