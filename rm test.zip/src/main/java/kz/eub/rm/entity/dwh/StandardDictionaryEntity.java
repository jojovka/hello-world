package kz.eub.rm.entity.dwh;

import kz.eub.rm.entity.ChangeDateMemorizingEntity;
import kz.eub.rm.entity.ChangeMemorizingEntity;
import kz.eub.rm.entity.ChangerUserMemorizingEntity;

public interface StandardDictionaryEntity extends HasId, ChangeMemorizingEntity {
}
