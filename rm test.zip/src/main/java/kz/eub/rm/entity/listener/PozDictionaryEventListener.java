package kz.eub.rm.entity.listener;

import kz.eub.rm.entity.dwh.PozDictionary;
import io.jmix.core.event.EntitySavingEvent;
import kz.eub.rm.entity.listener.support.ChangeDataMemorizingSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component("rm_PozDictionaryEventListener")
public class PozDictionaryEventListener {
    @Autowired
    private ChangeDataMemorizingSupport changeDataMemorizingSupport;

    @EventListener
    public void onPozDictionarySaving(EntitySavingEvent<PozDictionary> event) {
        //авто проставление даты изменения
        changeDataMemorizingSupport.fillChangeDateWithCurrent(event.getEntity());
    }
}