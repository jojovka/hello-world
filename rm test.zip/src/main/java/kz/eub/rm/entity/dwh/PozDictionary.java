package kz.eub.rm.entity.dwh;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;
import kz.eub.rm.entity.ChangeDateMemorizingEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;
import java.util.UUID;

//ПОЗ - портфель однородных займов
@Store(name = "dwhstore")
@JmixEntity
@Table(name = "s00_dict_snp_poz", schema = "dwh_risk")
@Entity(name = "rm_PozDictionary")
public class PozDictionary implements ChangeDateMemorizingEntity {
    @JmixGeneratedValue
    @Column(name = "sdsp_uuid", nullable = false)
    @Id
    private UUID id;

    @InstanceName
    @Column(name = "sdsp_poz_name")
    @Lob
    private String pozName;

    @Column(name = "sdsp_has_pledge")
    private Boolean isMortgage;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "\"sdsp$change_date\"")
    private Date changeDate;

    public Boolean getIsMortgage() {
        return isMortgage;
    }

    public void setIsMortgage(Boolean isMortgage) {
        this.isMortgage = isMortgage;
    }

    @Override
    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    @Override
    public Date getChangeDate() {
        return changeDate;
    }

    public String getPozName() {
        return pozName;
    }

    public void setPozName(String pozName) {
        this.pozName = pozName;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}