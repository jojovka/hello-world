package kz.eub.rm.entity;

//интерфейс сущности записи, хранящей информацию об изменившем ее пользователе
public interface ChangerFullNameMemorizingEntity {
    String getChangerFullName();

    void setChangerFullName(String userFullName);

}
