package kz.eub.rm.entity;

import io.jmix.bpm.entity.TaskData;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.JmixEntity;

import java.util.UUID;

@JmixEntity(name = "rm_ApplicationTask")
public class ApplicationTask {

    public static final String OUTCOME_APPROVE = "approve";
    public static final String OUTCOME_REJECT = "reject";

    @JmixGeneratedValue
    @JmixId
    private UUID id;

    private Application application;

    private TaskData taskData;

    public Application getApplication() {
        return application;
    }

    public void setApplication(Application application) {
        this.application = application;
    }

    public TaskData getTaskData() {
        return taskData;
    }

    public void setTaskData(TaskData taskData) {
        this.taskData = taskData;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}