package kz.eub.rm.entity.dwh;

import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;
import kz.eub.rm.entity.ChangeDateMemorizingEntity;

import javax.persistence.*;
import java.util.Date;

@JmixEntity
@Store(name = "dwhstore")
@Table(name = "triggers_dict", schema = "dwh_risk")
@Entity(name = "rm_TriggerDictionary")
public class TriggerDictionary implements ChangeDateMemorizingEntity {

    @Column(name = "td_code", nullable = false)
    @Id
    private String code;

    @InstanceName
    @Column(name = "td_name")
    private String name;

    @Column(name = "td_is_actual")
    private Boolean isActual;

    @Column(name = "\"td$start_date\"")
    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Column(name = "\"td$end_date\"")
    @Temporal(TemporalType.DATE)
    private Date endDate;

    @Column(name = "\"td$change_date\"")
    @Temporal(TemporalType.DATE)
    private Date changeDate;

    @Column(name = "td_fl")
    private Boolean isFl;

    @Column(name = "td_ul")
    private Boolean isUl;

    @Column(name = "TD_UNIFORM")
    private Boolean isUniform;

    @Column(name = "TD_NON_UNIFORM")
    private Boolean isNonUniform;

    @Column(name = "td_basket")
    private Integer basket;

    @Column(name = "td_level")
    private String definitionLevel;

    @Column(name = "td_type")
    private String triggerType;

    public TriggerType getTriggerType() {
        return triggerType == null ? null : TriggerType.fromId(triggerType);
    }

    public void setTriggerType(TriggerType triggerType) {
        this.triggerType = triggerType == null ? null : triggerType.getId();
    }

    public DefinitionLevel getDefinitionLevel() {
        return definitionLevel == null ? null : DefinitionLevel.fromId(definitionLevel);
    }

    public void setDefinitionLevel(DefinitionLevel definitionLevel) {
        this.definitionLevel = definitionLevel == null ? null : definitionLevel.getId();
    }

    public Integer getBasket() {
        return basket;
    }

    public void setBasket(Integer basket) {
        this.basket = basket;
    }

    public Boolean getIsNonUniform() {
        return isNonUniform;
    }

    public void setIsNonUniform(Boolean td_non_uniform) {
        this.isNonUniform = td_non_uniform;
    }

    public Boolean getIsUniform() {
        return isUniform;
    }

    public void setIsUniform(Boolean td_uniform) {
        this.isUniform = td_uniform;
    }

    public Boolean getIsUl() {
        return isUl;
    }

    public void setIsUl(Boolean isUl) {
        this.isUl = isUl;
    }

    public Boolean getIsFl() {
        return isFl;
    }

    public void setIsFl(Boolean isFl) {
        this.isFl = isFl;
    }

    @Override
    public Date getChangeDate() {
        return changeDate;
    }

    @Override
    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Boolean getIsActual() {
        return isActual;
    }

    public void setIsActual(Boolean isActual) {
        this.isActual = isActual;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

}