package kz.eub.rm.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;
import io.jmix.data.DdlGeneration;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import java.util.UUID;

@DdlGeneration(value = DdlGeneration.DbScriptGenerationMode.DISABLED)
@JmixEntity
@Store(name = "dwhstore")
@Table(name = "loans_sale_companies_dict")
@Entity(name = "rm_LoansSaleCompaniesDict")
public class LoansSaleCompaniesDict {
    @JmixGeneratedValue
    @Column(name = "lscd_uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "lscd_name")
    @Lob
    private String lscdName;

    @Column(name = "lscd_is_actual")
    private Boolean lscdIsActual;

    public String getLscdName() {
        return lscdName;
    }

    public void setLscdName(String lscdName) {
        this.lscdName = lscdName;
    }

    public Boolean getLscdIsActual() {
        return lscdIsActual;
    }

    public void setLscdIsActual(Boolean lscdIsActual) {
        this.lscdIsActual = lscdIsActual;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}