package kz.eub.rm.entity.dwh;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;
import kz.eub.rm.entity.ChangeDateMemorizingEntity;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhstore")
@Table(name = "s00_dict_snp_poz_mapping", schema = "dwh_risk", indexes = {
        @Index(name = "IDX_SDSPM_SDSP_ID", columnList = "sdspm_poz_uuid"),
        @Index(name = "IDX_S00DICTSNPPO_POZFORRESERV", columnList = "sdspm_poz_uuid_2")
})
@Entity(name = "rm_PozMapping")
public class PozMappingDictionary implements ChangeDateMemorizingEntity {
    @JmixGeneratedValue
    @Column(name = "sdspm_uuid", nullable = false)
    @Id
    private UUID id;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "\"sdspm$change_date\"")
    private Date changeDate;

    @Column(name = "sdspm_load_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date loadDate;

    @JoinColumn(name = "sdspm_poz_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private PozDictionary sdspId;

    @Column(name = "sdspm_prod_name")
    @InstanceName
    private String prodName;

    @JoinColumn(name = "sdspm_poz_uuid_2")
    @ManyToOne(fetch = FetchType.LAZY)
    private PozDictionary pozForReservePercentCalculation;

    @Column(name = "sdspm_is_actual")
    private Boolean isActual;

    public Boolean getIsActual() {
        return isActual;
    }

    public void setIsActual(Boolean isActual) {
        this.isActual = isActual;
    }

    public Date getLoadDate() {
        return loadDate;
    }

    public void setLoadDate(Date loadDate) {
        this.loadDate = loadDate;
    }

    public PozDictionary getPozForReservePercentCalculation() {
        return pozForReservePercentCalculation;
    }

    public void setPozForReservePercentCalculation(PozDictionary pozForReservePercentCalculation) {
        this.pozForReservePercentCalculation = pozForReservePercentCalculation;
    }

    @Override
    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    @Override
    public Date getChangeDate() {
        return changeDate;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public PozDictionary getSdspId() {
        return sdspId;
    }

    public void setSdspId(PozDictionary sdspId) {
        this.sdspId = sdspId;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}