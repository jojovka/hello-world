package kz.eub.rm.entity.dwh;

import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;
import io.jmix.data.DbView;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@DbView
@JmixEntity
@Store(name = "dwhstore")
@Table(name = "pledges_view", schema = "dwh_risk")
@Entity(name = "rm_PledgesDictionary")
public class PledgesDictionary {

    @Column(name = "uuid")
    @Id
    private UUID id;

    @Column(name = "C_REPORT_DATE")
    @Temporal(TemporalType.DATE)
    private Date reportDate;

    @Column(name = "c_gid")
    private Long gid;

    @Column(name = "c_dog_num")
    private String contractNumber;

    @Column(name = "c_cur_code")
    private String currentCode;

    @Column(name = "c_clnt_name")
    private String clientName;

    @Column(name = "c_cli_iin_bin")
    private String cliIinBin;

    @Column(name = "c_dprt_name")
    private String departmentName;

    @Column(name = "dlpled_gid")
    private Long dlpledGid;

    @Column(name = "DLPLED_DOG_NUM")
    private String dlpledDogNum;

    @Column(name = "DLPLED_OPEN_DATE")
    @Temporal(TemporalType.DATE)
    private Date dlpledOpenDate;

    @Column(name = "DLPLED_CUR_CD")
    private Long dlpledCurCd;

    @Column(name = "clnt_full_name")
    private String clientFullName;

    @Column(name = "clnt_iin_bin")
    private String clientIinBin;

    @Column(name = "lr_typename")
    private String lrTypeName;

    @Column(name = "KIND_ENS")
    private String kindEns;

    @Column(name = "DATE_NOK")
    @Temporal(TemporalType.DATE)
    private Date dateNok;

    @Column(name = "PRICE_ENS")
    private Long priceEns;

    @Column(name = "PRICE_KZT_ENS")
    private Long priceKztEns;

    @Column(name = "DATE_MON")
    @Temporal(TemporalType.DATE)
    private Date dateMon;

    @Column(name = "DLPLED_PRICE")
    private Long dlpledPrice;

    @Column(name = "DLPLED_PRICE_NAT")
    private Long dlpledPriceNat;

    @Column(name = "AL_PRICE")
    private Long alPrice;

    @Column(name = "COEFF", precision = 19, scale = 2)
    private BigDecimal coefficient;

    @Column(name = "DLPLED_STATUS")
    private String dlpledStatus;

    @Column(name = "C_STATE")
    private String state;

    @Column(name = "cs_run_id")
    private String runId;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getRunId() {
        return runId;
    }

    public void setRunId(String runId) {
        this.runId = runId;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getDlpledStatus() {
        return dlpledStatus;
    }

    public void setDlpledStatus(String dlpledStatus) {
        this.dlpledStatus = dlpledStatus;
    }

    public BigDecimal getCoefficient() {
        return coefficient;
    }

    public void setCoefficient(BigDecimal coefficient) {
        this.coefficient = coefficient;
    }

    public Long getAlPrice() {
        return alPrice;
    }

    public void setAlPrice(Long alPrice) {
        this.alPrice = alPrice;
    }

    public Long getDlpledPriceNat() {
        return dlpledPriceNat;
    }

    public void setDlpledPriceNat(Long dlpledPriceNat) {
        this.dlpledPriceNat = dlpledPriceNat;
    }

    public Long getDlpledPrice() {
        return dlpledPrice;
    }

    public void setDlpledPrice(Long dlpledPrice) {
        this.dlpledPrice = dlpledPrice;
    }

    public Date getDateMon() {
        return dateMon;
    }

    public void setDateMon(Date dateMon) {
        this.dateMon = dateMon;
    }

    public Long getPriceKztEns() {
        return priceKztEns;
    }

    public void setPriceKztEns(Long priceKztEns) {
        this.priceKztEns = priceKztEns;
    }

    public Long getPriceEns() {
        return priceEns;
    }

    public void setPriceEns(Long priceEns) {
        this.priceEns = priceEns;
    }

    public Date getDateNok() {
        return dateNok;
    }

    public void setDateNok(Date dateNok) {
        this.dateNok = dateNok;
    }

    public String getKindEns() {
        return kindEns;
    }

    public void setKindEns(String kindEns) {
        this.kindEns = kindEns;
    }

    public String getLrTypeName() {
        return lrTypeName;
    }

    public void setLrTypeName(String lrTypeName) {
        this.lrTypeName = lrTypeName;
    }

    public String getClientIinBin() {
        return clientIinBin;
    }

    public void setClientIinBin(String clientIinBin) {
        this.clientIinBin = clientIinBin;
    }

    public String getClientFullName() {
        return clientFullName;
    }

    public void setClientFullName(String clntFullName) {
        this.clientFullName = clntFullName;
    }

    public void setDlpledGid(Long dlpledGid) {
        this.dlpledGid = dlpledGid;
    }

    public Long getDlpledGid() {
        return dlpledGid;
    }

    public Long getDlpledCurCd() {
        return dlpledCurCd;
    }

    public void setDlpledCurCd(Long dpledCurCd) {
        this.dlpledCurCd = dpledCurCd;
    }

    public Date getDlpledOpenDate() {
        return dlpledOpenDate;
    }

    public void setDlpledOpenDate(Date dlpledOpenDate) {
        this.dlpledOpenDate = dlpledOpenDate;
    }

    public String getDlpledDogNum() {
        return dlpledDogNum;
    }

    public void setDlpledDogNum(String dlpledDogNum) {
        this.dlpledDogNum = dlpledDogNum;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getCliIinBin() {
        return cliIinBin;
    }

    public void setCliIinBin(String clientIinBin) {
        this.cliIinBin = clientIinBin;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getCurrentCode() {
        return currentCode;
    }

    public void setCurrentCode(String currentCode) {
        this.currentCode = currentCode;
    }

    public String getContractNumber() {
        return contractNumber;
    }

    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }

    public Date getReportDate() {
        return reportDate;
    }

    public void setReportDate(Date reportDate) {
        this.reportDate = reportDate;
    }

    public Long getGid() {
        return gid;
    }

    public void setGid(Long gid) {
        this.gid = gid;
    }
}