package kz.eub.rm.entity.listener;

import kz.eub.rm.entity.dwh.LiquidityCoefficientDictionary;
import io.jmix.core.event.EntitySavingEvent;
import kz.eub.rm.entity.listener.support.DictionaryRowAdjustmentSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component("rm_LiquidityCoefficientDictionaryEventListener")
public class LiquidityCoefficientDictionaryEventListener {
    @Autowired
    private DictionaryRowAdjustmentSupport dictionaryRowAdjustmentSupport;

    @EventListener
    public void onLiquidityCoefficientDictionarySaving(EntitySavingEvent<LiquidityCoefficientDictionary> event) {
        dictionaryRowAdjustmentSupport.adjustOnSave(event);
    }
}