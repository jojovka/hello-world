package kz.eub.rm.entity.dwh;

import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;
import io.jmix.data.DbView;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.UUID;

@DbView
@JmixEntity
@Store(name = "dwhstore")
@Table(name = "credits_view", schema = "dwh_risk")
@Entity(name = "rm_CreditContractsDictionary")
public class CreditContractsDictionary {

    @Column(name = "uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "c_gid")
    private Long cGid;

    @Column(name = "c_report_date")
    private Date cReportDate;

    @Column(name = "c_id", nullable = false)
    private Integer cId;

    @Column(name = "c_dog_num")
    @InstanceName
    private String cDogNum;

    @Column(name = "transh")
    private String transh;

    @Column(name = "c_cur_code", length = 3)
    private String cCurCode;

    @Column(name = "c_dprt_name")
    private String cDprtName;

    @Column(name = "c_clnt_name")
    private String cClntName;

    @Column(name = "c_cgrp_name")
    private String cCgrpName;

    @Column(name = "c_out_sum_od")
    private BigDecimal cOutSumOd;

    @Column(name = "c_out_sum_od_delay")
    private BigDecimal cOutSumOdDelay;

    @Column(name = "c_out_sum_perc")
    private BigDecimal cOutSumPerc;

    @Column(name = "c_out_sum_perc_delay")
    private BigDecimal cOutSumPercDelay;

    @Column(name = "c_out_sum_perc_od")
    private BigDecimal cOutSumPercOd;

    @Column(name = "c_out_sum_com")
    private BigDecimal cOutSumCom;

    @Column(name = "c_out_sum_com_delay")
    private BigDecimal cOutSumComDelay;

    @Column(name = "c_out_sum_pen_kzt")
    private BigDecimal cOutSumPenKzt;

    @Column(name = "c_out_sum_msfo_per")
    private BigDecimal cOutSumMsfoPer;

    @Column(name = "c_out_sum_neg_corr")
    private BigDecimal cOutSumNegCorr;

    @Column(name = "c_out_sum_dis_1434")
    private BigDecimal cOutSumDis1434;

    @Column(name = "c_out_sum_dis_2794")
    private BigDecimal cOutSumDis2794;

    @Column(name = "c_out_sum_corr_esp")
    private BigDecimal cOutSumCorrEsp;

    @Column(name = "c_out_sum_dev")
    private BigDecimal cOutSumDev;

    @Column(name = "c_out_sum_mod_1435")
    private BigDecimal cOutSumMod1435;

    @Column(name = "c_out_sum_msfo_1428")
    private BigDecimal cOutSumMsfo1428;

    @Column(name = "c_out_sum_prov_com_1845")
    private BigDecimal cOutSumProvCom1845;

    @Column(name = "c_out_sum_prov_1877_kzt")
    private BigDecimal cOutSumProv1877Kzt;

    @Column(name = "c_out_sum_debt_1860_kzt")
    private BigDecimal cOutSumDebt1860Kzt;

    @Column(name = "c_out_sum_kik")
    private BigDecimal cOutSumKik;

    @Column(name = "c_out_sum_dz_1877_kzt")
    private BigDecimal cOutSumDz1877Kzt;

    @Column(name = "c_out_sum_reser_kzt")
    private BigDecimal cOutSumReserKzt;

    @Column(name = "c_out_sum_outsys")
    private BigDecimal cOutSumOutsys;

    @Column(name = "c_out_sum_od_odd")
    private BigDecimal cOutSumOdOdd;

    @Column(name = "c_out_sum_all_debt")
    private BigDecimal cOutSumAllDebt;

    @Column(name = "c_out_sum_od_odd_mon_beg")
    private BigDecimal cOutSumOdOddMonBeg;

    @Column(name = "c_out_sum_all_debt_mon_beg")
    private BigDecimal cOutSumAllDebtMonBeg;

    @Column(name = "c_msfo_rate")
    private BigDecimal cMsfoRate;

    @Column(name = "c_out_sum_outsys_sum")
    private BigDecimal cOutSumOutsysSum;

    @Column(name = "c_out_sum_lesion")
    private BigDecimal cOutSumLesion;

    @Column(name = "c_cr_rate_month_beg")
    private BigDecimal cCrRateMonthBeg;

    @Column(name = "c_cr_rate_rep_date")
    private BigDecimal cCrRateRepDate;

    @Column(name = "c_prod_name")
    private String cProdName;

    @Column(name = "c_tarif")
    private String cTarif;

    @Column(name = "cs_is_uniform")
    private Integer isUniform;

    @Column(name = "cs_poz_name")
    private String pozName;

    @Column(name = "c_user_cred_type")
    private String cUserCredType;

    @Column(name = "c_cli_iin_bin")
    private String cCliIinBin;

    @Column(name = "c_cli_type", length = 3)
    private String cCliType;

    @Column(name = "c_sd_cd")
    private String cSdCd;

    @Column(name = "c_kod_ip")
    private String cKodIp;

    @Column(name = "c_exp_days")
    private Integer cExpDays;

    @Column(name = "c_exp_days_op_perc")
    private Integer cExpDaysOpPerc;

    //....
    @Column(name = "c_open_date")
    private Date cOpenDate;

    @Column(name = "c_paym_date")
    private Date cPaymDate;

    @Column(name = "c_oked")
    private String cOked;

    @Column(name = "c_cli_oked_cd")
    private String cCliOkedCd;

    @Column(name = "c_problem")
    private String cProblem;

    @Column(name = "c_class")
    private String cClass;

    @Column(name = "c_modif")
    private String cModif;

    @Column(name = "c_mod_date")
    private Date cModDate;

    @Column(name = "c_basket_mon_beg")
    private Integer cBasketMonBeg;

    @Column(name = "cs_basket_rep_date")
    private Integer basketOnReportDate;

    @Column(name = "c_rate")
    private BigDecimal cRate;

    @Column(name = "c_eff_rate")
    private BigDecimal cEffRate;

    //....
    @Column(name = "c_non_market_fl")
    private Boolean cNonMarketFl;

    @Column(name = "c_all_sum")
    private BigDecimal cAllSum;

    @Column(name = "c_control_list")
    private String cControlList;

    @Column(name = "c_state")
    private String cState;

    @Column(name = "c_source")
    private String cSource;

    @Column(name = "cs_trg_2")
    private Boolean trigger2;

    @Column(name = "cs_trg_3")
    private Boolean trigger3;

    @Column(name = "cs_trg_4")
    private Boolean trigger4;

    @Column(name = "cs_recovery_ready")
    private Boolean recoveryReady;

    @Column(name = "cs_default_date")
    @Temporal(TemporalType.DATE)
    private java.util.Date defaultDate;

    @Column(name = "cs_recovery_date")
    @Temporal(TemporalType.DATE)
    private java.util.Date recoveryDate;

    @Column(name = "cs_run_id")
    private String runId;

    @Column(name = "cs_uuid")
    private UUID uuid;

    @Column(name = "cs_segment")
    private String segment;

    @Column(name = "c_credit_dep")
    private String creditDepartmentCode;

    @Column(name = "C_CREDITSUM_KZT", precision = 19, scale = 2)
    private BigDecimal creditSumKzt;

    @Column(name = "C_DURATION")
    private Integer duration;

    @Column(name = "CS_SEGMENT_PROV")
    @Lob
    private String csSegmentProv;

    @Column(name = "cs_pd12ol", precision = 19, scale = 2)
    private BigDecimal csPd12ol;

    @Column(name = "cs_pdltol", precision = 19, scale = 2)
    private BigDecimal csPdltol;

    @Column(name = "cs_pd12", precision = 19, scale = 2)
    private BigDecimal csPd12;

    @Column(name = "cs_pdlt", precision = 19, scale = 2)
    private BigDecimal csPdlt;

    @Column(name = "cs_lgd", precision = 19, scale = 2)
    private BigDecimal csLgd;

    public String getCsSegmentProv() {
        return csSegmentProv;
    }
    public void setCsSegmentProv(String csSegmentProv) {
        this.csSegmentProv = csSegmentProv;
    }

    public BigDecimal getCsLgd() {
        return csLgd;
    }

    public void setCsLgd(BigDecimal csLgd) {
        this.csLgd = csLgd;
    }

    public BigDecimal getCsPdlt() {
        return csPdlt;
    }

    public void setCsPdlt(BigDecimal csPdlt) {
        this.csPdlt = csPdlt;
    }

    public BigDecimal getCsPd12() {
        return csPd12;
    }

    public void setCsPd12(BigDecimal csPd12) {
        this.csPd12 = csPd12;
    }

    public BigDecimal getCsPdltol() {
        return csPdltol;
    }

    public void setCsPdltol(BigDecimal csPdltol) {
        this.csPdltol = csPdltol;
    }

    public BigDecimal getCsPd12ol() {
        return csPd12ol;
    }

    public void setCsPd12ol(BigDecimal csPd12ol) {
        this.csPd12ol = csPd12ol;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public BigDecimal getCreditSumKzt() {
        return creditSumKzt;
    }

    public void setCreditSumKzt(BigDecimal creditSumKzt) {
        this.creditSumKzt = creditSumKzt;
    }

    public Long getCGid() {
        return cGid;
    }

    public void setCGid(Long cGid) {
        this.cGid = cGid;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getId() {
        return id;
    }

    public String getCreditDepartmentCode() {
        return creditDepartmentCode;
    }

    public void setCreditDepartmentCode(String creditDepartmentCode) {
        this.creditDepartmentCode = creditDepartmentCode;
    }

    public String getSegment() {
        return segment;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public void setBasketOnReportDate(Integer basketReportDate) {
        this.basketOnReportDate = basketReportDate;
    }

    public Integer getBasketOnReportDate() {
        return basketOnReportDate;
    }

    public String getTransh() {
        return transh;
    }

    public void setTransh(String transh) {
        this.transh = transh;
    }

    public UUID getUuid() {
        return uuid;
    }

    public void setUuid(UUID uuid) {
        this.uuid = uuid;
    }

    public String getRunId() {
        return runId;
    }

    public void setRunId(String runId) {
        this.runId = runId;
    }

    public String getPozName() {
        return pozName;
    }

    public void setPozName(String pozName) {
        this.pozName = pozName;
    }

    public Integer getIsUniform() {
        return isUniform;
    }

    public void setIsUniform(Integer isUniform) {
        this.isUniform = isUniform;
    }

    public java.util.Date getRecoveryDate() {
        return recoveryDate;
    }

    public void setRecoveryDate(java.util.Date recoveryDate) {
        this.recoveryDate = recoveryDate;
    }

    public java.util.Date getDefaultDate() {
        return defaultDate;
    }

    public void setDefaultDate(java.util.Date defaultDate) {
        this.defaultDate = defaultDate;
    }

    public Boolean getRecoveryReady() {
        return recoveryReady;
    }

    public void setRecoveryReady(Boolean recoveryReady) {
        this.recoveryReady = recoveryReady;
    }

    public Boolean getTrigger4() {
        return trigger4;
    }

    public void setTrigger4(Boolean trigger4) {
        this.trigger4 = trigger4;
    }

    public Boolean getTrigger3() {
        return trigger3;
    }

    public void setTrigger3(Boolean trigger2Copy) {
        this.trigger3 = trigger2Copy;
    }

    public Boolean getTrigger2() {
        return trigger2;
    }

    public void setTrigger2(Boolean trigger2) {
        this.trigger2 = trigger2;
    }

    public Date getCReportDate() {
        return cReportDate;
    }

    public void setCReportDate(Date cReportDate) {
        this.cReportDate = cReportDate;
    }

    public Integer getCId() {
        return cId;
    }

    public void setCId(Integer cId) {
        this.cId = cId;
    }

    public String getCDogNum() {
        return cDogNum;
    }

    public void setCDogNum(String cDogNum) {
        this.cDogNum = cDogNum;
    }

    public String getCCurCode() {
        return cCurCode;
    }

    public void setCCurCode(String cCurCode) {
        this.cCurCode = cCurCode;
    }

    public String getCDprtName() {
        return cDprtName;
    }

    public void setCDprtName(String cDprtName) {
        this.cDprtName = cDprtName;
    }

    public String getCClntName() {
        return cClntName;
    }

    public void setCClntName(String cClntName) {
        this.cClntName = cClntName;
    }

    public String getCCgrpName() {
        return cCgrpName;
    }

    public void setCCgrpName(String cCgrpName) {
        this.cCgrpName = cCgrpName;
    }

    public BigDecimal getCOutSumOd() {
        return cOutSumOd;
    }

    public void setCOutSumOd(BigDecimal cOutSumOd) {
        this.cOutSumOd = cOutSumOd;
    }

    public BigDecimal getCOutSumOdDelay() {
        return cOutSumOdDelay;
    }

    public void setCOutSumOdDelay(BigDecimal cOutSumOdDelay) {
        this.cOutSumOdDelay = cOutSumOdDelay;
    }

    public BigDecimal getCOutSumPerc() {
        return cOutSumPerc;
    }

    public void setCOutSumPerc(BigDecimal cOutSumPerc) {
        this.cOutSumPerc = cOutSumPerc;
    }

    public BigDecimal getCOutSumPercDelay() {
        return cOutSumPercDelay;
    }

    public void setCOutSumPercDelay(BigDecimal cOutSumPercDelay) {
        this.cOutSumPercDelay = cOutSumPercDelay;
    }

    public BigDecimal getCOutSumPercOd() {
        return cOutSumPercOd;
    }

    public void setCOutSumPercOd(BigDecimal cOutSumPercOd) {
        this.cOutSumPercOd = cOutSumPercOd;
    }

    public BigDecimal getCOutSumCom() {
        return cOutSumCom;
    }

    public void setCOutSumCom(BigDecimal cOutSumCom) {
        this.cOutSumCom = cOutSumCom;
    }

    public BigDecimal getCOutSumComDelay() {
        return cOutSumComDelay;
    }

    public void setCOutSumComDelay(BigDecimal cOutSumComDelay) {
        this.cOutSumComDelay = cOutSumComDelay;
    }

    public BigDecimal getCOutSumPenKzt() {
        return cOutSumPenKzt;
    }

    public void setCOutSumPenKzt(BigDecimal cOutSumPenKzt) {
        this.cOutSumPenKzt = cOutSumPenKzt;
    }

    public BigDecimal getCOutSumMsfoPer() {
        return cOutSumMsfoPer;
    }

    public void setCOutSumMsfoPer(BigDecimal cOutSumMsfoPer) {
        this.cOutSumMsfoPer = cOutSumMsfoPer;
    }

    public BigDecimal getCOutSumNegCorr() {
        return cOutSumNegCorr;
    }

    public void setCOutSumNegCorr(BigDecimal cOutSumNegCorr) {
        this.cOutSumNegCorr = cOutSumNegCorr;
    }

    public BigDecimal getCOutSumDis1434() {
        return cOutSumDis1434;
    }

    public void setCOutSumDis1434(BigDecimal cOutSumDis1434) {
        this.cOutSumDis1434 = cOutSumDis1434;
    }

    public BigDecimal getCOutSumDis2794() {
        return cOutSumDis2794;
    }

    public void setCOutSumDis2794(BigDecimal cOutSumDis2794) {
        this.cOutSumDis2794 = cOutSumDis2794;
    }

    public BigDecimal getCOutSumCorrEsp() {
        return cOutSumCorrEsp;
    }

    public void setCOutSumCorrEsp(BigDecimal cOutSumCorrEsp) {
        this.cOutSumCorrEsp = cOutSumCorrEsp;
    }

    public BigDecimal getCOutSumDev() {
        return cOutSumDev;
    }

    public void setCOutSumDev(BigDecimal cOutSumDev) {
        this.cOutSumDev = cOutSumDev;
    }

    public BigDecimal getCOutSumMod1435() {
        return cOutSumMod1435;
    }

    public void setCOutSumMod1435(BigDecimal cOutSumMod1435) {
        this.cOutSumMod1435 = cOutSumMod1435;
    }

    public BigDecimal getCOutSumMsfo1428() {
        return cOutSumMsfo1428;
    }

    public void setCOutSumMsfo1428(BigDecimal cOutSumMsfo1428) {
        this.cOutSumMsfo1428 = cOutSumMsfo1428;
    }

    public BigDecimal getCOutSumProvCom1845() {
        return cOutSumProvCom1845;
    }

    public void setCOutSumProvCom1845(BigDecimal cOutSumProvCom1845) {
        this.cOutSumProvCom1845 = cOutSumProvCom1845;
    }

    public BigDecimal getCOutSumProv1877Kzt() {
        return cOutSumProv1877Kzt;
    }

    public void setCOutSumProv1877Kzt(BigDecimal cOutSumProv1877Kzt) {
        this.cOutSumProv1877Kzt = cOutSumProv1877Kzt;
    }

    public BigDecimal getCOutSumDebt1860Kzt() {
        return cOutSumDebt1860Kzt;
    }

    public void setCOutSumDebt1860Kzt(BigDecimal cOutSumDebt1860Kzt) {
        this.cOutSumDebt1860Kzt = cOutSumDebt1860Kzt;
    }

    public BigDecimal getCOutSumKik() {
        return cOutSumKik;
    }

    public void setCOutSumKik(BigDecimal cOutSumKik) {
        this.cOutSumKik = cOutSumKik;
    }

    public BigDecimal getCOutSumDz1877Kzt() {
        return cOutSumDz1877Kzt;
    }

    public void setCOutSumDz1877Kzt(BigDecimal cOutSumDz1877Kzt) {
        this.cOutSumDz1877Kzt = cOutSumDz1877Kzt;
    }

    public BigDecimal getCOutSumReserKzt() {
        return cOutSumReserKzt;
    }

    public void setCOutSumReserKzt(BigDecimal cOutSumReserKzt) {
        this.cOutSumReserKzt = cOutSumReserKzt;
    }

    public BigDecimal getCOutSumOutsys() {
        return cOutSumOutsys;
    }

    public void setCOutSumOutsys(BigDecimal cOutSumOutsys) {
        this.cOutSumOutsys = cOutSumOutsys;
    }

    public BigDecimal getCOutSumOdOdd() {
        return cOutSumOdOdd;
    }

    public void setCOutSumOdOdd(BigDecimal cOutSumOdOdd) {
        this.cOutSumOdOdd = cOutSumOdOdd;
    }

    public BigDecimal getCOutSumAllDebt() {
        return cOutSumAllDebt;
    }

    public void setCOutSumAllDebt(BigDecimal cOutSumAllDebt) {
        this.cOutSumAllDebt = cOutSumAllDebt;
    }

    public BigDecimal getCOutSumOdOddMonBeg() {
        return cOutSumOdOddMonBeg;
    }

    public void setCOutSumOdOddMonBeg(BigDecimal cOutSumOdOddMonBeg) {
        this.cOutSumOdOddMonBeg = cOutSumOdOddMonBeg;
    }

    public BigDecimal getCOutSumAllDebtMonBeg() {
        return cOutSumAllDebtMonBeg;
    }

    public void setCOutSumAllDebtMonBeg(BigDecimal cOutSumAllDebtMonBeg) {
        this.cOutSumAllDebtMonBeg = cOutSumAllDebtMonBeg;
    }

    public BigDecimal getCMsfoRate() {
        return cMsfoRate;
    }

    public void setCMsfoRate(BigDecimal cMsfoRate) {
        this.cMsfoRate = cMsfoRate;
    }

    public BigDecimal getCOutSumOutsysSum() {
        return cOutSumOutsysSum;
    }

    public void setCOutSumOutsysSum(BigDecimal cOutSumOutsysSum) {
        this.cOutSumOutsysSum = cOutSumOutsysSum;
    }

    public BigDecimal getCOutSumLesion() {
        return cOutSumLesion;
    }

    public void setCOutSumLesion(BigDecimal cOutSumLesion) {
        this.cOutSumLesion = cOutSumLesion;
    }

    public BigDecimal getCCrRateMonthBeg() {
        return cCrRateMonthBeg;
    }

    public void setCCrRateMonthBeg(BigDecimal cCrRateMonthBeg) {
        this.cCrRateMonthBeg = cCrRateMonthBeg;
    }

    public BigDecimal getCCrRateRepDate() {
        return cCrRateRepDate;
    }

    public void setCCrRateRepDate(BigDecimal cCrRateRepDate) {
        this.cCrRateRepDate = cCrRateRepDate;
    }

    public String getCProdName() {
        return cProdName;
    }

    public void setCProdName(String cProdName) {
        this.cProdName = cProdName;
    }

    public String getCTarif() {
        return cTarif;
    }

    public void setCTarif(String cTarif) {
        this.cTarif = cTarif;
    }

    public String getCUserCredType() {
        return cUserCredType;
    }

    public void setCUserCredType(String cUserCredType) {
        this.cUserCredType = cUserCredType;
    }

    public String getCCliIinBin() {
        return cCliIinBin;
    }

    public void setCCliIinBin(String cCliIinBin) {
        this.cCliIinBin = cCliIinBin;
    }

    public String getCCliType() {
        return cCliType;
    }

    public void setCCliType(String cCliType) {
        this.cCliType = cCliType;
    }

    public String getCSdCd() {
        return cSdCd;
    }

    public void setCSdCd(String cSdCd) {
        this.cSdCd = cSdCd;
    }

    public String getCKodIp() {
        return cKodIp;
    }

    public void setCKodIp(String cKodIp) {
        this.cKodIp = cKodIp;
    }

    public Integer getCExpDays() {
        return cExpDays;
    }

    public void setCExpDays(Integer cExpDays) {
        this.cExpDays = cExpDays;
    }

    public Integer getCExpDaysOpPerc() {
        return cExpDaysOpPerc;
    }

    public void setCExpDaysOpPerc(Integer cExpDaysOpPerc) {
        this.cExpDaysOpPerc = cExpDaysOpPerc;
    }

    public Date getCOpenDate() {
        return cOpenDate;
    }

    public void setCOpenDate(Date cOpenDate) {
        this.cOpenDate = cOpenDate;
    }

    public Date getCPaymDate() {
        return cPaymDate;
    }

    public void setCPaymDate(Date cPaymDate) {
        this.cPaymDate = cPaymDate;
    }
    

    public String getCOked() {
        return cOked;
    }

    public void setCOked(String cOked) {
        this.cOked = cOked;
    }

    public String getCCliOkedCd() {
        return cCliOkedCd;
    }

    public void setCCliOkedCd(String cCliOkedCd) {
        this.cCliOkedCd = cCliOkedCd;
    }

    public String getCProblem() {
        return cProblem;
    }

    public void setCProblem(String cProblem) {
        this.cProblem = cProblem;
    }

    public String getCClass() {
        return cClass;
    }

    public void setCClass(String cClass) {
        this.cClass = cClass;
    }

    public String getCModif() {
        return cModif;
    }

    public void setCModif(String cModif) {
        this.cModif = cModif;
    }

    public Date getCModDate() {
        return cModDate;
    }

    public void setCModDate(Date cModDate) {
        this.cModDate = cModDate;
    }

    public Integer getCBasketMonBeg() {
        return cBasketMonBeg;
    }

    public void setCBasketMonBeg(Integer cBasketMonBeg) {
        this.cBasketMonBeg = cBasketMonBeg;
    }

    public BigDecimal getCRate() {
        return cRate;
    }

    public void setCRate(BigDecimal cRate) {
        this.cRate = cRate;
    }

    public BigDecimal getCEffRate() {
        return cEffRate;
    }

    public void setCEffRate(BigDecimal cEffRate) {
        this.cEffRate = cEffRate;
    }

    public Boolean getCNonMarketFl() {
        return cNonMarketFl;
    }

    public void setCNonMarketFl(Boolean cNonMarketFl) {
        this.cNonMarketFl = cNonMarketFl;
    }

    public BigDecimal getCAllSum() {
        return cAllSum;
    }

    public void setCAllSum(BigDecimal cAllSum) {
        this.cAllSum = cAllSum;
    }

    public String getCControlList() {
        return cControlList;
    }

    public void setCControlList(String cControlList) {
        this.cControlList = cControlList;
    }

    public String getCState() {
        return cState;
    }

    public void setCState(String cState) {
        this.cState = cState;
    }
//....
    public String getCSource() {
        return cSource;
    }

    public void setCSource(String cSource) {
        this.cSource = cSource;
    }
}