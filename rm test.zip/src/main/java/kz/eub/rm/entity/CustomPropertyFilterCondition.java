package kz.eub.rm.entity;

import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;
import kz.eub.rm.filter.CustomPropertyFilter;
import io.jmix.ui.entity.AbstractSingleFilterCondition;

@JmixEntity(name = "rm_CustomPropertyFilterCondition")
public class CustomPropertyFilterCondition extends AbstractSingleFilterCondition {

    private static final long serialVersionUID = 486148668136186191L;

    @JmixProperty
    protected String property;

    @JmixProperty
    protected String parameterName;

    @JmixProperty
    protected String operation;

    @JmixProperty
    protected Boolean operationEditable = true;

    @JmixProperty
    protected Boolean operationCaptionVisible = true;

    public String getProperty() {
        return property;
    }

    public void setProperty(String property) {
        this.property = property;
    }

    public String getParameterName() {
        return parameterName;
    }

    public void setParameterName(String parameterName) {
        this.parameterName = parameterName;
    }

    public CustomPropertyFilter.Operation getOperation() {
        return CustomPropertyFilter.Operation.fromId(operation);
    }

    public void setOperation(CustomPropertyFilter.Operation operation) {
        this.operation = operation != null ? operation.getId() : null;
    }

    public Boolean getOperationEditable() {
        return operationEditable;
    }

    public void setOperationEditable(Boolean operationEditable) {
        this.operationEditable = operationEditable;
    }

    public Boolean getOperationCaptionVisible() {
        return operationCaptionVisible;
    }

    public void setOperationCaptionVisible(Boolean operationCaptionVisible) {
        this.operationCaptionVisible = operationCaptionVisible;
    }
}