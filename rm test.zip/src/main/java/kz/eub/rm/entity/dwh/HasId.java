package kz.eub.rm.entity.dwh;

import java.util.UUID;

public interface HasId {
    UUID getId();
    void setId(UUID id);
}
