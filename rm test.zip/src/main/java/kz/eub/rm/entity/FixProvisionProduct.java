package kz.eub.rm.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;
import io.jmix.core.metamodel.annotation.NumberFormat;
import io.jmix.core.metamodel.annotation.Store;
import io.jmix.data.DdlGeneration;
import kz.eub.rm.entity.dwh.PozMappingDictionary;
import kz.eub.rm.entity.dwh.StandardDictionaryEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@DdlGeneration(value = DdlGeneration.DbScriptGenerationMode.DISABLED)
@JmixEntity
@Store(name = "dwhstore")
@Table(name = "fix_provision_products", indexes = {
        @Index(name = "IDX_FIXPROVISION_FPPPRODUCTUU", columnList = "FPP_PRODUCT_UUID")
})
@Entity(name = "rm_FixProvisionProduct")
public class FixProvisionProduct implements StandardDictionaryEntity {
    @JmixGeneratedValue
    @Column(name = "fpp_uuid", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "FPP_PRODUCT_UUID")
    @OneToOne(fetch = FetchType.LAZY)
    private PozMappingDictionary fppProductUuid;

    @Column(name = "fpp_product")
    @InstanceName
    @Lob
    private String fppProduct;

    @Column(name = "fpp_basket")
    private Integer fppBasket;

    @Column(name = "fpp_provision", precision = 19, scale = 2)
    @NumberFormat(pattern = "#,##0.00", decimalSeparator = ",")
    private BigDecimal fppProvision;

    @Column(name = "fpp_is_actual")
    private Boolean fppIsActual;

    @Temporal(TemporalType.DATE)
    @Column(name = "fpp_change_date")
    private Date fppChangeDate;

    @Column(name = "fpp_change_user_uuid")
    private UUID fppChangeUserUuid;

    @Column(name = "fpp_dog_num_mask")
    @Lob
    private String fppDogNumMask;

    @DependsOnProperties({"fppChangeUserUuid"})
    @JmixProperty
    @Transient
    private User fppChangeUser;

    public User getFppChangeUser() {
        return fppChangeUser;
    }

    public void setFppChangeUser(User fppChangeUser) {
        this.fppChangeUser = fppChangeUser;
    }

    public void setFppChangeDate(Date fppChangeDate) {
        this.fppChangeDate = fppChangeDate;
    }

    public Date getFppChangeDate() {
        return fppChangeDate;
    }

    public void setFppProductUuid(PozMappingDictionary fppProductUuid) {
        this.fppProductUuid = fppProductUuid;
    }

    public PozMappingDictionary getFppProductUuid() {
        return fppProductUuid;
    }

    public BigDecimal getFppProvision() {
        return fppProvision;
    }

    public void setFppProvision(BigDecimal fppProvision) {
        this.fppProvision = fppProvision;
    }

    public String getFppProduct() {
        return fppProduct;
    }

    public void setFppProduct(String fppProduct) {
        this.fppProduct = fppProduct;
    }

    public Boolean getFppIsActual() {
        return fppIsActual;
    }

    public void setFppIsActual(Boolean fppIsActual) {
        this.fppIsActual = fppIsActual;
    }

    public String getFppDogNumMask() {
        return fppDogNumMask;
    }

    public void setFppDogNumMask(String fppDogNumMask) {
        this.fppDogNumMask = fppDogNumMask;
    }

    public UUID getFppChangeUserUuid() {
        return fppChangeUserUuid;
    }

    public void setFppChangeUserUuid(UUID fppChangeUserUuid) {
        this.fppChangeUserUuid = fppChangeUserUuid;
    }

    public Integer getFppBasket() {
        return fppBasket;
    }

    public void setFppBasket(Integer fppBasket) {
        this.fppBasket = fppBasket;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @Override
    public Date getChangeDate() {
        return fppChangeDate;
    }

    @Override
    public void setChangeDate(Date changeDate) {
        this.fppChangeDate = changeDate;
    }

    @Override
    public UUID getChangerUserId() {
        return fppChangeUserUuid;
    }

    @Override
    public void setChangerUserId(UUID id) {
        this.fppChangeUserUuid = id;
    }
}