package kz.eub.rm.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum EGender implements EnumClass<String> {

    MALE("MALE"),
    FEMALE("FEMALE");

    private String id;

    EGender(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static EGender fromId(String id) {
        for (EGender at : EGender.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}