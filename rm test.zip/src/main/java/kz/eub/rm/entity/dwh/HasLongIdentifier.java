package kz.eub.rm.entity.dwh;

public interface HasLongIdentifier {
    void setLongIdentifier(Long identifier);
    Long getLongIdentifier();
}
