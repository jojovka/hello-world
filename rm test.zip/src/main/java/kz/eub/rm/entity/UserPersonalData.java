package kz.eub.rm.entity;

public interface UserPersonalData {
    String getFullName();
}
