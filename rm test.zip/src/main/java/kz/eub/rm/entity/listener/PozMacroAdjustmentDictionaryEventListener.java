package kz.eub.rm.entity.listener;

import kz.eub.rm.entity.dwh.PozMacroAdjustmentDictionary;
import io.jmix.core.event.EntitySavingEvent;
import kz.eub.rm.entity.listener.support.ChangeDataMemorizingSupport;
import kz.eub.rm.entity.listener.support.DictionaryRowAdjustmentSupport;
import kz.eub.rm.sql.access.function.sequence.SequenceName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component("rm_PozMacroAdjustmentDictionaryEventListener")
public class PozMacroAdjustmentDictionaryEventListener {
    @Autowired
    private ChangeDataMemorizingSupport changeDataMemorizingSupport;

    @EventListener
    public void onPozMacroAdjustmentDictionarySaving(EntitySavingEvent<PozMacroAdjustmentDictionary> event) {
        changeDataMemorizingSupport.fillChangeDateWithCurrent(event.getEntity());
        changeDataMemorizingSupport.fillChangerUserId(event.getEntity());
    }
}