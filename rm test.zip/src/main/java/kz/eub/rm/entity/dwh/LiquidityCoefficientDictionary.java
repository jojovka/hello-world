package kz.eub.rm.entity.dwh;

import io.jmix.core.entity.annotation.SystemLevel;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;
import io.jmix.core.metamodel.annotation.Store;
import kz.eub.rm.entity.ChangeMemorizingEntity;
import kz.eub.rm.entity.User;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhstore")
@Table(name = "liqudity_ratio", schema = "dwh_risk")
@Entity(name = "rm_LiquidityCoefficientDictionary")
public class LiquidityCoefficientDictionary implements ChangeMemorizingEntity {

    @Column(name = "lr_pledge_type", nullable = false)
    @Id
    @GeneratedValue
    private String pledgeType;

    @Column(name = "lr_ratio", precision = 19, scale = 2)
    private BigDecimal liquidityRatio;

    @Column(name = "lr_typename")
    @InstanceName
    private String name;

    @Column(name = "lr_fullname")
    private String fullName;

    @Column(name = "lr_is_actual")
    private Boolean isActual;

    @Column(name = "lr_period")
    private Integer discountingTermMonths;

    @Column(name = "lr$start_date")
    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Column(name = "lr$end_date")
    @Temporal(TemporalType.DATE)
    private Date endDate;

    @SystemLevel
    @Column(name = "lr_user_uuid")
    private UUID changerUserId;

    @Column(name = "lr$change_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date changeDate;

    @DependsOnProperties({"changerUserId"})
    @JmixProperty
    @Transient
    private User changerUser;

    public Integer getDiscountingTermMonths() {
        return discountingTermMonths;
    }

    public void setDiscountingTermMonths(Integer discountingTermMonths) {
        this.discountingTermMonths = discountingTermMonths;
    }

    @Override
    public Date getChangeDate() {
        return changeDate;
    }

    @Override
    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public User getChangerUser() {
        return changerUser;
    }

    public void setChangerUser(User changerUser) {
        this.changerUser = changerUser;
    }

    @Override
    public UUID getChangerUserId() {
        return changerUserId;
    }

    @Override
    public void setChangerUserId(UUID changerUserId) {
        this.changerUserId = changerUserId;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Boolean getIsActual() {
        return isActual;
    }

    public void setIsActual(Boolean isActual) {
        this.isActual = isActual;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getName() {
        return name;
    }

    public void setName(String typeName) {
        this.name = typeName;
    }

    public BigDecimal getLiquidityRatio() {
        return liquidityRatio;
    }

    public void setLiquidityRatio(BigDecimal ratio) {
        this.liquidityRatio = ratio;
    }

    public String getPledgeType() {
        return pledgeType;
    }

    public void setPledgeType(String pledgeType) {
        this.pledgeType = pledgeType;
    }

}