package kz.eub.report360.app.service;

import java.util.List;

public interface ExcelDataImporter {
    void saveObjectsListUsingSaveContext(List<?> objects);
}
