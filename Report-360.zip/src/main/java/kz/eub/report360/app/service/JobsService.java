package kz.eub.report360.app.service;

import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Service("r360_JobsServiceService")
public class JobsService {
    @PersistenceContext(unitName = "dwhprod")
    private EntityManager em;

    public int getNumOfBDaysToday() {
        return em.createNativeQuery("with recursive dep as (\n" +
                        "select\n" +
                        "h11.objid as dep_id,\n" +
                        "h11.sobid as dep_par_id\n" +
                        "from\n" +
                        "dwh_stage.s07_hrp1001 h11    \n" +
                        "where 1=1\n" +
                        "and h11.otype = 'O'\n" +
                        "and h11.subty = 'A002'\n" +
                        "and current_date between to_date (h11.begda, 'yyyymmdd') and to_date (h11.endda, 'yyyymmdd')\n" +
                        "and h11.objid = '50003807'\n" +
                        "union all \n" +
                        "select\n" +
                        "h11.objid as dep_id,\n" +
                        "h11.sobid as dep_par_id\n" +
                        "from\n" +
                        "dwh_stage.s07_hrp1001 h11   \n" +
                        "join dep \n" +
                        "        on dep.dep_id = h11.sobid \n" +
                        "where 1=1\n" +
                        "and h11.otype = 'O'\n" +
                        "and h11.subty = 'A002'\n" +
                        "and current_date between to_date (h11.begda, 'yyyymmdd') and to_date (h11.endda, 'yyyymmdd')\n" +
                        ")\n" +
                        "SELECT                                                                 \n" +
                        "pa2.NACHN ||' ' || pa2.VORNA AS name  \n" +
                        "from dwh_stage.s07_hrp1000 h10 \n" +
                        "join dep \n" +
                        "        on h10.objid = dep.dep_id \n" +
                        "LEFT JOIN dwh_stage.s07_hrp1001 h11 \n" +
                        "        ON h11.sobid=h10.OBJID \n" +
                        "        AND h11.OTYPE='S' \n" +
                        "        AND h11.SUBTY='A003' \n" +
                        "        AND current_date BETWEEN to_date(h11.BEGDA,'yyyymmdd') and to_date(h11.ENDDA,'yyyymmdd')\n" +
                        "left join dwh_stage.s07_pa0001 pa1 \n" +
                        "        on pa1.plans = h11.objid \n" +
                        "        AND current_date BETWEEN to_date(pa1.BEGDA,'yyyymmdd') and to_date(pa1.ENDDA,'yyyymmdd')\n" +
                        "left join dwh_stage.s07_pa0002 pa2 \n" +
                        "        on pa2.pernr = pa1.pernr \n" +
                        "        AND current_date BETWEEN to_date(pa2.BEGDA,'yyyymmdd') and to_date(pa2.ENDDA,'yyyymmdd')   \n" +
                        "left join dwh_stage.s07_pa0000 p0 \n" +
                        "        ON p0.pernr = pa1.pernr \n" +
                        "        AND current_date BETWEEN to_date(p0.BEGDA,'yyyymmdd') and to_date(p0.ENDDA,'yyyymmdd')   \n" +
                        "LEFT JOIN dwh_stage.s07_hrp1000 h10_p \n" +
                        "        ON h10_p.objid = pa1.PLANS \n" +
                        "        AND h10_p.otype = 'S' \n" +
                        "        AND h10_p.langu = 'R' \n" +
                        "        AND current_date BETWEEN to_date(h10_p.BEGDA,'yyyymmdd') and to_date(h10_p.ENDDA,'yyyymmdd')\n" +
                        "where 1=1\n" +
                        "--AND substring (to_char (current_date::date, 'dd.mm.yyyy'), 1, 5) = substring (to_char (to_date(pa2.gbdat,'yyyymmdd'), 'dd.mm.yyyy') , 1, 5)\n" +
                        "AND current_date BETWEEN to_date(h10.BEGDA,'yyyymmdd') AND to_date(h10.ENDDA,'yyyymmdd') \n" +
                        "and substring (to_char (to_date(pa2.gbdat,'yyyymmdd'), 'dd.mm.yyyy') , 1, 5) = substring(to_char(current_date,'dd.mm.yyyy'),1,5)\n" +
                        "and p0.stat2 = '3'\n" +
                        "AND h10.OTYPE='O'                                                                      \n" +
                        "AND h10.PLVAR='01'                                                                     \n" +
                        "AND h10.LANGU='R'                                                                      \n" +
                        "AND pa1.PERNR  IS NOT null\n" +
                        "Order by h10.objid\n")
                .getResultList()
                .size();
    }
}