package kz.eub.report360.app;

import io.jmix.notifications.channel.UserEmailResolver;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import javax.annotation.Nullable;

@Component("r360_GetEmailService")
public class GetEmailService implements UserEmailResolver {
    @Nullable
    @Override
    public String resolveEmail(UserDetails user) {
        return user.getUsername() + "@eubank.kz";
    }
}