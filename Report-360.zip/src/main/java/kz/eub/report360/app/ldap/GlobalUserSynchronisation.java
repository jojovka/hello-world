package kz.eub.report360.app.ldap;

import io.jmix.core.security.Authenticated;
import io.jmix.ldap.userdetails.LdapUserSynchronizationManager;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.stereotype.Component;

@Component("r360_GlobalUserSynchronisation")
public class GlobalUserSynchronisation implements Job {

    private static final Logger log = LoggerFactory.getLogger(GlobalUserSynchronisation.class);

    private ApplicationContext context;

    @Autowired
    public void context(ApplicationContext context) {
        this.context = context;
    }

    @Authenticated
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        synchronizeUsersFromAD();
    }

    public void synchronizeUsersFromAD() {

        LdapUserSynchronizationManager ldapUserSynchronizationManager = context.getBean(LdapUserSynchronizationManager.class);

        LdapTemplate ldapTemplate = context.getBean(LdapTemplate.class);
        ldapUserSynchronizationManager.setLdapTemplate(ldapTemplate);

        ldapUserSynchronizationManager.synchronizeUsersFromGroup();
    }
}
