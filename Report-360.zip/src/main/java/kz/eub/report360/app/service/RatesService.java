package kz.eub.report360.app.service;

import com.google.common.base.Strings;
import io.jmix.core.DataManager;
import kz.eub.report360.entity.RateDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Component("r360_RatesService")
public class RatesService {

    private static final Logger log = LoggerFactory.getLogger(RatesService.class);
    private static final SimpleDateFormat f1 = new SimpleDateFormat("yyyy-MM-dd");
    private static final SimpleDateFormat f2 = new SimpleDateFormat("dd.MM.yyyy");

    @Autowired
    protected DataManager dataManager;

    private JdbcTemplate dwhdbJdbcTemplate;
    private JdbcTemplate dwhDataSource;

    @Autowired
    public RatesService(@Qualifier("dwhdbDataSource") DataSource dwhdbDataSource,
                        @Qualifier("dwhprodDataSource") DataSource dwhDataSource) {
        this.dwhdbJdbcTemplate = new JdbcTemplate(dwhdbDataSource);
        this.dwhDataSource = new JdbcTemplate(dwhDataSource);
    }

    public List<RateDto> getCurrencyRates(String code) {
        return dwhdbJdbcTemplate.query("select " +
                        "rate.gl_workdate AS CUR_DATE, " +
                        "cur.code||'/KZT' AS CUR_CODE, " +
                        "sum(CASE WHEN type.name = 'Курс покупки банком валю' THEN rate ELSE 0 end) rate_BUY, " +
                        "sum(CASE WHEN type.name = 'Курс продажи банком валю' THEN rate ELSE 0 end) rate_SALE, " +
                        "sum(CASE WHEN type.name = 'Курс НБ РК' THEN rate ELSE 0 end) rate_NBRK " +
                        "from " +
                        "target.gl_currency_d cur, " +
                        "target.gl_cur_rate rate, " +
                        "target.gl_cur_ratetype_d type " +
                        "where cur.code = ? " +
                        "and cur.id = rate.cur_ref " +
                        "and type.id = rate.cur_ratetype " +
                        "and rate.gl_workdate BETWEEN to_date('01.06.2020', 'dd.mm.yyyy') AND to_date('30.06.2023', 'dd.mm.yyyy') " +
                        "and type.id IN (1,2,3) " +
                        "GROUP BY rate.gl_workdate, cur.code " +
                        "ORDER BY rate.gl_workdate, cur.code",
                getRateDtoRowMapper(), code);
    }

    public List<RateDto> getAllCurrencyRates(Date ds) {
        return dwhdbJdbcTemplate.query("select " +
                        "rate.gl_workdate AS CUR_DATE, " +
                        "cur.code||'/KZT' AS CUR_CODE, " +
                        "sum(CASE WHEN type.name = 'Курс покупки банком валю' THEN rate ELSE 0 end) rate_BUY, " +
                        "sum(CASE WHEN type.name = 'Курс продажи банком валю' THEN rate ELSE 0 end) rate_SALE, " +
                        "sum(CASE WHEN type.name = 'Курс НБ РК' THEN rate ELSE 0 end) rate_NBRK " +
                        "from " +
                        "target.gl_currency_d cur, " +
                        "target.gl_cur_rate rate, " +
                        "target.gl_cur_ratetype_d type " +
                        "where cur.id = rate.cur_ref " +
                        "and type.id = rate.cur_ratetype " +
                        "and rate.gl_workdate = to_date(?, 'dd.mm.yyyy') " +
                        "and type.id IN (1,2,3) " +
                        "GROUP BY rate.gl_workdate, cur.code " +
                        "ORDER BY rate.gl_workdate, cur.code",
                getRateDtoRowMapper(), f2.format(ds));
    }

    private RowMapper<RateDto> getRateDtoRowMapper() {
        return (rs, rowNum) -> {
            RateDto rate = dataManager.create(RateDto.class);
            rate.setRateNbrk(rs.getBigDecimal("rate_NBRK"));
            rate.setRateSale(rs.getBigDecimal("rate_SALE"));
            rate.setRateBuy(rs.getBigDecimal("rate_BUY"));
            rate.setDate(rs.getDate("CUR_DATE"));
            rate.setCode(rs.getString("CUR_CODE"));
            return rate;
        };
    }

    public List<RateDto> getBloombergRates(String code) {
        return dwhDataSource.query("select " +
                        "c.report_date as CUR_DATE, " +
                        "substring(c.recordidentifier,1,3)||'/'||substring(c.recordidentifier,4,3) as CUR_CODE, " +
                        "c.pxbid as BID, " +
                        "c.pxask as ASK, " +
                        "c.pxlast as LAST " +
                        "from  " +
                        "dwh_stage.s08_dict_bloomberg_curquota c  " +
                        "where " +
                        "substring(c.recordidentifier,1,3) = ? and  " +
                        "c.pxbid is not null and length(c.pxbid) > 1 and " +
                        "c.report_date between '2020-06-16' and '2023-06-16' " +
                        "order by c.report_date asc",
                getBloombergRateDtoRowMapper(), code);
    }

    private RowMapper<RateDto> getBloombergRateDtoRowMapper() {
        return (rs, rowNum) -> {
            RateDto rate = dataManager.create(RateDto.class);
            if (!Strings.isNullOrEmpty(rs.getString("BID").trim()))
                rate.setBid(rs.getBigDecimal("BID"));
            if (!Strings.isNullOrEmpty(rs.getString("LAST").trim()))
                rate.setLast(rs.getBigDecimal("LAST"));
            if (!Strings.isNullOrEmpty(rs.getString("ASK").trim()))
                rate.setAsk(rs.getBigDecimal("ASK"));
            rate.setDate(rs.getDate("CUR_DATE"));
            rate.setCode(rs.getString("CUR_CODE"));
            return rate;
        };
    }

}