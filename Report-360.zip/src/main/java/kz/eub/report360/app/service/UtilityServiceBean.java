package kz.eub.report360.app.service;

import io.jmix.core.DataManager;
import io.jmix.core.querycondition.PropertyCondition;
import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import io.jmix.emailtemplates.EmailTemplateBuilder;
import io.jmix.emailtemplates.EmailTemplates;
import io.jmix.emailtemplates.exception.ReportParameterTypeChangedException;
import io.jmix.emailtemplates.exception.TemplateNotFoundException;
import io.jmix.security.model.ResourceRole;
import io.jmix.security.role.ResourceRoleRepository;
import io.jmix.securitydata.entity.RoleAssignmentEntity;
import io.jmix.securityui.model.ResourceRoleModel;
import io.jmix.securityui.model.RoleModelConverter;
import kz.eub.report360.entity.AppSetting;
import kz.eub.report360.entity.DictDepartment;
import kz.eub.report360.entity.Employee;
import kz.eub.report360.entity.ReportXml;
import kz.eub.report360.entity.ReportXmlHist;
import kz.eub.report360.entity.ReportXmlParam;
import kz.eub.report360.entity.Reporting;
import kz.eub.report360.entity.ReportingApprov;
import kz.eub.report360.entity.ReportingGrants;
import kz.eub.report360.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service(UtilityService.NAME)
public class UtilityServiceBean implements UtilityService {
    @Autowired
    private DataManager dataManager;
    @Autowired
    private CurrentUserSubstitution currentUserSubstitution;
    @Autowired
    private ResourceRoleRepository roleRepository;
    @Autowired
    private RoleModelConverter roleModelConverter;
    @Autowired
    private EmailTemplates emailTemplates;


    /**
     * Функционал для согласования отчетов
     */
    @Override
    public void saveChangeRepApprov(ReportingApprov reportingApprov) {
        List<ReportingApprov> approvList = getReportingApprov(reportingApprov);
        for (ReportingApprov approv : approvList) {
            dataManager.remove(approv);
        }
        dataManager.save(reportingApprov);
    }

    private List getReportingApprov(ReportingApprov reportingApprov) {
        return dataManager.load(ReportingApprov.class)
                .query("select e from r360_ReportingApprov e where e.reporting=:reporting and e.dateOnRep=:onDate")
                .parameter("reporting", reportingApprov.getReporting())
                .parameter("onDate", reportingApprov.getDateOnRep())
                .fetchPlan("_base")
                .list();
    }

    /**
     * Модуль XML Отчеты
     */
    @Override
    public ReportXmlHist getRepXmlHist(Date dateOnRep, ReportXml reportXml) {
        try {
            return dataManager.load(ReportXmlHist.class)
                    .query("select h from r360_ReportXmlHist h where h.dateOnRep = :dateOnRep and h.reportXml = :reportXml")
                    .parameter("dateOnRep", dateOnRep)
                    .parameter("reportXml", reportXml)
                    .one();
        } catch (IllegalStateException e) {
            return null;
        }
    }

    @Override
    public List<ReportXmlParam> getRepXmlPar(ReportXml reportXml) {
        try {
            return dataManager.load(ReportXmlParam.class)
                    .query("select p from r360_ReportXmlParam p where p.reportXml = :reportXml")
                    .parameter("reportXml", reportXml)
                    .list();
        } catch (IllegalStateException e) {
            return null;
        }
    }

    @Override
    public ReportXmlParam getRepXmlParam(ReportXml reportXml, String parCode) {
        try {
            return dataManager.load(ReportXmlParam.class)
                    .query("select p from r360_ReportXmlParam p where p.reportXml = :reportXml and p.code = :code")
                    .parameter("reportXml", reportXml)
                    .parameter("code", parCode)
                    .one();
        } catch (IllegalStateException e) {
            return null;
        }
    }

    @Override
    public void addRepXmlHist(Date dateOnRep, ReportXml reportXml, int countRep, ReportXmlHist reportXmlHist) {
        if (reportXmlHist == null) {
            reportXmlHist = dataManager.create(ReportXmlHist.class);
            reportXmlHist.setReportXml(reportXml);
            reportXmlHist.setDateOnRep(dateOnRep);
            reportXmlHist.setCountRun(countRep);
        } else {
            reportXmlHist.setCountRun(countRep);
        }
        dataManager.save(reportXmlHist);
    }

    @Override
    public String getAppSettingVal(String val) {
        try {
            return dataManager.load(AppSetting.class)
                    .query("select e from r360_AppSetting e where e.code = :val")
                    .parameter("val", val)
                    .one()
                    .getValue();
        } catch (IllegalStateException e) {
            return "No results";
        }
    }

    @Override
    public String getDateToString(java.sql.Date date) {
        if (date == null) {
            return null;
        }

        String dateFormat = "dd.MM.yyyy"; //формат по умолчанию
        String dateCode = "[DATE]"; //код по умолчанию
        Pattern pattern;
        Matcher matcher;
        int i = 1;
        pattern = Pattern.compile("(\\')(.*?)(\\')"); //поиск строк между символами ''

        String strFormat = getAppSettingVal("FORMAT_DATE"); //пример значения, которое должна вернуть функция: to_date('[DATE]','dd/MM/yyyy')
        if (strFormat.equals("No results")) {
            return null;
        }

        matcher = pattern.matcher(strFormat);
        while (matcher.find()) {
            if (i == 1) {
                dateCode = matcher.group(2);
            } else if (i == 2) {
                dateFormat = matcher.group(2);
            }
            i++;
        }

        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
        return strFormat.replace(dateCode, formatter.format(date));
    }

    /**
     * Поиск всех доступных отчетов для пользователя
     */
    @Override
    public Set<Reporting> findAllPermittedReporting(User user) {
        Set<Reporting> reportingSet = new HashSet<>();
        //1 Если пользователь админ или ДУД, возвращаем все отчеты
        for (ResourceRoleModel resourceRoleModel : getUserRoles(user)) {
            if ((resourceRoleModel.getCode() != null && resourceRoleModel.getCode().equals("system-full-access"))
                    || (resourceRoleModel.getCode() != null && resourceRoleModel.getCode().equals("r360-top-access"))) {
                reportingSet.addAll(dataManager.load(Reporting.class).all().list());
                return reportingSet;
            }
        }

        //2 Ищем где пользователь владелец за отчет
        reportingSet.addAll(dataManager.load(Reporting.class)
                .query("select e from r360_Reporting e where e.ownerUserLog=:owner_user")
                .parameter("owner_user", user)
                .list());

        //3 Ищем этого пользователя в разрешенных правах для отчета
        reportingSet.addAll(dataManager.load(ReportingGrants.class)
                .query("select e from r360_ReportingGrants e where e.user=:user")
                .parameter("user", user)
                .fetchPlan("reportingGrants-fetch-plan")
                .list().stream().map(ReportingGrants::getReporting).collect(Collectors.toSet()));

        //4. Ищем в разрешенных правах указанное подразделение для отчета и проверяем доступен ли этот отчет для пользователя
        //согласно его подразделению. Например если структура: Департамент-Управление-Отдел и у пользователя, подразделение Отдел а в
        //правах для отчета указано подразделение Департамент, то необходимо проверить по иерархии входит ли отдел в департамент по вышестоящему id
        //и если входит, выдать доступ
        //расширение переданного пользователя
        Employee employee = getEmployee(user);
        if (employee != null) {
            if (employee.getDepartment() != null) {
                List<ReportingGrants> reportingGrants = dataManager.load(ReportingGrants.class).query("select e from r360_ReportingGrants e where e.department is not null")
                        .fetchPlan("reportingGrants-fetch-plan").list();
                for (ReportingGrants reportingGrant : reportingGrants) {
                    DictDepartment dictDepartment = getDep(reportingGrant.getDepartment());
                    if (dictDepartment != null) {
                        if (dictDepartment.getId().equals(employee.getDepartment().getId())) {
                            reportingSet.add(reportingGrant.getReporting());
                        } else {
                            DictDepartment parentDepartment = employee.getDepartment().getParent();
                            while (parentDepartment != null) {
                                if (parentDepartment.getId().equals(dictDepartment.getId())) {
                                    reportingSet.add(reportingGrant.getReporting());
                                    break;
                                } else {
                                    parentDepartment = parentDepartment.getParent();
                                }
                            }
                        }
                    }
                }
            }
        }

        return reportingSet;
    }

    private List<ResourceRoleModel> getUserRoles(User user) {
        List<RoleAssignmentEntity> roleAssignmentEntities = dataManager.load(RoleAssignmentEntity.class)
                .condition(PropertyCondition.equal("username", user.getUsername()))
                .list();
        List<String> roleCodes = roleAssignmentEntities.stream()
                .map(RoleAssignmentEntity::getRoleCode)
                .collect(Collectors.toList());
        Collection<ResourceRole> allRoles = roleRepository.getAllRoles();
        return allRoles.stream()
                .filter(r -> roleCodes.contains(r.getCode()))
                .map(roleModelConverter::createResourceRoleModel)
                .sorted(Comparator.comparing(ResourceRoleModel::getName))
                .collect(Collectors.toList());
    }

    private DictDepartment getDep(DictDepartment department) {
        try {
            return dataManager.load(DictDepartment.class).query("select e from r360_DictDepartment e where e.id=:department")
                    .parameter("department", department)
                    .one();
        } catch (Exception e) {
            return null;
        }
    }

    private Employee getEmployee(User user) {
        try {
            return dataManager.load(Employee.class).query("select e from r360_Employee e where e.username=:user")
                    .parameter("user", user)
                    .one();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    @Deprecated
    public String userHasReportingGrants(User user, Reporting reporting) {
        ReportingGrants reportingGrants;

        for (ResourceRoleModel resourceRoleModel : getUserRoles(user)) {
            if ((resourceRoleModel.getCode() != null && resourceRoleModel.getCode().equals("system-full-access"))
                    || (resourceRoleModel.getCode() != null && resourceRoleModel.getCode().equals("r360-top-access")))
                return R360_TOP_ACCESS_WITH_GRANT_OPTION;
        }

        if (reporting.getOwnerUserLog().equals(user)) {
            return REPORT_ACCESS_WITH_GRANT_OPTION;
        } else {
            //Поиск по пользователю
            try {
                reportingGrants = dataManager.load(ReportingGrants.class)
                        .query("select e from r360_ReportingGrants e where e.user=:user and e.reporting=:reporting")
                        .parameter("user", user)
                        .parameter("reporting", reporting)
                        .one();
                if (reportingGrants.getWithGrantOption() != null && reportingGrants.getWithGrantOption()) {
                    return REPORT_ACCESS_WITH_GRANT_OPTION;
                } else {
                    return REPORT_ACCESS_AVAILABLE;
                }
            } catch (IllegalStateException e) {
                //Поиск по группе
                try {
                    reportingGrants = dataManager.load(ReportingGrants.class)
                            .query("select e from r360_ReportingGrants e where e.userGroup=:userGroup and e.reporting=:reporting")
                            .parameter("userGroup", user.getUserGroups())
                            .parameter("reporting", reporting)
                            .one();
                    if (reportingGrants.getWithGrantOption() != null && reportingGrants.getWithGrantOption()) {
                        return REPORT_ACCESS_WITH_GRANT_OPTION;
                    } else {
                        return REPORT_ACCESS_AVAILABLE;
                    }
                } catch (IllegalStateException ex) {
                    return REPORT_ACCESS_NOT_AVAILABLE;
                }
            }
        }
    }

    /**
     * Отправка почты владельцу и начальнику для получения прав доступа на отчет
     */
    @Override
    public void sendQueryGrantsEmail(Reporting reporting) throws TemplateNotFoundException, ReportParameterTypeChangedException {
        EmailTemplateBuilder emailTemplateBuilder = emailTemplates.buildFromTemplate("REPORT_REQUEST_GRANTS");

        Employee employee = dataManager.load(Employee.class).query("select e from r360_Employee e where e.username=:user").parameter("user", currentUserSubstitution.getEffectiveUser().getUsername()).optional().orElse(null);
        if (employee != null) {
            if (employee.getLeader() != null) {
                emailTemplateBuilder.addTo(employee.getLeader().getEmail());
            }
        }

        emailTemplateBuilder.addTo(dataManager.load(User.class).id(reporting.getOwnerUserLog().getId()).one().getEmail())
                .setBodyParameter("reporting_group", reporting.getGroup())
                .setBodyParameter("reporting_name", reporting.getName())
                .setBodyParameter("user", currentUserSubstitution.getEffectiveUser().getClass().getName())
                .sendEmailAsync();
    }
}
