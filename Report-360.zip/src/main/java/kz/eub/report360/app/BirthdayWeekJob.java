package kz.eub.report360.app;

import io.jmix.core.security.Authenticated;
import io.jmix.email.EmailException;
import io.jmix.email.EmailInfo;
import io.jmix.email.Emailer;
import io.jmix.emailtemplates.EmailTemplates;
import io.jmix.emailtemplates.exception.ReportParameterTypeChangedException;
import io.jmix.emailtemplates.exception.TemplateNotFoundException;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component("r360_BirthdayWeekJob")
public class BirthdayWeekJob implements Job {

    private static final Logger LOGGER = LoggerFactory.getLogger(BirthdayWeekJob.class);

    @Autowired
    private EmailTemplates emailTemplates;
    @Autowired
    private Emailer emailer;

    @Authenticated
    @Override
    public void execute(JobExecutionContext context) {
        try {
            Map<String, Object> paramsMap = new HashMap<>();
            EmailInfo emailInfo = emailTemplates.generateEmail("DR_week", paramsMap);
            emailer.sendEmail(emailInfo);
            LOGGER.info("r360_BirthdayWeekJob задание выполнено");
        } catch (EmailException | TemplateNotFoundException | ReportParameterTypeChangedException e) {
            LOGGER.info(e.getMessage());
        }
    }
}