package kz.eub.report360.app.service;

import io.jmix.core.DataManager;
import io.jmix.core.SaveContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Service("r360_CredregExcelDataImporter")
public class CredregExcelDataImporter implements ExcelDataImporter{
    @PersistenceContext
    EntityManager entityManager;
    @Autowired
    TransactionTemplate transactionTemplate;
    @Autowired
    private DataManager dataManager;

    @Override
    public void saveObjectsListUsingSaveContext(List<?> objects) {
        SaveContext saveContext = new SaveContext().setDiscardSaved(true);
        for (int i = 0; i < objects.size(); i++) {
            saveContext.saving(objects.get(i));
            if (i > 0 && (i % 50 == 0 || i == objects.size() - 1)) {
                dataManager.save(saveContext);
                saveContext = new SaveContext().setDiscardSaved(true);
                System.out.println("()()()()()()()()SAVED BATCH 50()()()()()()()()");
            }
        }
        dataManager.save(saveContext);
        saveContext = new SaveContext().setDiscardSaved(true);
    }
}
