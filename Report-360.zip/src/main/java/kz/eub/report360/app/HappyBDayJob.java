package kz.eub.report360.app;

import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;
import gui.ava.html.image.generator.HtmlImageGenerator;
import io.jmix.core.Messages;
import io.jmix.core.security.Authenticated;
import io.jmix.email.EmailException;
import io.jmix.email.EmailInfo;
import io.jmix.email.Emailer;
import io.jmix.emailtemplates.EmailTemplates;
import io.jmix.emailtemplates.exception.ReportParameterTypeChangedException;
import io.jmix.emailtemplates.exception.TemplateNotFoundException;
import io.jmix.ui.Notifications;
import kz.eub.report360.app.service.JobsService;
import org.jsoup.Jsoup;
import org.jsoup.helper.W3CDom;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import org.xhtmlrenderer.layout.SharedContext;
import org.xhtmlrenderer.pdf.ITextRenderer;

import javax.imageio.ImageIO;
import javax.sql.DataSource;
import javax.swing.*;
import javax.xml.bind.DatatypeConverter;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;
import java.util.List;

@Component("r360_HappyBDayJob")
public class HappyBDayJob implements Job {

    private static final Logger log = LoggerFactory.getLogger(HappyBDayJob.class);

    @Autowired
    private EmailTemplates emailTemplates;
    @Autowired
    private Emailer emailer;
    @Autowired
    JobsService jobsService;

    private NamedParameterJdbcTemplate sapJdbcTemplate;

    @Autowired
    public HappyBDayJob(@Qualifier("sapDataSource") DataSource sapDataSource) {
        this.sapJdbcTemplate = new NamedParameterJdbcTemplate(sapDataSource);
    }

    @Authenticated
    @Override
    public void execute(JobExecutionContext context) {
        try {
            onHappyBDay();
        } catch (Exception e) {
            log.info(e.getMessage());
        }
    }

    public void onHappyBDay() throws Exception {
        try {
            if (!getBdayDate().isEmpty()) {
                int checkBDayToday = jobsService.getNumOfBDaysToday();
                if (checkBDayToday != 0){
                    Map<String, Object> paramsMap = new HashMap<>();
                    LocalDate hbDate = LocalDate.now();
                    paramsMap.put("hb_date", hbDate);
                    EmailInfo emailInfo = emailTemplates.generateEmail("HB", paramsMap);
                    //String html = emailInfo.getBody();
                    //generateNewHtml(html);
                    emailer.sendEmail(emailInfo);
                    log.info("Happy B-Day Job is executed");
                } else {
                    System.out.println("There's no bdays today");
                }
            }
        } catch (TemplateNotFoundException | EmailException | ReportParameterTypeChangedException e) {
            log.info(e.getMessage());
        }
    }

//    public void generateImage() throws IOException{
//
//        String html = "<b>Hello World!</b> Please goto <a title=\\\"Goto Google\\\" href=\\\"http://www.google.com\\\">Google</a>.\n" +
//                "<img src=\"https://play-lh.googleusercontent.com/1-hPxafOxdYpYZEOKzNIkSP43HXCNftVJVttoo4ucl7rsMASXW3Xr6GlXURCubE1tA=w3840-h2160-rw\"/>";
//
//        JLabel label = new JLabel(html);
//        label.setSize(1903, 2688);
//
//        BufferedImage image = new BufferedImage(
//                label.getWidth(), label.getHeight(),
//                BufferedImage.TYPE_INT_ARGB);
//
//        {
//            // paint the html to an image
//            Graphics g = image.getGraphics();
//            g.setColor(Color.BLACK);
//            label.paint(g);
//            g.dispose();
//        }
//
//        // get the byte array of the image (as jpeg)
//        ByteArrayOutputStream baos = new ByteArrayOutputStream();
////        ImageIO.write(image, "jpg", baos);
////        byte[] bytes = baos.toByteArray();
//        ImageIO.write(image, "png", new File("test.png"));
//    }

//    public void test() throws Exception{
//        String html = "<b>Hello World!</b> Please goto <a title=\\\"Goto Google\\\" href=\\\"http://www.google.com\\\">Google</a>.\n" +
//                "<img src=\"https://play-lh.googleusercontent.com/1-hPxafOxdYpYZEOKzNIkSP43HXCNftVJVttoo4ucl7rsMASXW3Xr6GlXURCubE1tA=w3840-h2160-rw\"/>";
//
//        Document document = Jsoup.parse(html, "UTF-8");
//        document.outputSettings().syntax(Document.OutputSettings.Syntax.xml);
//        String outputPdf = "./rep/image/test.pdf";
//        try (OutputStream os = new FileOutputStream(outputPdf)) {
//            PdfRendererBuilder builder = new PdfRendererBuilder();
//            builder.withUri(outputPdf);
//            builder.toStream(os);
//            builder.withW3cDocument(new W3CDom().fromJsoup(document), "/");;
//
//            builder.run();
//        }
//    }


    public void parseHtml(String html) throws IOException {
        Document doc = Jsoup.parse(html);

        Element imageElement = doc.select("img").first();
        String content = imageElement.absUrl("src");

        String base64Image = content.split(",")[1];
        byte[] imageBytes = DatatypeConverter.parseBase64Binary(base64Image);
        try (FileOutputStream fos = new FileOutputStream("../rep/image/original.jpg")) {
            fos.write(imageBytes);
        }
    }

    public void generateNewHtml(String html) throws IOException {
        Document doc = Jsoup.parse(html);

        try (FileOutputStream fos = new FileOutputStream("./rep/html/index.html")) {
            fos.write(doc.html().getBytes(StandardCharsets.UTF_8));
        }

    }

    protected void htmlToImage(String html) {
        try {
            JEditorPane editor = new JEditorPane();
            editor.setContentType("text/html");
            editor.setText(html);
            editor.setSize(editor.getPreferredSize());
            editor.addNotify();
            log.info("Панель создана");
            BufferedImage bufferSave = new BufferedImage(editor.getPreferredSize().width,
                    editor.getPreferredSize().height, BufferedImage.TYPE_3BYTE_BGR);
            Graphics g = bufferSave.getGraphics();
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, editor.getPreferredSize().width, editor.getPreferredSize().height);
            editor.paint(g);
            log.info("Рисуется графика");
            ImageIO.write(bufferSave, "png", new File("./rep/image/image3.png"));

        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }


    public void safeHtmlFile() throws IOException {

        String html = "<b>Hello World!</b> Please goto <a title=\\\"Goto Google\\\" href=\\\"http://www.google.com\\\">Google</a>.\n" +
                "<img src=\"https://play-lh.googleusercontent.com/1-hPxafOxdYpYZEOKzNIkSP43HXCNftVJVttoo4ucl7rsMASXW3Xr6GlXURCubE1tA=w3840-h2160-rw\"/>";

//        StringBuilder contentBuilder = new StringBuilder();
//        try (BufferedReader is = new BufferedReader(new FileReader("./rep/html/index.html"))) {
//            String str;
//            while ((str = is.readLine()) != null){
//                contentBuilder.append(str);
//            }
//
//        }
//        String html = contentBuilder.toString();

        HtmlImageGenerator htmlImageGenerator = new HtmlImageGenerator();
        htmlImageGenerator.loadHtml(html);
        htmlImageGenerator.saveAsImage("image.png");
//        BufferedImage bufferedImage = htmlImageGenerator.getBufferedImage();
//        File outPutFile = new File("./rep/png/image2.png");
//        ImageIO.write(bufferedImage, "jpg", outPutFile);
//
//
//
//            try (BufferedWriter bf = new BufferedWriter(new FileWriter("./rep/html/index.html"))) {
//                bf.write(html);
//            }
//        }
    }

    public List<String> getBdayDate() {
        String query = "SELECT\n" +
                "to_char (to_date(pa2.gbdat,'yyyymmdd'), 'dd.mm.yyyy') AS b_date\n" +
                "FROM SAPSR3.hrp1000 h10\n" +
                "LEFT JOIN SAPSR3.hrp1001 h11\n" +
                "\tON h11.sobid=h10.OBJID\n" +
                "\tAND h11.OTYPE='S'\n" +
                "\tAND h11.SUBTY='A003'\n" +
                "\tAND :hb_date BETWEEN to_date(h11.BEGDA,'yyyymmdd') AND to_date(h11.ENDDA,'yyyymmdd')\n" +
                "LEFT JOIN sapsr3.pa0001 pa1\n" +
                "\tON pa1.plans = h11.objid\n" +
                "\tAND :hb_date BETWEEN to_date(pa1.BEGDA,'yyyymmdd') AND to_date(pa1.ENDDA,'yyyymmdd')\n" +
                "LEFT JOIN sapsr3.pa0002 pa2\n" +
                "\tON pa2.pernr = pa1.pernr\n" +
                "\tAND :hb_date BETWEEN to_date(pa2.BEGDA,'yyyymmdd') AND to_date(pa2.ENDDA,'yyyymmdd')\n" +
                "LEFT JOIN sapsr3.pa0000 p0\n" +
                "\tON p0.pernr = pa1.pernr\n" +
                "\tAND p0.stat2 = '3'\n" +
                "\tAND :hb_date BETWEEN to_date(p0.BEGDA,'yyyymmdd') AND to_date(p0.ENDDA,'yyyymmdd')\n" +
                "WHERE 1=1\n" +
                "AND substr (to_char (:hb_date, 'dd.mm.yyyy'), 1, 5) = substr (to_char (to_date(pa2.gbdat,'yyyymmdd'), 'dd.mm.yyyy') , 1, 5)\n" +
                "AND :hb_date BETWEEN to_date(h10.BEGDA,'yyyymmdd') AND to_date(h10.ENDDA,'yyyymmdd')\n" +
                "AND h10.OTYPE='O'\n" +
                "AND h10.PLVAR='01'\n" +
                "AND h10.LANGU='R'\n" +
                "AND pa1.PERNR  IS NOT NULL\n" +
                "AND (h10.OBJID IN (SELECT CHILD_ID\n" +
                "    FROM (\n" +
                "         SELECT objid AS CHILD_ID, sobid AS PARENT_ID\n" +
                "         FROM sapsr3.hrp1001 h11\n" +
                "         WHERE 1=1\n" +
                "         AND h11.otype = 'O'\n" +
                "         AND h11.subty IN ('A002')\n" +
                "         AND h11.endda = '99991231') h11\n" +
                "    CONNECT BY PRIOR h11.CHILD_ID=PARENT_ID\n" +
                "    START WITH h11.PARENT_ID IN ('50003807')) OR h10.OBJID = '50003807')\n" +
                "ORDER BY h10.objid";
        MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
        LocalDate hbDate = LocalDate.parse("2022-10-25");
        mapSqlParameterSource.addValue("hb_date", hbDate);
        List<String> fields = new ArrayList<>();
        return sapJdbcTemplate.query(query, mapSqlParameterSource, rs -> {
            while (rs.next()) {
                fields.add(rs.getObject(1, String.class));
            }
            return fields;
        });
    }
}