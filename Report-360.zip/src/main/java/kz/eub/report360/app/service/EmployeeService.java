package kz.eub.report360.app.service;

import io.jmix.core.DataManager;
import io.jmix.core.querycondition.PropertyCondition;
import kz.eub.report360.entity.DictDepartment;
import kz.eub.report360.entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;
import java.util.UUID;

@Service("r360_EmployeeService")
public class EmployeeService {

    @PersistenceContext
    private EntityManager entityManager;
    @Autowired
    private DataManager dataManager;
    @PersistenceContext
    private EntityManager em;

    public boolean checkUserExistsByUsername(String username) {
        return entityManager.createNativeQuery("select u.id from r360_user u " +
                        "where u.username = ?")
                .setParameter(1, username)
                .getResultList()
                .size() > 0;
    }

    public List<Employee> searchEmployee(String fio) {
        return dataManager.load(Employee.class)
                .query("select c from r360_Employee c " +
                        "where c.fullName like :name")
                .parameter("name", "(?i)%" + fio + "%")
                .list();
    }

    public List<Employee> getAllDepartmentSubTreeEmployees(DictDepartment department) {
        List<UUID> idList = getDepartmentSubTreeIdList(department.getId());
        return dataManager.load(Employee.class)
                .condition(PropertyCondition.inList("department.id", idList))
                .list();
    }

    public List<UUID> getDepartmentSubTreeIdList(UUID id) {
        String query = "with RECURSIVE cte as " +
                "( " +
                "   select id from r360_dict_department where id = #depId " +
                "   union all " +
                "   select e.id from r360_dict_department e inner join cte on e.parent_id=cte.id " +
                "   where e.end_date > CURRENT_DATE " +
                ") " +
                "select cte.id from cte";
        List<UUID> depIdList = em.createNativeQuery(query, DictDepartment.class)
                .setParameter("depId", id)
                .getResultList();
        return depIdList;
    }
}