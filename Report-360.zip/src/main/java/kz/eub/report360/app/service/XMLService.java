package kz.eub.report360.app.service;

import io.jmix.ui.download.ByteArrayDataProvider;
import kz.eub.report360.entity.DataStoreType;
import kz.eub.report360.entity.ReportXmlParam;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

public interface XMLService {
    String NAME = "r360_XMLService";

    String xmlBeautifier(String xmlString) throws Exception;

    boolean validateXml(String xmlString, String xsdString) throws Exception;

    byte[] getXml(String xml, DataStoreType dataStores) throws Exception;

    String getTxtResult(String func, DataStoreType dataStores) throws Exception;

    List<byte[]> getXmlList(String xml, String xsd, DataStoreType dataStores, boolean checkValid) throws Exception;

    byte[] getManifestXml(Date dt, String code) throws Exception;

    byte[] getZipFile(HashMap<String, byte[]> map) throws Exception;

    String getXmlSelectWithPar(String xmlSelect, HashMap<String, String> mapPar, List<ReportXmlParam> listPar);

    ByteArrayDataProvider getByteArrayDataProvider(String strXmlSelectWithPar);
}
