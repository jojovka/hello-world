package kz.eub.report360.app;

import io.jmix.email.EmailException;
import io.jmix.email.EmailInfo;
import io.jmix.email.Emailer;
import io.jmix.emailtemplates.EmailTemplates;
import io.jmix.emailtemplates.entity.EmailTemplate;
import io.jmix.emailtemplates.exception.ReportParameterTypeChangedException;
import io.jmix.emailtemplates.exception.TemplateNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service("r360_EmailReportsService")
public class EmailReportsService {
    public static final String SUCCESS_CODE = "Successful";
    @Autowired
    private EmailTemplates emailTemplates;
    @Autowired
    private Emailer emailer;

    public String emailFisRsReport(String templateCode, String date, String recipients) {
        try {
            EmailTemplate newTemplate = emailTemplates.buildFromTemplate(templateCode)
                    .setTo(recipients)
                    .build();
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            Date date2 = format.parse(date);
            Map<String, Object> paramsMap = new HashMap<>();
            paramsMap.put("rep_date", date2);
            EmailInfo emailInfo = emailTemplates.generateEmail(newTemplate, paramsMap);
            emailer.sendEmail(emailInfo);
            return SUCCESS_CODE;
        } catch (TemplateNotFoundException | EmailException | ReportParameterTypeChangedException | ParseException e) {
            throw new RuntimeException(e);
        }
    }
}