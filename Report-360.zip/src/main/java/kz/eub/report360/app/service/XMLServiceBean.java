package kz.eub.report360.app.service;

import io.jmix.core.CoreProperties;
import io.jmix.core.DataManager;
import io.jmix.ui.UiProperties;
import io.jmix.ui.download.ByteArrayDataProvider;
import kz.eub.report360.entity.DataStoreType;
import kz.eub.report360.entity.ReportXmlParam;
import kz.eub.report360.entity.XmlContent;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Service(XMLService.NAME)
public class XMLServiceBean implements XMLService {
    @Autowired
    private UtilityService utilityService;
    @Autowired
    private UiProperties uiProperties;
    @Autowired
    private CoreProperties coreProperties;

    @Autowired
    @Qualifier("cdbJdbcTemplate")
    private JdbcTemplate cdbJdbcTemplate;

    @Autowired
    @Qualifier("dwhdbJdbcTemplate")
    private JdbcTemplate dwhdbJdbcTemplate;

    @Autowired
    @Qualifier("dwhprodJdbcTemplate")
    private JdbcTemplate dwhprodJdbcTemplate;

    @Autowired
    @Qualifier("jiraJdbcTemplate")
    private JdbcTemplate jiraJdbcTemplate;

    @Autowired
    @Qualifier("sapJdbcTemplate")
    private JdbcTemplate sapJdbcTemplate;
    @Autowired
    private DataManager dataManager;


    @Override
    public String xmlBeautifier(String xmlString) throws Exception {
        XMLWriter xw = null;
        try (StringWriter sw = new StringWriter()) {
            Document doc = DocumentHelper.parseText(xmlString);
            OutputFormat format = OutputFormat.createPrettyPrint();
            format.setTrimText(false);
            xw = new XMLWriter(sw, format);
            xw.write(doc);
            xmlString = sw.toString();
            sw.flush();
        } catch (DocumentException | IOException e) {
            throw new Exception("Ошибка форматирования xml (Beautifier). Текст ошибки: " + e.getMessage());
        } finally {
            assert xw != null;
            xw.flush();
            xw.close();
        }
        return xmlString;
    }

    @Override
    public boolean validateXml(String xmlString, String xsdString) throws Exception {
        try {
            SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = factory.newSchema(new StreamSource(new ByteArrayInputStream(xsdString.getBytes())));
            Validator validator = schema.newValidator();
            validator.validate(new StreamSource(new ByteArrayInputStream(xmlString.getBytes())));
            return true;
        } catch (SAXException | IOException e) {
            throw new Exception("Ошибка валидации xml по xsd. Текст ошибки: " + e.getMessage());
        }
    }

    @Override
    public byte[] getXml(String xml, DataStoreType dataStores) {
        String content = "";
        if (dataStores == DataStoreType.CDB) {
            try {
                content = getXmlContent(cdbJdbcTemplate, xml);
            } catch (DataAccessException e) {
                throw new RuntimeException(e.getMessage());
            }
        } else if (dataStores == DataStoreType.DWHPROD) {
            try {
                content = getXmlContent(dwhprodJdbcTemplate, xml);
            } catch (DataAccessException e) {
                throw new RuntimeException(e.getMessage());
            }
        } else if (dataStores == DataStoreType.DWHDB) {
            try {
                content = getXmlContent(dwhdbJdbcTemplate, xml);
            } catch (DataAccessException e) {
                throw new RuntimeException(e.getMessage());
            }
        } else if (dataStores == DataStoreType.JIRA) {
            try {
                content = getXmlContent(jiraJdbcTemplate, xml);
            } catch (DataAccessException e) {
                throw new RuntimeException(e.getMessage());
            }
        } else if (dataStores == DataStoreType.SAP) {
            try {
                content = getXmlContent(sapJdbcTemplate, xml);
            } catch (DataAccessException e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return content.getBytes();
    }


    @Override

    public String getTxtResult(String func, DataStoreType dataStores) {
        String result = null;
        if (dataStores == DataStoreType.CDB) {
            result = getXmlContent(cdbJdbcTemplate, func);
        } else if (dataStores == DataStoreType.DWHPROD) {
            result = getXmlContent(dwhprodJdbcTemplate, func);
        } else if (dataStores == DataStoreType.DWHDB) {
            result = getXmlContent(dwhdbJdbcTemplate, func);
        } else if (dataStores == DataStoreType.JIRA) {
            result = getXmlContent(jiraJdbcTemplate, func);
        } else if (dataStores == DataStoreType.SAP) {
            result = getXmlContent(sapJdbcTemplate, func);
        }
        return result;
    }

    public String getXmlContent(JdbcTemplate jdbcTemplate, String query) {
        XmlContent content = dataManager.create(XmlContent.class);
        return jdbcTemplate.query(query, rs -> {
            while (rs.next()) {
                content.setContent(new String(rs.getBytes(1)));
            }
            return content.getContent();
        });
    }

    @Override
    public List<byte[]> getXmlList(String xml, String xsd, DataStoreType dataStores, boolean checkValid) throws Exception {
        String xmlString;
        String content = null;
        List<byte[]> listXmlByte = new ArrayList<>();

        if (dataStores == DataStoreType.CDB) {
            try {
                content = getXmlContent(cdbJdbcTemplate, xml);

            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        if (dataStores == DataStoreType.DWHPROD) {
            try {
                content = getXmlContent(dwhprodJdbcTemplate, xml);
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        if (dataStores == DataStoreType.DWHDB) {
            try {
                content = getXmlContent(dwhdbJdbcTemplate, xml);

            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        if (dataStores == DataStoreType.JIRA) {
            try {
                content = getXmlContent(jiraJdbcTemplate, xml);

            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        if (dataStores == DataStoreType.SAP) {
            try {
                content = getXmlContent(sapJdbcTemplate, xml);

            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }

        assert content != null;

        try {
            xmlString = xmlBeautifier(content);
            if (checkValid) {
                validateXml(xmlString, xsd);
            }
            listXmlByte.add(xmlString.getBytes());
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
        return listXmlByte;
    }

    @Override
    public byte[] getManifestXml(Date dt, String code) throws Exception {
        String xmlString;
        XMLStreamWriter xMLStreamWriter = null;
        try (StringWriter stringWriter = new StringWriter()) {
            SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");

            XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
            xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);

            xMLStreamWriter.writeStartDocument();
            xMLStreamWriter.writeStartElement("manifest");

            xMLStreamWriter.writeStartElement("product");
            xMLStreamWriter.writeCharacters(code);
            xMLStreamWriter.writeEndElement();//product

            xMLStreamWriter.writeStartElement("report_date");
            xMLStreamWriter.writeCharacters(formatter.format(dt));
            xMLStreamWriter.writeEndElement();//report_date

            xMLStreamWriter.writeStartElement("respondent");
            xMLStreamWriter.writeCharacters(utilityService.getAppSettingVal("XML_RESPONDENT"));
            xMLStreamWriter.writeEndElement();//respondent

            xMLStreamWriter.writeEndDocument();//manifest

            xmlString = stringWriter.getBuffer().toString();
            //форматирование xml (beautifier)
            xmlString = xmlBeautifier(xmlString);
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        } finally {
            assert xMLStreamWriter != null;
            xMLStreamWriter.flush();
            xMLStreamWriter.close();
        }
        return xmlString.getBytes();
    }

    @Override
    public byte[] getZipFile(HashMap<String, byte[]> map) throws Exception {
        byte[] arrByte;
        try (ByteArrayOutputStream f = new ByteArrayOutputStream();
             ZipOutputStream zout = new ZipOutputStream(f)) {
            for (Map.Entry<String, byte[]> entry : map.entrySet()) {
                zout.putNextEntry(new ZipEntry(entry.getKey()));
                zout.write(entry.getValue());
                zout.closeEntry();
            }
            zout.finish();
            arrByte = f.toByteArray();
        } catch (Exception e) {
            throw new Exception("Ошибка формирования zip архива. Текст ошибки: " + e.getMessage());
        }
        return arrByte;
    }

    @Override
    public String getXmlSelectWithPar(String xmlSelect, HashMap<String, String> mapPar, List<ReportXmlParam> listPar) {
        //Замена параметров запроса на конкретные значения
        if (mapPar.size() == 0) {
            return xmlSelect;
        }

        Pattern pattern;
        Matcher matcher;
        StringBuilder sb = new StringBuilder();
        String strCondition;
        pattern = Pattern.compile("(\\[)(.*?)(])"); //поиск строк между символами []

        for (ReportXmlParam par : listPar) {
            strCondition = par.getCondition();
            matcher = pattern.matcher(strCondition);
            while (matcher.find()) {
                String parCode = matcher.group(2).toUpperCase();
                String parValue = mapPar.get(parCode);
                if (parValue != null) {
                    sb.append("[").append(parCode).append("]");
                    String strConditionUpper = strCondition.toUpperCase();
                    strConditionUpper = strConditionUpper.replace(sb.toString(), parValue);
                    strCondition = null;
                    sb.setLength(0);
                    xmlSelect = xmlSelect.replace(par.getReplaceableCh(), strConditionUpper);
                }
                break;
            }
        }

        return xmlSelect;
    }

    public ByteArrayDataProvider getByteArrayDataProvider(String strXmlSelectWithPar) {
        return new ByteArrayDataProvider(strXmlSelectWithPar.getBytes(),
                uiProperties.getSaveExportedByteArrayDataThresholdBytes(), coreProperties.getTempDir());
    }
}
