package kz.eub.report360.app.ldap;

import io.jmix.core.DataManager;
import io.jmix.core.SaveContext;
import io.jmix.core.security.Authenticated;
import io.jmix.ldap.userdetails.AbstractLdapUserDetailsSynchronizationStrategy;
import io.jmix.securitydata.entity.RoleAssignmentEntity;
import kz.eub.report360.app.service.EmployeeService;
import kz.eub.report360.entity.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Component("ldap_EubUserSynchronizationStrategy")
public class EubUserSynchronizationStrategy extends AbstractLdapUserDetailsSynchronizationStrategy<User> {

    private static final Logger log = LoggerFactory.getLogger(EubUserSynchronizationStrategy.class);

    @Autowired
    protected DataManager dataManager;
    @Autowired
    private EmployeeService employeeService;

    @Override
    protected Class<User> getUserClass() {
        return User.class;
    }

    @Authenticated
    @Override
    public UserDetails synchronizeUserDetails(DirContextOperations ctx, String username, Collection<? extends GrantedAuthority> authorities) {
        User jmixUserDetails;
        try {
            username = username.toLowerCase();
//            jmixUserDetails = (User) userRepository.loadUserByUsername(username);
            jmixUserDetails = dataManager.load(User.class)
                    .query("select c from r360_User c " +
                            "where c.username like :username")
                    .parameter("username", "(?i)" + username)
                    .optional().orElse(null);
            if (jmixUserDetails == null)
                throw new UsernameNotFoundException(String.format("User %s not found.", username));
        } catch (UsernameNotFoundException e) {
            log.info("User with login {} wasn't found in user repository", username);
            if (employeeService.checkUserExistsByUsername(username))
                return null;
            jmixUserDetails = createUserDetails(username, ctx);
        }

        //copy ldap attributes to UserDetails
        mapUserDetailsAttributes(jmixUserDetails, ctx);

        SaveContext saveContext = new SaveContext();
        if (ldapProperties.getSynchronizeRoleAssignments()) {
            Set<GrantedAuthority> grantedAuthorities = authoritiesMapper.mapAuthorities(authorities);

            //clean previous role assignments
            List<RoleAssignmentEntity> existingRoleAssignments = dataManager.load(RoleAssignmentEntity.class)
                    .query("select e from sec_RoleAssignmentEntity e where e.username = :username")
                    .parameter("username", username)
                    .list();
            saveContext.removing(existingRoleAssignments);

            saveContext.saving(buildRoleAssignments(grantedAuthorities, username));
        }
        saveContext.saving(jmixUserDetails);

        //persist user details and roles if needed
        dataManager.save(saveContext);

        return jmixUserDetails;
    }

    @Override
    protected void mapUserDetailsAttributes(@Nonnull User userDetails, DirContextOperations ctx) {
        if (ctx.attributeExists("displayName")) {
            userDetails.setLastName(getLastName(ctx.getStringAttribute("displayName")));
            userDetails.setFirstName(getFirstName(ctx.getStringAttribute("displayName")));
            userDetails.setMiddleName(getMiddleName(ctx.getStringAttribute("displayName")));
        } else
            return;

        if (ctx.attributeExists("mail")) {
            userDetails.setEmail(ctx.getStringAttribute("mail"));
        }

        if (ctx.attributeExists("sAMAccountName")) {
            userDetails.setUsername(ctx.getStringAttribute("sAMAccountName").toLowerCase());
        }

        if (ctx.attributeExists("employeeId"))
            userDetails.setPn(String.format("%08d", Long.parseLong(ctx.getStringAttribute("employeeId"))));

        if (ctx.attributeExists("mobile"))
            userDetails.setMobile(ctx.getStringAttribute("mobile"));

        if (ctx.attributeExists("homePhone"))
            userDetails.setPhone(ctx.getStringAttribute("homePhone"));

        userDetails.setLastModifiedDate(new Date());
        log.info(">>>>>>>>>>>>>>>>>>> Sync user:    {}", userDetails);
    }

    public String getLastName(String fullName) {
        if (fullName == null) return null;
        String[] name = fullName.split(" ");
        if (name.length > 0 && name[0].length() > 0)
            return name[0];
        return null;
    }

    public String getFirstName(String fullName) {
        if (fullName == null) return null;
        String[] name = fullName.split(" ");
        if (name.length > 1 && name[1].length() > 0)
            return name[1];
        return null;
    }

    public String getMiddleName(String fullName) {
        if (fullName == null) return null;
        String[] name = fullName.split(" ");
        if (name.length > 2 && name[2].length() > 0)
            return name[2];
        return null;
    }

}