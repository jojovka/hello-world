package kz.eub.report360.app.service;

import io.jmix.emailtemplates.exception.ReportParameterTypeChangedException;
import io.jmix.emailtemplates.exception.TemplateNotFoundException;
import kz.eub.report360.entity.ReportXml;
import kz.eub.report360.entity.ReportXmlHist;
import kz.eub.report360.entity.ReportXmlParam;
import kz.eub.report360.entity.Reporting;
import kz.eub.report360.entity.ReportingApprov;
import kz.eub.report360.entity.User;

import java.util.Date;
import java.util.List;
import java.util.Set;

public interface UtilityService {
    String NAME = "r360_UtilityService";

    String R360_TOP_ACCESS_WITH_GRANT_OPTION = "R360_TOP_ACCESS_WITH_GRANT_OPTION";
    String REPORT_ACCESS_WITH_GRANT_OPTION = "REPORT_ACCESS_WITH_GRANT_OPTION";
    String REPORT_ACCESS_AVAILABLE = "REPORT_ACCESS_AVAILABLE";
    String REPORT_ACCESS_NOT_AVAILABLE = "REPORT_ACCESS_NOT_AVAILABLE";

    void saveChangeRepApprov(ReportingApprov reportingApprov);

    ReportXmlHist getRepXmlHist(Date dateOnRep, ReportXml reportXml);

    List<ReportXmlParam> getRepXmlPar(ReportXml reportXml);

    ReportXmlParam getRepXmlParam(ReportXml reportXml, String parCode);

    void addRepXmlHist(Date dateOnRep, ReportXml reportXml, int countRep, ReportXmlHist reportXmlHist);

    String getAppSettingVal(String val);

    String getDateToString(java.sql.Date date);

    Set<Reporting> findAllPermittedReporting(User user);

    String userHasReportingGrants(User user, Reporting reporting);

    void sendQueryGrantsEmail(Reporting reporting) throws TemplateNotFoundException, ReportParameterTypeChangedException;
}
