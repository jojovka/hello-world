package kz.eub.report360.security;

import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.security.role.annotation.SpecificPolicy;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import kz.eub.report360.entity.Correction700nd;

import javax.annotation.Nonnull;

@Nonnull
@ResourceRole(name = "700ND correction role", code = "700-n-d-correction-role")
public interface A700NDCorrectionRole {
    @MenuPolicy(menuIds = "r360_Correction700nd.browse")
    @ScreenPolicy(screenIds = {"r360_Correction700nd.browse", "r360_Correction700nd.edit", "ui_PropertyFilterCondition.edit", "ui_GroupFilterCondition.edit", "ui_JpqlFilterCondition.edit", "ui_AddConditionScreen"})
    void screens();

    @EntityAttributePolicy(entityClass = Correction700nd.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = Correction700nd.class, actions = EntityPolicyAction.ALL)
    void correction700nd();

    @SpecificPolicy(resources = {"ui.filter.modifyConfiguration", "ui.filter.modifyJpqlCondition"})
    void specific();
}