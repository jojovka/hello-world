package kz.eub.report360.security;

import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.security.role.annotation.SpecificPolicy;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;

import javax.annotation.Nonnull;

@Nonnull
@ResourceRole(name = "archiveDateEditor", code = "archive-date-editor")
public interface ArchiveDateEditorRole {

    @MenuPolicy(menuIds = "r360_ArchiveReloadDayForJob.browse")
    @ScreenPolicy(screenIds = {"r360_ArchiveReloadDayForJob.browse", "r360_ArchiveReloadDayForJob.edit"})
    void screens();

    @SpecificPolicy(resources = "ui.showExceptionDetails")
    void specific();
}