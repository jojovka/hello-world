package kz.eub.report360.security;

import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import kz.eub.report360.entity.Credreg;

import javax.annotation.Nonnull;

@Nonnull
@ResourceRole(name = "CredRegCorrection", code = "cred-reg-correction")
public interface CredRegCorrectionRole {
    @MenuPolicy(menuIds = "r360_Credreg.browse")
    @ScreenPolicy(screenIds = "r360_Credreg.browse")
    void screens();

    @EntityAttributePolicy(entityClass = Credreg.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = Credreg.class, actions = EntityPolicyAction.ALL)
    void credreg();
}