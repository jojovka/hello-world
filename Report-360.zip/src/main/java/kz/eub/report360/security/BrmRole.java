package kz.eub.report360.security;

import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import kz.eub.report360.entity.DictBasketSnp;
import kz.eub.report360.entity.DictProductPozSnp;
import kz.eub.report360.entity.DictRatingSnp;
import kz.eub.report360.entity.DictRecoverySnp;
import kz.eub.report360.entity.DictRefProduct;
import kz.eub.report360.entity.DictSegmentSnp;
import kz.eub.report360.entity.DictSources;
import kz.eub.report360.entity.DmCreditSnp;
import kz.eub.report360.entity.DmPledgeSnp;
import kz.eub.report360.entity.PozReference;
import kz.eub.report360.entity.PozReferenceMap;

@ResourceRole(name = "BRM", code = "r360-brm", scope = "UI", description = "Роль BRM, модуль СНП.")
public interface BrmRole {
    @MenuPolicy(menuIds = {"r360_PozReference.browse", "r360_PozReferenceMap.browse", "r360_DictBasketSnp.browse", "r360_DictRecoverySnp.browse", "r360_DictSegmentSnp.browse", "r360_DictRatingSnp.browse", "r360_DictProductPozSnp.browse", "r360_DmCreditSnp.browse", "r360_DmPledgeSnp.browse"})
    @ScreenPolicy(screenIds = {"r360_PozReference.browse", "r360_PozReferenceMap.browse", "r360_DictBasketSnp.browse", "r360_DictRecoverySnp.browse", "r360_DictSegmentSnp.browse", "r360_DictRatingSnp.browse", "r360_PozReference.edit", "r360_PozReferenceMap.edit", "r360_DictBasketSnp.edit", "r360_DictRatingSnp.edit", "r360_DictRecoverySnp.edit", "r360_DictSegmentSnp.edit", "r360_DictProductPozSnp.browse", "r360_DictRefProduct.browse", "r360_DictProductPozSnp.edit", "r360_DmCreditSnp.browse", "r360_DmCreditSnp.edit", "r360_DictSources.browse", "r360_DmPledgeSnp.browse", "r360_DmPledgeSnp.edit"})
    void screens();

    @EntityAttributePolicy(entityClass = PozReference.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = PozReference.class, actions = EntityPolicyAction.ALL)
    void pozReference();

    @EntityAttributePolicy(entityClass = PozReferenceMap.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = PozReferenceMap.class, actions = EntityPolicyAction.ALL)
    void pozReferenceMap();

    @EntityAttributePolicy(entityClass = DictBasketSnp.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DictBasketSnp.class, actions = EntityPolicyAction.ALL)
    void dictBasketSnp();

    @EntityAttributePolicy(entityClass = DictRecoverySnp.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DictRecoverySnp.class, actions = EntityPolicyAction.ALL)
    void dictRecoverySnp();

    @EntityAttributePolicy(entityClass = DictSegmentSnp.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DictSegmentSnp.class, actions = EntityPolicyAction.ALL)
    void dictSegmentSnp();

    @EntityAttributePolicy(entityClass = DictRatingSnp.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DictRatingSnp.class, actions = EntityPolicyAction.ALL)
    void dictRatingSnp();

    @EntityAttributePolicy(entityClass = DictProductPozSnp.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DictProductPozSnp.class, actions = EntityPolicyAction.ALL)
    void dictProductPozSnp();

    @EntityAttributePolicy(entityClass = DictRefProduct.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = DictRefProduct.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void dictRefProduct();

    @EntityAttributePolicy(entityClass = DictSources.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = DictSources.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void dictSources();

    @EntityAttributePolicy(entityClass = DmCreditSnp.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DmCreditSnp.class, actions = EntityPolicyAction.ALL)
    void dmCreditSnp();

    @EntityAttributePolicy(entityClass = DmPledgeSnp.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DmPledgeSnp.class, actions = EntityPolicyAction.ALL)
    void dmPledgeSnp();
}