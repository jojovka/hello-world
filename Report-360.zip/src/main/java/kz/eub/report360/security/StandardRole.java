package kz.eub.report360.security;

import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.security.role.annotation.SpecificPolicy;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import kz.eub.report360.entity.*;

@ResourceRole(name = "Standard", code = "r360-standard", description = "Role defines permissions for all employees", scope = "UI")
public interface StandardRole {
    @EntityAttributePolicy(entityClass = UniDictEntity.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = UniDictEntity.class, actions = EntityPolicyAction.ALL)
    void uniDictEntity();

    @MenuPolicy(menuIds = {"r360_ErrCardClient.browse", "r360_DictErrors.browse", "r360_DealErrors.browse", "r360_AccountErrors.browse", "r360_RatesBankScreen", "r360_DictErrorDeadline.browse", "r360_DictErrorGroup.browse", "r360_DictSubError.browse", "r360_DictResponsibleMatrix.browse", "r360_ReportingRun.browse", "r360_ReportXmlRun.browse", "themeSettingsScreen"})
    @ScreenPolicy(screenIds = {"r360_UniDictEntity.browse", "r360_ErrCardClient.browse", "r360_DictErrors.browse", "r360_DealErrors.browse", "r360_AccountErrors.browse", "r360_RatesBankScreen", "r360_UniDictCwdb.browse", "r360_DictErrorDeadline.browse", "r360_DictErrorGroup.browse", "r360_DictSubError.browse", "r360_DictResponsibleMatrix.browse", "r360_DictErrorDeadline.edit", "r360_DictErrorGroup.edit", "r360_DictErrors.edit", "r360_DictSubError.edit", "r360_DictDepartment.browse", "r360_User.browse", "r360_UserGroup.browse", "r360_ReportingRun.browse", "r360_ReportXmlRun.browse", "themeSettingsScreen", "r360_ReportingGrants.browse", "r360_ReportingGrants.edit", "r360_ReportingApprov.limited", "r360_ReportingApprov.edit", "r360_ReportingApprov.browse", "r360_DictSources.browse", "r360_ReportXmlRun.edit", "r360_Reporting.editDescr", "report_ReportExecution.browse", "report_ReportExecution.dialog"})
    void screens();

    @SpecificPolicy(resources = "ui.showExceptionDetails")
    void specific();

    @EntityAttributePolicy(entityClass = AccountErrors.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = AccountErrors.class, actions = EntityPolicyAction.ALL)
    void accountErrors();

    @EntityAttributePolicy(entityClass = DealErrors.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DealErrors.class, actions = EntityPolicyAction.ALL)
    void dealErrors();

    @EntityAttributePolicy(entityClass = DictErrors.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DictErrors.class, actions = EntityPolicyAction.ALL)
    void dictErrors();

    @EntityAttributePolicy(entityClass = ErrCardClient.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = ErrCardClient.class, actions = EntityPolicyAction.ALL)
    void errCardClient();

    @EntityAttributePolicy(entityClass = RateDto.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = RateDto.class, actions = EntityPolicyAction.ALL)
    void rateDto();

    @EntityAttributePolicy(entityClass = UniDictCwdb.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = UniDictCwdb.class, actions = EntityPolicyAction.ALL)
    void uniDictCwdb();

    @EntityAttributePolicy(entityClass = DictErrorDeadline.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DictErrorDeadline.class, actions = EntityPolicyAction.ALL)
    void dictErrorDeadline();

    @EntityAttributePolicy(entityClass = DictErrorGroup.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DictErrorGroup.class, actions = EntityPolicyAction.ALL)
    void dictErrorGroup();

    @EntityAttributePolicy(entityClass = DictSubError.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DictSubError.class, actions = EntityPolicyAction.ALL)
    void dictSubError();

    @EntityAttributePolicy(entityClass = DictResponsibleMatrix.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DictResponsibleMatrix.class, actions = EntityPolicyAction.ALL)
    void dictResponsibleMatrix();

    @EntityAttributePolicy(entityClass = ReportXml.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = ReportXml.class, actions = EntityPolicyAction.ALL)
    void reportXml();

    @EntityAttributePolicy(entityClass = ReportXmlHist.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    void reportXmlHist();

    @EntityAttributePolicy(entityClass = Reporting.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = Reporting.class, actions = EntityPolicyAction.ALL)
    void reporting();

    @EntityAttributePolicy(entityClass = ReportingGrants.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = ReportingGrants.class, actions = EntityPolicyAction.ALL)
    void reportingGrants();

    @EntityAttributePolicy(entityClass = ReportingApprov.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = ReportingApprov.class, actions = EntityPolicyAction.ALL)
    void reportingApprov();

    @EntityAttributePolicy(entityClass = DictDepartment.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = DictDepartment.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void dictDepartment();

    @EntityAttributePolicy(entityClass = User.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = User.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void user();

    @EntityAttributePolicy(entityClass = UserGroup.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = UserGroup.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void userGroup();

    @EntityAttributePolicy(entityClass = DictSources.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = DictSources.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void dictSources();

}