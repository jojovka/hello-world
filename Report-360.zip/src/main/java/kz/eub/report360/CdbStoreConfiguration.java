package kz.eub.report360;

import io.jmix.core.JmixModules;
import io.jmix.core.Resources;
import io.jmix.data.impl.JmixEntityManagerFactoryBean;
import io.jmix.data.impl.JmixTransactionManager;
import io.jmix.data.persistence.DbmsSpecifics;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

@Configuration
public class CdbStoreConfiguration {

    @Bean
    @ConfigurationProperties("cdb.datasource")
    DataSourceProperties cdbDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "cdb.datasource.hikari")
    DataSource cdbDataSource(@Qualifier("cdbDataSourceProperties") DataSourceProperties properties) {
        return properties.initializeDataSourceBuilder().build();
    }

    @Bean
    LocalContainerEntityManagerFactoryBean cdbEntityManagerFactory(
            @Qualifier("cdbDataSource") DataSource dataSource,
            JpaVendorAdapter jpaVendorAdapter,
            DbmsSpecifics dbmsSpecifics,
            JmixModules jmixModules,
            Resources resources) {
        return new JmixEntityManagerFactoryBean("cdb", dataSource, jpaVendorAdapter, dbmsSpecifics, jmixModules, resources);
    }

    @Bean
    JpaTransactionManager cdbTransactionManager(@Qualifier("cdbEntityManagerFactory") EntityManagerFactory entityManagerFactory) {
        return new JmixTransactionManager("cdb", entityManagerFactory);
    }

    @Bean(name = "cdbJdbcTemplate")
    JdbcTemplate cdbJdbcTemplate(@Qualifier("cdbDataSource") DataSource ds) {
        return new JdbcTemplate(ds);
    }
}
