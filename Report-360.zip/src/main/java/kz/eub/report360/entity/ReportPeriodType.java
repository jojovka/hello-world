package kz.eub.report360.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum ReportPeriodType implements EnumClass<String> {

    //Периодичность отчета
    DAILY("DAILY"),
    WEEKLY("WEEKLY"),
    MONTHLY("MONTHLY"),
    QUARTERLY("QUARTERLY"),
    YEARLY("YEARLY"),
    NOTIMETABLE("NOTIMETABLE");

    private String id;

    ReportPeriodType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static ReportPeriodType fromId(String id) {
        for (ReportPeriodType at : ReportPeriodType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}