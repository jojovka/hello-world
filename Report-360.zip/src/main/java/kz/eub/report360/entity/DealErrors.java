package kz.eub.report360.entity;

import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "dm_deal_error", schema = "dwh_dq", indexes = {
        @Index(name = "IDX_DM_DEAL_ERROR_DDE_ERROR_UUID", columnList = "dde_error_uuid")
})
@Entity(name = "r360_DealErrors")
public class DealErrors {
    @Column(name = "dce_uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "dde_deal_gid", precision = 19, scale = 2)
    private BigDecimal ddeDealGid;

    @Temporal(TemporalType.DATE)
    @Column(name = "\"dde$start_date\"")
    private Date ddeStartDate;

    @Temporal(TemporalType.DATE)
    @Column(name = "\"dde$end_date\"")
    private Date ddeEndDate;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "\"dde$change_date\"")
    private Date ddeChangeDate;

    @Temporal(TemporalType.DATE)
    @Column(name = "dde_dedline_date")
    private Date ddeDedlineDate;

    @Column(name = "dde_department", length = 100)
    private String ddeDepartment;

    @JoinColumn(name = "dde_system")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictSources ddeSystem;

    @Column(name = "dde_dog_num", length = 100)
    private String ddeDogNum;

    @Column(name = "dde_product", length = 100)
    private String ddeProduct;

    @Temporal(TemporalType.DATE)
    @Column(name = "dde_open_date")
    private Date ddeOpenDate;

    @Column(name = "dde_clnt_code", length = 100)
    private String ddeClntCode;

    @Column(name = "dde_cli_name", length = 1000)
    private String ddeCliName;

    @Column(name = "dde_cli_iin")
    private String ddeIin;

    @Column(name = "dde_deal_status", length = 100)
    private String ddeDealStatus;

    @Column(name = "dde_deal_info")
    private String ddeDealInfo;

    @Lob
    @Column(name = "dde_error")
    private String ddeError;

    @JoinColumn(name = "dde_error_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictErrors ddeErrorUU;

    public DictSources getDdeSystem() {
        return ddeSystem;
    }

    public Date getDdeChangeDate() {
        return ddeChangeDate;
    }

    public BigDecimal getDdeDealGid() {
        return ddeDealGid;
    }

    public Date getDdeDedlineDate() {
        return ddeDedlineDate;
    }

    public Date getDdeOpenDate() {
        return ddeOpenDate;
    }

    public String getDdeClntCode() {
        return ddeClntCode;
    }

    public Date getDdeStartDate() {
        return ddeStartDate;
    }

    public Date getDdeEndDate() {
        return ddeEndDate;
    }

    public DictErrors getDdeErrorUU() {
        return ddeErrorUU;
    }

    public String getDdeError() {
        return ddeError;
    }

    public String getDdeDealInfo() {
        return ddeDealInfo;
    }

    public String getDdeDealStatus() {
        return ddeDealStatus;
    }

    public String getDdeIin() {
        return ddeIin;
    }

    public String getDdeCliName() {
        return ddeCliName;
    }

    public String getDdeDogNum() {
        return ddeDogNum;
    }

    public String getDdeProduct() {
        return ddeProduct;
    }

    public String getDdeDepartment() {
        return ddeDepartment;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

}