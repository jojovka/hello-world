package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "s00_dict_snp_poz_mapping", schema = "dwh_draft", indexes = {
        @Index(name = "IDX_SDSPM_SDSP_ID", columnList = "sdspm_poz_uuid")
})
@Entity(name = "r360_PozReferenceMap")
public class PozReferenceMap {
    @JmixGeneratedValue
    @Column(name = "sdspm_uuid", nullable = false)
    @Id
    private UUID id;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "\"sdspm$change_date\"")
    private Date changeDate;

    @JoinColumn(name = "sdspm_src_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictSources srcId;

    @JoinColumn(name = "sdspm_poz_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private PozReference sdspId;

    @InstanceName
    @Column(name = "sdspm_prod_name")
    private String prodName;

    @Column(name = "sdspm_prod_code")
    private String prodCode;

    @Column(name = "sdspm_cred_type")
    private String credType;

    @Column(name = "sdspm_prod_gid")
    private BigDecimal prodId;

    public void setProdId(BigDecimal prodId) {
        this.prodId = prodId;
    }

    public BigDecimal getProdId() {
        return prodId;
    }

    public void setSrcId(DictSources srcCd) {
        this.srcId = srcCd;
    }

    public DictSources getSrcId() {
        return srcId;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public String getCredType() {
        return credType;
    }

    public void setCredType(String credType) {
        this.credType = credType;
    }

    public String getProdCode() {
        return prodCode;
    }

    public void setProdCode(String prodCode) {
        this.prodCode = prodCode;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public PozReference getSdspId() {
        return sdspId;
    }

    public void setSdspId(PozReference sdspId) {
        this.sdspId = sdspId;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}