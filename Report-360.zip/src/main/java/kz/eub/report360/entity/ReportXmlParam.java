package kz.eub.report360.entity;

import io.jmix.core.DeletePolicy;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDelete;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "R360_REPORT_XML_PARAM", indexes = {
        @Index(name = "IDX_R360_REPORT_XML_PARAM", columnList = "REPORT_XML_ID")
})
@Entity(name = "r360_ReportXmlParam")
public class ReportXmlParam {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @NotNull
    @OnDelete(DeletePolicy.CASCADE)
    @JoinColumn(name = "REPORT_XML_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private ReportXml reportXml;

    @Column(name = "CODE", nullable = false)
    @NotNull
    private String code;

    @InstanceName
    @Column(name = "NAME")
    private String name;

    @NotNull
    @Column(name = "PARAM_TYPE", nullable = false)
    private String paramType;

    @Column(name = "VALUE_")
    @Lob
    private String value;

    @Temporal(TemporalType.DATE)
    @Column(name = "VALUE_DATE")
    private Date valueDate;

    @Column(name = "CONDITION_", nullable = false)
    @Lob
    @NotNull
    private String condition;

    @Column(name = "REPLACEABLE_CH", nullable = false)
    @Lob
    @NotNull
    private String replaceableCh;

    @Column(name = "SHOW_PARAM")
    private Boolean showParam;

    @Column(name = "MANDATORY_PARAM")
    private Boolean mandatoryParam;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATE_TS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "UPDATED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "UPDATE_TS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETE_TS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    public ReportXml getReportXml() {
        return reportXml;
    }

    public void setReportXml(ReportXml reportXml) {
        this.reportXml = reportXml;
    }

    public void setParamType(ReportXmlParType paramType) {
        this.paramType = paramType == null ? null : paramType.getId();
    }

    public ReportXmlParType getParamType() {
        return paramType == null ? null : ReportXmlParType.fromId(paramType);
    }

    public String getReplaceableCh() {
        return replaceableCh;
    }

    public void setReplaceableCh(String replaceableCh) {
        this.replaceableCh = replaceableCh;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public Boolean getMandatoryParam() {
        return mandatoryParam;
    }

    public void setMandatoryParam(Boolean mandatoryParam) {
        this.mandatoryParam = mandatoryParam;
    }

    public Boolean getShowParam() {
        return showParam;
    }

    public void setShowParam(Boolean showParam) {
        this.showParam = showParam;
    }

    public void setValueDate(Date valueDate) {
        this.valueDate = valueDate;
    }

    public Date getValueDate() {
        return valueDate;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}