package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;
import io.jmix.data.DbView;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;

@DbView
@JmixEntity
@Store(name = "dwhdb")
@Table(name = "ARCHIVE_RELOAD_DAY_FOR_JOB", indexes = {
        @Index(name = "IDX_ARCHIVE_RELOAD_DAY_FOR_JOB_ON_ARCH_DATE", columnList = "\"ARCH_DATE\"", unique = true)
})
@Entity(name = "r360_ArchiveReloadDayForJob")
public class ArchiveReloadDayForJob {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private Long id;

    @NotNull
    @Column(name = "\"ARCH_DATE\"", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date archDate;

    @Column(name = "\"UPDATE_DATETIME\"")
    @Temporal(TemporalType.DATE)
    private Date updateDatetime;

    @Column(name = "USERNAME", length = 250)
    private String username;

    public String getUsername() {
        return username;
    }

    public void setUsername(String users) {
        this.username = users;
    }

    public Date getUpdateDatetime() {
        return updateDatetime;
    }

    public void setUpdateDatetime(Date updateDatetime) {
        this.updateDatetime = updateDatetime;
    }

    public Date getArchDate() {
        return archDate;
    }

    public void setArchDate(Date archDate) {
        this.archDate = archDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}