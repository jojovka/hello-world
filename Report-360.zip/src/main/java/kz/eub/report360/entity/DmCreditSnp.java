package kz.eub.report360.entity;

import io.jmix.core.DeletePolicy;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "dm_credit_snp", schema = "dwh_risk", indexes = {
        @Index(name = "IDX_DSC_SOURCE_UUID", columnList = "DSC_SOURCE_UUID"),
        @Index(name = "IDX_DSC_POZ_UUID", columnList = "DSC_POZ_UUID")
})
@Entity(name = "r360_DmCreditSnp")
public class DmCreditSnp {
    @JmixGeneratedValue
    @Column(name = "DCS_UUID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "DCS_REPORT_DATE")
    @Temporal(TemporalType.DATE)
    private Date dcsReportDate;

    @OnDeleteInverse(DeletePolicy.CASCADE)
    @JoinColumn(name = "DSC_SOURCE_UUID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictSources dscSourceUuid;

    @Column(name = "DSC_GID")
    private Long dscGid;

    @InstanceName
    @Column(name = "DSC_DOG_NUM")
    private String dscDogNum;

    @Column(name = "DSC_TRAN_NUM")
    private String dscTranNum;

    @Column(name = "DSC_CUR_CODE")
    private String dscCurCode;

    @Column(name = "DSC_DPRT_NAME", length = 320)
    private String dscDprtName;

    @Column(name = "DSC_CLNT_NAME")
    private String dscClntName;

    @Column(name = "DSC_CGRP_NAME")
    private String dscCgrpName;

    @Column(name = "DSC_OUT_SUM_KZT_OD", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztOd;

    @Column(name = "DSC_OUT_SUM_KZT_OD_DELAY", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztOdDelay;

    @Column(name = "DSC_OUT_SUM_KZT_PERC", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztPerc;

    @Column(name = "DSC_OUT_SUM_KZT_PERC_DELAY", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztPercDelay;

    @Column(name = "DSC_OUT_SUM_KZT_PERC_OD", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztPercOd;

    @Column(name = "DSC_OUT_SUM_KZT_COM", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztCom;

    @Column(name = "DSC_OUT_SUM_KZT_COM_DELAY", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztComDelay;

    @Column(name = "DSC_OUT_SUM_KZT_PEN", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztPen;

    @Column(name = "DSC_OUT_SUM_KZT_MSFO_PER", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztMsfoPer;

    @Column(name = "DSC_OUT_SUM_KZT_NEG_CORR", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztNegCorr;

    @Column(name = "DSC_OUT_SUM_KZT_DIS_1434", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztDis1434;

    @Column(name = "DSC_OUT_SUM_KZT_DIS_2794", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztDis2794;

    @Column(name = "DSC_OUT_SUM_KZT_CORR_ESP", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztCorrEsp;

    @Column(name = "DSC_OUT_SUM_KZT_DEV", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztDev;

    @Column(name = "DSC_OUT_SUM_KZT_MOD_1435", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztMod1435;

    @Column(name = "DSC_OUT_SUM_KZT_OD_ODD", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztOdOdd;

    @Column(name = "DSC_OUT_SUM_KZT_ALL_DEBT", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztAllDebt;

    @Column(name = "DSC_MSFO_RATE", precision = 19, scale = 2)
    private BigDecimal dscMsfoRate;

    @Column(name = "DSC_OUT_SUM_KZT_MSFO_1428", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztMsfo1428;

    @Column(name = "DSC_OUT_SUM_KZT_PROV_COM_1845", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztProvCom1845;

    @Column(name = "DSC_OUT_SUM_KZT_PROV_1877", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztProv1877;

    @Column(name = "DSC_OUT_SUM_KZT_DEBT_1860", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztDebt1860;

    @Column(name = "DSC_OUT_SUM_KZT_KIK", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztKik;

    @Column(name = "DSC_OUT_SUM_KZT_DZ_1877", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztDz1877;

    @Column(name = "DSC_OUT_SUM_KZT_OD_ODD_MON_BEG", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztOdOddMonBeg;

    @Column(name = "DSC_OUT_SUM_KZT_ALL_DEBT_WITHOUT_DIS", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztAllDebtWithoutDis;

    @Column(name = "DSC_OUT_SUM_KZT_RESER", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztReser;

    @Column(name = "DSC_OUT_SUM_KZT_OUTSYS", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztOutsys;

    @Column(name = "DSC_OUT_SUM_KZT_OUTSYS_SUM", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztOutsysSum;

    @Column(name = "DSC_OUT_SUM_KZT_LESION", precision = 19, scale = 2)
    private BigDecimal dscOutSumKztLesion;

    @Column(name = "DSC_CR_RATE_MONTH_BEG", precision = 19, scale = 2)
    private BigDecimal dscCrRateMonthBeg;

    @Column(name = "DSC_CR_RATE_REP_DATE", precision = 19, scale = 2)
    private BigDecimal dscCrRateRepDate;

    @Column(name = "DSC_PROD_NAME")
    private String dscProdName;

    @Column(name = "DSC_TARIF")
    private String dscTarif;

    @Column(name = "DSC_IS_UNIFORM")
    private Long dscIsUniform;

    @OnDeleteInverse(DeletePolicy.CASCADE)
    @JoinColumn(name = "DSC_POZ_UUID")
    @ManyToOne(fetch = FetchType.LAZY)
    private PozReference dscPozId;

    @Column(name = "DSC_USER_CRED_TYPE")
    private String dscUserCredType;

    @Column(name = "DSC_DPRT_GID")
    private Long dscDprtGid;

    @Column(name = "DSC_CLI_RATI_IN")
    private String dscCliRatiIn;

    @Column(name = "DSC_CLI_RATI_IN_DATE")
    @Temporal(TemporalType.DATE)
    private Date dscCliRatiInDate;

    @Column(name = "DSC_DEAL_RATI")
    private String dscDealRati;

    @Column(name = "DSC_DEAL_RATI_DATE")
    @Temporal(TemporalType.DATE)
    private Date dscDealRatiDate;

    @Column(name = "DSC_MON_DATE")
    @Temporal(TemporalType.DATE)
    private Date dscMonDate;

    @Column(name = "DSC_ACT_FIN_DATE")
    @Temporal(TemporalType.DATE)
    private Date dscActFinDate;

    @Column(name = "DSC_MON_PER")
    private String dscMonPer;

    @Column(name = "DSC_LAST_FIN_DATE")
    @Temporal(TemporalType.DATE)
    private Date dscLastFinDate;

    @Column(name = "DSC_CLI_RATI_OUT")
    private String dscCliRatiOut;

    @Column(name = "DSC_CLI_IIN_BIN")
    private String dscCliIinBin;

    @Column(name = "DSC_CLI_TYPE")
    private String dscCliType;

    @Column(name = "DSC_SD_CD")
    private Long dscSdCd;

    @Column(name = "DSC_KOD_IP")
    private String dscKodIp;

    @Column(name = "DSC_MAX_DELAY_DAY")
    private Long dscMaxDelayDay;

    @Column(name = "DSC_MIN_DELAY_DAY")
    private Long dscMinDelayDay;

    @Column(name = "DSC_OPEN_DATE")
    @Temporal(TemporalType.DATE)
    private Date dscOpenDate;

    @Column(name = "DSC_PAY_DATE")
    @Temporal(TemporalType.DATE)
    private Date dscPayDate;

    @Column(name = "DSC_OKED")
    private String dscOked;

    @Column(name = "DSC_CLI_OKED_CD")
    private Long dscCliOkedCd;

    @Column(name = "DSC_PROBLEM")
    private String dscProblem;

    @Column(name = "DSC_CLASS")
    private String dscClass;

    @Column(name = "DSC_MODIF")
    private String dscModif;

    @Column(name = "DSC_MOD_DATE")
    @Temporal(TemporalType.DATE)
    private Date dscModDate;

    @Column(name = "DSC_BASKET_MON_BEG")
    private Long dscBasketMonBeg;

    @Column(name = "DSC_BASKET_REP_DATE")
    @Temporal(TemporalType.DATE)
    private Date dscBasketRepDate;

    @Column(name = "DSC_RATE", precision = 19, scale = 2)
    private BigDecimal dscRate;

    @Column(name = "DSC_GESV_BEG", precision = 19, scale = 2)
    private BigDecimal dscGesvBeg;

    @NotNull
    @Column(name = "DSC_TRG_2", nullable = false)
    private Boolean dscTrg2 = false;

    @NotNull
    @Column(name = "DSC_TRG_3", nullable = false)
    private Boolean dscTrg3 = false;

    @NotNull
    @Column(name = "DSC_TRG_4", nullable = false)
    private Boolean dscTrg4 = false;

    @NotNull
    @Column(name = "DSC_RECOVERY", nullable = false)
    private Boolean dscRecovery = false;

    @Column(name = "DSC_DEFOLT_DATE")
    @Temporal(TemporalType.DATE)
    private Date dscDefoltDate;

    @Column(name = "DSC_RECOVERY_DATE")
    @Temporal(TemporalType.DATE)
    private Date dscRecoveryDate;

    @NotNull
    @Column(name = "DSC_NON_MARKET_FL", nullable = false)
    private Boolean dscNonMarketFl = false;

    @Column(name = "DSC_ALL_SUM", precision = 19, scale = 2)
    private BigDecimal dscAllSum;

    @Column(name = "DSC_CONTROL_LIST")
    private String dscControlList;

    @Column(name = "DSC_STATE")
    private String dscState;

    public void setDscProdName(String dscProdName) {
        this.dscProdName = dscProdName;
    }

    public String getDscProdName() {
        return dscProdName;
    }

    public void setDscCgrpName(String dscCgrpName) {
        this.dscCgrpName = dscCgrpName;
    }

    public String getDscCgrpName() {
        return dscCgrpName;
    }

    public void setDscClntName(String dscClntName) {
        this.dscClntName = dscClntName;
    }

    public String getDscClntName() {
        return dscClntName;
    }

    public void setDscDprtName(String dscDprtName) {
        this.dscDprtName = dscDprtName;
    }

    public String getDscDprtName() {
        return dscDprtName;
    }

    public void setDscCurCode(String dscCurCode) {
        this.dscCurCode = dscCurCode;
    }

    public String getDscCurCode() {
        return dscCurCode;
    }

    public String getDscState() {
        return dscState;
    }

    public void setDscState(String dscState) {
        this.dscState = dscState;
    }

    public String getDscControlList() {
        return dscControlList;
    }

    public void setDscControlList(String dscControlList) {
        this.dscControlList = dscControlList;
    }

    public BigDecimal getDscAllSum() {
        return dscAllSum;
    }

    public void setDscAllSum(BigDecimal dscAllSum) {
        this.dscAllSum = dscAllSum;
    }

    public Boolean getDscNonMarketFl() {
        return dscNonMarketFl;
    }

    public void setDscNonMarketFl(Boolean dscNonMarketFl) {
        this.dscNonMarketFl = dscNonMarketFl;
    }

    public Date getDscRecoveryDate() {
        return dscRecoveryDate;
    }

    public void setDscRecoveryDate(Date dscRecoveryDate) {
        this.dscRecoveryDate = dscRecoveryDate;
    }

    public Date getDscDefoltDate() {
        return dscDefoltDate;
    }

    public void setDscDefoltDate(Date dscDefoltDate) {
        this.dscDefoltDate = dscDefoltDate;
    }

    public Boolean getDscRecovery() {
        return dscRecovery;
    }

    public void setDscRecovery(Boolean dscRecovery) {
        this.dscRecovery = dscRecovery;
    }

    public Boolean getDscTrg4() {
        return dscTrg4;
    }

    public void setDscTrg4(Boolean dscTrg4) {
        this.dscTrg4 = dscTrg4;
    }

    public Boolean getDscTrg3() {
        return dscTrg3;
    }

    public void setDscTrg3(Boolean dscTrg3) {
        this.dscTrg3 = dscTrg3;
    }

    public Boolean getDscTrg2() {
        return dscTrg2;
    }

    public void setDscTrg2(Boolean dscTrg2) {
        this.dscTrg2 = dscTrg2;
    }

    public BigDecimal getDscGesvBeg() {
        return dscGesvBeg;
    }

    public void setDscGesvBeg(BigDecimal dscGesvBeg) {
        this.dscGesvBeg = dscGesvBeg;
    }

    public BigDecimal getDscRate() {
        return dscRate;
    }

    public void setDscRate(BigDecimal dscRate) {
        this.dscRate = dscRate;
    }

    public Date getDscBasketRepDate() {
        return dscBasketRepDate;
    }

    public void setDscBasketRepDate(Date dscBasketRepDate) {
        this.dscBasketRepDate = dscBasketRepDate;
    }

    public Long getDscBasketMonBeg() {
        return dscBasketMonBeg;
    }

    public void setDscBasketMonBeg(Long dscBasketMonBeg) {
        this.dscBasketMonBeg = dscBasketMonBeg;
    }

    public Date getDscModDate() {
        return dscModDate;
    }

    public void setDscModDate(Date dscModDate) {
        this.dscModDate = dscModDate;
    }

    public String getDscModif() {
        return dscModif;
    }

    public void setDscModif(String dscModif) {
        this.dscModif = dscModif;
    }

    public String getDscClass() {
        return dscClass;
    }

    public void setDscClass(String dscClass) {
        this.dscClass = dscClass;
    }

    public String getDscProblem() {
        return dscProblem;
    }

    public void setDscProblem(String dscProblem) {
        this.dscProblem = dscProblem;
    }

    public Long getDscCliOkedCd() {
        return dscCliOkedCd;
    }

    public void setDscCliOkedCd(Long dscCliOkedCd) {
        this.dscCliOkedCd = dscCliOkedCd;
    }

    public String getDscOked() {
        return dscOked;
    }

    public void setDscOked(String dscOked) {
        this.dscOked = dscOked;
    }

    public Date getDscPayDate() {
        return dscPayDate;
    }

    public void setDscPayDate(Date dscPayDate) {
        this.dscPayDate = dscPayDate;
    }

    public Date getDscOpenDate() {
        return dscOpenDate;
    }

    public void setDscOpenDate(Date dscOpenDate) {
        this.dscOpenDate = dscOpenDate;
    }

    public Long getDscMinDelayDay() {
        return dscMinDelayDay;
    }

    public void setDscMinDelayDay(Long dscMinDelayDay) {
        this.dscMinDelayDay = dscMinDelayDay;
    }

    public Long getDscMaxDelayDay() {
        return dscMaxDelayDay;
    }

    public void setDscMaxDelayDay(Long dscMaxDelayDay) {
        this.dscMaxDelayDay = dscMaxDelayDay;
    }

    public String getDscKodIp() {
        return dscKodIp;
    }

    public void setDscKodIp(String dscKodIp) {
        this.dscKodIp = dscKodIp;
    }

    public Long getDscSdCd() {
        return dscSdCd;
    }

    public void setDscSdCd(Long dscSdCd) {
        this.dscSdCd = dscSdCd;
    }

    public String getDscCliType() {
        return dscCliType;
    }

    public void setDscCliType(String dscCliType) {
        this.dscCliType = dscCliType;
    }

    public String getDscCliIinBin() {
        return dscCliIinBin;
    }

    public void setDscCliIinBin(String dscCliIinBin) {
        this.dscCliIinBin = dscCliIinBin;
    }

    public String getDscCliRatiOut() {
        return dscCliRatiOut;
    }

    public void setDscCliRatiOut(String dscCliRatiOut) {
        this.dscCliRatiOut = dscCliRatiOut;
    }

    public Date getDscLastFinDate() {
        return dscLastFinDate;
    }

    public void setDscLastFinDate(Date dscLastFinDate) {
        this.dscLastFinDate = dscLastFinDate;
    }

    public String getDscMonPer() {
        return dscMonPer;
    }

    public void setDscMonPer(String dscMonPer) {
        this.dscMonPer = dscMonPer;
    }

    public Date getDscActFinDate() {
        return dscActFinDate;
    }

    public void setDscActFinDate(Date dscActFinDate) {
        this.dscActFinDate = dscActFinDate;
    }

    public Date getDscMonDate() {
        return dscMonDate;
    }

    public void setDscMonDate(Date dscMonDate) {
        this.dscMonDate = dscMonDate;
    }

    public Date getDscDealRatiDate() {
        return dscDealRatiDate;
    }

    public void setDscDealRatiDate(Date dscDealRatiDate) {
        this.dscDealRatiDate = dscDealRatiDate;
    }

    public String getDscDealRati() {
        return dscDealRati;
    }

    public void setDscDealRati(String dscDealRati) {
        this.dscDealRati = dscDealRati;
    }

    public Date getDscCliRatiInDate() {
        return dscCliRatiInDate;
    }

    public void setDscCliRatiInDate(Date dscCliRatiInDate) {
        this.dscCliRatiInDate = dscCliRatiInDate;
    }

    public String getDscCliRatiIn() {
        return dscCliRatiIn;
    }

    public void setDscCliRatiIn(String dscCliRatiIn) {
        this.dscCliRatiIn = dscCliRatiIn;
    }

    public Long getDscDprtGid() {
        return dscDprtGid;
    }

    public void setDscDprtGid(Long dscDprtGid) {
        this.dscDprtGid = dscDprtGid;
    }

    public String getDscUserCredType() {
        return dscUserCredType;
    }

    public void setDscUserCredType(String dscUserCredType) {
        this.dscUserCredType = dscUserCredType;
    }

    public PozReference getDscPozId() {
        return dscPozId;
    }

    public void setDscPozId(PozReference dscPozId) {
        this.dscPozId = dscPozId;
    }

    public Long getDscIsUniform() {
        return dscIsUniform;
    }

    public void setDscIsUniform(Long dscIsUniform) {
        this.dscIsUniform = dscIsUniform;
    }

    public String getDscTarif() {
        return dscTarif;
    }

    public void setDscTarif(String dscTarif) {
        this.dscTarif = dscTarif;
    }

    public BigDecimal getDscCrRateRepDate() {
        return dscCrRateRepDate;
    }

    public void setDscCrRateRepDate(BigDecimal dscCrRateRepDate) {
        this.dscCrRateRepDate = dscCrRateRepDate;
    }

    public BigDecimal getDscCrRateMonthBeg() {
        return dscCrRateMonthBeg;
    }

    public void setDscCrRateMonthBeg(BigDecimal dscCrRateMonthBeg) {
        this.dscCrRateMonthBeg = dscCrRateMonthBeg;
    }

    public BigDecimal getDscOutSumKztLesion() {
        return dscOutSumKztLesion;
    }

    public void setDscOutSumKztLesion(BigDecimal dscOutSumKztLesion) {
        this.dscOutSumKztLesion = dscOutSumKztLesion;
    }

    public BigDecimal getDscOutSumKztOutsysSum() {
        return dscOutSumKztOutsysSum;
    }

    public void setDscOutSumKztOutsysSum(BigDecimal dscOutSumKztOutsysSum) {
        this.dscOutSumKztOutsysSum = dscOutSumKztOutsysSum;
    }

    public BigDecimal getDscOutSumKztOutsys() {
        return dscOutSumKztOutsys;
    }

    public void setDscOutSumKztOutsys(BigDecimal dscOutSumKztOutsys) {
        this.dscOutSumKztOutsys = dscOutSumKztOutsys;
    }

    public BigDecimal getDscOutSumKztReser() {
        return dscOutSumKztReser;
    }

    public void setDscOutSumKztReser(BigDecimal dscOutSumKztReser) {
        this.dscOutSumKztReser = dscOutSumKztReser;
    }

    public BigDecimal getDscOutSumKztAllDebtWithoutDis() {
        return dscOutSumKztAllDebtWithoutDis;
    }

    public void setDscOutSumKztAllDebtWithoutDis(BigDecimal dscOutSumKztAllDebtWithoutDis) {
        this.dscOutSumKztAllDebtWithoutDis = dscOutSumKztAllDebtWithoutDis;
    }

    public BigDecimal getDscOutSumKztOdOddMonBeg() {
        return dscOutSumKztOdOddMonBeg;
    }

    public void setDscOutSumKztOdOddMonBeg(BigDecimal dscOutSumKztOdOddMonBeg) {
        this.dscOutSumKztOdOddMonBeg = dscOutSumKztOdOddMonBeg;
    }

    public BigDecimal getDscOutSumKztDz1877() {
        return dscOutSumKztDz1877;
    }

    public void setDscOutSumKztDz1877(BigDecimal dscOutSumKztDz1877) {
        this.dscOutSumKztDz1877 = dscOutSumKztDz1877;
    }

    public BigDecimal getDscOutSumKztKik() {
        return dscOutSumKztKik;
    }

    public void setDscOutSumKztKik(BigDecimal dscOutSumKztKik) {
        this.dscOutSumKztKik = dscOutSumKztKik;
    }

    public BigDecimal getDscOutSumKztDebt1860() {
        return dscOutSumKztDebt1860;
    }

    public void setDscOutSumKztDebt1860(BigDecimal dscOutSumKztDebt1860) {
        this.dscOutSumKztDebt1860 = dscOutSumKztDebt1860;
    }

    public BigDecimal getDscOutSumKztProv1877() {
        return dscOutSumKztProv1877;
    }

    public void setDscOutSumKztProv1877(BigDecimal dscOutSumKztProv1877) {
        this.dscOutSumKztProv1877 = dscOutSumKztProv1877;
    }

    public BigDecimal getDscOutSumKztProvCom1845() {
        return dscOutSumKztProvCom1845;
    }

    public void setDscOutSumKztProvCom1845(BigDecimal dscOutSumKztProvCom1845) {
        this.dscOutSumKztProvCom1845 = dscOutSumKztProvCom1845;
    }

    public BigDecimal getDscOutSumKztMsfo1428() {
        return dscOutSumKztMsfo1428;
    }

    public void setDscOutSumKztMsfo1428(BigDecimal dscOutSumKztMsfo1428) {
        this.dscOutSumKztMsfo1428 = dscOutSumKztMsfo1428;
    }

    public BigDecimal getDscMsfoRate() {
        return dscMsfoRate;
    }

    public void setDscMsfoRate(BigDecimal dscMsfoRate) {
        this.dscMsfoRate = dscMsfoRate;
    }

    public BigDecimal getDscOutSumKztAllDebt() {
        return dscOutSumKztAllDebt;
    }

    public void setDscOutSumKztAllDebt(BigDecimal dscOutSumKztAllDebt) {
        this.dscOutSumKztAllDebt = dscOutSumKztAllDebt;
    }

    public BigDecimal getDscOutSumKztOdOdd() {
        return dscOutSumKztOdOdd;
    }

    public void setDscOutSumKztOdOdd(BigDecimal dscOutSumKztOdOdd) {
        this.dscOutSumKztOdOdd = dscOutSumKztOdOdd;
    }

    public BigDecimal getDscOutSumKztMod1435() {
        return dscOutSumKztMod1435;
    }

    public void setDscOutSumKztMod1435(BigDecimal dscOutSumKztMod1435) {
        this.dscOutSumKztMod1435 = dscOutSumKztMod1435;
    }

    public BigDecimal getDscOutSumKztDev() {
        return dscOutSumKztDev;
    }

    public void setDscOutSumKztDev(BigDecimal dscOutSumKztDev) {
        this.dscOutSumKztDev = dscOutSumKztDev;
    }

    public BigDecimal getDscOutSumKztCorrEsp() {
        return dscOutSumKztCorrEsp;
    }

    public void setDscOutSumKztCorrEsp(BigDecimal dscOutSumKztCorrEsp) {
        this.dscOutSumKztCorrEsp = dscOutSumKztCorrEsp;
    }

    public BigDecimal getDscOutSumKztDis2794() {
        return dscOutSumKztDis2794;
    }

    public void setDscOutSumKztDis2794(BigDecimal dscOutSumKztDis2794) {
        this.dscOutSumKztDis2794 = dscOutSumKztDis2794;
    }

    public BigDecimal getDscOutSumKztDis1434() {
        return dscOutSumKztDis1434;
    }

    public void setDscOutSumKztDis1434(BigDecimal dscOutSumKztDis_1434) {
        this.dscOutSumKztDis1434 = dscOutSumKztDis_1434;
    }

    public BigDecimal getDscOutSumKztNegCorr() {
        return dscOutSumKztNegCorr;
    }

    public void setDscOutSumKztNegCorr(BigDecimal dscOutSumKztNegCorr) {
        this.dscOutSumKztNegCorr = dscOutSumKztNegCorr;
    }

    public BigDecimal getDscOutSumKztMsfoPer() {
        return dscOutSumKztMsfoPer;
    }

    public void setDscOutSumKztMsfoPer(BigDecimal dscOutSumKztMsfoPer) {
        this.dscOutSumKztMsfoPer = dscOutSumKztMsfoPer;
    }

    public BigDecimal getDscOutSumKztPen() {
        return dscOutSumKztPen;
    }

    public void setDscOutSumKztPen(BigDecimal dscOutSumKztPen) {
        this.dscOutSumKztPen = dscOutSumKztPen;
    }

    public BigDecimal getDscOutSumKztComDelay() {
        return dscOutSumKztComDelay;
    }

    public void setDscOutSumKztComDelay(BigDecimal dscOutSumKztComDelay) {
        this.dscOutSumKztComDelay = dscOutSumKztComDelay;
    }

    public BigDecimal getDscOutSumKztCom() {
        return dscOutSumKztCom;
    }

    public void setDscOutSumKztCom(BigDecimal dscOutSumKztCom) {
        this.dscOutSumKztCom = dscOutSumKztCom;
    }

    public BigDecimal getDscOutSumKztPercOd() {
        return dscOutSumKztPercOd;
    }

    public void setDscOutSumKztPercOd(BigDecimal dscOutSumKztPercOd) {
        this.dscOutSumKztPercOd = dscOutSumKztPercOd;
    }

    public BigDecimal getDscOutSumKztPercDelay() {
        return dscOutSumKztPercDelay;
    }

    public void setDscOutSumKztPercDelay(BigDecimal dscOutSumKztPercDelay) {
        this.dscOutSumKztPercDelay = dscOutSumKztPercDelay;
    }

    public BigDecimal getDscOutSumKztPerc() {
        return dscOutSumKztPerc;
    }

    public void setDscOutSumKztPerc(BigDecimal dscOutSumKztPerc) {
        this.dscOutSumKztPerc = dscOutSumKztPerc;
    }

    public BigDecimal getDscOutSumKztOdDelay() {
        return dscOutSumKztOdDelay;
    }

    public void setDscOutSumKztOdDelay(BigDecimal dscOutSumKztOdDelay) {
        this.dscOutSumKztOdDelay = dscOutSumKztOdDelay;
    }

    public BigDecimal getDscOutSumKztOd() {
        return dscOutSumKztOd;
    }

    public void setDscOutSumKztOd(BigDecimal dscOutSumKztOd) {
        this.dscOutSumKztOd = dscOutSumKztOd;
    }

    public String getDscTranNum() {
        return dscTranNum;
    }

    public void setDscTranNum(String dscTranNum) {
        this.dscTranNum = dscTranNum;
    }

    public String getDscDogNum() {
        return dscDogNum;
    }

    public void setDscDogNum(String dscDogNum) {
        this.dscDogNum = dscDogNum;
    }

    public Long getDscGid() {
        return dscGid;
    }

    public void setDscGid(Long dscGid) {
        this.dscGid = dscGid;
    }

    public DictSources getDscSourceUuid() {
        return dscSourceUuid;
    }

    public void setDscSourceUuid(DictSources dscSourceUuid) {
        this.dscSourceUuid = dscSourceUuid;
    }

    public Date getDcsReportDate() {
        return dcsReportDate;
    }

    public void setDcsReportDate(Date dcsReportDate) {
        this.dcsReportDate = dcsReportDate;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}