package kz.eub.report360.entity;

import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "dm_account_error", schema = "dwh_dq", indexes = {
        @Index(name = "IDX_DM_ACCOUNT_ERROR_DAE_ERROR_UUID", columnList = "dae_error_uuid")
})
@Entity(name = "r360_AccountErrors")
public class AccountErrors {
    @Column(name = "dae_uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "dae_acnt_gid", length = 50)
    private String daeAcntGid;

    @Temporal(TemporalType.DATE)
    @Column(name = "\"dae$start_date\"")
    private Date daestartDate;

    @Temporal(TemporalType.DATE)
    @Column(name = "\"dae$end_date\"")
    private Date daeendDate;

    @Column(name = "\"dae$change_date\"")
    private LocalDateTime daeChangeDate;

    @Temporal(TemporalType.DATE)
    @Column(name = "dae_dedline_date")
    private Date daeDeadlineDate;

    @Column(name = "dae_department", length = 100)
    private String daeDepartment;

    @JoinColumn(name = "dae_system")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictSources daeSystem;

    @Column(name = "dae_acntpln_bal_num", length = 30)
    private String daeAcntplnBalNum;

    @Column(name = "dae_acnt_number", length = 50)
    private String daeAcntNumber;

    @Column(name = "dae_acnt_name", length = 1000)
    private String daeAcntName;

    @Column(name = "dae_stat_name", length = 30)
    private String daeStatName;

    @Column(name = "dae_cur_code", length = 10)
    private String daeCurCode;

    @Temporal(TemporalType.DATE)
    @Column(name = "dae_acnt_open_date")
    private Date daeAcntOpenDate;

    @Temporal(TemporalType.DATE)
    @Column(name = "dae_acnt_close_date")
    private Date daeAcntCloseDate;

    @Column(name = "dae_out_kzt", precision = 19, scale = 2)
    private BigDecimal daeOutKzt;

    @Column(name = "dae_clnt_type", length = 10)
    private String daeClntType;

    @Column(name = "dae_clnt_iin_bin")
    private String daeClntIinBin;

    @Column(name = "dae_clnt_full_name")
    private String daeClntFullName;

    @Column(name = "dae_clnt_resident_flg", precision = 19, scale = 2)
    private BigDecimal daeClntResidentFlg;

    @Column(name = "dae_error")
    private String daeError;

    @JoinColumn(name = "dae_error_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictErrors daeDictError;

    public DictSources getDaeSystem() {
        return daeSystem;
    }

    public String getDaeAcntGid() {
        return daeAcntGid;
    }

    public BigDecimal getDaeClntResidentFlg() {
        return daeClntResidentFlg;
    }

    public String getDaeClntFullName() {
        return daeClntFullName;
    }

    public String getDaeClntIinBin() {
        return daeClntIinBin;
    }

    public String getDaeClntType() {
        return daeClntType;
    }

    public DictErrors getDaeDictError() {
        return daeDictError;
    }

    public Date getDaeAcntOpenDate() {
        return daeAcntOpenDate;
    }

    public Date getDaeAcntCloseDate() {
        return daeAcntCloseDate;
    }

    public String getDaeError() {
        return daeError;
    }

    public Date getDaeDeadlineDate() {
        return daeDeadlineDate;
    }

    public Date getDaestartDate() {
        return daestartDate;
    }

    public Date getDaeendDate() {
        return daeendDate;
    }

    public String getDaeAcntName() {
        return daeAcntName;
    }

    public BigDecimal getDaeOutKzt() {
        return daeOutKzt;
    }

    public LocalDateTime getDaeChangeDate() {
        return daeChangeDate;
    }

    public String getDaeCurCode() {
        return daeCurCode;
    }

    public String getDaeStatName() {
        return daeStatName;
    }

    public String getDaeAcntNumber() {
        return daeAcntNumber;
    }

    public String getDaeAcntplnBalNum() {
        return daeAcntplnBalNum;
    }

    public String getDaeDepartment() {
        return daeDepartment;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"daeAcntName"})
    public String getInstanceName() {
        return String.format("%s", daeAcntName);
    }
}