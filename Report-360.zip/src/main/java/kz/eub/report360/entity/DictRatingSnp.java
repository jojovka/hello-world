package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "s00_dict_snp_pnz_rating", schema = "dwh_draft")
@Entity(name = "r360_DictRatingSnp")
public class DictRatingSnp {
    @JmixGeneratedValue
    @Column(name = "sdsr_uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "sdsr_in_values")
    private String inValues;

    @Column(name = "sdsr_out_values")
    private String outValues;

    @InstanceName
    @Column(name = "sdsr_descr")
    private String description;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getOutValues() {
        return outValues;
    }

    public void setOutValues(String outValues) {
        this.outValues = outValues;
    }

    public String getInValues() {
        return inValues;
    }

    public void setInValues(String inValues) {
        this.inValues = inValues;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}