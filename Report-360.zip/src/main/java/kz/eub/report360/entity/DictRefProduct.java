package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "ref_product", schema = "dwh_dds")
@Entity(name = "r360_DictRefProduct")
public class DictRefProduct {
    @JmixGeneratedValue
    @Column(name = "prd_uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "\"prd$id\"", precision = 19, scale = 2)
    private BigDecimal prdId;

    @Column(name = "\"prd$start_date\"")
    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Column(name = "\"prd$end_date\"")
    @Temporal(TemporalType.DATE)
    private Date endDate;

    @Column(name = "\"prd$change_date\"")
    @Temporal(TemporalType.TIMESTAMP)
    private Date changeDate;

    @Column(name = "\"prd$row_status\"", length = 10)
    private String rowStatus;

    @Column(name = "\"prd$source\"", length = 10)
    private String prdSource;

    @Column(name = "\"prd$source_pk\"", precision = 19, scale = 2)
    private BigDecimal prdSourcePk;

    @Column(name = "\"prd$audit_id\"", precision = 19, scale = 2)
    private BigDecimal auditId;

    @Column(name = "prd_gid", precision = 19, scale = 2)
    private BigDecimal prdGid;

    @Column(name = "prd_prnt_prd_gid", precision = 19, scale = 2)
    private BigDecimal prntPrdGid;

    @Column(name = "prd_code")
    private String code;

    @Column(name = "prd_name")
    private String name;

    @Column(name = "prd_cur_cd", precision = 19, scale = 2)
    private BigDecimal curCd;

    @Column(name = "prd_term", precision = 19, scale = 2)
    private BigDecimal term;

    @Column(name = "prd_prol_count", precision = 19, scale = 2)
    private BigDecimal prolCount;

    @Column(name = "prd_category")
    private String category;

    @Column(name = "prd_subproduct")
    private String subProduct;

    @Column(name = "prd_deal_type")
    private String dealType;

    public String getDealType() {
        return dealType;
    }

    public void setDealType(String dealType) {
        this.dealType = dealType;
    }

    public String getSubProduct() {
        return subProduct;
    }

    public void setSubProduct(String subProduct) {
        this.subProduct = subProduct;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public BigDecimal getProlCount() {
        return prolCount;
    }

    public void setProlCount(BigDecimal prolCount) {
        this.prolCount = prolCount;
    }

    public BigDecimal getTerm() {
        return term;
    }

    public void setTerm(BigDecimal term) {
        this.term = term;
    }

    public BigDecimal getCurCd() {
        return curCd;
    }

    public void setCurCd(BigDecimal curCd) {
        this.curCd = curCd;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public BigDecimal getPrntPrdGid() {
        return prntPrdGid;
    }

    public void setPrntPrdGid(BigDecimal prntPrdGid) {
        this.prntPrdGid = prntPrdGid;
    }

    public BigDecimal getPrdGid() {
        return prdGid;
    }

    public void setPrdGid(BigDecimal prdGid) {
        this.prdGid = prdGid;
    }

    public BigDecimal getAuditId() {
        return auditId;
    }

    public void setAuditId(BigDecimal auditId) {
        this.auditId = auditId;
    }

    public BigDecimal getPrdSourcePk() {
        return prdSourcePk;
    }

    public void setPrdSourcePk(BigDecimal prdSourcePk) {
        this.prdSourcePk = prdSourcePk;
    }

    public String getPrdSource() {
        return prdSource;
    }

    public void setPrdSource(String prdSource) {
        this.prdSource = prdSource;
    }

    public String getRowStatus() {
        return rowStatus;
    }

    public void setRowStatus(String rowStatus) {
        this.rowStatus = rowStatus;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public BigDecimal getPrdId() {
        return prdId;
    }

    public void setPrdId(BigDecimal prdId) {
        this.prdId = prdId;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"name"})
    public String getInstanceName() {
        return String.format("%s", name);
    }
}