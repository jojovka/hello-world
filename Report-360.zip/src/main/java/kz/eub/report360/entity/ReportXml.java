package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "R360_REPORT_XML")
@Entity(name = "r360_ReportXml")
public class ReportXml {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @InstanceName
    @Column(name = "NAME", nullable = false)
    @NotNull
    private String name;

    @Column(name = "CODE", nullable = false)
    @NotNull
    private String code;

    @NotNull
    @Column(name = "DATA_STORE", nullable = false)
    private String dataStore;

    @Column(name = "XML_FIELD")
    @Lob
    private String xmlField;

    @Column(name = "XSD_FIELD")
    @Lob
    private String xsdField;

    @Column(name = "FUNCTION_FIELD")
    @Lob
    private String functionField;

    @Column(name = "REP_XML_TYPE", nullable = false)
    @NotNull
    private String repXmlType;

    @Column(name = "CHECK_ZIP", nullable = false)
    @NotNull
    private Boolean checkZip = false;

    @Column(name = "CHECK_XSD", nullable = false)
    @NotNull
    private Boolean checkXsd = false;

    @Column(name = "CHECK_MANIFEST", nullable = false)
    @NotNull
    private Boolean checkManifest = false;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATE_TS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "UPDATED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "UPDATE_TS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    public Boolean getCheckManifest() {
        return checkManifest;
    }

    public void setCheckManifest(Boolean checkManifest) {
        this.checkManifest = checkManifest;
    }

    public Boolean getCheckXsd() {
        return checkXsd;
    }

    public void setCheckXsd(Boolean checkXsd) {
        this.checkXsd = checkXsd;
    }

    public Boolean getCheckZip() {
        return checkZip;
    }

    public void setCheckZip(Boolean checkZip) {
        this.checkZip = checkZip;
    }

    public void setDataStore(DataStoreType dataStore) {
        this.dataStore = dataStore == null ? null : dataStore.getId();
    }

    public DataStoreType getDataStore() {
        return dataStore == null ? null : DataStoreType.fromId(dataStore);
    }

    public void setRepXmlType(ReportXmlType repXmlType) {
        this.repXmlType = repXmlType == null ? null : repXmlType.getId();
    }

    public ReportXmlType getRepXmlType() {
        return repXmlType == null ? null : ReportXmlType.fromId(repXmlType);
    }

    public String getFunctionField() {
        return functionField;
    }

    public void setFunctionField(String functionField) {
        this.functionField = functionField;
    }

    public String getXsdField() {
        return xsdField;
    }

    public void setXsdField(String xsdField) {
        this.xsdField = xsdField;
    }

    public String getXmlField() {
        return xmlField;
    }

    public void setXmlField(String xmlField) {
        this.xmlField = xmlField;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}