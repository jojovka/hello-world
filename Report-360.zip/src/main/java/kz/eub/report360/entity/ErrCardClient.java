package kz.eub.report360.entity;

import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "dm_client_error", schema = "dwh_dq", indexes = {
        @Index(name = "IDX_DM_CLIENT_ERROR_DCE_ERROR_UUID", columnList = "dce_error_uuid")
})
@Entity(name = "r360_ErrCardClient")
public class ErrCardClient {
    @Id
    @Column(name = "dce_uuid", nullable = false)
    private UUID id;

    @Column(name = "dce_cli_gid", precision = 19, scale = 2)
    private BigDecimal dceCliGid;

    @Temporal(TemporalType.DATE)
    @Column(name = "dce$start_date")
    private Date dceStartDate;

    @Temporal(TemporalType.DATE)
    @Column(name = "dce$end_date")
    private Date dceEndDate;

    @Column(name = "dce$change_date")
    private LocalDateTime dceChangeDate;

    @Temporal(TemporalType.DATE)
    @Column(name = "dce_dedline_date")
    private Date dceDeadlineDate;

    @Column(name = "dce_cli_type", length = 100)
    private String dceClntType;

    @Column(name = "dce_department", length = 100)
    private String dceDepartment;

    @JoinColumn(name = "dce_system")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictSources dceSystem;

    @Temporal(TemporalType.DATE)
    @Column(name = "dce_birth_date")
    private Date dceBirthDate;

    @InstanceName
    @Column(name = "dce_name", length = 1000)
    private String dceName;

    @Column(name = "dce_iin_bin")
    private String dceIinBin;

    @Column(name = "dce_cl_rezident", length = 10)
    private String dceClRezident;

    @Column(name = "dce_err_descr", length = 1000)
    private String dceErrDescr;

    @JoinColumn(name = "dce_error_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictErrors dceError;

    public DictSources getDceSystem() {
        return dceSystem;
    }

    public BigDecimal getDceCliGid() {
        return dceCliGid;
    }

    public DictErrors getDceError() {
        return dceError;
    }

    public Date getDceBirthDate() {
        return dceBirthDate;
    }

    public Date getDceDeadlineDate() {
        return dceDeadlineDate;
    }

    public Date getDceStartDate() {
        return dceStartDate;
    }

    public Date getDceEndDate() {
        return dceEndDate;
    }

    public LocalDateTime getDceChangeDate() {
        return dceChangeDate;
    }

    public String getDceErrDescr() {
        return dceErrDescr;
    }

    public String getDceClRezident() {
        return dceClRezident;
    }

    public String getDceIinBin() {
        return dceIinBin;
    }

    public String getDceName() {
        return dceName;
    }

    public String getDceDepartment() {
        return dceDepartment;
    }

    public String getDceClntType() {
        return dceClntType;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}