package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "s00_dict_snp_tr_basket", schema = "dwh_draft")
@Entity(name = "r360_DictBasketSnp")
public class DictBasketSnp {
    @JmixGeneratedValue
    @Column(name = "sdstb_uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "sdstb_code")
    private String code;

    @InstanceName
    @Column(name = "sdsts_name", length = 1000)
    private String name;

    @Column(name = "sdsts_td_lvl")
    private String tdLvl;

    @Column(name = "sdstb_basket", precision = 19, scale = 2)
    private BigDecimal basket;

    @Column(name = "sdstb_uniformity")
    private String uniformity;

    @Column(name = "sdstb_ul_sign")
    private String ulSign;

    @Column(name = "\"sdstb$start_date\"")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startDate;

    @Column(name = "\"sdstb$end_date\"")
    @Temporal(TemporalType.TIMESTAMP)
    private Date endDate;

    @Column(name = "sdstb_is_actual")
    private String isActual;

    @Column(name = "\"sdstb$change_date\"")
    @Temporal(TemporalType.TIMESTAMP)
    private Date changeDate;

    @Column(name = "sdstb_users")
    private String user;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String getIsActual() {
        return isActual;
    }

    public void setIsActual(String isActual) {
        this.isActual = isActual;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getUlSign() {
        return ulSign;
    }

    public void setUlSign(String ulSign) {
        this.ulSign = ulSign;
    }

    public String getUniformity() {
        return uniformity;
    }

    public void setUniformity(String uniformity) {
        this.uniformity = uniformity;
    }

    public BigDecimal getBasket() {
        return basket;
    }

    public void setBasket(BigDecimal basket) {
        this.basket = basket;
    }

    public String getTdLvl() {
        return tdLvl;
    }

    public void setTdLvl(String tdLvl) {
        this.tdLvl = tdLvl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}