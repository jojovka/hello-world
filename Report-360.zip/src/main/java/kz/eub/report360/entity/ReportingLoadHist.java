package kz.eub.report360.entity;

import io.jmix.core.DeletePolicy;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "R360_REPORTING_LOAD_HIST", indexes = {
        @Index(name = "IDX_R360_REPORTING_LOAD_HIST", columnList = "REPORTING_ID")
})
@Entity(name = "r360_ReportingLoadHist")
public class ReportingLoadHist {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @OnDeleteInverse(DeletePolicy.CASCADE)
    @JoinColumn(name = "REPORTING_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Reporting reporting;

    @Column(name = "DATE_ON_REP")
    @Temporal(TemporalType.DATE)
    private Date dateOnRep;

    @Column(name = "DATE_BEGIN")
    @Temporal(TemporalType.DATE)
    private Date dateBegin;

    @Column(name = "DATE_END")
    @Temporal(TemporalType.DATE)
    private Date dateEnd;

    @Column(name = "DATE_LOAD", nullable = false)
    @Temporal(TemporalType.DATE)
    @NotNull
    private Date dateLoad;

    @Column(name = "USER_NAME", nullable = false)
    @NotNull
    private String userName;

    @Column(name = "DESCRIPTION")
    @Lob
    private String description;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Date getDateLoad() {
        return dateLoad;
    }

    public void setDateLoad(Date dateLoad) {
        this.dateLoad = dateLoad;
    }

    public Date getDateEnd() {
        return dateEnd;
    }

    public void setDateEnd(Date dateEnd) {
        this.dateEnd = dateEnd;
    }

    public Date getDateBegin() {
        return dateBegin;
    }

    public void setDateBegin(Date dateBegin) {
        this.dateBegin = dateBegin;
    }

    public Date getDateOnRep() {
        return dateOnRep;
    }

    public void setDateOnRep(Date dateOnRep) {
        this.dateOnRep = dateOnRep;
    }

    public Reporting getReporting() {
        return reporting;
    }

    public void setReporting(Reporting reporting) {
        this.reporting = reporting;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"dateLoad", "description"})
    public String getInstanceName() {
        return String.format("%s %s", dateLoad, description);
    }
}