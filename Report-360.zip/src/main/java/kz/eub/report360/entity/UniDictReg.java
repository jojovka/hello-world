package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "s00_uni_dict_reg", schema = "dwh_draft")
@Entity(name = "r360_UniDictReg")
public class UniDictReg {
    @JmixGeneratedValue
    @Column(name = "SUDR_UUID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "SUDR_SRC")
    private String sudrSrc;

    @Column(name = "SUDR_TYPE")
    private String sudrType;

    @Column(name = "SUDR_TYPE_RUS")
    private String sudrTypeRus;

    @Column(name = "SUDR_CODE")
    private String sudrCode;

    @Column(name = "SUDR_NAME")
    private String sudrName;

    @InstanceName
    @Column(name = "SUDR_NAME_KAZ")
    private String sudrNameKaz;

    public String getSudrNameKaz() {
        return sudrNameKaz;
    }

    public void setSudrNameKaz(String sudrNameKaz) {
        this.sudrNameKaz = sudrNameKaz;
    }

    public String getSudrName() {
        return sudrName;
    }

    public void setSudrName(String sudrName) {
        this.sudrName = sudrName;
    }

    public String getSudrCode() {
        return sudrCode;
    }

    public void setSudrCode(String sudrCode) {
        this.sudrCode = sudrCode;
    }

    public String getSudrTypeRus() {
        return sudrTypeRus;
    }

    public void setSudrTypeRus(String sudrTypeRus) {
        this.sudrTypeRus = sudrTypeRus;
    }

    public String getSudrType() {
        return sudrType;
    }

    public void setSudrType(String sudrType) {
        this.sudrType = sudrType;
    }

    public String getSudrSrc() {
        return sudrSrc;
    }

    public void setSudrSrc(String sudrSrc) {
        this.sudrSrc = sudrSrc;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}