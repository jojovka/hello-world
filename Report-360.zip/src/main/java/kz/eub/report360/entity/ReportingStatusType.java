package kz.eub.report360.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum ReportingStatusType implements EnumClass<String> {

    AGREED("AGREED"),
    NOT_AGREED("NOT_AGREED");

    private String id;

    ReportingStatusType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static ReportingStatusType fromId(String id) {
        for (ReportingStatusType at : ReportingStatusType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}