package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "s00_relation_type", schema = "dwh_draft")
@Entity(name = "r360_RelationTypeLsbo")
public class RelationTypeLsbo {
    @JmixGeneratedValue
    @Column(name = "srt_uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "srt_code")
    private String srtCode;

    @Lob
    @InstanceName
    @Column(name = "srt_name")
    private String srtName;

    @Column(name = "srt_start_date")
    @Temporal(TemporalType.DATE)
    private Date srtStartDate;

    @Column(name = "srt_end_date")
    @Temporal(TemporalType.DATE)
    private Date srtEndDate;

    public void setSrtCode(String srtCode) {
        this.srtCode = srtCode;
    }

    public void setSrtName(String srtName) {
        this.srtName = srtName;
    }

    public void setSrtStartDate(Date srtStartDate) {
        this.srtStartDate = srtStartDate;
    }

    public void setSrtEndDate(Date srtEndDate) {
        this.srtEndDate = srtEndDate;
    }

    public Date getSrtEndDate() {
        return srtEndDate;
    }

    public Date getSrtStartDate() {
        return srtStartDate;
    }

    public String getSrtName() {
        return srtName;
    }

    public String getSrtCode() {
        return srtCode;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}