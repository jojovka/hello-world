package kz.eub.report360.entity;

import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "s00_uni_dict", schema = "dwh_draft")
@Entity(name = "r360_UniDictEntity")
public class UniDictEntity {
    @Column(name = "uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "id", precision = 19, scale = 2)
    private BigDecimal uniDictId;

    @InstanceName
    @Column(name = "descr")
    @Lob
    private String descr;

    @Column(name = "type", length = 100)
    private String type;

    @Column(name = "subtype", length = 100)
    private String subType;

    @Column(name = "value", length = 510)
    private String value;

    public String getValue() {
        return value;
    }

    public String getSubType() {
        return subType;
    }

    public String getType() {
        return type;
    }

    public String getDescr() {
        return descr;
    }

    public BigDecimal getUniDictId() {
        return uniDictId;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}