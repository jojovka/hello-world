package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity(name = "r360_RateDto")
public class RateDto {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    @Temporal(TemporalType.DATE)
    private Date date;

    private String code;

    private BigDecimal rateNbrk;

    private BigDecimal rateBuy;

    private BigDecimal rateSale;

    private String type;

    private BigDecimal bid;

    private BigDecimal ask;

    private BigDecimal last;

    public BigDecimal getLast() {
        return last;
    }

    public void setLast(BigDecimal last) {
        this.last = last;
    }

    public BigDecimal getAsk() {
        return ask;
    }

    public void setAsk(BigDecimal ask) {
        this.ask = ask;
    }

    public BigDecimal getBid() {
        return bid;
    }

    public void setBid(BigDecimal bid) {
        this.bid = bid;
    }

    public BigDecimal getRateBuy() {
        return rateBuy;
    }

    public void setRateBuy(BigDecimal rateBuy) {
        this.rateBuy = rateBuy;
    }

    public BigDecimal getRateSale() {
        return rateSale;
    }

    public void setRateSale(BigDecimal rateSale) {
        this.rateSale = rateSale;
    }

    public CurrencyRateType getType() {
        return type == null ? null : CurrencyRateType.fromId(type);
    }

    public void setType(CurrencyRateType type) {
        this.type = type == null ? null : type.getId();
    }

    public BigDecimal getRateNbrk() {
        return rateNbrk;
    }

    public void setRateNbrk(BigDecimal rateNbrk) {
        this.rateNbrk = rateNbrk;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}