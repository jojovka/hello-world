package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "dict_errors", schema = "dwh_dq", indexes = {
        @Index(name = "IDX_DICT_ERRORS_ERR_SUBGROUP_UUID", columnList = "err_subgroup_uuid"),
        @Index(name = "IDX_DICT_ERRORS_ERR_GROUP_UUID", columnList = "err_group_uuid")
})
@Entity(name = "r360_DictErrors")
public class DictErrors {
    @JmixGeneratedValue
    @Column(name = "err_uuid", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "err_group_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictErrorGroup errGroup;

    @JoinColumn(name = "err_subgroup_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictSubError errSubgroup;

    @InstanceName
    @Column(name = "err_descr", length = 510)
    private String errDescr;

    @Column(name = "err_alg")
    @Lob
    private String errAlg;

    public String getErrAlg() {
        return errAlg;
    }

    public void setErrAlg(String errAlg) {
        this.errAlg = errAlg;
    }

    public void setErrDescr(String errDescr) {
        this.errDescr = errDescr;
    }

    public void setErrGroup(DictErrorGroup errGroup) {
        this.errGroup = errGroup;
    }

    public void setErrSubgroup(DictSubError errSubgroup) {
        this.errSubgroup = errSubgroup;
    }

    public DictErrorGroup getErrGroup() {
        return errGroup;
    }

    public DictSubError getErrSubgroup() {
        return errSubgroup;
    }

    public String getErrDescr() {
        return errDescr;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}