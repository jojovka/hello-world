package kz.eub.report360.entity;

import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;
import io.jmix.data.DdlGeneration;
import kz.eub.report360.entity.key.CredregCompKey;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.Table;
import java.time.LocalDate;

@DdlGeneration(value = DdlGeneration.DbScriptGenerationMode.DISABLED)
@JmixEntity
@Store(name = "dwhdb")
//@Store(name = "dwhdb")
@Table(name = "CREDREG", schema = "JMIX_USER")
@Entity(name = "r360_Credreg")
public class Credreg {
    @EmbeddedId
    private CredregCompKey id;

    @Column(name = "\"ACCRUED_FINES_PENALTIES\"")
    private Long accruedFinesPenalties;

    @Column(name = "\"ACCRUED_FINES_PENALTIES_CUR\"")
    private Long accruedFinesPenaltiesCur;

    @Column(name = "\"ACTUAL_ISSUE_DATE\"")
    private LocalDate actualIssueDate;

    @Column(name = "\"ACTUAL_RECEIVED_PAYMENT\"")
    private Double actualReceivedPayment;
    @Column(name = "\"CONTRACT_S_ID\"")
    private Long contractS;

    @Column(name = "\"CR_FL_CLASSIFICATION\"", length = 300)
    private String crFlClassification;

    @Column(name = "\"CR_FL_CLASSIFICATION_NB_ID\"", length = 300)
    private String crFlClassificationNb;

    @Column(name = "\"CR_FL_PROV_BAL_ACC_MSFO_NB_ID\"", length = 300)
    private String crFlProvBalAccMsfoNb;

    @Column(name = "\"CR_FL_PROV_BAL_ACC_MSFO_S_ID\"", length = 300)
    private String crFlProvBalAccMsfoS;

    @Column(name = "\"CR_FL_PROV_BAL_ACC_NB_ID\"", length = 300)
    private String crFlProvBalAccNb;

    @Column(name = "\"CR_FL_PROV_BAL_ACC_S_ID\"", length = 300)
    private String crFlProvBalAccS;

    @Column(name = "\"CR_FL_PROV_VAL\"")
    private Long crFlProvVal;

    @Column(name = "\"CR_FL_PROV_VAL_MSFO\"")
    private Double crFlProvValMsfo;

    @Column(name = "\"IS_IMPAIRED\"", length = 10)
    private String isImpaired;

    @Column(name = "\"IS_RESTRUCTURED\"", length = 1)
    private String isRestructured;

    @Column(name = "\"MATURITY_DATE\"")
    private LocalDate maturityDate;

    @Column(name = "\"OPERATION_DATE\"")
    private LocalDate operationDate;

    @Column(name = "\"PORTF_FLOW_BAL_ACCOUNT_NB_ID\"", length = 300)
    private String portfFlowBalAccountNb;

    @Column(name = "\"PORTF_FLOW_BAL_ACCOUNT_S_ID\"", length = 300)
    private String portfFlowBalAccountS;

    @Column(name = "\"PORTF_FLOW_MSFO_BAL_ACC_NB_ID\"", length = 300)
    private String portfFlowMsfoBalAccNb;

    @Column(name = "\"PORTF_FLOW_MSFO_BAL_ACC_S_ID\"", length = 300)
    private String portfFlowMsfoBalAccS;

    @Column(name = "\"PRIMARY_CONTRACT_NO\"", length = 300)
    private String primaryContractNo;

    @Column(name = "\"PROLONGATION_DATE\"")
    private LocalDate prolongationDate;

    @Column(name = "\"PROVISION_RATE\"")
    private Double provisionRate;

    @Column(name = "\"REF_REMNS_LIMIT_ACCOUNT_NO\"", length = 300)
    private String refRemnsLimitAccountNo;

    @Column(name = "\"REF_REMNS_LIMIT_ACCOUNT_NO_NB\"", length = 300)
    private String refRemnsLimitAccountNoNb;

    @Column(name = "\"REMNS_CORRECTION_BAL_ACC_NB_ID\"", length = 300)
    private String remnsCorrectionBalAccNb;

    @Column(name = "\"REMNS_CORRECTION_BAL_ACC_S_ID\"", length = 300)
    private String remnsCorrectionBalAccS;

    @Column(name = "\"REMNS_CORRECTION_VAL\"")
    private Long remnsCorrectionVal;

    @Column(name = "\"REMNS_CORRECTION_VAL_CUR\"")
    private Long remnsCorrectionValCur;

    @Column(name = "\"REMNS_DEB_CURR_BALACC_NB_ID\"")
    private String remnsDebCurrBalaccNb;

    @Column(name = "\"REMNS_DEB_CURR_BALACC_S_ID\"")
    private String remnsDebCurrBalaccS;

    @Column(name = "\"REMNS_DEB_CURRENT_VAL\"")
    private Double remnsDebCurrentVal;

    @Column(name = "\"REMNS_DEB_CURRENT_VAL_CUR\"")
    private Double remnsDebCurrentValCur;

    @Column(name = "\"REMNS_DEB_PASTD_BALACC_NB_ID\"")
    private String remnsDebPastdBalaccNb;

    @Column(name = "\"REMNS_DEB_PASTD_BALACC_S_ID\"")
    private String remnsDebPastdBalaccS;

    @Column(name = "\"REMNS_DEB_PASTDUE_CLOSE_DATE\"")
    private LocalDate remnsDebPastdueCloseDate;

    @Column(name = "\"REMNS_DEB_PASTDUE_OPEN_DATE\"")
    private LocalDate remnsDebPastdueOpenDate;

    @Column(name = "\"REMNS_DEB_PASTDUE_VAL\"")
    private Double remnsDebPastdueVal;

    @Column(name = "\"REMNS_DEB_PASTDUE_VAL_CUR\"")
    private Double remnsDebPastdueValCur;

    @Column(name = "\"REMNS_DEB_WRITE_BALACC_NB_ID\"", length = 300)
    private String remnsDebWriteBalaccNb;

    @Column(name = "\"REMNS_DEB_WRITE_BALACC_S_ID\"", length = 300)
    private String remnsDebWriteBalaccS;

    @Column(name = "\"REMNS_DEB_WRITE_OFF_DATE\"")
    private LocalDate remnsDebWriteOffDate;

    @Column(name = "\"REMNS_DEB_WRITE_OFF_VAL\"")
    private Double remnsDebWriteOffVal;

    @Column(name = "\"REMNS_DEB_WRITE_OFF_VAL_CUR\"")
    private Double remnsDebWriteOffValCur;

    @Column(name = "\"REMNS_DEBT_FORGIVEN_VALUE\"")
    private Long remnsDebtForgivenValue;

    @Column(name = "\"REMNS_DEBT_FORGIVEN_VALUE_CUR\"")
    private Long remnsDebtForgivenValueCur;

    @Column(name = "\"REMNS_DEBT_WRITE_OFF_VAL\"")
    private Long remnsDebtWriteOffVal;

    @Column(name = "\"REMNS_DEBT_WRITE_OFF_VAL_CUR\"")
    private Long remnsDebtWriteOffValCur;

    @Column(name = "\"REMNS_DISC_BAL_ACC_NB_ID\"", length = 300)
    private String remnsDiscBalAccNb;

    @Column(name = "\"REMNS_DISC_BAL_ACC_NB_ID_ADD\"", length = 300)
    private String remnsDiscBalAccNbIdAdd;

    @Column(name = "\"REMNS_DISC_BAL_ACC_S_ID\"", length = 300)
    private String remnsDiscBalAccS;

    @Column(name = "\"REMNS_DISC_VALUE_VAL\"")
    private Long remnsDiscValueVal;

    @Column(name = "\"REMNS_DISC_VALUE_VAL_CUR\"")
    private Long remnsDiscValueValCur;

    @Column(name = "\"REMNS_DISCOUNT_ADD\"")
    private Long remnsDiscountAdd;

    @Column(name = "\"REMNS_DISCOUNT_VAL\"")
    private Double remnsDiscountVal;

    @Column(name = "\"REMNS_DISCOUNT_VAL_CUR\"")
    private Double remnsDiscountValCur;

    @Column(name = "\"REMNS_DISCOUNT_VAL_CUR_ADD\"")
    private Long remnsDiscountValCurAdd;

    @Column(name = "\"REMNS_INT_CURR_BALACC_NB_ID\"")
    private String remnsIntCurrBalaccNb;

    @Column(name = "\"REMNS_INT_CURR_BALACC_S_ID\"")
    private String remnsIntCurrBalaccS;

    @Column(name = "\"REMNS_INT_CURRENT_VAL\"")
    private Double remnsIntCurrentVal;

    @Column(name = "\"REMNS_INT_CURRENT_VAL_CUR\"")
    private Double remnsIntCurrentValCur;

    @Column(name = "\"REMNS_INT_FORGIVEN_VALUE\"")
    private Long remnsIntForgivenValue;

    @Column(name = "\"REMNS_INT_FORGIVEN_VALUE_CUR\"")
    private Long remnsIntForgivenValueCur;

    @Column(name = "\"REMNS_INT_PASTD_BALACC_NB_ID\"", length = 300)
    private String remnsIntPastdBalaccNb;

    @Column(name = "\"REMNS_INT_PASTD_BALACC_S_ID\"", length = 300)
    private String remnsIntPastdBalaccS;

    @Column(name = "\"REMNS_INT_PASTDUE_CLOSE_DATE\"")
    private LocalDate remnsIntPastdueCloseDate;

    @Column(name = "\"REMNS_INT_PASTDUE_OPEN_DATE\"")
    private LocalDate remnsIntPastdueOpenDate;

    @Column(name = "\"REMNS_INT_PASTDUE_VAL\"")
    private Double remnsIntPastdueVal;

    @Column(name = "\"REMNS_INT_PASTDUE_VAL_CUR\"")
    private Double remnsIntPastdueValCur;

    @Column(name = "\"REMNS_INT_WRITE_OFF_DATE\"")
    private LocalDate remnsIntWriteOffDate;

    @Column(name = "\"REMNS_INT_WRITE_OFF_VAL\"")
    private Double remnsIntWriteOffVal;

    @Column(name = "\"REMNS_INT_WRITE_OFF_VAL_CUR\"")
    private Double remnsIntWriteOffValCur;

    @Column(name = "\"REMNS_LIM_BAL_ACC_NB_ID\"", length = 300)
    private String remnsLimBalAccNb;

    @Column(name = "\"REMNS_LIM_BAL_ACC_S_ID\"", length = 300)
    private String remnsLimBalAccS;

    @Column(name = "\"REMNS_LIM_VAL\"")
    private Long remnsLimVal;

    @Column(name = "\"REMNS_LIM_VAL_CUR\"")
    private Long remnsLimValCur;

    @Column(name = "\"REMNS_PENALTY_FORGIVEN_VAL_CUR\"")
    private Long remnsPenaltyForgivenValCur;

    @Column(name = "\"REMNS_PENALTY_FORGIVEN_VALUE\"")
    private Long remnsPenaltyForgivenValue;

    @Column(name = "\"REMNS_PENALTY_VALUE\"")
    private Long remnsPenaltyValue;

    @Column(name = "\"REMNS_PENALTY_VALUE_CUR\"")
    private Long remnsPenaltyValueCur;

    @Column(name = "\"REMNS_PENALTY_WRITE_OFF\"")
    private Long remnsPenaltyWriteOff;

    @Column(name = "\"REMNS_PENALTY_WRITE_OFF_CUR\"")
    private Long remnsPenaltyWriteOffCur;

    @Column(name = "\"RESTRUCTURING_DATE\"")
    private LocalDate restructuringDate;

    @Column(name = "\"SOURCE_SYSTEM\"", length = 300)
    private String sourceSystem;

    @Column(name = "\"TURNOVER_DEB_AMOUNT\"")
    private Long turnoverDebAmount;

    @Column(name = "\"TURNOVER_DEB_AMOUNT_CUR\"")
    private Long turnoverDebAmountCur;

    @Column(name = "\"TURNOVER_INT_AMOUNT\"")
    private Long turnoverIntAmount;

    @Column(name = "\"TURNOVER_INT_AMOUNT_CUR\"")
    private Long turnoverIntAmountCur;

    @Column(name = "\"UPDATE_DATE\"")
    private LocalDate updateDate;

    @Column(name = "\"UPDATED_BY\"", length = 300)
    private String updatedBy;

    public void setRestructuringDate(LocalDate restructuringDate) {
        this.restructuringDate = restructuringDate;
    }

    public LocalDate getRestructuringDate() {
        return restructuringDate;
    }

    public void setActualIssueDate(LocalDate actualIssueDate) {
        this.actualIssueDate = actualIssueDate;
    }

    public LocalDate getActualIssueDate() {
        return actualIssueDate;
    }

    public void setUpdateDate(LocalDate updateDate) {
        this.updateDate = updateDate;
    }

    public LocalDate getUpdateDate() {
        return updateDate;
    }

    public void setProlongationDate(LocalDate prolongationDate) {
        this.prolongationDate = prolongationDate;
    }

    public LocalDate getProlongationDate() {
        return prolongationDate;
    }

    public void setMaturityDate(LocalDate maturityDate) {
        this.maturityDate = maturityDate;
    }

    public LocalDate getMaturityDate() {
        return maturityDate;
    }

    public void setRemnsIntWriteOffDate(LocalDate remnsIntWriteOffDate) {
        this.remnsIntWriteOffDate = remnsIntWriteOffDate;
    }

    public LocalDate getRemnsIntWriteOffDate() {
        return remnsIntWriteOffDate;
    }

    public void setRemnsDebWriteOffDate(LocalDate remnsDebWriteOffDate) {
        this.remnsDebWriteOffDate = remnsDebWriteOffDate;
    }

    public LocalDate getRemnsDebWriteOffDate() {
        return remnsDebWriteOffDate;
    }

    public void setRemnsIntPastdueCloseDate(LocalDate remnsIntPastdueCloseDate) {
        this.remnsIntPastdueCloseDate = remnsIntPastdueCloseDate;
    }

    public LocalDate getRemnsIntPastdueCloseDate() {
        return remnsIntPastdueCloseDate;
    }

    public void setRemnsIntPastdueOpenDate(LocalDate remnsIntPastdueOpenDate) {
        this.remnsIntPastdueOpenDate = remnsIntPastdueOpenDate;
    }

    public LocalDate getRemnsIntPastdueOpenDate() {
        return remnsIntPastdueOpenDate;
    }

    public void setRemnsDebPastdueOpenDate(LocalDate remnsDebPastdueOpenDate) {
        this.remnsDebPastdueOpenDate = remnsDebPastdueOpenDate;
    }

    public LocalDate getRemnsDebPastdueOpenDate() {
        return remnsDebPastdueOpenDate;
    }

    public void setOperationDate(LocalDate operationDate) {
        this.operationDate = operationDate;
    }

    public LocalDate getOperationDate() {
        return operationDate;
    }

    public void setRemnsDebPastdueCloseDate(LocalDate remnsDebPastdueCloseDate) {
        this.remnsDebPastdueCloseDate = remnsDebPastdueCloseDate;
    }

    public LocalDate getRemnsDebPastdueCloseDate() {
        return remnsDebPastdueCloseDate;
    }

    public void setTurnoverIntAmountCur(Long turnoverIntAmountCur) {
        this.turnoverIntAmountCur = turnoverIntAmountCur;
    }

    public Long getTurnoverIntAmountCur() {
        return turnoverIntAmountCur;
    }

    public void setTurnoverIntAmount(Long turnoverIntAmount) {
        this.turnoverIntAmount = turnoverIntAmount;
    }

    public Long getTurnoverIntAmount() {
        return turnoverIntAmount;
    }

    public void setRemnsIntCurrBalaccNb(String remnsIntCurrBalaccNb) {
        this.remnsIntCurrBalaccNb = remnsIntCurrBalaccNb;
    }

    public String getRemnsIntCurrBalaccNb() {
        return remnsIntCurrBalaccNb;
    }

    public void setRemnsIntCurrBalaccS(String remnsIntCurrBalaccS) {
        this.remnsIntCurrBalaccS = remnsIntCurrBalaccS;
    }

    public String getRemnsIntCurrBalaccS() {
        return remnsIntCurrBalaccS;
    }

    public void setRemnsDebPastdBalaccNb(String remnsDebPastdBalaccNb) {
        this.remnsDebPastdBalaccNb = remnsDebPastdBalaccNb;
    }

    public String getRemnsDebPastdBalaccNb() {
        return remnsDebPastdBalaccNb;
    }

    public void setRemnsDebPastdBalaccS(String remnsDebPastdBalaccS) {
        this.remnsDebPastdBalaccS = remnsDebPastdBalaccS;
    }

    public String getRemnsDebPastdBalaccS() {
        return remnsDebPastdBalaccS;
    }

    public void setRemnsDebCurrBalaccNb(String remnsDebCurrBalaccNb) {
        this.remnsDebCurrBalaccNb = remnsDebCurrBalaccNb;
    }

    public String getRemnsDebCurrBalaccNb() {
        return remnsDebCurrBalaccNb;
    }

    public void setRemnsDebCurrBalaccS(String remnsDebCurrBalaccS) {
        this.remnsDebCurrBalaccS = remnsDebCurrBalaccS;
    }

    public String getRemnsDebCurrBalaccS() {
        return remnsDebCurrBalaccS;
    }

    public void setCrFlProvValMsfo(Double crFlProvValMsfo) {
        this.crFlProvValMsfo = crFlProvValMsfo;
    }

    public Double getCrFlProvValMsfo() {
        return crFlProvValMsfo;
    }

    public void setActualReceivedPayment(Double actualReceivedPayment) {
        this.actualReceivedPayment = actualReceivedPayment;
    }

    public Double getActualReceivedPayment() {
        return actualReceivedPayment;
    }

    public void setProvisionRate(Double provisionRate) {
        this.provisionRate = provisionRate;
    }

    public Double getProvisionRate() {
        return provisionRate;
    }

    public void setRemnsDiscountValCur(Double remnsDiscountValCur) {
        this.remnsDiscountValCur = remnsDiscountValCur;
    }

    public Double getRemnsDiscountValCur() {
        return remnsDiscountValCur;
    }

    public void setRemnsDiscountVal(Double remnsDiscountVal) {
        this.remnsDiscountVal = remnsDiscountVal;
    }

    public Double getRemnsDiscountVal() {
        return remnsDiscountVal;
    }

    public void setRemnsIntWriteOffValCur(Double remnsIntWriteOffValCur) {
        this.remnsIntWriteOffValCur = remnsIntWriteOffValCur;
    }

    public Double getRemnsIntWriteOffValCur() {
        return remnsIntWriteOffValCur;
    }

    public void setRemnsIntWriteOffVal(Double remnsIntWriteOffVal) {
        this.remnsIntWriteOffVal = remnsIntWriteOffVal;
    }

    public Double getRemnsIntWriteOffVal() {
        return remnsIntWriteOffVal;
    }

    public void setRemnsIntPastdueValCur(Double remnsIntPastdueValCur) {
        this.remnsIntPastdueValCur = remnsIntPastdueValCur;
    }

    public Double getRemnsIntPastdueValCur() {
        return remnsIntPastdueValCur;
    }

    public void setRemnsIntPastdueVal(Double remnsIntPastdueVal) {
        this.remnsIntPastdueVal = remnsIntPastdueVal;
    }

    public Double getRemnsIntPastdueVal() {
        return remnsIntPastdueVal;
    }

    public void setRemnsIntCurrentValCur(Double remnsIntCurrentValCur) {
        this.remnsIntCurrentValCur = remnsIntCurrentValCur;
    }

    public Double getRemnsIntCurrentValCur() {
        return remnsIntCurrentValCur;
    }

    public void setRemnsIntCurrentVal(Double remnsIntCurrentVal) {
        this.remnsIntCurrentVal = remnsIntCurrentVal;
    }

    public Double getRemnsIntCurrentVal() {
        return remnsIntCurrentVal;
    }

    public void setRemnsDebWriteOffValCur(Double remnsDebWriteOffValCur) {
        this.remnsDebWriteOffValCur = remnsDebWriteOffValCur;
    }

    public Double getRemnsDebWriteOffValCur() {
        return remnsDebWriteOffValCur;
    }

    public void setRemnsDebWriteOffVal(Double remnsDebWriteOffVal) {
        this.remnsDebWriteOffVal = remnsDebWriteOffVal;
    }

    public Double getRemnsDebWriteOffVal() {
        return remnsDebWriteOffVal;
    }

    public void setRemnsDebPastdueValCur(Double remnsDebPastdueValCur) {
        this.remnsDebPastdueValCur = remnsDebPastdueValCur;
    }

    public Double getRemnsDebPastdueValCur() {
        return remnsDebPastdueValCur;
    }

    public void setRemnsDebPastdueVal(Double remnsDebPastdueVal) {
        this.remnsDebPastdueVal = remnsDebPastdueVal;
    }

    public Double getRemnsDebPastdueVal() {
        return remnsDebPastdueVal;
    }

    public void setRemnsDebCurrentValCur(Double remnsDebCurrentValCur) {
        this.remnsDebCurrentValCur = remnsDebCurrentValCur;
    }

    public Double getRemnsDebCurrentValCur() {
        return remnsDebCurrentValCur;
    }

    public void setRemnsDebCurrentVal(Double remnsDebCurrentVal) {
        this.remnsDebCurrentVal = remnsDebCurrentVal;
    }

    public Double getRemnsDebCurrentVal() {
        return remnsDebCurrentVal;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Long getTurnoverDebAmountCur() {
        return turnoverDebAmountCur;
    }

    public void setTurnoverDebAmountCur(Long turnoverDebAmountCur) {
        this.turnoverDebAmountCur = turnoverDebAmountCur;
    }

    public Long getTurnoverDebAmount() {
        return turnoverDebAmount;
    }

    public void setTurnoverDebAmount(Long turnoverDebAmount) {
        this.turnoverDebAmount = turnoverDebAmount;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public Long getRemnsPenaltyWriteOffCur() {
        return remnsPenaltyWriteOffCur;
    }

    public void setRemnsPenaltyWriteOffCur(Long remnsPenaltyWriteOffCur) {
        this.remnsPenaltyWriteOffCur = remnsPenaltyWriteOffCur;
    }

    public Long getRemnsPenaltyWriteOff() {
        return remnsPenaltyWriteOff;
    }

    public void setRemnsPenaltyWriteOff(Long remnsPenaltyWriteOff) {
        this.remnsPenaltyWriteOff = remnsPenaltyWriteOff;
    }

    public Long getRemnsPenaltyValueCur() {
        return remnsPenaltyValueCur;
    }

    public void setRemnsPenaltyValueCur(Long remnsPenaltyValueCur) {
        this.remnsPenaltyValueCur = remnsPenaltyValueCur;
    }

    public Long getRemnsPenaltyValue() {
        return remnsPenaltyValue;
    }

    public void setRemnsPenaltyValue(Long remnsPenaltyValue) {
        this.remnsPenaltyValue = remnsPenaltyValue;
    }

    public Long getRemnsPenaltyForgivenValue() {
        return remnsPenaltyForgivenValue;
    }

    public void setRemnsPenaltyForgivenValue(Long remnsPenaltyForgivenValue) {
        this.remnsPenaltyForgivenValue = remnsPenaltyForgivenValue;
    }

    public Long getRemnsPenaltyForgivenValCur() {
        return remnsPenaltyForgivenValCur;
    }

    public void setRemnsPenaltyForgivenValCur(Long remnsPenaltyForgivenValCur) {
        this.remnsPenaltyForgivenValCur = remnsPenaltyForgivenValCur;
    }

    public Long getRemnsLimValCur() {
        return remnsLimValCur;
    }

    public void setRemnsLimValCur(Long remnsLimValCur) {
        this.remnsLimValCur = remnsLimValCur;
    }

    public Long getRemnsLimVal() {
        return remnsLimVal;
    }

    public void setRemnsLimVal(Long remnsLimVal) {
        this.remnsLimVal = remnsLimVal;
    }

    public String getRemnsLimBalAccS() {
        return remnsLimBalAccS;
    }

    public void setRemnsLimBalAccS(String remnsLimBalAccS) {
        this.remnsLimBalAccS = remnsLimBalAccS;
    }

    public String getRemnsLimBalAccNb() {
        return remnsLimBalAccNb;
    }

    public void setRemnsLimBalAccNb(String remnsLimBalAccNb) {
        this.remnsLimBalAccNb = remnsLimBalAccNb;
    }

    public String getRemnsIntPastdBalaccS() {
        return remnsIntPastdBalaccS;
    }

    public void setRemnsIntPastdBalaccS(String remnsIntPastdBalaccS) {
        this.remnsIntPastdBalaccS = remnsIntPastdBalaccS;
    }

    public String getRemnsIntPastdBalaccNb() {
        return remnsIntPastdBalaccNb;
    }

    public void setRemnsIntPastdBalaccNb(String remnsIntPastdBalaccNb) {
        this.remnsIntPastdBalaccNb = remnsIntPastdBalaccNb;
    }

    public Long getRemnsIntForgivenValueCur() {
        return remnsIntForgivenValueCur;
    }

    public void setRemnsIntForgivenValueCur(Long remnsIntForgivenValueCur) {
        this.remnsIntForgivenValueCur = remnsIntForgivenValueCur;
    }

    public Long getRemnsIntForgivenValue() {
        return remnsIntForgivenValue;
    }

    public void setRemnsIntForgivenValue(Long remnsIntForgivenValue) {
        this.remnsIntForgivenValue = remnsIntForgivenValue;
    }

    public Long getRemnsDiscountValCurAdd() {
        return remnsDiscountValCurAdd;
    }

    public void setRemnsDiscountValCurAdd(Long remnsDiscountValCurAdd) {
        this.remnsDiscountValCurAdd = remnsDiscountValCurAdd;
    }

    public Long getRemnsDiscountAdd() {
        return remnsDiscountAdd;
    }

    public void setRemnsDiscountAdd(Long remnsDiscountAdd) {
        this.remnsDiscountAdd = remnsDiscountAdd;
    }

    public Long getRemnsDiscValueValCur() {
        return remnsDiscValueValCur;
    }

    public void setRemnsDiscValueValCur(Long remnsDiscValueValCur) {
        this.remnsDiscValueValCur = remnsDiscValueValCur;
    }

    public Long getRemnsDiscValueVal() {
        return remnsDiscValueVal;
    }

    public void setRemnsDiscValueVal(Long remnsDiscValueVal) {
        this.remnsDiscValueVal = remnsDiscValueVal;
    }

    public String getRemnsDiscBalAccS() {
        return remnsDiscBalAccS;
    }

    public void setRemnsDiscBalAccS(String remnsDiscBalAccS) {
        this.remnsDiscBalAccS = remnsDiscBalAccS;
    }

    public String getRemnsDiscBalAccNbIdAdd() {
        return remnsDiscBalAccNbIdAdd;
    }

    public void setRemnsDiscBalAccNbIdAdd(String remnsDiscBalAccNbIdAdd) {
        this.remnsDiscBalAccNbIdAdd = remnsDiscBalAccNbIdAdd;
    }

    public String getRemnsDiscBalAccNb() {
        return remnsDiscBalAccNb;
    }

    public void setRemnsDiscBalAccNb(String remnsDiscBalAccNb) {
        this.remnsDiscBalAccNb = remnsDiscBalAccNb;
    }

    public Long getRemnsDebtWriteOffValCur() {
        return remnsDebtWriteOffValCur;
    }

    public void setRemnsDebtWriteOffValCur(Long remnsDebtWriteOffValCur) {
        this.remnsDebtWriteOffValCur = remnsDebtWriteOffValCur;
    }

    public Long getRemnsDebtWriteOffVal() {
        return remnsDebtWriteOffVal;
    }

    public void setRemnsDebtWriteOffVal(Long remnsDebtWriteOffVal) {
        this.remnsDebtWriteOffVal = remnsDebtWriteOffVal;
    }

    public Long getRemnsDebtForgivenValueCur() {
        return remnsDebtForgivenValueCur;
    }

    public void setRemnsDebtForgivenValueCur(Long remnsDebtForgivenValueCur) {
        this.remnsDebtForgivenValueCur = remnsDebtForgivenValueCur;
    }

    public Long getRemnsDebtForgivenValue() {
        return remnsDebtForgivenValue;
    }

    public void setRemnsDebtForgivenValue(Long remnsDebtForgivenValue) {
        this.remnsDebtForgivenValue = remnsDebtForgivenValue;
    }

    public String getRemnsDebWriteBalaccS() {
        return remnsDebWriteBalaccS;
    }

    public void setRemnsDebWriteBalaccS(String remnsDebWriteBalaccS) {
        this.remnsDebWriteBalaccS = remnsDebWriteBalaccS;
    }

    public String getRemnsDebWriteBalaccNb() {
        return remnsDebWriteBalaccNb;
    }

    public void setRemnsDebWriteBalaccNb(String remnsDebWriteBalaccNb) {
        this.remnsDebWriteBalaccNb = remnsDebWriteBalaccNb;
    }

    public Long getRemnsCorrectionValCur() {
        return remnsCorrectionValCur;
    }

    public void setRemnsCorrectionValCur(Long remnsCorrectionValCur) {
        this.remnsCorrectionValCur = remnsCorrectionValCur;
    }

    public Long getRemnsCorrectionVal() {
        return remnsCorrectionVal;
    }

    public void setRemnsCorrectionVal(Long remnsCorrectionVal) {
        this.remnsCorrectionVal = remnsCorrectionVal;
    }

    public String getRemnsCorrectionBalAccS() {
        return remnsCorrectionBalAccS;
    }

    public void setRemnsCorrectionBalAccS(String remnsCorrectionBalAccS) {
        this.remnsCorrectionBalAccS = remnsCorrectionBalAccS;
    }

    public String getRemnsCorrectionBalAccNb() {
        return remnsCorrectionBalAccNb;
    }

    public void setRemnsCorrectionBalAccNb(String remnsCorrectionBalAccNb) {
        this.remnsCorrectionBalAccNb = remnsCorrectionBalAccNb;
    }

    public String getRefRemnsLimitAccountNoNb() {
        return refRemnsLimitAccountNoNb;
    }

    public void setRefRemnsLimitAccountNoNb(String refRemnsLimitAccountNoNb) {
        this.refRemnsLimitAccountNoNb = refRemnsLimitAccountNoNb;
    }

    public String getRefRemnsLimitAccountNo() {
        return refRemnsLimitAccountNo;
    }

    public void setRefRemnsLimitAccountNo(String refRemnsLimitAccountNo) {
        this.refRemnsLimitAccountNo = refRemnsLimitAccountNo;
    }

    public String getPrimaryContractNo() {
        return primaryContractNo;
    }

    public void setPrimaryContractNo(String primaryContractNo) {
        this.primaryContractNo = primaryContractNo;
    }

    public String getPortfFlowMsfoBalAccS() {
        return portfFlowMsfoBalAccS;
    }

    public void setPortfFlowMsfoBalAccS(String portfFlowMsfoBalAccS) {
        this.portfFlowMsfoBalAccS = portfFlowMsfoBalAccS;
    }

    public String getPortfFlowMsfoBalAccNb() {
        return portfFlowMsfoBalAccNb;
    }

    public void setPortfFlowMsfoBalAccNb(String portfFlowMsfoBalAccNb) {
        this.portfFlowMsfoBalAccNb = portfFlowMsfoBalAccNb;
    }

    public String getPortfFlowBalAccountS() {
        return portfFlowBalAccountS;
    }

    public void setPortfFlowBalAccountS(String portfFlowBalAccountS) {
        this.portfFlowBalAccountS = portfFlowBalAccountS;
    }

    public String getPortfFlowBalAccountNb() {
        return portfFlowBalAccountNb;
    }

    public void setPortfFlowBalAccountNb(String portfFlowBalAccountNb) {
        this.portfFlowBalAccountNb = portfFlowBalAccountNb;
    }

    public String getIsRestructured() {
        return isRestructured;
    }

    public void setIsRestructured(String isRestructured) {
        this.isRestructured = isRestructured;
    }

    public String getIsImpaired() {
        return isImpaired;
    }

    public void setIsImpaired(String isImpaired) {
        this.isImpaired = isImpaired;
    }

    public Long getCrFlProvVal() {
        return crFlProvVal;
    }

    public void setCrFlProvVal(Long crFlProvVal) {
        this.crFlProvVal = crFlProvVal;
    }

    public String getCrFlProvBalAccS() {
        return crFlProvBalAccS;
    }

    public void setCrFlProvBalAccS(String crFlProvBalAccS) {
        this.crFlProvBalAccS = crFlProvBalAccS;
    }

    public String getCrFlProvBalAccNb() {
        return crFlProvBalAccNb;
    }

    public void setCrFlProvBalAccNb(String crFlProvBalAccNb) {
        this.crFlProvBalAccNb = crFlProvBalAccNb;
    }

    public String getCrFlProvBalAccMsfoS() {
        return crFlProvBalAccMsfoS;
    }

    public void setCrFlProvBalAccMsfoS(String crFlProvBalAccMsfoS) {
        this.crFlProvBalAccMsfoS = crFlProvBalAccMsfoS;
    }

    public String getCrFlProvBalAccMsfoNb() {
        return crFlProvBalAccMsfoNb;
    }

    public void setCrFlProvBalAccMsfoNb(String crFlProvBalAccMsfoNb) {
        this.crFlProvBalAccMsfoNb = crFlProvBalAccMsfoNb;
    }

    public String getCrFlClassificationNb() {
        return crFlClassificationNb;
    }

    public void setCrFlClassificationNb(String crFlClassificationNb) {
        this.crFlClassificationNb = crFlClassificationNb;
    }

    public String getCrFlClassification() {
        return crFlClassification;
    }

    public void setCrFlClassification(String crFlClassification) {
        this.crFlClassification = crFlClassification;
    }

    public Long getContractS() {
        return contractS;
    }

    public void setContractS(Long contractS) {
        this.contractS = contractS;
    }

    public Long getAccruedFinesPenaltiesCur() {
        return accruedFinesPenaltiesCur;
    }

    public void setAccruedFinesPenaltiesCur(Long accruedFinesPenaltiesCur) {
        this.accruedFinesPenaltiesCur = accruedFinesPenaltiesCur;
    }

    public Long getAccruedFinesPenalties() {
        return accruedFinesPenalties;
    }

    public void setAccruedFinesPenalties(Long accruedFinesPenalties) {
        this.accruedFinesPenalties = accruedFinesPenalties;
    }

    public CredregCompKey getId() {
        return id;
    }

    public void setId(CredregCompKey id) {
        this.id = id;
    }
}