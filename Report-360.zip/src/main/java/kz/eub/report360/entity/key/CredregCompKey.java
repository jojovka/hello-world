package kz.eub.report360.entity.key;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.util.ProxyUtils;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@JmixEntity(name = "r360_CredregCompKey")
@Embeddable
public class CredregCompKey implements Serializable {
    @Column(name = "\"EF_BATCHES_INT_ID\"")
    private Long efBatchesInt;
    @Column(name = "\"EF_CONTRACT_ID\"")
    private Long efContract;

    public Long getEfContract() {
        return efContract;
    }

    public void setEfContract(Long efContract) {
        this.efContract = efContract;
    }

    public Long getEfBatchesInt() {
        return efBatchesInt;
    }

    public void setEfBatchesInt(Long efBatchesInt) {
        this.efBatchesInt = efBatchesInt;
    }

    @Override
    public int hashCode() {
        return Objects.hash(efBatchesInt, efContract);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || ProxyUtils.getUserClass(this) != ProxyUtils.getUserClass(o)) return false;
        CredregCompKey entity = (CredregCompKey) o;
        return Objects.equals(this.efBatchesInt, entity.efBatchesInt) &&
                Objects.equals(this.efContract, entity.efContract);
    }
}