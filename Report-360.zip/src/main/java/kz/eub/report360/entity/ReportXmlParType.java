package kz.eub.report360.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum ReportXmlParType implements EnumClass<String> {

    STRING("STRING"),
    DATE("DATE");

    private String id;

    ReportXmlParType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static ReportXmlParType fromId(String id) {
        for (ReportXmlParType at : ReportXmlParType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}