package kz.eub.report360.entity;

import io.jmix.core.FileRef;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import java.util.Date;

@DiscriminatorValue("EMPLOYEE")
@Table(name = "R360_EMPLOYEE", indexes = {
        @Index(name = "IDX_R360_EMPLOYEE_SUPERVISOR", columnList = "SUPERVISOR_ID"),
        @Index(name = "IDX_R360_EMPLOYEE_LEADER", columnList = "LEADER_ID"),
        @Index(name = "IDX_R360_EMPLOYEE_ORG_UNIT", columnList = "ORG_UNIT_ID"),
        @Index(name = "IDX_R360_EMPLOYEE_DEPARTMENT", columnList = "DEPARTMENT_ID"),
        @Index(name = "IDX_R360_EMPLOYEE_GROUP_TYPE", columnList = "GROUP_TYPE_ID")
})
@JmixEntity
@Entity(name = "r360_Employee")
@PrimaryKeyJoinColumn(name = "id")
public class Employee extends User implements Comparable<Employee> {
    @Column(name = "IIN", length = 60)
    private String iin;

    @JoinColumn(name = "DEPARTMENT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictDepartment department;

    @JoinColumn(name = "ORG_UNIT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictDepartment orgUnit;

    @Column(name = "HIRE_DATE")
    @Temporal(TemporalType.DATE)
    private Date hireDate;

    @Column(name = "START_DATE")
    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Column(name = "END_DATE")
    @Temporal(TemporalType.DATE)
    private Date endDate;

    @Column(name = "BIRTH_DATE")
    @Temporal(TemporalType.DATE)
    private Date birthDate;

    @JoinColumn(name = "POSITION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictPosition position;

    @JoinColumn(name = "SUPERVISOR_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Employee supervisor;

    @JoinColumn(name = "LEADER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Employee leader;

    @Column(name = "GENDER")
    private String gender;

    @Column(name = "GRADE")
    private String grade;

    @Column(name = "PHOTO", length = 1024)
    private FileRef photo;

    @Column(name = "COMMENT_")
    private String comment;

    @JoinColumn(name = "GROUP_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private EmployeeGroupType groupType;

    @Column(name = "PAYROLL_NUMBER", length = 24)
    private String payrollNumber;

    public String getPayrollNumber() {
        return payrollNumber;
    }

    public void setPayrollNumber(String payrollNumber) {
        this.payrollNumber = payrollNumber;
    }

    public EmployeeGroupType getGroupType() {
        return groupType;
    }

    public void setGroupType(EmployeeGroupType groupType) {
        this.groupType = groupType;
    }

    public void setGender(EGender gender) {
        this.gender = gender == null ? null : gender.getId();
    }

    public EGender getGender() {
        return gender == null ? null : EGender.fromId(gender);
    }

    public Employee getLeader() {
        return leader;
    }

    public void setLeader(Employee leader) {
        this.leader = leader;
    }

    public Employee getSupervisor() {
        return supervisor;
    }

    public void setSupervisor(Employee supervisor) {
        this.supervisor = supervisor;
    }

    public DictPosition getPosition() {
        return position;
    }

    public void setPosition(DictPosition position) {
        this.position = position;
    }

    public DictDepartment getOrgUnit() {
        return orgUnit;
    }

    public void setOrgUnit(DictDepartment orgUnit) {
        this.orgUnit = orgUnit;
    }

    public DictDepartment getDepartment() {
        return department;
    }

    public void setDepartment(DictDepartment department) {
        this.department = department;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public FileRef getPhoto() {
        return photo;
    }

    public void setPhoto(FileRef photo) {
        this.photo = photo;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getHireDate() {
        return hireDate;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    public String getIin() {
        return iin;
    }

    public void setIin(String iin) {
        this.iin = iin;
    }

    @Override
    public int compareTo(@NotNull Employee e2) {
        if (fullName == null) {
            if (e2.getFullName() != null)
                return 1;
            else
                return 0;
        }
        if (e2.getFullName() == null) return -1;
        return fullName.compareTo(e2.getFullName());
    }
}