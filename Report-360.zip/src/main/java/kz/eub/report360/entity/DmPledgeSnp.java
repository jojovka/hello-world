package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "dm_pledge_snp", schema = "dwh_risk", indexes = {
        @Index(name = "IDX_DPS_SOURCE_UUID", columnList = "DPS_SOURCE_UUID")
})
@Entity(name = "r360_DmPledgeSnp")
public class DmPledgeSnp {
    @JmixGeneratedValue
    @Column(name = "DPS_UUID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "DPS_ID")
    private Long dpsId;

    @Column(name = "DPS_AUDIT_ID")
    private Long dpsAuditId;

    @Column(name = "\"dps$change_date\"")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dpsChangeDate;

    @Column(name = "DPS_REPORT_DATE")
    @Temporal(TemporalType.DATE)
    private Date dpsReportDate;

    @JoinColumn(name = "DPS_SOURCE_UUID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictSources dpsSourceUuid;

    @Column(name = "DPS_GID")
    private Long dpsGid;

    @Column(name = "DPS_DOG_NUM")
    private String dpsDogNum;

    @Column(name = "DPS_CURR_CODE", length = 10)
    private String dpsCurrCode;

    @Column(name = "DPS_CLI_NAME")
    private String dpsCliName;

    @Column(name = "DPS_CLI_IIN_BIN")
    private String dpsCliIinBin;

    @Column(name = "DPS_DPRT_NAME")
    private String dpsDprtName;

    @Column(name = "DPS_DO_GID")
    private Long dpsDoGid;

    @Column(name = "DPS_DO_DOG_NUM")
    private String dpsDoDogNum;

    @Column(name = "DPS_DO_DATE")
    @Temporal(TemporalType.DATE)
    private Date dpsDoDate;

    @Column(name = "DPS_DO_CURR_CODE", length = 10)
    private String dpsDoCurrCode;

    @Column(name = "DPS_PLG_CLI_NAME")
    private String dpsPlgCliName;

    @Column(name = "DPS_PLG_CLI_IIN_BIN")
    private String dpsPlgCliIinBin;

    @Column(name = "DPS_PLG_TYPE")
    private String dpsPlgType;

    @Column(name = "DPS_PLG_CATEG")
    private String dpsPlgCateg;

    @Column(name = "DPS_DATE_NOK")
    @Temporal(TemporalType.DATE)
    private Date dpsDateNok;

    @Column(name = "DPS_SUM_CUR", precision = 19, scale = 2)
    private BigDecimal dpsSumCur;

    @Column(name = "DPS_SUM_KZT", precision = 19, scale = 2)
    private BigDecimal dpsSumKzt;

    @Column(name = "DPS_DATE_MON")
    @Temporal(TemporalType.DATE)
    private Date dpsDateMon;

    @Column(name = "DPS_SUM_MAR_CUR", precision = 19, scale = 2)
    private BigDecimal dpsSumMarCur;

    @Column(name = "DPS_SUM_MAR_KZT", precision = 19, scale = 2)
    private BigDecimal dpsSumMarKzt;

    @Column(name = "DPS_SUM_ALC", precision = 19, scale = 2)
    private BigDecimal dpsSumAlc;

    @Column(name = "DPS_PROP_PERC", precision = 19, scale = 2)
    private BigDecimal dpsPropPerc;

    @Column(name = "DPS_DO_STATE")
    private String dpsDoState;

    @Column(name = "DPS_STATE")
    private String dpsState;

    public String getDpsDoState() {
        return dpsDoState;
    }

    public void setDpsDoState(String dpsDoState) {
        this.dpsDoState = dpsDoState;
    }

    public String getDpsState() {
        return dpsState;
    }

    public void setDpsState(String dpsState) {
        this.dpsState = dpsState;
    }

    public BigDecimal getDpsPropPerc() {
        return dpsPropPerc;
    }

    public void setDpsPropPerc(BigDecimal dpsPropPerc) {
        this.dpsPropPerc = dpsPropPerc;
    }

    public BigDecimal getDpsSumAlc() {
        return dpsSumAlc;
    }

    public void setDpsSumAlc(BigDecimal dpsSumAlc) {
        this.dpsSumAlc = dpsSumAlc;
    }

    public BigDecimal getDpsSumMarKzt() {
        return dpsSumMarKzt;
    }

    public void setDpsSumMarKzt(BigDecimal dpsSumMarKzt) {
        this.dpsSumMarKzt = dpsSumMarKzt;
    }

    public BigDecimal getDpsSumMarCur() {
        return dpsSumMarCur;
    }

    public void setDpsSumMarCur(BigDecimal dpsSumMarCur) {
        this.dpsSumMarCur = dpsSumMarCur;
    }

    public Date getDpsDateMon() {
        return dpsDateMon;
    }

    public void setDpsDateMon(Date dpsDateMon) {
        this.dpsDateMon = dpsDateMon;
    }

    public BigDecimal getDpsSumKzt() {
        return dpsSumKzt;
    }

    public void setDpsSumKzt(BigDecimal dpsSumKzt) {
        this.dpsSumKzt = dpsSumKzt;
    }

    public BigDecimal getDpsSumCur() {
        return dpsSumCur;
    }

    public void setDpsSumCur(BigDecimal dpsSumCur) {
        this.dpsSumCur = dpsSumCur;
    }

    public Date getDpsDateNok() {
        return dpsDateNok;
    }

    public void setDpsDateNok(Date dpsDateNok) {
        this.dpsDateNok = dpsDateNok;
    }

    public String getDpsPlgCateg() {
        return dpsPlgCateg;
    }

    public void setDpsPlgCateg(String dpsPlgCateg) {
        this.dpsPlgCateg = dpsPlgCateg;
    }

    public String getDpsPlgType() {
        return dpsPlgType;
    }

    public void setDpsPlgType(String dpsPlgType) {
        this.dpsPlgType = dpsPlgType;
    }

    public String getDpsPlgCliIinBin() {
        return dpsPlgCliIinBin;
    }

    public void setDpsPlgCliIinBin(String dpsPlgCliIinBin) {
        this.dpsPlgCliIinBin = dpsPlgCliIinBin;
    }

    public String getDpsPlgCliName() {
        return dpsPlgCliName;
    }

    public void setDpsPlgCliName(String dpsPlgCliName) {
        this.dpsPlgCliName = dpsPlgCliName;
    }

    public String getDpsDoCurrCode() {
        return dpsDoCurrCode;
    }

    public void setDpsDoCurrCode(String dpsDoCurrCode) {
        this.dpsDoCurrCode = dpsDoCurrCode;
    }

    public Date getDpsDoDate() {
        return dpsDoDate;
    }

    public void setDpsDoDate(Date dpsDoDate) {
        this.dpsDoDate = dpsDoDate;
    }

    public String getDpsDoDogNum() {
        return dpsDoDogNum;
    }

    public void setDpsDoDogNum(String dpsDoDogNum) {
        this.dpsDoDogNum = dpsDoDogNum;
    }

    public Long getDpsDoGid() {
        return dpsDoGid;
    }

    public void setDpsDoGid(Long dpsDoGid) {
        this.dpsDoGid = dpsDoGid;
    }

    public String getDpsDprtName() {
        return dpsDprtName;
    }

    public void setDpsDprtName(String dpsDprtName) {
        this.dpsDprtName = dpsDprtName;
    }

    public String getDpsCliIinBin() {
        return dpsCliIinBin;
    }

    public void setDpsCliIinBin(String dpsCliIinBin) {
        this.dpsCliIinBin = dpsCliIinBin;
    }

    public String getDpsCliName() {
        return dpsCliName;
    }

    public void setDpsCliName(String dpsCliName) {
        this.dpsCliName = dpsCliName;
    }

    public String getDpsCurrCode() {
        return dpsCurrCode;
    }

    public void setDpsCurrCode(String dpsCurrCode) {
        this.dpsCurrCode = dpsCurrCode;
    }

    public String getDpsDogNum() {
        return dpsDogNum;
    }

    public void setDpsDogNum(String dpsDogNum) {
        this.dpsDogNum = dpsDogNum;
    }

    public Long getDpsGid() {
        return dpsGid;
    }

    public void setDpsGid(Long dpsGid) {
        this.dpsGid = dpsGid;
    }

    public DictSources getDpsSourceUuid() {
        return dpsSourceUuid;
    }

    public void setDpsSourceUuid(DictSources dpsSourceUuid) {
        this.dpsSourceUuid = dpsSourceUuid;
    }

    public Date getDpsReportDate() {
        return dpsReportDate;
    }

    public void setDpsReportDate(Date dpsReportDate) {
        this.dpsReportDate = dpsReportDate;
    }

    public Date getDpsChangeDate() {
        return dpsChangeDate;
    }

    public void setDpsChangeDate(Date dpsChangeDate) {
        this.dpsChangeDate = dpsChangeDate;
    }

    public Long getDpsAuditId() {
        return dpsAuditId;
    }

    public void setDpsAuditId(Long dpsAuditId) {
        this.dpsAuditId = dpsAuditId;
    }

    public Long getDpsId() {
        return dpsId;
    }

    public void setDpsId(Long dpsId) {
        this.dpsId = dpsId;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}