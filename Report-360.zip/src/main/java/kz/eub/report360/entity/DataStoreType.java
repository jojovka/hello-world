package kz.eub.report360.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum DataStoreType implements EnumClass<String> {

    CDB("CDB"),
    DWHPROD("DWHPROD"),
    DWHDB("DWHDB"),
    SAP("SAP"),
    JIRA("JIRA");

    private String id;

    DataStoreType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static DataStoreType fromId(String id) {
        for (DataStoreType at : DataStoreType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}