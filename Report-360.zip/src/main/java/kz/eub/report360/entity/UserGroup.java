package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "R360_USER_GROUP")
@Entity(name = "r360_UserGroup")
public class UserGroup {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @InstanceName
    @Column(name = "NAME")
    private String name;

    @Column(name = "CODE", nullable = false)
    @NotNull
    private String code;

    @JoinTable(name = "R360_USER_GROUP_USER_LINK",
            joinColumns = @JoinColumn(name = "USER_GROUP_ID", referencedColumnName = "ID"),
            inverseJoinColumns = @JoinColumn(name = "USER_ID", referencedColumnName = "ID"))
    @ManyToMany
    private List<User> users;

    @JoinTable(name = "R360_USER_GROUP_DICT_DEPARTMENT_LINK",
            joinColumns = @JoinColumn(name = "USER_GROUP_ID", referencedColumnName = "ID"),
            inverseJoinColumns = @JoinColumn(name = "DICT_DEPARTMENT_ID", referencedColumnName = "ID"))
    @ManyToMany
    private List<DictDepartment> departments;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setDepartments(List<DictDepartment> departments) {
        this.departments = departments;
    }

    public List<DictDepartment> getDepartments() {
        return departments;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    public List<User> getUsers() {
        return users;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}