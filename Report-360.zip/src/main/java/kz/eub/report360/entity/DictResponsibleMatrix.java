package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "dict_responsible_matrix", schema = "dwh_dq")
@Entity(name = "r360_DictResponsibleMatrix")
public class DictResponsibleMatrix {
    @JmixGeneratedValue
    @Column(name = "drm_uuid", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "drm_errgr_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictErrorGroup drmErrorGroup;

    @JoinColumn(name = "drm_errsubgr_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictSubError drmSubError;

    @JoinColumn(name = "drm_err_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictErrors drmError;

    @JoinColumn(name = "drm_dead_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictErrorDeadline drmDead;

    @Column(name = "drm_role_uuid")
    private UUID drmUserGroupId;

    @Column(name = "drm_user_uuid")
    private UUID drmUserId;

    @Column(name = "drm_branch_uuid")
    private UUID drmBranchId;

    @JoinColumn(name = "drm_filial")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictFilial drmFilial;

    @JoinColumn(name = "drm_source")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictSources drmSource;

    @Column(name = "drm_online_notif")
    private Boolean drmOnlineNotif;

    @Column(name = "drm_stat_day")
    private Boolean drmStatDay;

    @Column(name = "drm_stat_week")
    private Boolean drmStatWeek;

    @Column(name = "drm_stat_month")
    private Boolean drmStatMonth;

    @JmixProperty
    @Transient
    private UserGroup userGroup;

    @JmixProperty
    @Transient
    private User user;

    @JmixProperty
    @Transient
    private DictDepartment branch;

    public UUID getDrmBranchId() {
        return drmBranchId;
    }

    public void setDrmBranchId(UUID drmBranchId) {
        this.drmBranchId = drmBranchId;
    }

    public UUID getDrmUserId() {
        return drmUserId;
    }

    public void setDrmUserId(UUID drmUser) {
        this.drmUserId = drmUser;
    }

    public UUID getDrmUserGroupId() {
        return drmUserGroupId;
    }

    public void setDrmUserGroupId(UUID drmUserGroupId) {
        this.drmUserGroupId = drmUserGroupId;
    }

    public void setDrmDead(DictErrorDeadline drmDead) {
        this.drmDead = drmDead;
    }

    public DictErrorDeadline getDrmDead() {
        return drmDead;
    }

    public void setDrmFilial(DictFilial drmFilial) {
        this.drmFilial = drmFilial;
    }

    public DictFilial getDrmFilial() {
        return drmFilial;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setDrmStatMonth(Boolean drmStatMonth) {
        this.drmStatMonth = drmStatMonth;
    }

    public void setDrmStatWeek(Boolean drmStatWeek) {
        this.drmStatWeek = drmStatWeek;
    }

    public void setDrmStatDay(Boolean drmStatDay) {
        this.drmStatDay = drmStatDay;
    }

    public void setDrmOnlineNotif(Boolean drmOnlineNotif) {
        this.drmOnlineNotif = drmOnlineNotif;
    }

    public void setDrmSource(DictSources drmSource) {
        this.drmSource = drmSource;
    }

    public void setDrmError(DictErrors drmError) {
        this.drmError = drmError;
    }

    public void setDrmSubError(DictSubError drmSubError) {
        this.drmSubError = drmSubError;
    }

    public void setDrmErrorGroup(DictErrorGroup drmErrorGroup) {
        this.drmErrorGroup = drmErrorGroup;
    }


    public DictSources getDrmSource() {
        return drmSource;
    }

    public void setBranch(DictDepartment branch) {
        this.branch = branch;
    }

    public DictDepartment getBranch() {
        return branch;
    }

    public void setUserGroup(UserGroup userGroup) {
        this.userGroup = userGroup;
    }

    public UserGroup getUserGroup() {
        return userGroup;
    }

    public DictSubError getDrmSubError() {
        return drmSubError;
    }

    public DictErrorGroup getDrmErrorGroup() {
        return drmErrorGroup;
    }

    public DictErrors getDrmError() {
        return drmError;
    }

    public Boolean getDrmStatMonth() {
        return drmStatMonth;
    }

    public Boolean getDrmStatWeek() {
        return drmStatWeek;
    }

    public Boolean getDrmStatDay() {
        return drmStatDay;
    }

    public Boolean getDrmOnlineNotif() {
        return drmOnlineNotif;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @PrePersist
    public void prePersist() {

        drmUserId = null;
        if (user != null) {
            drmUserId = user.getId();
        }

        drmBranchId = null;
        if (branch != null) {
            drmBranchId = branch.getId();
        }

        drmUserGroupId = null;
        if (userGroup != null) {
            drmUserGroupId = userGroup.getId();
        }
    }
}