package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "s00_dict_snp_poz", schema = "dwh_draft")
@Entity(name = "r360_PozReference")
public class PozReference {
    @JmixGeneratedValue
    @Column(name = "sdsp_uuid", nullable = false)
    @Id
    private UUID id;

    @InstanceName
    @Column(name = "sdsp_poz_name")
    @Lob
    private String pozName;

    @JoinColumn(name = "sdsp_src_cd")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictSources srcCd;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "\"sdsp$change_date\"")
    private Date changeDate;

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public void setSrcCd(DictSources srcCd) {
        this.srcCd = srcCd;
    }

    public DictSources getSrcCd() {
        return srcCd;
    }

    public String getPozName() {
        return pozName;
    }

    public void setPozName(String pozName) {
        this.pozName = pozName;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}