package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "s00_dict_snp_poz_product", schema = "dwh_draft", indexes = {
        @Index(name = "IDX_SDSPP_PRD_ID", columnList = "sdspp_prd_uuid")
})
@Entity(name = "r360_DictProductPozSnp")
public class DictProductPozSnp {
    @JmixGeneratedValue
    @Column(name = "sdspp_uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "\"sdspp$change_date\"")
    @Temporal(TemporalType.TIMESTAMP)
    private Date changeDate;

    @Column(name = "\"sdspp$start_date\"")
    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Column(name = "\"sdspp$end_date\"")
    @Temporal(TemporalType.DATE)
    private Date endDate;

    @InstanceName
    @Column(name = "\"sdspp$row_status\"", length = 10)
    private String rowStatus;

    @JoinColumn(name = "sdspp_prd_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictRefProduct prdId;

    @Column(name = "sdspp_user_uuid")
    private UUID userId;

    @JmixProperty
    @Transient
    private User user;

    public void setPrdId(DictRefProduct prdId) {
        this.prdId = prdId;
    }

    public DictRefProduct getPrdId() {
        return prdId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public String getRowStatus() {
        return rowStatus;
    }

    public void setRowStatus(String rowStatus) {
        this.rowStatus = rowStatus;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @PrePersist
    public void prePersist() {
        userId = null;
        if (user != null) {
            userId = user.getId();
        }
    }
}