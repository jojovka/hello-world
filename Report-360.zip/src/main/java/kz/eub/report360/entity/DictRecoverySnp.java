package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "s00_dict_snp_tr_do", schema = "dwh_draft")
@Entity(name = "r360_DictRecoverySnp")
public class DictRecoverySnp {
    @JmixGeneratedValue
    @Column(name = "sdstd_uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "sdstd_code")
    private String code;

    @InstanceName
    @Column(name = "sdstd_name", length = 1000)
    private String name;

    @Column(name = "sdstd_values")
    private String values;

    @Column(name = "sdstd_uniformity")
    private String uniformity;

    @Column(name = "sdstd_ul_sign")
    private String ulSign;

    @Column(name = "\"sdstd$start_date\"")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startDate;

    @Column(name = "\"sdstd$end_date\"")
    @Temporal(TemporalType.TIMESTAMP)
    private Date endDate;

    @Column(name = "sdstd_is_actual")
    private String isActual;

    @Column(name = "\"sdstd$change_date\"")
    @Temporal(TemporalType.TIMESTAMP)
    private Date changeDate;

    @Column(name = "sdstd_users")
    private String user;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public String getIsActual() {
        return isActual;
    }

    public void setIsActual(String isActual) {
        this.isActual = isActual;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getUlSign() {
        return ulSign;
    }

    public void setUlSign(String ulSign) {
        this.ulSign = ulSign;
    }

    public String getUniformity() {
        return uniformity;
    }

    public void setUniformity(String uniformity) {
        this.uniformity = uniformity;
    }

    public String getValues() {
        return values;
    }

    public void setValues(String values) {
        this.values = values;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}