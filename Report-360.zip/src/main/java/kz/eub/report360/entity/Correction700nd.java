package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;
import io.jmix.data.DdlGeneration;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.time.LocalDateTime;
import java.util.Date;

@DdlGeneration(value = DdlGeneration.DbScriptGenerationMode.DISABLED)
@JmixEntity
@Store(name = "dwhdb")
//@Store(name = "dwhdb")
@Table(name = "CORRECTION_700ND", schema = "JMIX_USER")
@Entity(name = "r360_Correction700nd")
public class Correction700nd {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private Integer id;

    @Column(name = "COMMENTS", length = 250)
    private String comments;//!

    @Column(name = "\"CREATED_BY\"", length = 50)
    private String createdBy;

    @Column(name = "\"CREATED_DATE\"")
    @Temporal(TemporalType.DATE)
    private Date createdDate;

    @Column(name = "CUR", length = 50)
    private String cur;//!

    @Column(name = "\"DATE_VALUE\"")
    private LocalDateTime dateValue;

    @Column(name = "ECON", length = 50)
    private String econ;

    @Column(name = "\"OUT_SALDO_KZT\"")
    private Integer outSaldoKzt;

    @Column(name = "\"PA4CODE\"")
    private Integer pa4code;

    @Column(name = "REZ", length = 50)
    private String rez;

    public void setDateValue(LocalDateTime dateValue) {
        this.dateValue = dateValue;
    }

    public LocalDateTime getDateValue() {
        return dateValue;
    }

    public void setPa4code(Integer pa4code) {
        this.pa4code = pa4code;
    }

    public Integer getPa4code() {
        return pa4code;
    }

    public void setOutSaldoKzt(Integer outSaldoKzt) {
        this.outSaldoKzt = outSaldoKzt;
    }

    public Integer getOutSaldoKzt() {
        return outSaldoKzt;
    }

    public String getRez() {
        return rez;
    }

    public void setRez(String rez) {
        this.rez = rez;
    }

    public String getEcon() {
        return econ;
    }

    public void setEcon(String econ) {
        this.econ = econ;
    }

    public String getCur() {
        return cur;
    }

    public void setCur(String cur) {
        this.cur = cur;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}