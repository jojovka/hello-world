package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "dict_error_group", schema = "dwh_dq")
@Entity(name = "r360_DictErrorGroup")
public class DictErrorGroup {
    @JmixGeneratedValue
    @Column(name = "errg_uuid", nullable = false)
    @Id
    private UUID id;

    @InstanceName
    @Column(name = "errg_descr")
    @Lob
    private String errgDescr;

    public void setErrgDescr(String errgDescr) {
        this.errgDescr = errgDescr;
    }

    public String getErrgDescr() {
        return errgDescr;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}