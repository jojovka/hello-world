package kz.eub.report360.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum ReportXmlType implements EnumClass<String> {

    XML("XML"),
    TXT("TXT");

    private String id;

    ReportXmlType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static ReportXmlType fromId(String id) {
        for (ReportXmlType at : ReportXmlType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}