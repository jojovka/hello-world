package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "dict_sub_error", schema = "dwh_dq")
@Entity(name = "r360_DictSubError")
public class DictSubError {
    @JmixGeneratedValue
    @Column(name = "dse_uuid", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "dse_errg_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictErrorGroup dseErrg;

    @InstanceName
    @Column(name = "dse_name")
    private String dseName;

    public void setDseName(String dseName) {
        this.dseName = dseName;
    }

    public void setDseErrg(DictErrorGroup dseErrg) {
        this.dseErrg = dseErrg;
    }

    public DictErrorGroup getDseErrg() {
        return dseErrg;
    }

    public String getDseName() {
        return dseName;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}