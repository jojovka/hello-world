package kz.eub.report360.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum ReportingType implements EnumClass<String> {

    R360_REGULAR("R360-regular"),
    R360_MATRIX("R360-matrix"),
    R360_DYNAMIC("R360-dynamic"),
    R360_HYBRID("R360-hybrid");

    private String id;

    ReportingType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static ReportingType fromId(String id) {
        for (ReportingType at : ReportingType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}