package kz.eub.report360.entity;

import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "dict_departments", schema = "dwh_dds")
@Entity(name = "r360_DictFilial")
public class DictFilial {
    @Column(name = "dprt_uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "\"dprt$change_date\"")
    @Temporal(TemporalType.TIMESTAMP)
    private Date changeDate;

    @Column(name = "\"dprt$audit_id\"", precision = 19, scale = 2)
    private BigDecimal auditId;

    @Column(name = "dprt_id")
    private BigDecimal dprtId;

    @Column(name = "\"dprt$source\"")
    private String dprtSource;

    @Column(name = "\"dprt$source_pk\"", precision = 19, scale = 2)
    private BigDecimal sourcePk;

    @Column(name = "dprt_cd", precision = 19, scale = 2)
    private BigDecimal dprtCd;

    @Column(name = "\"dprt$start_date\"")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startDate;

    @Column(name = "\"dprt$end_date\"")
    @Temporal(TemporalType.TIMESTAMP)
    private Date endDate;

    @Column(name = "\"dprt$row_status\"")
    private String rowStatus;

    @Column(name = "dprt_name", length = 320)
    private String name;

    @Column(name = "dprt_shortname", length = 320)
    private String shortName;

    @Column(name = "dprt_is_filial")
    private String dprtFilial;

    @Column(name = "dprt_filial_user_code")
    private String dprtFilialUserCd;

    @InstanceName
    @Column(name = "dprt_filname", length = 320)
    private String filname;

    @Column(name = "dprt_fil_shortname", length = 320)
    private String filShortName;

    @Column(name = "dprt_okpo")
    private String okpo;

    @Column(name = "dprt_user_code")
    private String userCode;

    @Column(name = "dprt_is_exchange")
    private String dprtIsExchange;

    @Column(name = "dprt_legal_address")
    private String legalAddress;

    @Column(name = "dprt_parentcode", precision = 19, scale = 2)
    private BigDecimal parentCode;

    @Column(name = "dprt_lvl", precision = 19, scale = 2)
    private BigDecimal dprtLvl;

    public BigDecimal getDprtId() {
        return dprtId;
    }

    public BigDecimal getDprtLvl() {
        return dprtLvl;
    }

    public BigDecimal getParentCode() {
        return parentCode;
    }

    public String getLegalAddress() {
        return legalAddress;
    }

    public String getDprtIsExchange() {
        return dprtIsExchange;
    }

    public String getUserCode() {
        return userCode;
    }

    public String getOkpo() {
        return okpo;
    }

    public String getFilShortName() {
        return filShortName;
    }

    public String getFilname() {
        return filname;
    }

    public String getDprtFilialUserCd() {
        return dprtFilialUserCd;
    }

    public String getDprtFilial() {
        return dprtFilial;
    }

    public String getShortName() {
        return shortName;
    }

    public String getName() {
        return name;
    }

    public String getRowStatus() {
        return rowStatus;
    }

    public Date getEndDate() {
        return endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public BigDecimal getDprtCd() {
        return dprtCd;
    }

    public BigDecimal getSourcePk() {
        return sourcePk;
    }

    public String getDprtSource() {
        return dprtSource;
    }

    public BigDecimal getAuditId() {
        return auditId;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}