package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhdb")
@Table(name = "S00_UNI_DICT_CWDB", schema = "REPORT_USER")
@Entity(name = "r360_UniDictCwdb")
public class UniDictCwdb {
    @Column(name = "UUID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "ID", precision = 19, scale = 2)
    private BigDecimal uniCwdbId;

    @Lob
    @InstanceName
    @Column(name = "DESCR")
    private String descr;

    @Column(name = "TYPE", length = 100)
    private String type;

    @Column(name = "SUBTYPE", length = 100)
    private String subtype;

    @Column(name = "VALUE", length = 50)
    private String value;

    @Column(name = "ID_REPORT", length = 5)
    private String idReport;

    @Column(name = "NAME_DEMENSION_CWDB", length = 30)
    private String nameDemensionCwdb;

    @Column(name = "DATE_BEGIN")
    private LocalDate dateBegin;

    @Column(name = "DATE_END")
    private LocalDate dateEnd;

    @Column(name = "IS_ACTUAL", length = 100)
    private String isActual;

    @Column(name = "ROW_CREATION_DATE")
    private LocalDate rowCreationDate;

    public BigDecimal getUniCwdbId() {
        return uniCwdbId;
    }

    public LocalDate getRowCreationDate() {
        return rowCreationDate;
    }

    public String getIsActual() {
        return isActual;
    }

    public LocalDate getDateEnd() {
        return dateEnd;
    }

    public LocalDate getDateBegin() {
        return dateBegin;
    }

    public String getNameDemensionCwdb() {
        return nameDemensionCwdb;
    }

    public String getIdReport() {
        return idReport;
    }

    public String getValue() {
        return value;
    }

    public String getSubtype() {
        return subtype;
    }

    public String getType() {
        return type;
    }

    public String getDescr() {
        return descr;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}