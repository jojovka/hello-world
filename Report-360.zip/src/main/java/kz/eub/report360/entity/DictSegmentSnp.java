package kz.eub.report360.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhprod")
@Table(name = "s00_dict_snp_poz_segm", schema = "dwh_draft", indexes = {
        @Index(name = "IDX_SDSPS_POZ_UUID", columnList = "sdsps_poz_uuid"),
        @Index(name = "IDX_SDSPS_SRC_UUID", columnList = "sdsps_src_uuid")
})
@Entity(name = "r360_DictSegmentSnp")
public class DictSegmentSnp {
    @JmixGeneratedValue
    @Column(name = "sdsps_uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "sdsps_change_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date changeDate;

    @JoinColumn(name = "sdsps_poz_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private PozReference pozId;

    @InstanceName
    @Column(name = "sdsps_segm")
    private String segment;

    @Column(name = "sdsps_amount_min", precision = 19, scale = 2)
    private BigDecimal amountMin;

    @Column(name = "sdsps_amount_max", precision = 19, scale = 2)
    private BigDecimal amountMax;

    @Column(name = "sdsps_duration_min", precision = 19, scale = 2)
    private BigDecimal durationMin;

    @Column(name = "sdsps_duration_max", precision = 19, scale = 2)
    private BigDecimal durationMax;

    @JoinColumn(name = "sdsps_src_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictSources dictSrcId;

    public DictSources getDictSrcId() {
        return dictSrcId;
    }

    public void setDictSrcId(DictSources dictSrcId) {
        this.dictSrcId = dictSrcId;
    }

    public BigDecimal getDurationMax() {
        return durationMax;
    }

    public void setDurationMax(BigDecimal durationMax) {
        this.durationMax = durationMax;
    }

    public BigDecimal getDurationMin() {
        return durationMin;
    }

    public void setDurationMin(BigDecimal durationMin) {
        this.durationMin = durationMin;
    }

    public BigDecimal getAmountMax() {
        return amountMax;
    }

    public void setAmountMax(BigDecimal amountMax) {
        this.amountMax = amountMax;
    }

    public BigDecimal getAmountMin() {
        return amountMin;
    }

    public void setAmountMin(BigDecimal amountMin) {
        this.amountMin = amountMin;
    }

    public String getSegment() {
        return segment;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public PozReference getPozId() {
        return pozId;
    }

    public void setPozId(PozReference pozId) {
        this.pozId = pozId;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}