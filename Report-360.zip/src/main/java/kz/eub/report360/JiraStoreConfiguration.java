package kz.eub.report360;

import io.jmix.core.JmixModules;
import io.jmix.core.Resources;
import io.jmix.data.impl.JmixEntityManagerFactoryBean;
import io.jmix.data.impl.JmixTransactionManager;
import io.jmix.data.persistence.DbmsSpecifics;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

@Configuration
public class JiraStoreConfiguration {

    @Bean
    @ConfigurationProperties("jira.datasource")
    DataSourceProperties jiraDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "jira.datasource.hikari")
    DataSource jiraDataSource(@Qualifier("jiraDataSourceProperties") DataSourceProperties properties) {
        return properties.initializeDataSourceBuilder().build();
    }

    @Bean
    LocalContainerEntityManagerFactoryBean jiraEntityManagerFactory(
            @Qualifier("jiraDataSource") DataSource dataSource,
            JpaVendorAdapter jpaVendorAdapter,
            DbmsSpecifics dbmsSpecifics,
            JmixModules jmixModules,
            Resources resources) {
        return new JmixEntityManagerFactoryBean("jira", dataSource, jpaVendorAdapter, dbmsSpecifics, jmixModules, resources);
    }

    @Bean
    JpaTransactionManager jiraTransactionManager(@Qualifier("jiraEntityManagerFactory") EntityManagerFactory entityManagerFactory) {
        return new JmixTransactionManager("jira", entityManagerFactory);
    }

    @Bean(name = "jiraJdbcTemplate")
    JdbcTemplate jiraJdbcTemplate(@Qualifier("jiraDataSource") DataSource ds) {
        return new JdbcTemplate(ds);
    }
}
