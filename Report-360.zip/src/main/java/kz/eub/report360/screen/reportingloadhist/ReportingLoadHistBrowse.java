package kz.eub.report360.screen.reportingloadhist;

import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.Reporting;
import kz.eub.report360.entity.ReportingLoadHist;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("r360_ReportingLoadHist.browse")
@UiDescriptor("reporting-load-hist-browse.xml")
@LookupComponent("reportingLoadHistsTable")
public class ReportingLoadHistBrowse extends StandardLookup<ReportingLoadHist> {
    @Autowired
    private CollectionLoader<ReportingLoadHist> reportingLoadHistsDl;

    private Reporting reporting;

    public void setValues(Reporting reporting) {
        this.reporting=reporting;
    }

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        reportingLoadHistsDl.setParameter("reporting", reporting);
        reportingLoadHistsDl.load();
    }
}