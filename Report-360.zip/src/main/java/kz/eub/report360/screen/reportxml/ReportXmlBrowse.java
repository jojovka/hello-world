package kz.eub.report360.screen.reportxml;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.ReportXml;

@UiController("r360_ReportXml.browse")
@UiDescriptor("report-xml-browse.xml")
@LookupComponent("reportXmlTable")
public class ReportXmlBrowse extends StandardLookup<ReportXml> {
}