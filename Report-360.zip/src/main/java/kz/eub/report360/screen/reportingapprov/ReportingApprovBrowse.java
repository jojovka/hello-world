package kz.eub.report360.screen.reportingapprov;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.ReportingApprov;

@UiController("r360_ReportingApprov.browse")
@UiDescriptor("reporting-approv-browse.xml")
@LookupComponent("reportingApprovesTable")
public class ReportingApprovBrowse extends StandardLookup<ReportingApprov> {
}