package kz.eub.report360.screen.reportxmlparam;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.ReportXmlParam;

@UiController("r360_ReportXmlParam.browse")
@UiDescriptor("report-xml-param-browse.xml")
@LookupComponent("reportXmlParamsTable")
public class ReportXmlParamBrowse extends StandardLookup<ReportXmlParam> {
}