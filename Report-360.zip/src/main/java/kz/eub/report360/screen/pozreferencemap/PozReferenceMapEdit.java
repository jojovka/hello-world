package kz.eub.report360.screen.pozreferencemap;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.PozReferenceMap;

@UiController("r360_PozReferenceMap.edit")
@UiDescriptor("poz-reference-map-edit.xml")
@EditedEntityContainer("pozReferenceMapDc")
public class PozReferenceMapEdit extends StandardEditor<PozReferenceMap> {
}