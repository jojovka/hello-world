package kz.eub.report360.screen.dictbasketsnp;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictBasketSnp;

@UiController("r360_DictBasketSnp.browse")
@UiDescriptor("dict-basket-snp-browse.xml")
@LookupComponent("dictBasketSnpsTable")
public class DictBasketSnpBrowse extends StandardLookup<DictBasketSnp> {
}