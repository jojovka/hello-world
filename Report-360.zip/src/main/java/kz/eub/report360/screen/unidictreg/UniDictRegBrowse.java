package kz.eub.report360.screen.unidictreg;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.UniDictReg;

@UiController("r360_UniDictReg.browse")
@UiDescriptor("uni-dict-reg-browse.xml")
@LookupComponent("uniDictRegsTable")
public class UniDictRegBrowse extends StandardLookup<UniDictReg> {
}