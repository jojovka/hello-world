package kz.eub.report360.screen.dictsuberror;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictSubError;

@UiController("r360_DictSubError.edit")
@UiDescriptor("dict-sub-error-edit.xml")
@EditedEntityContainer("dictSubErrorDc")
public class DictSubErrorEdit extends StandardEditor<DictSubError> {
}