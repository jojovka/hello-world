package kz.eub.report360.screen.unidictentity;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.UniDictEntity;

@UiController("r360_UniDictEntity.browse")
@UiDescriptor("uni-dict-entity-browse.xml")
@LookupComponent("uniDictEntitiesTable")
public class UniDictEntityBrowse extends StandardLookup<UniDictEntity> {
}