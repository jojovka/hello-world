package kz.eub.report360.screen.dictdepartment;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictDepartment;

@UiController("r360_DictDepartment.browse")
@UiDescriptor("dict-department-browse.xml")
@LookupComponent("dictDepartmentsTable")
public class DictDepartmentBrowse extends StandardLookup<DictDepartment> {
}