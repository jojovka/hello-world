package kz.eub.report360.screen.unidictreg;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.UniDictReg;

@UiController("r360_UniDictReg.edit")
@UiDescriptor("uni-dict-reg-edit.xml")
@EditedEntityContainer("uniDictRegDc")
public class UniDictRegEdit extends StandardEditor<UniDictReg> {
}