package kz.eub.report360.screen.reporting;

import io.jmix.core.DataManager;
import io.jmix.core.common.util.ParamsMap;
import io.jmix.core.security.CurrentAuthentication;
import io.jmix.emailtemplates.exception.TemplateNotFoundException;
import io.jmix.reports.entity.Report;
import io.jmix.reports.entity.ReportExecution;
import io.jmix.reportsui.runner.FluentUiReportRunner;
import io.jmix.reportsui.runner.ParametersDialogShowMode;
import io.jmix.reportsui.runner.UiReportRunner;
import io.jmix.reportsui.screen.ReportsClientProperties;
import io.jmix.reportsui.screen.report.history.ReportExecutionBrowser;
import io.jmix.ui.Dialogs;
import io.jmix.ui.Notifications;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.Action;
import io.jmix.ui.action.DialogAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.CheckBox;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.TextField;
import io.jmix.ui.download.Downloader;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.Reporting;
import kz.eub.report360.entity.ReportingApprov;
import kz.eub.report360.entity.ReportingGrants;
import kz.eub.report360.entity.User;
import kz.eub.report360.screen.reportingapprov.ReportingApprovEdit;
import kz.eub.report360.screen.reportingapprov.ReportingApprovLimited;
import kz.eub.report360.screen.reportinggrants.ReportingGrantsBrowse;
import kz.eub.report360.app.service.UtilityService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;


@UiController("r360_ReportingRun.browse")
@UiDescriptor("reporting-run-browse.xml")
@LookupComponent("reportingRunTable")
public class ReportingRunBrowse extends StandardLookup<Reporting> {
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private GroupTable<Reporting> reportingRunTable;
    @Autowired
    private CollectionLoader<Reporting> reportingRunDl;
    @Autowired
    protected DataManager dataManager;
    @Autowired
    protected UiReportRunner uiReportRunner;
    @Autowired
    private Notifications notifications;
    @Autowired
    private CurrentAuthentication currentAuthentication;
    @Autowired
    private ReportsClientProperties reportsClientProperties;
    @Autowired
    private CheckBox reportingDisplayChB;
    @Autowired
    private UtilityService utilityService;
    @Autowired
    private TextField<String> nameField;
    private Set<Reporting> permittedReporting;
    @Autowired
    protected Dialogs dialogs;
    @Autowired
    private Downloader downloader;

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        permittedReporting = utilityService.findAllPermittedReporting((User) currentAuthentication.getUser());
        showView(null);
    }

    @Subscribe("searchBtn")
    public void onSearchBtnClick(Button.ClickEvent event) {
        showView(nameField.getValue());
    }

    private void showView(String nameRep) {
        reportingRunDl.setParameter("reporting_display", true);
        reportingRunDl.setParameter("permitted_reporting", permittedReporting);
        reportingRunDl.setParameter("nameRep", nameRep == null ? null : "%" + nameRep + "%");

        reportingDisplayChB.setValue(true);
        reportingRunDl.load();
    }

    private void clearFilter() {
        nameField.setValue(null);
    }

    @Subscribe("reportingDisplayChB")
    public void onReportingDisplayChBValueChange(HasValue.ValueChangeEvent<Boolean> event) {
        if (event.isUserOriginated()) {
            clearFilter();
            reportingRunDl.setParameter("reporting_display", reportingDisplayChB.getValue());
            reportingRunDl.setParameter("nameRep", nameField.getValue());
            reportingRunDl.load();
        }
    }

    @Subscribe("runReportingBtn")
    public void onRunReportingBtnClick(Button.ClickEvent event) {
        if (reportingRunTable.getSingleSelected() == null) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Внимание")
                    .withDescription("Необходимо выбрать отчёт").show();
            return;
        }
        if (permittedReporting.contains(reportingRunTable.getSingleSelected())) {
            Reporting reporting = reportingRunTable.getSingleSelected();
            if (reporting != null) {
                Report report = getMyReport(reporting.getReportId());
                FluentUiReportRunner fluentRunner = uiReportRunner.byReportEntity(report)
                        .withParametersDialogShowMode(ParametersDialogShowMode.IF_REQUIRED);
                if (reportsClientProperties.getUseBackgroundReportProcessing()) {
                    fluentRunner.inBackground(ReportingRunBrowse.this);
                }
                fluentRunner.runAndShow();
            }
        } else {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Внимание")
                    .withDescription("У вас нет доступа к выгрузке отчета, вы можете его запросить по кнопке \"Запросы на права доступа\"").show();
        }
    }

    public Report getMyReport(UUID id) {
        return dataManager.load(Report.class)
                .query("select r from report_Report r where r.id = :id")
                .parameter("id", id)
                .one();
    }

    @Subscribe("reportingExampleBtn")
    public void onReportingExampleBtnClick(Button.ClickEvent event) {
        if (reportingRunTable.getSingleSelected() == null) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Внимание")
                    .withDescription("Необходимо выбрать отчет").show();
            return;
        } else if (reportingRunTable.getSingleSelected().getFile() == null) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Внимание")
                    .withDescription("Файл с примером отчета отсутствует").show();
            return;
        }
        downloader.download(reportingRunTable.getSingleSelected().getFile());
    }

    @Subscribe("reportingDescrBtn")
    public void onReportingDescrBtnClick(Button.ClickEvent event) {
        if (reportingRunTable.getSingleSelected()==null) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Внимание")
                    .withDescription("Необходимо выбрать отчет").show();
            return;
        }

        screenBuilders.editor(reportingRunTable)
                .withScreenId("r360_Reporting.editDescr")
                .withOpenMode(OpenMode.DIALOG)
                .build()
                .show();
    }

    @Subscribe("accessRightsBtn")
    public void onAccessRightsBtnClick(Button.ClickEvent event) {
        if (reportingRunTable.getSingleSelected() == null) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Внимание")
                    .withDescription("Необходимо выбрать отчет").show();
            return;
        }

        ReportingGrantsBrowse screen = screenBuilders
                .lookup(ReportingGrants.class, this)
                .withScreenClass(ReportingGrantsBrowse.class)
                .withOpenMode(OpenMode.DIALOG)
                .build();

        screen.setParam(reportingRunTable.getSingleSelected());
        screen.addAfterCloseListener(afterCloseEvent -> getScreenData().loadAll());
        screen.show();
    }

    @Subscribe("accessQueryBtn")
    public void onAccessQueryBtnClick(Button.ClickEvent event) {
        if (reportingRunTable.getSingleSelected() == null) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Внимание")
                    .withDescription("Необходимо выбрать отчет").show();
            return;
        } else if (permittedReporting.contains(reportingRunTable.getSingleSelected())) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Внимание")
                    .withDescription("У вас уже есть доступ к данному отчету").show();
            return;
        }

        dialogs.createOptionDialog()
                .withWidth("450px")
                .withCaption("Запрос на доступ")
                .withMessage("Вашему руководителю и ответственному по выбранному отчету будет отослано письмо с запросом на доступ.\n" +
                        "Вы уверены?")
                .withActions(
                        new DialogAction(DialogAction.Type.YES, Action.Status.PRIMARY).withHandler(e -> {
                            try {
                                utilityService.sendQueryGrantsEmail(reportingRunTable.getSingleSelected());

                                notifications.create(Notifications.NotificationType.HUMANIZED)
                                        .withDescription("Запрос на доступ отправлен").show();
                            } catch (TemplateNotFoundException ex) {
                                notifications.create(Notifications.NotificationType.ERROR)
                                        .withCaption("Внимание")
                                        .withDescription("Не настроен шаблон для отправки письма. Обратитесь к администратору.").show();
                            } catch (Exception ex) {
                                notifications.create(Notifications.NotificationType.ERROR)
                                        .withCaption("Внимание")
                                        .withDescription("Произошла ошибка при отправке почты " + ex.getMessage()).show();
                            }

                        }),
                        new DialogAction(DialogAction.Type.NO)
                )
                .show();
    }

    @Subscribe("reportingExecutionBtn")
    public void onReportingExecutionBtnClick(Button.ClickEvent event) {
        if (reportingRunTable.getSingleSelected() == null) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Внимание")
                    .withDescription("Необходимо выбрать отчет").show();
            return;
        }

        if (reportingRunTable.getSingleSelected().getReportId() != null) {
            Report report = getMyReport(reportingRunTable.getSingleSelected().getReportId());
            List<Report> lst = new ArrayList<>();
            lst.add(report);
            ReportExecutionBrowser screen = (ReportExecutionBrowser) screenBuilders
                    .lookup(ReportExecution.class, this)
                    .withOptions(new MapScreenOptions(ParamsMap.of(ReportExecutionBrowser.REPORTS_PARAMETER, lst)))
                    .build();

            screen.addAfterCloseListener(afterCloseEvent -> getScreenData().loadAll());
            screen.show();
        }
    }

    @Subscribe("agreementBtn")
    public void onAgreementBtnClick(Button.ClickEvent event) {
        if (reportingRunTable.getSingleSelected() == null) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Внимание")
                    .withDescription("Необходимо выбрать отчет для согласования").show();
            return;
        }

        ReportingApprovEdit screen = (ReportingApprovEdit) screenBuilders.editor(ReportingApprov.class, this)
                .newEntity()
                .withOpenMode(OpenMode.DIALOG)
                .build();

        screen.setParam((User) currentAuthentication.getUser(), reportingRunTable.getSingleSelected());
        screen.addAfterCloseListener(afterCloseEvent -> getScreenData().loadAll());
        screen.show();
    }

    @Subscribe("viewAgreementBtn")
    public void onViewAgreementBtnClick(Button.ClickEvent event) {
        if (reportingRunTable.getSingleSelected() == null) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Внимание")
                    .withDescription("Необходимо выбрать отчет").show();
            return;
        }

        ReportingApprovLimited screen = screenBuilders
                .lookup(ReportingApprov.class, this)
                .withScreenClass(ReportingApprovLimited.class)
                .withOpenMode(OpenMode.DIALOG)
                .build();

        screen.setParam(reportingRunTable.getSingleSelected());
        screen.addAfterCloseListener(afterCloseEvent -> getScreenData().loadAll());
        screen.show();
    }

}