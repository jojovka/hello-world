package kz.eub.report360.screen.reportxmlhist;

import io.jmix.ui.component.EntityPicker;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.model.InstanceLoader;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.ReportXml;
import kz.eub.report360.entity.ReportXmlHist;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("r360_ReportXmlHist.edit")
@UiDescriptor("report-xml-hist-edit.xml")
@EditedEntityContainer("reportXmlHistDc")
public class ReportXmlHistEdit extends StandardEditor<ReportXmlHist> {
    @Autowired
    private InstanceContainer<ReportXmlHist> reportXmlHistDc;
    @Autowired
    private InstanceLoader<ReportXmlHist> reportXmlHistDl;
    @Autowired
    private EntityPicker<ReportXml> reportXmlField;
    private boolean notShowRepXml = false;
    private ReportXml reportXml;

    public void setReportXml(ReportXml reportXml) {
        this.reportXml = reportXml;
    }

    public void setNotShowRepXml(boolean in_notShowRepXml) {
        notShowRepXml = in_notShowRepXml;
    }

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        if (reportXml != null) {
            reportXmlHistDc.getItem().setReportXml(reportXml);
        }
        if (notShowRepXml) {
            reportXmlField.setVisible(false);
        }
    }
}