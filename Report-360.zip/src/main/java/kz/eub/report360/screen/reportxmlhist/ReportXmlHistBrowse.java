package kz.eub.report360.screen.reportxmlhist;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.ReportXmlHist;

@UiController("r360_ReportXmlHist.browse")
@UiDescriptor("report-xml-hist-browse.xml")
@LookupComponent("reportXmlHistsTable")
public class ReportXmlHistBrowse extends StandardLookup<ReportXmlHist> {
}