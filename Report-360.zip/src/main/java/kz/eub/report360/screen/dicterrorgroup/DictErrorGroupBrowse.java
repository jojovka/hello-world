package kz.eub.report360.screen.dicterrorgroup;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictErrorGroup;

@UiController("r360_DictErrorGroup.browse")
@UiDescriptor("dict-error-group-browse.xml")
@LookupComponent("dictErrorGroupsTable")
public class DictErrorGroupBrowse extends StandardLookup<DictErrorGroup> {
}