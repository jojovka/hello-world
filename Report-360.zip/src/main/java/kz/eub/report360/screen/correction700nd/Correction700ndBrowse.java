package kz.eub.report360.screen.correction700nd;

import io.jmix.core.DataManager;
import io.jmix.core.FileRef;
import io.jmix.core.FileStorage;
import io.jmix.core.Messages;
import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import io.jmix.ui.Notifications;
import io.jmix.ui.component.FileStorageUploadField;
import io.jmix.ui.component.SingleFileUploadField;
import io.jmix.ui.screen.*;
import kz.eub.report360.app.service.ExcelDataImporter;
import kz.eub.report360.entity.Correction700nd;
import org.dhatim.fastexcel.reader.Cell;
import org.dhatim.fastexcel.reader.CellType;
import org.dhatim.fastexcel.reader.ReadableWorkbook;
import org.dhatim.fastexcel.reader.Row;
import org.dhatim.fastexcel.reader.Sheet;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Stream;

@UiController("r360_Correction700nd.browse")
@UiDescriptor("correction700nd-browse.xml")
@LookupComponent("correction700ndsTable")
public class Correction700ndBrowse extends StandardLookup<Correction700nd> {

    @Autowired
    private FileStorageUploadField attachmentFileField;
    @Autowired
    private Notifications notifications;
    @Autowired
    private Messages messages;
    @Autowired
    private FileStorage fileStorage;
    @Autowired
    private DataManager dataManager;
    @Autowired
    ExcelDataImporter excelDataImporter;
    @Autowired
    private CurrentUserSubstitution currentUserSubstitution;

    @Subscribe("attachmentFileField")
    public void onAttachmentFileFieldFileUploadSucceed(SingleFileUploadField.FileUploadSucceedEvent event) {
        FileRef fileRef = attachmentFileField.getValue();
        if (fileRef != null) {
            try {
                try (InputStream is = fileStorage.openStream(fileRef)) {
                    try (ReadableWorkbook wb = new ReadableWorkbook(is)) {
                        Sheet sheet = wb.getFirstSheet();
                        try (Stream<Row> rows = sheet.openStream()) {
                            List<Correction700nd> batch = new ArrayList<>(10000);
                            LocalDateTime localDateTimeStart = LocalDateTime.now();
                            rows.skip(1)
                                    .forEach(row -> {
                                        Correction700nd correction700nd = dataManager.create(Correction700nd.class);

                                        Cell cell0 = row.getCell(0);
                                        Cell cell1 = row.getCell(1);
                                        Cell cell2 = row.getCell(2);
                                        Cell cell3 = row.getCell(3);
                                        Cell cell4 = row.getCell(4);
                                        Cell cell5 = row.getCell(5);
                                        Cell cell6 = row.getCell(6);

                                        if (cell0.getType() != CellType.EMPTY){
                                            correction700nd.setDateValue(cell0.asDate());
                                        } else if (cell0.getType() == CellType.EMPTY) {
                                            correction700nd.setDateValue(null);
                                        }

                                        if (cell1.getType() != CellType.EMPTY){
                                            correction700nd.setPa4code(cell1.asNumber().intValue());
                                        } else if (cell1.getType() == CellType.EMPTY) {
                                            correction700nd.setPa4code(null);
                                        }

                                        if (cell2.getType() != CellType.EMPTY){
                                            correction700nd.setRez(cell2.asString());
                                        } else if (cell2.getType() == CellType.EMPTY) {
                                            correction700nd.setRez("");
                                        }

                                        if (cell3.getType() != CellType.EMPTY){
                                            correction700nd.setEcon(cell3.asString());
                                        } else if (cell3.getType() == CellType.EMPTY) {
                                            correction700nd.setEcon("");
                                        }

                                        if (cell4.getType() != CellType.EMPTY){
                                            correction700nd.setCur(cell4.asString());
                                        } else if (cell4.getType() == CellType.EMPTY) {
                                            correction700nd.setCur("");
                                        }

                                        if (cell5.getType() != CellType.EMPTY){
                                           correction700nd.setOutSaldoKzt(cell5.asNumber().intValue());
                                        }else if (cell5.getType() == CellType.EMPTY) {
                                            correction700nd.setOutSaldoKzt(null);
                                        }

                                        if (cell6.getType() != CellType.EMPTY){
                                            correction700nd.setComments(cell6.asString());
                                        } else if (cell6.getType() == CellType.EMPTY){
                                            correction700nd.setComments("");
                                        }

                                        correction700nd.setCreatedBy(currentUserSubstitution.getEffectiveUser().getUsername());
                                        correction700nd.setCreatedDate(new Date());

                                        System.out.println("$$$$ ROW #" + row.getRowNum() + " IS FINISHED $$$");

                                        batch.add(correction700nd);

                                        if (batch.size() == 10000) {
                                            excelDataImporter.saveObjectsListUsingSaveContext(batch);
                                            batch.clear();
                                        }
                                    });
                            if (!batch.isEmpty()) {
                                excelDataImporter.saveObjectsListUsingSaveContext(batch);
                                batch.clear();
                                LocalDateTime localDateTimeEnd = LocalDateTime.now();
                                System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$FINISHED$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
                                System.out.println("Start time:" + localDateTimeStart);
                                System.out.println("Start time:" + localDateTimeEnd);
                            }
                        }
                    }
                }
            } catch (IOException e) {
                notifications.create(Notifications.NotificationType.ERROR)
                        .withCaption(messages.getMessage(e.getMessage()))
                        .show();
            }
        } else {
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption(messages.getMessage("ФАЙЛ НЕ ЗАГРУЖЕН"))
                    .show();
        }
    }
}