package kz.eub.report360.screen.dictsuberror;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictSubError;

@UiController("r360_DictSubError.browse")
@UiDescriptor("dict-sub-error-browse.xml")
@LookupComponent("dictSubErrorsTable")
public class DictSubErrorBrowse extends StandardLookup<DictSubError> {
}