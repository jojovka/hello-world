package kz.eub.report360.screen.dicterrordeadline;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictErrorDeadline;

@UiController("r360_DictErrorDeadline.browse")
@UiDescriptor("dict-error-deadline-browse.xml")
@LookupComponent("dictErrorDeadlinesTable")
public class DictErrorDeadlineBrowse extends StandardLookup<DictErrorDeadline> {
}