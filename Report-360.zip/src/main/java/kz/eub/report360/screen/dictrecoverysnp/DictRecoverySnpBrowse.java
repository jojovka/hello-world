package kz.eub.report360.screen.dictrecoverysnp;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictRecoverySnp;

@UiController("r360_DictRecoverySnp.browse")
@UiDescriptor("dict-recovery-snp-browse.xml")
@LookupComponent("dictRecoverySnpsTable")
public class DictRecoverySnpBrowse extends StandardLookup<DictRecoverySnp> {
}