package kz.eub.report360.screen.relationtypelsbo;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.RelationTypeLsbo;

@UiController("r360_RelationTypeLsbo.browse")
@UiDescriptor("relation-type-lsbo-browse.xml")
@LookupComponent("relationTypeLsboesTable")
public class RelationTypeLsboBrowse extends StandardLookup<RelationTypeLsbo> {
}