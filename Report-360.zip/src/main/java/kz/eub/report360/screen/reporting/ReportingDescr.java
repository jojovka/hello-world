package kz.eub.report360.screen.reporting;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.Reporting;

@UiController("r360_Reporting.editDescr")
@UiDescriptor("reporting-descr.xml")
@EditedEntityContainer("reportingDc")
public class ReportingDescr extends StandardEditor<Reporting> {
}