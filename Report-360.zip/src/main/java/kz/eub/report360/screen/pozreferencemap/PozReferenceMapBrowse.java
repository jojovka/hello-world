package kz.eub.report360.screen.pozreferencemap;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.PozReferenceMap;

@UiController("r360_PozReferenceMap.browse")
@UiDescriptor("poz-reference-map-browse.xml")
@LookupComponent("pozReferenceMapsTable")
public class PozReferenceMapBrowse extends StandardLookup<PozReferenceMap> {
}