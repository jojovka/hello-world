package kz.eub.report360.screen.pozreference;

import io.jmix.ui.component.DateField;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.PozReference;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

@UiController("r360_PozReference.edit")
@UiDescriptor("poz-reference-edit.xml")
@EditedEntityContainer("pozReferenceDc")
public class PozReferenceEdit extends StandardEditor<PozReference> {

    @Autowired
    private DateField<Date> changeDateField;

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        changeDateField.setValue(new Date());
    }
}