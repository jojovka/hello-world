package kz.eub.report360.screen.dmcreditsnp;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DmCreditSnp;

@UiController("r360_DmCreditSnp.browse")
@UiDescriptor("dm-credit-snp-browse.xml")
@LookupComponent("dmCreditSnpsTable")
public class DmCreditSnpBrowse extends StandardLookup<DmCreditSnp> {
}