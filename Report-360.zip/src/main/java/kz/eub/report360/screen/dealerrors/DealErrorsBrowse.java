package kz.eub.report360.screen.dealerrors;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DealErrors;

@UiController("r360_DealErrors.browse")
@UiDescriptor("deal-errors-browse.xml")
@LookupComponent("dealErrorsTable")
public class DealErrorsBrowse extends StandardLookup<DealErrors> {
}