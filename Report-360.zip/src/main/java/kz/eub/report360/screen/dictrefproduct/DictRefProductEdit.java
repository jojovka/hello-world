package kz.eub.report360.screen.dictrefproduct;

import io.jmix.ui.component.DateField;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictRefProduct;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

@UiController("r360_DictRefProduct.edit")
@UiDescriptor("dict-ref-product-edit.xml")
@EditedEntityContainer("dictRefProductDc")
public class DictRefProductEdit extends StandardEditor<DictRefProduct> {
    @Autowired
    private InstanceContainer<DictRefProduct> dictRefProductDc;
    @Autowired
    private DateField<Date> changeDateField;

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        changeDateField.setValue(new Date());
    }
}