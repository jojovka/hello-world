package kz.eub.report360.screen.reportinggrants;

import io.jmix.ui.Notifications;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.component.EntityComboBox;
import io.jmix.ui.component.EntityPicker;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictDepartment;
import kz.eub.report360.entity.Reporting;
import kz.eub.report360.entity.ReportingGrants;
import kz.eub.report360.entity.User;
import kz.eub.report360.entity.UserGroup;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("r360_ReportingGrants.edit")
@UiDescriptor("reporting-grants-edit.xml")
@EditedEntityContainer("reportingGrantsDc")
public class ReportingGrantsEdit extends StandardEditor<ReportingGrants> {
    private Reporting report;
    @Autowired
    private InstanceContainer<ReportingGrants> reportingGrantsDc;
    @Autowired
    private EntityComboBox<DictDepartment> departField;
    @Autowired
    private EntityPicker<UserGroup> userGroupField;
    @Autowired
    private EntityPicker<User> userField;
    @Autowired
    private Notifications notifications;
    @Autowired
    private ScreenBuilders screenBuilders;

    public void setParam(Reporting report) {
        this.report = report;
    }

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        if (report != null) {
            reportingGrantsDc.getItem().setReporting(report);
        }
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        departField.setValue(reportingGrantsDc.getItem().getDepartment());
    }

    @Subscribe
    public void onBeforeCommitChanges(BeforeCommitChangesEvent event) {
        if (reportingGrantsDc.getItem().getUserGroup() == null && userField.getValue() == null) {
            notifications.create().withCaption("Требуется выбрать подразделение или пользователя").show();
            event.preventCommit();
        } else if (reportingGrantsDc.getItem().getUserGroup() != null && userField.getValue() != null) {
            notifications.create().withCaption("Требуется выбрать что-то одно. Подразделение или пользователя").show();
            event.preventCommit();
        }
    }
}