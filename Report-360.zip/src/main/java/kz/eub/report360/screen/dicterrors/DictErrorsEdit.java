package kz.eub.report360.screen.dicterrors;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictErrors;

@UiController("r360_DictErrors.edit")
@UiDescriptor("dict-errors-edit.xml")
@EditedEntityContainer("dictErrorsDc")
public class DictErrorsEdit extends StandardEditor<DictErrors> {
}