package kz.eub.report360.screen.appsetting;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.AppSetting;

@UiController("r360_AppSetting.edit")
@UiDescriptor("app-setting-edit.xml")
@EditedEntityContainer("appSettingDc")
public class AppSettingEdit extends StandardEditor<AppSetting> {
}