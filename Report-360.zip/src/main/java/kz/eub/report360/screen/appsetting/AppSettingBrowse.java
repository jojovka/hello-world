package kz.eub.report360.screen.appsetting;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.AppSetting;

@UiController("r360_AppSetting.browse")
@UiDescriptor("app-setting-browse.xml")
@LookupComponent("appSettingsTable")
public class AppSettingBrowse extends StandardLookup<AppSetting> {
}