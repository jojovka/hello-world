package kz.eub.report360.screen.dictsegmentsnp;

import io.jmix.ui.component.DateField;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictSegmentSnp;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

@UiController("r360_DictSegmentSnp.edit")
@UiDescriptor("dict-segment-snp-edit.xml")
@EditedEntityContainer("dictSegmentSnpDc")
public class DictSegmentSnpEdit extends StandardEditor<DictSegmentSnp> {
    @Autowired
    private DateField<Date> changeDateField;

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        changeDateField.setValue(new Date());
    }
}