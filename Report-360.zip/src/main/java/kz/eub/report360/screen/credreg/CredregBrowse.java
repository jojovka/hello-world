package kz.eub.report360.screen.credreg;

import io.jmix.core.DataManager;
import io.jmix.core.FileRef;
import io.jmix.core.FileStorage;
import io.jmix.core.Messages;
import io.jmix.core.SaveContext;
import io.jmix.ui.Notifications;
import io.jmix.ui.component.FileStorageUploadField;
import io.jmix.ui.component.SingleFileUploadField;
import io.jmix.ui.screen.*;
import kz.eub.report360.app.service.ExcelDataImporter;
import kz.eub.report360.entity.Credreg;
import kz.eub.report360.entity.key.CredregCompKey;
import org.dhatim.fastexcel.reader.ReadableWorkbook;
import org.dhatim.fastexcel.reader.Sheet;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

import org.dhatim.fastexcel.reader.*;

@UiController("r360_Credreg.browse")
@UiDescriptor("credreg-browse.xml")
@LookupComponent("credregsTable")
public class CredregBrowse extends StandardLookup<Credreg> {

    @Autowired
    private FileStorageUploadField attachmentFileField;
    @Autowired
    private Notifications notifications;
    @Autowired
    private Messages messages;
    @Autowired
    private FileStorage fileStorage;
    @Autowired
    private DataManager dataManager;
    @Autowired
    ExcelDataImporter excelDataImporter;

//    @Subscribe("attachmentFileField")
//    public void onAttachmentFileFieldFileUploadSucceed(SingleFileUploadField.FileUploadSucceedEvent event) {
//        FileRef fileRef = attachmentFileField.getValue();
//        if (fileRef != null) {
//            try {
//                try (InputStream is = fileStorage.openStream(fileRef)) {
//                    try (ReadableWorkbook wb = new ReadableWorkbook(is)) {
//                        Sheet sheet = wb.getFirstSheet();
//
//                        AtomicInteger rowIndex = new AtomicInteger();
//                        AtomicReference<Row> headerRow = new AtomicReference<>();
//                        List<Credreg> credregs = new ArrayList<>();
//                        int batchSize = 5000;
//
//                        sheet.openStream().forEach(row -> {
//                            if (rowIndex.getAndIncrement() == 0) {
//                                headerRow.set(row); // Get the header row
//                            } else {
//                                Credreg credreg = dataManager.create(Credreg.class);
//                                for (int i = 0; i < row.getCellCount(); i++) {
//                                    Cell cell = row.getCell(i);
//                                    String columnName = CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, headerRow.get().getCell(i).getText());
//                                        Object value;
//                                        switch (cell.getType()) {
//                                            case EMPTY:
//                                                value = "";
//                                            case NUMBER:
//                                                value = cell.asNumber();
//                                                break;
//                                            case BOOLEAN:
//                                                value = cell.asBoolean();
//                                                break;
//                                            case STRING:
//                                                String text = cell.toString();
//                                                if ("IS_IMPAIRED".equals(columnName.toUpperCase())) {
//                                                    value = "ИСТИНА".equals(text);
//                                                } else {
//                                                    value = text;
//                                                }
//                                                break;
//                                            default:
//                                                value = cell.getValue();
//                                        }
//
//                                        if (value == null){
//                                            value = "";
//                                        }
//                                        String methodName = "set" + columnName;
//                                        Method method;
//                                    try {
//                                        method = Credreg.class.getMethod(methodName, value.getClass());
//                                        method.invoke(credreg, value);
//                                    } catch (NoSuchMethodException | IllegalAccessException |
//                                             InvocationTargetException e) {
//                                        notifications.create(Notifications.NotificationType.ERROR)
//                                                .withCaption(e.getMessage())
//                                                .show();
//                                    }
//                                }
//                                credregs.add(credreg);
//
//                                // If we've reached batch size or this is the last row, save the data
//                                try {
//                                    if (credregs.size() == batchSize || !sheet.openStream().iterator().hasNext()) {
//                                        dataManager.save(credregs);
//                                        credregs.clear();
//                                    }
//                                } catch (IOException e) {
//                                    throw new RuntimeException(e);
//                                }
//                            }
//                        });
//                    }
//                } catch (IOException e) {
//                    throw new RuntimeException(e);
//                }
//            } catch (RuntimeException e) {
//                throw new RuntimeException(e);
//            }
//        }
//    }


    @Subscribe("attachmentFileField")
    public void onAttachmentFileFieldFileUploadSucceed(SingleFileUploadField.FileUploadSucceedEvent event) {
        SaveContext saveContext = new SaveContext().setDiscardSaved(true);
        FileRef fileRef = attachmentFileField.getValue();
        if (fileRef != null) {
            try {
                try (InputStream is = fileStorage.openStream(fileRef)) {
                    try (ReadableWorkbook wb = new ReadableWorkbook(is)) {
                        Sheet sheet = wb.getFirstSheet();
                        try (Stream<Row> rows = sheet.openStream()) {
                            List<Credreg> batch = new ArrayList<>(10000);
                            LocalDateTime localDateTimeStart = LocalDateTime.now();
                            rows.skip(2)
                                    .forEach(row -> {
                                        Credreg credreg = dataManager.create(Credreg.class);
                                        CredregCompKey credregCompKey = dataManager.create(CredregCompKey.class);

                                        Cell cell0 = row.getCell(0);
                                        Cell cell1 = row.getCell(1);
                                        Cell cell2 = row.getCell(2);
                                        Cell cell3 = row.getCell(3);
                                        Cell cell4 = row.getCell(4);
                                        Cell cell5 = row.getCell(5);
                                        Cell cell6 = row.getCell(6);
                                        Cell cell7 = row.getCell(7);
                                        Cell cell8 = row.getCell(8);
                                        Cell cell9 = row.getCell(9);
                                        Cell cell10 = row.getCell(10);
                                        Cell cell11 = row.getCell(11);
                                        Cell cell12 = row.getCell(12);
                                        Cell cell13 = row.getCell(13);
                                        Cell cell14 = row.getCell(14);
                                        Cell cell15 = row.getCell(15);
                                        Cell cell16 = row.getCell(16);
                                        Cell cell17 = row.getCell(17);
                                        Cell cell18 = row.getCell(18);
                                        Cell cell19 = row.getCell(19);
                                        Cell cell20 = row.getCell(20);
                                        Cell cell21 = row.getCell(21);
                                        Cell cell22 = row.getCell(22);
                                        Cell cell23 = row.getCell(23);
                                        Cell cell24 = row.getCell(24);
                                        Cell cell25 = row.getCell(25);
                                        Cell cell26 = row.getCell(26);
                                        Cell cell27 = row.getCell(27);
                                        Cell cell28 = row.getCell(28);
                                        Cell cell29 = row.getCell(29);
                                        Cell cell30 = row.getCell(30);
                                        Cell cell31 = row.getCell(31);
                                        Cell cell32 = row.getCell(32);
                                        Cell cell33 = row.getCell(33);
                                        Cell cell34 = row.getCell(34);
                                        Cell cell35 = row.getCell(35);
                                        Cell cell36 = row.getCell(36);
                                        Cell cell37 = row.getCell(37);
                                        Cell cell38 = row.getCell(38);
                                        Cell cell39 = row.getCell(39);
                                        Cell cell40 = row.getCell(40);
                                        Cell cell41 = row.getCell(41);
                                        Cell cell42 = row.getCell(42);
                                        Cell cell43 = row.getCell(43);
                                        Cell cell44 = row.getCell(44);
                                        Cell cell45 = row.getCell(45);
                                        Cell cell46 = row.getCell(46);
                                        Cell cell47 = row.getCell(47);
                                        Cell cell48 = row.getCell(48);
                                        Cell cell49 = row.getCell(49);
                                        Cell cell50 = row.getCell(50);
                                        Cell cell51 = row.getCell(51);
                                        Cell cell52 = row.getCell(52);
                                        Cell cell53 = row.getCell(53);
                                        Cell cell54 = row.getCell(54);
                                        Cell cell55 = row.getCell(55);
                                        Cell cell56 = row.getCell(56);
                                        Cell cell57 = row.getCell(57);
                                        Cell cell58 = row.getCell(58);
                                        Cell cell59 = row.getCell(59);
                                        Cell cell60 = row.getCell(60);
                                        Cell cell61 = row.getCell(61);
                                        Cell cell62 = row.getCell(62);
                                        Cell cell63 = row.getCell(63);
                                        Cell cell64 = row.getCell(64);
                                        Cell cell65 = row.getCell(65);
                                        Cell cell66 = row.getCell(66);
                                        Cell cell67 = row.getCell(67);
                                        Cell cell68 = row.getCell(68);
                                        Cell cell69 = row.getCell(69);
                                        Cell cell70 = row.getCell(70);
                                        Cell cell71 = row.getCell(71);
                                        Cell cell72 = row.getCell(72);
                                        Cell cell73 = row.getCell(73);
                                        Cell cell74 = row.getCell(74);
                                        Cell cell75 = row.getCell(75);
                                        Cell cell76 = row.getCell(76);
                                        Cell cell77 = row.getCell(77);
                                        Cell cell78 = row.getCell(78);
                                        Cell cell79 = row.getCell(79);
                                        Cell cell80 = row.getCell(80);
                                        Cell cell81 = row.getCell(81);
                                        Cell cell82 = row.getCell(82);
                                        Cell cell83 = row.getCell(83);
                                        Cell cell84 = row.getCell(84);
                                        Cell cell85 = row.getCell(85);
                                        Cell cell86 = row.getCell(86);
                                        Cell cell87 = row.getCell(87);
                                        Cell cell88 = row.getCell(88);
                                        Cell cell89 = row.getCell(89);
                                        Cell cell90 = row.getCell(90);
                                        Cell cell91 = row.getCell(91);
                                        Cell cell92 = row.getCell(92);

                                        if (cell0.getType() != CellType.EMPTY){
                                            credreg.setSourceSystem(cell0.asString());
                                        } else if (cell0.getType() == CellType.EMPTY) {
                                            credreg.setSourceSystem("");
                                        }

                                        if (cell1.getType() != CellType.EMPTY){
                                            credreg.setOperationDate(cell1.asDate().toLocalDate());
                                        } else if (cell1.getType() == CellType.EMPTY) {
                                            credreg.setOperationDate(null);
                                        }

                                        if (cell2.getType() != CellType.EMPTY){
                                            credreg.setPrimaryContractNo(cell2.asString());
                                        } else if (cell2.getType() == CellType.EMPTY) {
                                            credreg.setPrimaryContractNo("");
                                        }

                                        if (cell3.getType() != CellType.EMPTY){
                                            credregCompKey.setEfBatchesInt(cell3.asNumber().longValue());
                                        } else if (cell3.getType() == CellType.EMPTY) {
                                            credregCompKey.setEfBatchesInt(null);
                                        }

                                        if (cell4.getType() != CellType.EMPTY){
                                            credregCompKey.setEfContract(cell4.asNumber().longValue());
                                        } else if (cell4.getType() == CellType.EMPTY) {
                                            credregCompKey.setEfBatchesInt(null);
                                        }

                                        if (cell5.getType() != CellType.EMPTY){
                                            credreg.setContractS(cell5.asNumber().longValue());
                                        }else if (cell5.getType() == CellType.EMPTY) {
                                            credreg.setContractS(null);
                                        }

                                        if (cell6.getType() != CellType.EMPTY){
                                            credreg.setTurnoverIntAmount(cell6.asNumber().longValue());
                                        } else if (cell6.getType() == CellType.EMPTY){
                                            credreg.setTurnoverIntAmount(null);
                                        }

                                        if (cell7.getType() != CellType.EMPTY){
                                            credreg.setTurnoverIntAmountCur(cell7.asNumber().longValue());
                                        } else if (cell7.getType() == CellType.EMPTY){
                                            credreg.setTurnoverIntAmountCur(null);
                                        }

                                        if (cell8.getType() != CellType.EMPTY){
                                            credreg.setTurnoverDebAmount(cell8.asNumber().longValue());
                                        } else if (cell8.getType() == CellType.EMPTY){
                                            credreg.setTurnoverDebAmount(null);
                                        }

                                        if (cell9.getType() != CellType.EMPTY){
                                            credreg.setTurnoverDebAmountCur(cell9.asNumber().longValue());
                                        } else if (cell9.getType() == CellType.EMPTY){
                                            credreg.setTurnoverDebAmountCur(null);
                                        }

                                        if (cell10.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebCurrentVal(cell10.asNumber().doubleValue());
                                        } else if (cell10.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebCurrentVal(null);
                                        }

                                        if (cell11.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebCurrentValCur(cell11.asNumber().doubleValue());
                                        } else if (cell11.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebCurrentValCur(null);
                                        }

                                        if (cell12.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebPastdueVal(cell12.asNumber().doubleValue());
                                        } else if (cell12.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebPastdueVal(null);
                                        }

                                        if (cell13.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebPastdueValCur(cell13.asNumber().doubleValue());
                                        } else if (cell13.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebPastdueValCur(null);
                                        }

                                        if (cell14.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebWriteOffVal(cell14.asNumber().doubleValue());
                                        } else if (cell14.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebWriteOffVal(null);
                                        }

                                        if (cell15.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebWriteOffValCur(cell15.asNumber().doubleValue());
                                        } else if (cell15.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebWriteOffValCur(null);
                                        }

                                        if (cell16.getType() != CellType.EMPTY){
                                            credreg.setRemnsIntCurrentVal(cell16.asNumber().doubleValue());
                                        } else if (cell16.getType() == CellType.EMPTY){
                                            credreg.setRemnsIntCurrentVal(null);
                                        }

                                        if (cell17.getType() != CellType.EMPTY){
                                            credreg.setRemnsIntCurrentValCur(cell17.asNumber().doubleValue());
                                        }else if (cell17.getType() == CellType.EMPTY){
                                            credreg.setRemnsIntCurrentValCur(null);
                                        }

                                        if (cell18.getType() != CellType.EMPTY){
                                            credreg.setRemnsIntPastdueVal(cell18.asNumber().doubleValue());
                                        } else if (cell18.getType() == CellType.EMPTY){
                                            credreg.setRemnsIntPastdueVal(null);
                                        }

                                        if (cell19.getType() != CellType.EMPTY){
                                            credreg.setRemnsIntPastdueValCur(cell19.asNumber().doubleValue());
                                        } else if (cell19.getType() == CellType.EMPTY){
                                            credreg.setRemnsIntPastdueValCur(null);
                                        }

                                        if (cell20.getType() != CellType.EMPTY){
                                            credreg.setRemnsIntWriteOffVal(cell20.asNumber().doubleValue());
                                        } else if (cell20.getType() == CellType.EMPTY){
                                            credreg.setRemnsIntWriteOffVal(null);
                                        }

                                        if (cell21.getType() != CellType.EMPTY){
                                            credreg.setRemnsIntWriteOffValCur(cell21.asNumber().doubleValue());
                                        } else if (cell21.getType() == CellType.EMPTY){
                                            credreg.setRemnsIntWriteOffValCur(null);
                                        }

                                        if (cell22.getType() != CellType.EMPTY && cell22.getType() == CellType.STRING){
                                            credreg.setCrFlProvBalAccS(cell22.asString());
                                        } else if (cell22.getType() != CellType.EMPTY && cell22.getType() == CellType.NUMBER) {
                                            credreg.setCrFlProvBalAccS(cell22.asNumber().toString());
                                        } else if (cell22.getType() == CellType.EMPTY){
                                            credreg.setCrFlProvBalAccS("");
                                        }

                                        if (cell23.getType() != CellType.EMPTY){
                                            credreg.setCrFlProvBalAccNb(cell23.asString());
                                        } else if (cell23.getType() == CellType.EMPTY){
                                            credreg.setCrFlProvBalAccNb("");
                                        }

                                        if (cell24.getType() != CellType.EMPTY){
                                            credreg.setCrFlProvBalAccMsfoS(cell24.asString());
                                        } else if (cell24.getType() == CellType.EMPTY){
                                            credreg.setCrFlProvBalAccMsfoS("");
                                        }

                                        if (cell25.getType() != CellType.EMPTY){
                                            credreg.setCrFlProvBalAccMsfoNb(cell25.asString());
                                        } else if (cell25.getType() == CellType.EMPTY){
                                            credreg.setCrFlProvBalAccMsfoNb("");
                                        }

                                        if (cell26.getType() != CellType.EMPTY){
                                            credreg.setCrFlProvVal(cell26.asNumber().longValue());
                                        } else if (cell26.getType() == CellType.EMPTY){
                                            credreg.setCrFlProvVal(null);
                                        }

                                        if (cell27.getType() != CellType.EMPTY){
                                            credreg.setCrFlProvValMsfo(cell27.asNumber().doubleValue());
                                        } else if (cell27.getType() == CellType.EMPTY){
                                            credreg.setCrFlProvValMsfo(null);
                                        }

                                        if (cell28.getType() != CellType.EMPTY){
                                            credreg.setRemnsDiscValueVal(cell28.asNumber().longValue());
                                        } else if (cell28.getType() == CellType.EMPTY){
                                            credreg.setRemnsDiscValueVal(null);
                                        }

                                        if (cell29.getType() != CellType.EMPTY){
                                            credreg.setRemnsDiscValueValCur(cell29.asNumber().longValue());
                                        } else if (cell29.getType() == CellType.EMPTY){
                                            credreg.setRemnsDiscValueValCur(null);
                                        }

                                        if (cell30.getType() != CellType.EMPTY){
                                            credreg.setRemnsCorrectionVal(cell30.asNumber().longValue());
                                        } else if (cell30.getType() == CellType.EMPTY){
                                            credreg.setRemnsCorrectionVal(null);
                                        }

                                        if (cell31.getType() != CellType.EMPTY){
                                            credreg.setRemnsCorrectionValCur(cell31.asNumber().longValue());
                                        } else if (cell31.getType() == CellType.EMPTY){
                                            credreg.setRemnsCorrectionValCur(null);
                                        }

                                        if (cell32.getType() != CellType.EMPTY){
                                            credreg.setRemnsDiscountVal(cell32.asNumber().doubleValue());
                                        } else if (cell32.getType() == CellType.EMPTY){
                                            credreg.setRemnsDiscountVal(null);
                                        }

                                        if (cell33.getType() != CellType.EMPTY){
                                            credreg.setRemnsDiscountValCur(cell33.asNumber().doubleValue());
                                        } else if (cell33.getType() == CellType.EMPTY){
                                            credreg.setRemnsDiscountValCur(null);
                                        }

                                        if (cell34.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebCurrBalaccS(cell34.asString());
                                        } else if (cell34.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebCurrBalaccS("");
                                        }

                                        if (cell35.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebCurrBalaccNb(cell35.asString());
                                        } else if (cell35.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebCurrBalaccNb("");
                                        }

                                        if (cell36.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebPastdBalaccS(cell36.asString());
                                        } else if (cell36.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebPastdBalaccS("");
                                        }

                                        if (cell37.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebPastdBalaccNb(cell37.asString());
                                        } else if (cell37.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebPastdBalaccNb("");
                                        }

                                        if (cell38.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebWriteBalaccS(cell38.asString());
                                        } else if (cell38.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebWriteBalaccS("");
                                        }

                                        if (cell39.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebWriteBalaccNb(cell39.asString());
                                        } else if (cell39.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebWriteBalaccNb("");
                                        }

                                        if (cell40.getType() != CellType.EMPTY){
                                            credreg.setRemnsIntCurrBalaccS(cell40.asString());
                                        } else if (cell40.getType() == CellType.EMPTY){
                                            credreg.setRemnsIntCurrBalaccS("");
                                        }

                                        if (cell41.getType() != CellType.EMPTY){
                                            credreg.setRemnsIntCurrBalaccNb(cell41.asString());
                                        } else if (cell41.getType() == CellType.EMPTY){
                                            credreg.setRemnsIntCurrBalaccNb("");
                                        }

                                        if (cell42.getType() != CellType.EMPTY){
                                            credreg.setRemnsIntPastdBalaccS(cell42.asString());
                                        } else if (cell42.getType() == CellType.EMPTY){
                                            credreg.setRemnsIntPastdBalaccS("");
                                        }

                                        if (cell43.getType() != CellType.EMPTY){
                                            credreg.setRemnsIntPastdBalaccNb(cell43.asString());
                                        } else if (cell43.getType() == CellType.EMPTY){
                                            credreg.setRemnsIntPastdBalaccNb("");
                                        }

                                        if (cell44.getType() != CellType.EMPTY){
                                            credreg.setPortfFlowBalAccountS(cell44.asString());
                                        } else if (cell44.getType() == CellType.EMPTY){
                                            credreg.setPortfFlowBalAccountS("");
                                        }

                                        if (cell45.getType() != CellType.EMPTY){
                                            credreg.setPortfFlowBalAccountNb(cell45.asString());
                                        } else if (cell45.getType() == CellType.EMPTY){
                                            credreg.setPortfFlowBalAccountNb("");
                                        }

                                        if (cell46.getType() != CellType.EMPTY){
                                            credreg.setPortfFlowMsfoBalAccS(cell46.asString());
                                        } else if (cell46.getType() == CellType.EMPTY){
                                            credreg.setPortfFlowMsfoBalAccS("");
                                        }

                                        if (cell47.getType() != CellType.EMPTY){
                                            credreg.setPortfFlowMsfoBalAccNb(cell47.asString());
                                        } else if (cell47.getType() == CellType.EMPTY){
                                            credreg.setPortfFlowMsfoBalAccNb("");
                                        }

                                        if (cell48.getType() != CellType.EMPTY){
                                            credreg.setRemnsCorrectionBalAccS(cell48.asString());
                                        } else if (cell48.getType() == CellType.EMPTY){
                                            credreg.setRemnsCorrectionBalAccS("");
                                        }

                                        if (cell49.getType() != CellType.EMPTY){
                                            credreg.setRemnsCorrectionBalAccNb(cell49.asString());
                                        } else if (cell49.getType() == CellType.EMPTY){
                                            credreg.setRemnsCorrectionBalAccNb("");
                                        }

                                        if (cell50.getType() != CellType.EMPTY){
                                            credreg.setRemnsDiscBalAccS(cell50.asString());
                                        } else if (cell50.getType() == CellType.EMPTY){
                                            credreg.setRemnsDiscBalAccS("");
                                        }

                                        if (cell51.getType() != CellType.EMPTY){
                                            credreg.setRemnsDiscBalAccNb(cell51.asString());
                                        } else if (cell51.getType() == CellType.EMPTY){
                                            credreg.setRemnsDiscBalAccNb("");
                                        }

                                        if (cell52.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebPastdueOpenDate(cell52.asDate().toLocalDate());
                                        } else if (cell52.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebPastdueOpenDate(null);
                                        }

                                        if (cell53.getType() != CellType.EMPTY){
                                            credreg.setRemnsIntPastdueOpenDate(cell53.asDate().toLocalDate());
                                        } else if (cell53.getType() == CellType.EMPTY){
                                            credreg.setRemnsIntPastdueOpenDate(null);
                                        }

                                        if (cell54.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebPastdueCloseDate(cell54.asDate().toLocalDate());//Проблема тут
                                        } else if (cell54.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebPastdueCloseDate(null);
                                        }

                                        if (cell55.getType() != CellType.EMPTY){
                                            credreg.setRemnsIntPastdueCloseDate(cell55.asDate().toLocalDate());
                                        } else if (cell55.getType() == CellType.EMPTY){
                                            credreg.setRemnsIntPastdueCloseDate(null);
                                        }

                                        if (cell56.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebWriteOffDate(cell56.asDate().toLocalDate());
                                        } else if (cell56.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebWriteOffDate(null);
                                        }

                                        if (cell57.getType() != CellType.EMPTY){
                                            credreg.setRemnsIntWriteOffDate(cell57.asDate().toLocalDate());
                                        } else if (cell57.getType() == CellType.EMPTY){
                                            credreg.setRemnsIntWriteOffDate(null);
                                        }

                                        if (cell58.getType() != CellType.EMPTY){
                                            credreg.setMaturityDate(cell58.asDate().toLocalDate());
                                        } else if (cell58.getType() == CellType.EMPTY){
                                            credreg.setMaturityDate(null);
                                        }

                                        if (cell59.getType() != CellType.EMPTY){
                                            credreg.setProlongationDate(cell59.asDate().toLocalDate());
                                        } else if (cell59.getType() == CellType.EMPTY){
                                            credreg.setProlongationDate(null);
                                        }

                                        if (cell60.getType() != CellType.EMPTY){
                                            credreg.setCrFlClassification(cell60.asString());
                                        } else if (cell60.getType() == CellType.EMPTY){
                                            credreg.setCrFlClassification("");
                                        }

                                        if (cell61.getType() != CellType.EMPTY){
                                            credreg.setUpdateDate(cell61.asDate().toLocalDate());
                                        } else if (cell61.getType() == CellType.EMPTY){
                                            credreg.setUpdateDate(null);
                                        }

                                        if (cell62.getType() != CellType.EMPTY){
                                            credreg.setUpdatedBy(cell62.asString());
                                        } else if (cell62.getType() == CellType.EMPTY){
                                            credreg.setUpdatedBy("");
                                        }

                                        if (cell63.getType() != CellType.EMPTY){
                                            credreg.setCrFlClassificationNb(cell63.asString());
                                        } else if (cell63.getType() == CellType.EMPTY){
                                            credreg.setCrFlClassificationNb("");
                                        }

                                        if (cell64.getType() != CellType.EMPTY){
                                            credreg.setRemnsLimVal(cell64.asNumber().longValue());
                                        } else if (cell64.getType() == CellType.EMPTY){
                                            credreg.setRemnsLimVal(null);
                                        }

                                        if (cell65.getType() != CellType.EMPTY){
                                            credreg.setRemnsLimValCur(cell65.asNumber().longValue());
                                        } else if (cell65.getType() == CellType.EMPTY){
                                            credreg.setRemnsLimValCur(null);
                                        }

                                        if (cell66.getType() != CellType.EMPTY && cell66.getType() == CellType.STRING){
                                            credreg.setRemnsLimBalAccS(cell66.asString());
                                        } else if (cell66.getType() != CellType.EMPTY && cell66.getType() == CellType.NUMBER){
                                            credreg.setRemnsLimBalAccS(cell66.asNumber().toString());
                                        }else if (cell66.getType() == CellType.EMPTY){
                                            credreg.setRemnsLimBalAccS("");
                                        }

                                        if (cell67.getType() != CellType.EMPTY){
                                            credreg.setRemnsLimBalAccNb(cell67.asString());
                                        } else if (cell67.getType() == CellType.EMPTY){
                                            credreg.setRemnsLimBalAccNb("");
                                        }

                                        if (cell68.getType() != CellType.EMPTY){
                                            credreg.setAccruedFinesPenalties(cell68.asNumber().longValue());
                                        } else if (cell68.getType() == CellType.EMPTY){
                                            credreg.setAccruedFinesPenalties(null);
                                        }

                                        if (cell69.getType() != CellType.EMPTY){
                                            credreg.setAccruedFinesPenaltiesCur(cell69.asNumber().longValue());
                                        } else if (cell69.getType() == CellType.EMPTY){
                                            credreg.setAccruedFinesPenaltiesCur(null);
                                        }

                                        if (cell70.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebtForgivenValue(cell70.asNumber().longValue());
                                        } else if (cell70.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebtForgivenValue(null);
                                        }

                                        if (cell71.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebtForgivenValueCur(cell71.asNumber().longValue());
                                        } else if (cell71.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebtForgivenValueCur(null);
                                        }

                                        if (cell72.getType() != CellType.EMPTY){
                                            credreg.setRemnsIntForgivenValue(cell72.asNumber().longValue());
                                        } else if (cell72.getType() == CellType.EMPTY){
                                            credreg.setRemnsIntForgivenValue(null);
                                        }

                                        if (cell73.getType() != CellType.EMPTY){
                                            credreg.setRefRemnsLimitAccountNo(cell73.asString());
                                        } else if (cell73.getType() == CellType.EMPTY){
                                            credreg.setRefRemnsLimitAccountNo("");
                                        }

                                        if (cell74.getType() != CellType.EMPTY){
                                            credreg.setRemnsPenaltyValue(cell74.asNumber().longValue());
                                        } else if (cell74.getType() == CellType.EMPTY){
                                            credreg.setRemnsPenaltyValue(null);
                                        }

                                        if (cell75.getType() != CellType.EMPTY){
                                            credreg.setRemnsPenaltyWriteOff(cell75.asNumber().longValue());
                                        } else if (cell75.getType() == CellType.EMPTY){
                                            credreg.setRemnsPenaltyWriteOff(null);
                                        }

                                        if (cell76.getType() != CellType.EMPTY){
                                            credreg.setRemnsPenaltyForgivenValue(cell76.asNumber().longValue());
                                        } else if (cell76.getType() == CellType.EMPTY){
                                            credreg.setRemnsPenaltyForgivenValue(null);
                                        }

                                        if (cell77.getType() != CellType.EMPTY){
                                            credreg.setProvisionRate(cell77.asNumber().doubleValue());
                                        } else if (cell77.getType() == CellType.EMPTY){
                                            credreg.setProvisionRate(null);
                                        }

                                        if (cell78.getType() != CellType.EMPTY){
                                            credreg.setActualIssueDate(cell78.asDate().toLocalDate());
                                        } else if (cell78.getType() != CellType.EMPTY){
                                            credreg.setActualIssueDate(null);
                                        }

                                        if (cell79.getType() != CellType.EMPTY){
                                            credreg.setActualReceivedPayment(cell79.asNumber().doubleValue());
                                        } else if (cell79.getType() == CellType.EMPTY){
                                            credreg.setActualReceivedPayment(null);
                                        }

                                        if (cell80.getType() != CellType.EMPTY){
                                            credreg.setRemnsDebtWriteOffVal(cell80.asNumber().longValue());
                                        } else if (cell80.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebtWriteOffVal(null);
                                        }

                                        if (cell81.getType() != CellType.EMPTY){
                                            credreg.setIsRestructured(cell81.asString());
                                        } else if (cell81.getType() == CellType.EMPTY){
                                            credreg.setIsRestructured("");
                                        }

                                        if (cell82.getType() != CellType.EMPTY){
                                            credreg.setRestructuringDate(cell82.asDate().toLocalDate());
                                        } else if (cell82.getType() == CellType.EMPTY){
                                            credreg.setRestructuringDate(null);
                                        }

                                        if (cell83.getType() != CellType.EMPTY){
                                            credreg.setIsImpaired(cell83.asString());
                                        } else if (cell83.getType() == CellType.EMPTY){
                                            credreg.setIsImpaired("");
                                        }

                                        if (cell84.getType() != CellType.EMPTY && cell84.getType() == CellType.NUMBER){
                                            credreg.setRemnsDebtWriteOffValCur(cell84.asNumber().longValue());
                                        } else if (cell84.getType() != CellType.EMPTY && cell84.getType() == CellType.STRING) {
                                            credreg.setRemnsDebtWriteOffValCur(Long.parseLong(cell84.asString()));
                                        } else if (cell84.getType() == CellType.EMPTY){
                                            credreg.setRemnsDebtWriteOffValCur(null);
                                        }

                                        if (cell85.getType() != CellType.EMPTY){
                                            credreg.setRemnsIntForgivenValueCur(cell85.asNumber().longValue());
                                        } else if (cell85.getType() == CellType.EMPTY){
                                            credreg.setRemnsIntForgivenValueCur(null);
                                        }

                                        if (cell86.getType() != CellType.EMPTY){
                                            credreg.setRefRemnsLimitAccountNoNb(cell86.asString());
                                        } else if (cell86.getType() == CellType.EMPTY){
                                            credreg.setRefRemnsLimitAccountNoNb("");
                                        }

                                        if (cell87.getType() != CellType.EMPTY){
                                            credreg.setRemnsPenaltyWriteOffCur(cell87.asNumber().longValue());
                                        } else if (cell87.getType() == CellType.EMPTY){
                                            credreg.setRemnsPenaltyWriteOffCur(null);
                                        }

                                        if (cell88.getType() != CellType.EMPTY){
                                            credreg.setRemnsPenaltyValueCur(cell88.asNumber().longValue());
                                        } else if (cell88.getType() == CellType.EMPTY){
                                            credreg.setRemnsPenaltyValueCur(null);
                                        }

                                        if (cell89.getType() != CellType.EMPTY){
                                            credreg.setRemnsPenaltyForgivenValCur(cell89.asNumber().longValue());
                                        } else if (cell89.getType() == CellType.EMPTY){
                                            credreg.setRemnsPenaltyForgivenValCur(null);
                                        }

                                        if (cell90.getType() != CellType.EMPTY){
                                            credreg.setRemnsDiscountAdd(cell90.asNumber().longValue());
                                        } else if (cell90.getType() == CellType.EMPTY){
                                            credreg.setRemnsDiscountAdd(null);
                                        }

                                        if (cell91.getType() != CellType.EMPTY){
                                            credreg.setRemnsDiscountValCurAdd(cell91.asNumber().longValue());
                                        } else if (cell91.getType() == CellType.EMPTY){
                                            credreg.setRemnsDiscountValCurAdd(null);
                                        }

                                        if (cell92.getType() != CellType.EMPTY){
                                            credreg.setRemnsDiscBalAccNbIdAdd(cell92.asString());
                                        } else if (cell92.getType() == CellType.EMPTY){
                                            credreg.setRemnsDiscBalAccNbIdAdd("");
                                        }

                                        System.out.println("$$$$ ROW #" + row.getRowNum() + " IS FINISHED $$$");

                                        credreg.setId(credregCompKey);
                                        batch.add(credreg);

                                        if (batch.size() == 10000) {
                                            excelDataImporter.saveObjectsListUsingSaveContext(batch);
                                            batch.clear();
                                        }
                                    });
                            if (!batch.isEmpty()) {
                                excelDataImporter.saveObjectsListUsingSaveContext(batch);
                                batch.clear();
                                LocalDateTime localDateTimeEnd = LocalDateTime.now();
                                System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$FINISHED$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
                                System.out.println("Start time:" + localDateTimeStart);
                                System.out.println("Start time:" + localDateTimeEnd);
                            }
                        }
                    }
                }
            } catch (IOException e) {
                notifications.create(Notifications.NotificationType.ERROR)
                        .withCaption(messages.getMessage(e.getMessage()))
                        .show();
            }
        } else {
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption(messages.getMessage("ФАЙЛ НЕ ЗАГРУЖЕН"))
                    .show();
        }
    }
}
