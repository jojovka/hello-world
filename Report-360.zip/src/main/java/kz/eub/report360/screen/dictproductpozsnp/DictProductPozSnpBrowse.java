package kz.eub.report360.screen.dictproductpozsnp;

import io.jmix.core.DataManager;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictProductPozSnp;
import kz.eub.report360.entity.User;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@UiController("r360_DictProductPozSnp.browse")
@UiDescriptor("dict-product-poz-snp-browse.xml")
@LookupComponent("dictProductPozSnpsTable")
public class DictProductPozSnpBrowse extends StandardLookup<DictProductPozSnp> {
    private static final Logger log = org.slf4j.LoggerFactory.getLogger(DictProductPozSnpBrowse.class);
    @Autowired
    private CollectionContainer<DictProductPozSnp> dictProductPozSnpsDc;
    @Autowired
    private DataManager dataManager;

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        getUser();
    }

    private void getUser() {
        try {
            List<DictProductPozSnp> dictProductPozSnps = dictProductPozSnpsDc.getMutableItems();

            for (DictProductPozSnp productPozSnp : dictProductPozSnps) {
                User user = dataManager.load(User.class).id(productPozSnp.getUserId()).one();
                productPozSnp.setUser(user);
            }
        } catch (Exception e) {
            log.error("Error", e);
        }
    }
}