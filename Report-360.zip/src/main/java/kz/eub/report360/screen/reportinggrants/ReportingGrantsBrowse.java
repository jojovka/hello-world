package kz.eub.report360.screen.reportinggrants;

import io.jmix.core.security.CurrentAuthentication;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.Action;
import io.jmix.ui.action.list.CreateAction;
import io.jmix.ui.action.list.EditAction;
import io.jmix.ui.action.list.RemoveAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.Reporting;
import kz.eub.report360.entity.ReportingGrants;
import kz.eub.report360.entity.User;
import kz.eub.report360.app.service.UtilityService;
import org.springframework.beans.factory.annotation.Autowired;

import javax.inject.Named;

@UiController("r360_ReportingGrants.browse")
@UiDescriptor("reporting-grants-browse.xml")
@LookupComponent("reportingGrantsTable")
public class ReportingGrantsBrowse extends StandardLookup<ReportingGrants> {

    private Reporting reporting;
    @Autowired
    private CollectionLoader<ReportingGrants> reportingGrantsDl;
    @Autowired
    ScreenBuilders screenBuilders;
    @Autowired
    GroupTable<ReportingGrants> reportingGrantsTable;
    @Autowired
    CollectionContainer<ReportingGrants> reportingGrantsDc;
    @Autowired
    UtilityService utilityService;
    @Autowired
    private CurrentAuthentication currentAuthentication;
    @Autowired
    private Button createBtn;
    @Autowired
    private Button editBtn;
    @Autowired
    private Button removeBtn;
    @Named("reportingGrantsTable.create")
    private CreateAction<ReportingGrants> reportingGrantsCreateAction;
    @Named("reportingGrantsTable.edit")
    private EditAction<ReportingGrants> reportingGrantsEditAction;
    @Named("reportingGrantsTable.remove")
    private RemoveAction<ReportingGrants> reportingGrantsRemoveAction;

    public void setParam(Reporting reporting) {
        this.reporting=reporting;
    }

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        if (utilityService.userHasReportingGrants((User) currentAuthentication.getUser(),reporting).equals(utilityService.R360_TOP_ACCESS_WITH_GRANT_OPTION)) {
            reportingGrantsCreateAction.setEnabled(true);
            reportingGrantsEditAction.setEnabled(true);
            reportingGrantsRemoveAction.setEnabled(true);
        } else if (utilityService.userHasReportingGrants((User) currentAuthentication.getUser(), reporting).equals(utilityService.REPORT_ACCESS_WITH_GRANT_OPTION)) {
            reportingGrantsCreateAction.setEnabled(false);
            reportingGrantsEditAction.setEnabled(false);
            reportingGrantsRemoveAction.setEnabled(false);
        }
        reportingGrantsDl.setParameter("reporting",reporting);
        reportingGrantsDl.load();
    }

    @Subscribe("reportingGrantsTable.create")
    public void onReportingGrantsCreate(Action.ActionPerformedEvent event) {
        ReportingGrantsEdit screen = screenBuilders.editor(reportingGrantsTable)
                .withScreenClass(ReportingGrantsEdit.class)
                .newEntity()
                .withOpenMode(OpenMode.DIALOG)
                .build();

        screen.setParam(reporting);
        screen.addAfterCloseListener(afterCloseEvent -> getScreenData().loadAll());
        screen.show();
    }

}