package kz.eub.report360.screen.errcardclient;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.ErrCardClient;

@UiController("r360_ErrCardClient.browse")
@UiDescriptor("err-card-client-browse.xml")
@LookupComponent("errCardClientsTable")
public class ErrCardClientBrowse extends StandardLookup<ErrCardClient> {
}