package kz.eub.report360.screen.dictratingsnp;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictRatingSnp;

@UiController("r360_DictRatingSnp.edit")
@UiDescriptor("dict-rating-snp-edit.xml")
@EditedEntityContainer("dictRatingSnpDc")
public class DictRatingSnpEdit extends StandardEditor<DictRatingSnp> {
}