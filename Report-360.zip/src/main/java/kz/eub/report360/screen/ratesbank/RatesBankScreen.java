package kz.eub.report360.screen.ratesbank;

import io.jmix.charts.component.StockChart;
import io.jmix.ui.component.EntityComboBox;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.report360.entity.RateDto;
import kz.eub.report360.app.service.RatesService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Calendar;
import java.util.List;

@UiController("r360_RatesBankScreen")
@UiDescriptor("rates-bank-screen.xml")
public class RatesBankScreen extends Screen {

    @Autowired
    private RatesService ratesService;
    @Autowired
    private CollectionContainer<RateDto> bankRatesDc;
    @Autowired
    private CollectionContainer<RateDto> currenciesDc;
    @Autowired
    private CollectionContainer<RateDto> bloombergRatesDc;
    @Autowired
    private EntityComboBox<RateDto> currencyFld;
    @Autowired
    private StockChart ratesChart;

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        loadCurrencies();
    }

    private void loadCurrencies() {
        Calendar cal = Calendar.getInstance();
        cal.set(2022, 5, 16);
        List<RateDto> ratesList = ratesService.getAllCurrencyRates(cal.getTime());
        currenciesDc.getMutableItems().clear();
        currenciesDc.getMutableItems().addAll(ratesList);
        bankRatesDc.getMutableItems().clear();
        bloombergRatesDc.getMutableItems().clear();
    }

    private void loadBankRates(String code) {
        List<RateDto> ratesList = ratesService.getCurrencyRates(code);
        bankRatesDc.getMutableItems().clear();
        bankRatesDc.getMutableItems().addAll(ratesList);
    }

    private void loadBloombergRates(String code) {
        List<RateDto> bloombergRates = ratesService.getBloombergRates(code);
        bloombergRatesDc.getMutableItems().clear();
        bloombergRatesDc.getMutableItems().addAll(bloombergRates);
    }

    @Subscribe("currencyFld")
    public void onCurrencyFldValueChange(HasValue.ValueChangeEvent<RateDto> event) {
        if (event.getValue() != null) {
            String currencyCode = event.getValue().getCode().substring(0, 3);
            loadBankRates(currencyCode);
            loadBloombergRates(currencyCode);
            ratesChart.repaint();
        }
    }

}