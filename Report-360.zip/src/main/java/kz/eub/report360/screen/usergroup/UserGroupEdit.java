package kz.eub.report360.screen.usergroup;

import io.jmix.ui.Notifications;
import io.jmix.ui.component.TextField;
import io.jmix.ui.component.TextInputField;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.UserGroup;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("r360_UserGroup.edit")
@UiDescriptor("user-group-edit.xml")
@EditedEntityContainer("userGroupDc")
public class UserGroupEdit extends StandardEditor<UserGroup> {
    @Autowired
    private TextField<String> codeField;
    @Autowired
    private TextField<String> nameField;
    @Autowired
    protected Notifications notifications;

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        if (getEditedEntity().getName() == null && getEditedEntity().getCode() == null) {
            nameField.setEditable(true);
            codeField.setEditable(true);
        }
    }

    @Subscribe("codeField")
    protected void onTextFieldTextChange(TextInputField.TextChangeEvent event) {
        notifications.create()
                .withCaption("Код добавлен: " + event.getText())
                .show();
    }
}