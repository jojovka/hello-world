package kz.eub.report360.screen.dictbasketsnp;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictBasketSnp;

@UiController("r360_DictBasketSnp.edit")
@UiDescriptor("dict-basket-snp-edit.xml")
@EditedEntityContainer("dictBasketSnpDc")
public class DictBasketSnpEdit extends StandardEditor<DictBasketSnp> {
}