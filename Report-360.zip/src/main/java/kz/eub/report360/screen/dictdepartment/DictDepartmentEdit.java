package kz.eub.report360.screen.dictdepartment;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictDepartment;

@UiController("r360_DictDepartment.edit")
@UiDescriptor("dict-department-edit.xml")
@EditedEntityContainer("dictDepartmentDc")
public class DictDepartmentEdit extends StandardEditor<DictDepartment> {
}