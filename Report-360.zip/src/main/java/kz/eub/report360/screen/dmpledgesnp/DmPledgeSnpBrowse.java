package kz.eub.report360.screen.dmpledgesnp;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DmPledgeSnp;

@UiController("r360_DmPledgeSnp.browse")
@UiDescriptor("dm-pledge-snp-browse.xml")
@LookupComponent("dmPledgeSnpsTable")
public class DmPledgeSnpBrowse extends StandardLookup<DmPledgeSnp> {
}