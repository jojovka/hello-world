package kz.eub.report360.screen.employee;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.Employee;

@UiController("r360_Employee.edit")
@UiDescriptor("employee-edit.xml")
@EditedEntityContainer("employeeDc")
public class EmployeeEdit extends StandardEditor<Employee> {
}