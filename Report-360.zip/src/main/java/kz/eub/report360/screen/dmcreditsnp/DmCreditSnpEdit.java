package kz.eub.report360.screen.dmcreditsnp;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DmCreditSnp;

@UiController("r360_DmCreditSnp.edit")
@UiDescriptor("dm-credit-snp-edit.xml")
@EditedEntityContainer("dmCreditSnpDc")
public class DmCreditSnpEdit extends StandardEditor<DmCreditSnp> {
}