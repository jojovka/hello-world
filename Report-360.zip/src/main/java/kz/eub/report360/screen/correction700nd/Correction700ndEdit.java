package kz.eub.report360.screen.correction700nd;

import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.Correction700nd;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@UiController("r360_Correction700nd.edit")
@UiDescriptor("correction700nd-edit.xml")
@EditedEntityContainer("correction700ndDc")
public class Correction700ndEdit extends StandardEditor<Correction700nd> {
    @Autowired
    private CurrentUserSubstitution currentUserSubstitution;
    @Autowired
    private ComboBox<String> rezField;
    @Autowired
    private ComboBox<String> econField;
    @Autowired
    private ComboBox<String> curField;

    @Subscribe
    public void onInitEntity(InitEntityEvent<Correction700nd> event) {
        List<String> rezFieldList = new ArrayList<>();
        rezFieldList.add("1");
        rezFieldList.add("2");
        rezField.setOptionsList(rezFieldList);

        List<String> econFieldList = new ArrayList<>();
        econFieldList.add("0");
        econFieldList.add("1");
        econFieldList.add("2");
        econFieldList.add("3");
        econFieldList.add("4");
        econFieldList.add("5");
        econFieldList.add("6");
        econFieldList.add("7");
        econFieldList.add("8");
        econFieldList.add("9");
        econField.setOptionsList(econFieldList);

        List<String> curFieldList = new ArrayList<>();
        curFieldList.add("1");
        curFieldList.add("2");
        curFieldList.add("3");
        curField.setOptionsList(curFieldList);
    }
    
    @Subscribe
    public void onBeforeClose(BeforeCloseEvent event) {
        Correction700nd item = getEditedEntity();
        item.setCreatedBy(currentUserSubstitution.getEffectiveUser().getUsername());
        item.setCreatedDate(new Date());
    }

}