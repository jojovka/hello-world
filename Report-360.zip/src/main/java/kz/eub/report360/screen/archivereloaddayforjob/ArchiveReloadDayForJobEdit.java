package kz.eub.report360.screen.archivereloaddayforjob;

import io.jmix.core.Messages;
import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import io.jmix.ui.Notifications;
import io.jmix.ui.component.Button;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.ArchiveReloadDayForJob;
import org.eclipse.persistence.exceptions.DatabaseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Date;

@UiController("r360_ArchiveReloadDayForJob.edit")
@UiDescriptor("archive-reload-day-for-job-edit.xml")
@EditedEntityContainer("archiveReloadDayForJobDc")
public class ArchiveReloadDayForJobEdit extends StandardEditor<ArchiveReloadDayForJob> {

    @Autowired
    private CurrentUserSubstitution currentUserSubstitution;
    @Autowired
    private Notifications notifications;
    @Autowired
    private Messages messages;

    @Subscribe
    public void onBeforeCommitChanges(BeforeCommitChangesEvent event) {
        ArchiveReloadDayForJob item = getEditedEntity();
        UserDetails user = currentUserSubstitution.getAuthenticatedUser();
        item.setUsername(user.getUsername());
        Date date = new Date();
        item.setUpdateDatetime(date);
    }

    @Subscribe("commitAndCloseBtn")
    public void onCommitAndCloseBtnClick(Button.ClickEvent event) {
        try {
            closeWithCommit();
        } catch (DatabaseException de) {
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption(messages.getMessage("databaseUniqueConstraintViolation.IDX_ARCHIVE_RELOAD_DAY_FOR_JOB_ON_ARCH_DATE"))
                    .show();
        } catch (Exception e) {
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption(messages.getMessage("databaseUniqueConstraintViolation.IDX_ARCHIVE_RELOAD_DAY_FOR_JOB_ON_ARCH_DATE"))
                    .show();
        }
    }


}