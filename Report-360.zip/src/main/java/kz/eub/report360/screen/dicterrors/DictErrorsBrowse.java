package kz.eub.report360.screen.dicterrors;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictErrors;

@UiController("r360_DictErrors.browse")
@UiDescriptor("dict-errors-browse.xml")
@LookupComponent("dictErrorsTable")
public class DictErrorsBrowse extends StandardLookup<DictErrors> {
}