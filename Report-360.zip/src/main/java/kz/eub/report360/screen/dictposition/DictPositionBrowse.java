package kz.eub.report360.screen.dictposition;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictPosition;

@UiController("r360_DictPosition.browse")
@UiDescriptor("dict-position-browse.xml")
@LookupComponent("dictPositionsTable")
public class DictPositionBrowse extends StandardLookup<DictPosition> {
}