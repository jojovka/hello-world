package kz.eub.report360.screen.reporting;

import io.jmix.core.DataManager;
import io.jmix.core.security.CurrentAuthentication;
import io.jmix.reports.entity.Report;
import io.jmix.ui.Notifications;
import io.jmix.ui.component.BrowserFrame;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.FileStorageResource;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.model.InstanceLoader;
import io.jmix.ui.navigation.Route;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.Reporting;
import kz.eub.report360.entity.ReportingApprov;
import kz.eub.report360.entity.ReportingType;
import kz.eub.report360.entity.User;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

@UiController("r360_Reporting.edit")
@UiDescriptor("reporting-edit.xml")
@EditedEntityContainer("reportingDc")
@Route(value = "reporting/edit", parentPrefix = "reporting")
public class ReportingEdit extends StandardEditor<Reporting> {
    @Autowired
    private BrowserFrame fileBrowserFrame;
    @Autowired
    private InstanceContainer<Reporting> reportingDc;
    @Autowired
    private InstanceLoader<Reporting> reportingDl;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private ComboBox<String> nameField;
    @Autowired
    private CurrentAuthentication currentAuthentication;
    @Autowired
    private Notifications notifications;

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        refreshFilePreview();
        reportingDl.load();
    }

    @Subscribe(id = "reportingDc", target = Target.DATA_CONTAINER)
    public void onReportingDcItemPropertyChange(InstanceContainer.ItemPropertyChangeEvent<Reporting> event) {
        if ("file".equals(event.getProperty())) {
            refreshFilePreview();
        }
    }

    public List<Report> getOrdinaryReport() {
        return dataManager.load(Report.class)
                .all().list();
    }

    private void refreshFilePreview() {
        Reporting reporting = getEditedEntity();
        if (reporting.getFile() != null) {
            fileBrowserFrame.setSource(FileStorageResource.class)
                    .setFileReference(reporting.getFile())
                    .setMimeType(reporting.getFile().getContentType());
        }
    }

    @Subscribe("reportingTypeField")
    public void onReportingTypeFieldValueChange(HasValue.ValueChangeEvent<ReportingType> event) {
        if (Objects.equals(event.getValue(), ReportingType.R360_REGULAR)) {
            nameField.setOptionsList(getOrdinaryReport().stream().map(Report::getName).collect(Collectors.toList()));
        }
    }

    @Subscribe("nameField")
    public void onNameFieldValueChange(HasValue.ValueChangeEvent<Report> event) {
        Reporting reporting = getEditedEntity();
        if (reportingDc.getItem().getReportingType() == ReportingType.R360_REGULAR) {
            UUID reportId = getOrdinaryReport().stream()
                    .filter(report -> Objects.equals(report.getName(), event.getValue()))
                    .map(Report::getId)
                    .collect(Collectors.toList()).get(0);
            reporting.setReportId(reportId);
        }
    }


    @Subscribe
    public void onInitEntity(InitEntityEvent<Reporting> event) {
        event.getEntity().setDeveloperUserLog((User) currentAuthentication.getUser());
    }

    @Subscribe
    public void onBeforeCommitChanges(BeforeCommitChangesEvent event) {
        if (getEditedEntity().getReportingType() == null) {
            notifications.create()
                    .withCaption("Укажите тип отчета")
                    .show();
            event.preventCommit();
        } else if (getEditedEntity().getReportingType() == ReportingType.R360_MATRIX
                || getEditedEntity().getReportingType() == ReportingType.R360_DYNAMIC
                || getEditedEntity().getReportingType() == ReportingType.R360_HYBRID) {
            notifications.create()
                    .withCaption("При выборе тип отчета выберите только Обычный отчет, остальные типы отчетов пока не работает")
                    .show();
            event.preventCommit();
        }
    }
}