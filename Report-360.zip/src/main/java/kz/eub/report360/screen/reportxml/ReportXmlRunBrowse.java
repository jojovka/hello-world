package kz.eub.report360.screen.reportxml;

import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.Action;
import io.jmix.ui.action.list.EditAction;
import io.jmix.ui.component.Table;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.ReportXml;
import org.springframework.beans.factory.annotation.Autowired;

import javax.inject.Named;

@UiController("r360_ReportXmlRun.browse")
@UiDescriptor("report-xml-run-browse.xml")
@LookupComponent("reportXmlsTable")
public class ReportXmlRunBrowse extends StandardLookup<ReportXml> {

    @Named("reportXmlsTable.edit")
    private EditAction<ReportXml> reportXmlTableEdit;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private Table<ReportXml> reportXmlsTable;

    @Subscribe
    public void onInit(InitEvent event) {
        reportXmlTableEdit.setScreenId("r360_ReportXmlRun.edit");
    }

    @Subscribe("reportXmlsTable.edit")
    public void onEditActionPerformed(Action.ActionPerformedEvent event) {
        screenBuilders.editor(reportXmlsTable)
                .withScreenId("r360_ReportXmlRun.edit")
                .withOpenMode(OpenMode.DIALOG)
                .build()
                .show();
    }

    
}