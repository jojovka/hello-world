package kz.eub.report360.screen.dictresponsiblematrix;

import io.jmix.core.DataManager;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictDepartment;
import kz.eub.report360.entity.DictResponsibleMatrix;
import kz.eub.report360.entity.User;
import kz.eub.report360.entity.UserGroup;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@UiController("r360_DictResponsibleMatrix.browse")
@UiDescriptor("dict-responsible-matrix-browse.xml")
@LookupComponent("dictResponsibleMatrixesTable")
public class DictResponsibleMatrixBrowse extends StandardLookup<DictResponsibleMatrix> {
    @Autowired
    private CollectionContainer<DictResponsibleMatrix> dictResponsibleMatrixesDc;
    @Autowired
    private DataManager dataManager;

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        getUserGroupDep();
    }

    private void getUserGroupDep() {
        List<DictResponsibleMatrix> matrixList = dictResponsibleMatrixesDc.getMutableItems();

        for (DictResponsibleMatrix matrix : matrixList) {
            UserGroup userGroup = dataManager.load(UserGroup.class).id(matrix.getDrmUserGroupId()).one();
            matrix.setUserGroup(userGroup);

            User user = dataManager.load(User.class).id(matrix.getDrmUserId()).one();
            matrix.setUser(user);

            DictDepartment department = dataManager.load(DictDepartment.class).id(matrix.getDrmBranchId()).one();
            matrix.setBranch(department);
        }
    }
}