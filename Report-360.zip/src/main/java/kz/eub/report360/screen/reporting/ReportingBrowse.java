package kz.eub.report360.screen.reporting;

import io.jmix.core.DataManager;
import io.jmix.core.LoadContext;
import io.jmix.core.Messages;
import io.jmix.core.Metadata;
import io.jmix.reports.entity.Report;
import io.jmix.ui.Notifications;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.Action;
import io.jmix.ui.action.list.RemoveAction;
import io.jmix.ui.component.Component;
import io.jmix.ui.component.Label;
import io.jmix.ui.component.Table;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.Reporting;
import org.springframework.beans.factory.annotation.Autowired;

import javax.inject.Named;
import java.util.UUID;

@UiController("r360_Reporting.browse")
@UiDescriptor("reporting-browse.xml")
@LookupComponent("reportingTable")
public class ReportingBrowse extends StandardLookup<Reporting> {

}