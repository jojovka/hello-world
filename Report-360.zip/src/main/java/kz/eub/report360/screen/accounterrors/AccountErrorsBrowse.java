package kz.eub.report360.screen.accounterrors;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.AccountErrors;

@UiController("r360_AccountErrors.browse")
@UiDescriptor("account-errors-browse.xml")
@LookupComponent("accountErrorsTable")
public class AccountErrorsBrowse extends StandardLookup<AccountErrors> {
}