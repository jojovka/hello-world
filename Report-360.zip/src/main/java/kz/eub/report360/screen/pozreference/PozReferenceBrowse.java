package kz.eub.report360.screen.pozreference;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.PozReference;

@UiController("r360_PozReference.browse")
@UiDescriptor("poz-reference-browse.xml")
@LookupComponent("pozReferencesTable")
public class PozReferenceBrowse extends StandardLookup<PozReference> {
}