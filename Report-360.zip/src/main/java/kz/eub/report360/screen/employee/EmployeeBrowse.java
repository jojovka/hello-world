package kz.eub.report360.screen.employee;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.Employee;

@UiController("r360_Employee.browse")
@UiDescriptor("employee-browse.xml")
@LookupComponent("employeesTable")
public class EmployeeBrowse extends StandardLookup<Employee> {
}