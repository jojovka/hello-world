package kz.eub.report360.screen.dictrefproduct;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictRefProduct;

@UiController("r360_DictRefProduct.browse")
@UiDescriptor("dict-ref-product-browse.xml")
@LookupComponent("dictRefProductsTable")
public class DictRefProductBrowse extends StandardLookup<DictRefProduct> {
}