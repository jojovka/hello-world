package kz.eub.report360.screen.reportingapprov;

import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.Reporting;
import kz.eub.report360.entity.ReportingApprov;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("r360_ReportingApprov.limited")
@UiDescriptor("reporting-approv-limited.xml")
@LookupComponent("reportingApprovesTable")
public class ReportingApprovLimited extends StandardLookup<ReportingApprov> {
    @Autowired
    private CollectionLoader<ReportingApprov> reportingApprovesDl;

    @Autowired
    private CollectionContainer<ReportingApprov> reportingApprovesDc;

    private Reporting reporting;

    public void setParam(Reporting reporting) {
        this.reporting = reporting;
    }

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        reportingApprovesDl.setParameter("reporting", reporting);
        reportingApprovesDl.load();
    }
}