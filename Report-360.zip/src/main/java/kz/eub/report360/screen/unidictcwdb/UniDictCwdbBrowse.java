package kz.eub.report360.screen.unidictcwdb;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.UniDictCwdb;

@UiController("r360_UniDictCwdb.browse")
@UiDescriptor("uni-dict-cwdb-browse.xml")
@LookupComponent("uniDictCwdbsTable")
public class UniDictCwdbBrowse extends StandardLookup<UniDictCwdb> {
}