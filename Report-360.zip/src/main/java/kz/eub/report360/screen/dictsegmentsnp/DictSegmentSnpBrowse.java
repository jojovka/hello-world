package kz.eub.report360.screen.dictsegmentsnp;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictSegmentSnp;

@UiController("r360_DictSegmentSnp.browse")
@UiDescriptor("dict-segment-snp-browse.xml")
@LookupComponent("dictSegmentSnpsTable")
public class DictSegmentSnpBrowse extends StandardLookup<DictSegmentSnp> {
}