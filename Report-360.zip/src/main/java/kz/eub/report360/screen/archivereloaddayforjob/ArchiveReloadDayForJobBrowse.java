package kz.eub.report360.screen.archivereloaddayforjob;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.ArchiveReloadDayForJob;

@UiController("r360_ArchiveReloadDayForJob.browse")
@UiDescriptor("archive-reload-day-for-job-browse.xml")
@LookupComponent("archiveReloadDayForJobsTable")
public class ArchiveReloadDayForJobBrowse extends StandardLookup<ArchiveReloadDayForJob> {
}