package kz.eub.report360.screen.dictrecoverysnp;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictRecoverySnp;

@UiController("r360_DictRecoverySnp.edit")
@UiDescriptor("dict-recovery-snp-edit.xml")
@EditedEntityContainer("dictRecoverySnpDc")
public class DictRecoverySnpEdit extends StandardEditor<DictRecoverySnp> {
}