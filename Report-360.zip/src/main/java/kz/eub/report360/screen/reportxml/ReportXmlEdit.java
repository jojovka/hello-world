package kz.eub.report360.screen.reportxml;

import io.jmix.ui.Notifications;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.Action;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.CheckBox;
import io.jmix.ui.component.DateField;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.SourceCodeEditor;
import io.jmix.ui.component.TabSheet;
import io.jmix.ui.component.Table;
import io.jmix.ui.component.TextField;
import io.jmix.ui.download.DownloadFormat;
import io.jmix.ui.download.Downloader;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.model.InstanceLoader;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.ReportXml;
import kz.eub.report360.entity.ReportXmlHist;
import kz.eub.report360.entity.ReportXmlParam;
import kz.eub.report360.entity.ReportXmlType;
import kz.eub.report360.screen.reportxmlhist.ReportXmlHistEdit;
import kz.eub.report360.screen.reportxmlparam.ReportXmlParamEdit;
import kz.eub.report360.app.service.UtilityService;
import kz.eub.report360.app.service.XMLService;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Objects;


@UiController("r360_ReportXml.edit")
@UiDescriptor("report-xml-edit.xml")
@EditedEntityContainer("reportXmlDc")
public class ReportXmlEdit extends StandardEditor<ReportXml> {
    @Autowired
    private XMLService xmlService;
    @Autowired
    private UtilityService utilityService;
    @Autowired
    private SourceCodeEditor xmlFieldField;
    @Autowired
    private SourceCodeEditor xsdFieldField;
    @Autowired
    private SourceCodeEditor functionFieldField;
    @Autowired
    private InstanceContainer<ReportXml> reportXmlDc;
    @Autowired
    private Notifications notifications;
    @Autowired
    private Downloader downloader;
    @Autowired
    private DateField<Date> reportDateField;
    @Autowired
    private CheckBox checkBoxZip;
    @Autowired
    private CheckBox checkBoxXsd;
    @Autowired
    private CheckBox checkBoxSelect;
    @Autowired
    private CheckBox checkBoxManifest;
    @Autowired
    private InstanceLoader<ReportXml> reportXmlDl;
    @Autowired
    private CollectionLoader<ReportXmlHist> reportXmlHistDl;
    @Autowired
    private CollectionLoader<ReportXmlParam> reportXmlParamDl;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private Table<ReportXmlHist> reportXmlHistTable;
    @Autowired
    private Table<ReportXmlParam> reportXmlParamTable;
    @Autowired
    private TabSheet tabSheetXml;
    @Autowired
    private TextField<String> codeField;
    Date dateRep;

    @Subscribe("checkXML")
    public void onCheckXMLClick(Button.ClickEvent event) {
        onCheckXML();
        SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyy");
        StringBuilder stringBuilder = new StringBuilder();
        if (reportXmlDc.getItem().getRepXmlType() == ReportXmlType.XML) {
            try {
                if (checkBoxSelect.isChecked()) {
                    downloader.download(xmlService.getByteArrayDataProvider(reportXmlDc.getItem().getXmlField()),
                            stringBuilder.append("Select_").append(dateFormat.format(dateRep)).append(".txt").toString(),
                            DownloadFormat.TEXT);
                }
                if (checkBoxZip.isChecked() && !checkBoxManifest.isChecked()) {
                    generateZip(xmlFieldField.getValue());
                } else if (checkBoxZip.isChecked() && checkBoxManifest.isChecked()) {
                    generateZipManifest(xmlFieldField.getValue());
                } else if (!checkBoxZip.isChecked() && checkBoxManifest.isChecked()) {
                    downloadXml(xmlFieldField.getValue());
                    downloadManifest();
                } else {
                    downloadXml(xmlFieldField.getValue());
                }
            } catch (Exception e) {
                notifications.create(Notifications.NotificationType.ERROR)
                        .withCaption("Ошибка")
                        .withDescription("При формировании xml произошла ошибка:" + e.getMessage()).show();
            }
        } else if (reportXmlDc.getItem().getRepXmlType() == ReportXmlType.TXT) {
            try {
                if (checkBoxSelect.isChecked()) {
                    downloader.download(xmlService.getByteArrayDataProvider(reportXmlDc.getItem().getFunctionField()),
                            stringBuilder.append("Select_").append(dateFormat.format(dateRep)).append(".txt").toString(),
                            DownloadFormat.TEXT);
                }
                downloadXmlTxt(functionFieldField.getValue());
            } catch (Exception e) {
                notifications.create(Notifications.NotificationType.ERROR)
                        .withCaption("Ошибка")
                        .withDescription("При формировании текстового файла произошла ошибка: " + e.getMessage()).show();
            }
        }
    }

    private void downloadXmlZip(byte[] content) {
        downloader.download(content, createXmlAndZipName() + ".zip", DownloadFormat.ZIP);
    }

    public void generateZip(String xml) throws Exception {
        byte[] xmlContent = xmlService.getXml(xml, getEditedEntity().getDataStore());
        downloadXmlZip(xmlService.getZipFile(packXml(xmlContent)));
    }

    public void generateZipManifest(String xml) throws Exception {
        byte[] xmlContent = xmlService.getXml(xml, getEditedEntity().getDataStore());
        downloadXmlZip(xmlService.getZipFile(packXmlAndManifest(xmlContent)));
    }

    public void downloadXml(String xml) throws Exception {
        byte[] xmlContent = xmlService.getXml(xml, getEditedEntity().getDataStore());
        downloader.download(xmlContent, createXmlAndZipName() + ".xml", DownloadFormat.XML);
    }

    public void downloadManifest() throws Exception {
        dateRep = reportDateField.getValue();
        String codeManifestContent = utilityService.getAppSettingVal("XML_MANIFEST_CODE");
        if (codeManifestContent.equals("No results")) {
            codeManifestContent=reportXmlDc.getItem().getCode();
        }
        String nameManifest = "usci_manifest";
        byte[] manifestContent = xmlService.getManifestXml(dateRep, codeManifestContent);
        downloader.download(manifestContent, nameManifest + ".xml", DownloadFormat.XML);
    }

    public void downloadXmlTxt(String func) throws Exception {
        String xmlContent = xmlService.getTxtResult(func, getEditedEntity().getDataStore());
        downloader.download(xmlContent.getBytes(), createXmlAndZipName() + ".txt", DownloadFormat.TEXT);
    }

    public HashMap<String, byte[]> packXml(byte[] xmlContent) {
        HashMap<String, byte[]> map;
        map = new HashMap<>();
        map.put(createXmlAndZipName() + ".xml", xmlContent);
        return map;
    }

    public HashMap<String, byte[]> packXmlAndManifest(byte[] xmlContent) throws Exception {
        dateRep = reportDateField.getValue();
        String nameManifest = "usci_manifest";
        HashMap<String, byte[]> map;
        String codeXmlManifest = utilityService.getAppSettingVal("XML_MANIFEST_CODE");
        if (codeXmlManifest.equals("No results")) {
            codeXmlManifest = reportXmlDc.getItem().getCode();
        }
        byte[] outManifest = xmlService.getManifestXml(dateRep, codeXmlManifest);
        map = new HashMap<>();
        map.put(createXmlAndZipName() + ".xml", xmlContent);
        map.put(nameManifest + ".xml", outManifest);
        return map;
    }

    public String createXmlAndZipName() {
        String formatPattern = "ddMMyyyy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(formatPattern);
        String currentDate = simpleDateFormat.format(new Date());
        return codeField.getValue() + "_" + currentDate;
    }

    public void checkXmlReportDataForm() {
        if (reportDateField.isVisible()) {
            if (reportDateField.getValue() == null) {
                notifications.create(Notifications.NotificationType.WARNING)
                        .withCaption("Следует указать дату отчета")
                        .show();
                return;
            }
            dateRep = reportDateField.getValue();
        }
        if (reportXmlDc.getItem().getRepXmlType() == null) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Следует указать тип отчета")
                    .show();
        } else if (reportXmlDc.getItem().getRepXmlType() == ReportXmlType.XML) {
            if (xmlFieldField.getValue() == null) {
                notifications.create(Notifications.NotificationType.WARNING)
                        .withCaption("Следует указать SQL запрос для получения xml")
                        .show();
                return;
            }
            if (Boolean.TRUE.equals(checkBoxXsd.getValue())) {
                if (xsdFieldField.getValue() == null) {
                    notifications.create(Notifications.NotificationType.WARNING)
                            .withCaption("Следует указать xsd схему")
                            .show();
                }
            }
        } else if (reportXmlDc.getItem().getRepXmlType() == ReportXmlType.TXT) {
            if (functionFieldField.getValue() == null) {
                notifications.create(Notifications.NotificationType.WARNING)
                        .withCaption("Следует указать функцию для выполнения")
                        .show();
            }
        }
    }

    private void onCheckXML() {
        checkXmlReportDataForm();
    }

    @Subscribe("repXmlTypeField")
    public void onRepXmlTypeFieldValueChange(HasValue.ValueChangeEvent<ReportXmlType> event) {
        if (event.isUserOriginated()) {
            if (event.getValue() == null) {
                setCheckBoxVisibleFalse();
                Objects.requireNonNull(tabSheetXml.getTab("tab_2")).setVisible(false);
                Objects.requireNonNull(tabSheetXml.getTab("tab_3")).setVisible(false);
                Objects.requireNonNull(tabSheetXml.getTab("tab_4")).setVisible(false);
                xmlFieldField.setValue(null);
                xsdFieldField.setValue(null);
                functionFieldField.setValue(null);
            } else if (event.getValue().toString().equals("XML")) {
                setCheckBoxVisibleTrue();
                Objects.requireNonNull(tabSheetXml.getTab("tab_2")).setVisible(true);
                Objects.requireNonNull(tabSheetXml.getTab("tab_3")).setVisible(true);
                Objects.requireNonNull(tabSheetXml.getTab("tab_4")).setVisible(true);
                functionFieldField.setValue(null);
            } else if (event.getValue().toString().equals("TXT")) {
                setCheckBoxVisibleFalse();
                Objects.requireNonNull(tabSheetXml.getTab("tab_2")).setVisible(false);
                Objects.requireNonNull(tabSheetXml.getTab("tab_3")).setVisible(false);
                Objects.requireNonNull(tabSheetXml.getTab("tab_4")).setVisible(true);
                xmlFieldField.setValue(null);
                xsdFieldField.setValue(null);
            }
        }
    }

    private void setCheckBoxVisibleTrue() {
        checkBoxZip.setVisible(true);
        checkBoxXsd.setVisible(true);
        checkBoxManifest.setVisible(true);
    }

    private void setCheckBoxVisibleFalse() {
        checkBoxZip.setVisible(false);
        checkBoxXsd.setVisible(false);
        checkBoxManifest.setVisible(false);
    }

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        reportXmlDl.load();
        reportXmlHistDl.setParameter("reportXml", reportXmlDc.getItem());
        reportXmlHistDl.load();

        reportXmlParamDl.setParameter("reportXml", reportXmlDc.getItem());

        reportXmlDl.load();
        reportXmlParamDl.load();

        reportDateField.setValue(new Date());

        if (reportXmlDc.getItem().getRepXmlType() == null) {
            setCheckBoxVisibleFalse();
            Objects.requireNonNull(tabSheetXml.getTab("tab_2")).setVisible(false);
            Objects.requireNonNull(tabSheetXml.getTab("tab_3")).setVisible(false);
            Objects.requireNonNull(tabSheetXml.getTab("tab_4")).setVisible(false);
        } else if (reportXmlDc.getItem().getRepXmlType() == ReportXmlType.XML) {
            setCheckBoxVisibleTrue();
            Objects.requireNonNull(tabSheetXml.getTab("tab_2")).setVisible(true);
            Objects.requireNonNull(tabSheetXml.getTab("tab_3")).setVisible(true);
            Objects.requireNonNull(tabSheetXml.getTab("tab_4")).setVisible(false);
        } else if (reportXmlDc.getItem().getRepXmlType() == ReportXmlType.TXT) {
            setCheckBoxVisibleFalse();
            Objects.requireNonNull(tabSheetXml.getTab("tab_2")).setVisible(false);
            Objects.requireNonNull(tabSheetXml.getTab("tab_3")).setVisible(false);
            Objects.requireNonNull(tabSheetXml.getTab("tab_4")).setVisible(true);
        }
    }

    @Subscribe("reportXmlHistTable.edit")
    public void onReportXmlHistTableEdit(Action.ActionPerformedEvent event) {
        ReportXmlHistEdit screen = screenBuilders.editor(reportXmlHistTable)
                .withScreenClass(ReportXmlHistEdit.class)
                .withOpenMode(OpenMode.DIALOG)
                .build();
        screen.setNotShowRepXml(true);
        screen.addAfterCloseListener(afterCloseEvent -> getScreenData().loadAll());
        screen.show();
    }

    @Subscribe("reportXmlHistTable.create")
    private void onReportXmlHistTableCreate(Action.ActionPerformedEvent event) {
        ReportXmlHistEdit screen = screenBuilders.editor(reportXmlHistTable)
                .withScreenClass(ReportXmlHistEdit.class)
                .newEntity()
                .withOpenMode(OpenMode.DIALOG)
                .build();
        screen.setNotShowRepXml(true);
        screen.setReportXml(reportXmlDc.getItem());
        screen.addAfterCloseListener(afterCloseEvent -> getScreenData().loadAll());
        screen.show();
    }

    @Subscribe("reportXmlParamTable.edit")
    public void onReportXmlParTableEdit(Action.ActionPerformedEvent event) {
        ReportXmlParamEdit screen = screenBuilders.editor(reportXmlParamTable)
                .withScreenClass(ReportXmlParamEdit.class)
                .withOpenMode(OpenMode.DIALOG)
                .build();
        screen.setNotShowRepXml(true);
        screen.addAfterCloseListener(afterCloseEvent -> getScreenData().loadAll());
        screen.show();
    }

    @Subscribe("reportXmlParamTable.create")
    private void onReportXmlParTableCreate(Action.ActionPerformedEvent event) {
        ReportXmlParamEdit screen = screenBuilders.editor(reportXmlParamTable)
                .withScreenClass(ReportXmlParamEdit.class)
                .newEntity()
                .withOpenMode(OpenMode.DIALOG)
                .build();
        screen.setNotShowRepXml(true);
        screen.setReportXml(reportXmlDc.getItem());
        screen.addAfterCloseListener(afterCloseEvent -> getScreenData().loadAll());
        screen.show();
    }

}