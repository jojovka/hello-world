package kz.eub.report360.screen.dicterrorgroup;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictErrorGroup;

@UiController("r360_DictErrorGroup.edit")
@UiDescriptor("dict-error-group-edit.xml")
@EditedEntityContainer("dictErrorGroupDc")
public class DictErrorGroupEdit extends StandardEditor<DictErrorGroup> {
}