package kz.eub.report360.screen.dictfilial;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictFilial;

@UiController("r360_DictFilial.browse")
@UiDescriptor("dict-filial-browse.xml")
@LookupComponent("dictFilialsTable")
public class DictFilialBrowse extends StandardLookup<DictFilial> {
}