package kz.eub.report360.screen.credreg;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.Credreg;

@UiController("r360_Credreg.edit")
@UiDescriptor("credreg-edit.xml")
@EditedEntityContainer("credregDc")
public class CredregEdit extends StandardEditor<Credreg> {
}