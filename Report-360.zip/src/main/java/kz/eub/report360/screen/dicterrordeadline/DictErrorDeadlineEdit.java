package kz.eub.report360.screen.dicterrordeadline;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictErrorDeadline;

@UiController("r360_DictErrorDeadline.edit")
@UiDescriptor("dict-error-deadline-edit.xml")
@EditedEntityContainer("dictErrorDeadlineDc")
public class DictErrorDeadlineEdit extends StandardEditor<DictErrorDeadline> {
}