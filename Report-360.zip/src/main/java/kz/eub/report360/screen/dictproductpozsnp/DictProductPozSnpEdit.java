package kz.eub.report360.screen.dictproductpozsnp;

import io.jmix.core.DataManager;
import io.jmix.ui.component.DateField;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictProductPozSnp;
import kz.eub.report360.entity.User;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@UiController("r360_DictProductPozSnp.edit")
@UiDescriptor("dict-product-poz-snp-edit.xml")
@EditedEntityContainer("dictProductPozSnpDc")
public class DictProductPozSnpEdit extends StandardEditor<DictProductPozSnp> {
    @Autowired
    private DateField<Date> changeDateField;
    @Autowired
    private InstanceContainer<DictProductPozSnp> dictProductPozSnpDc;
    @Autowired
    private DataManager dataManager;

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        changeDateField.setValue(new Date());
        getUser();
    }

    private void getUser() {
        if (Objects.requireNonNull(dictProductPozSnpDc.getItemOrNull()).getUserId() != null) {
            List<DictProductPozSnp> dictProductPozSnps = Collections.singletonList(dictProductPozSnpDc.getItemOrNull());

            for (DictProductPozSnp productPozSnp : dictProductPozSnps) {
                User user = dataManager.load(User.class).id(productPozSnp.getUserId()).one();
                productPozSnp.setUser(user);
            }
        }
    }
}