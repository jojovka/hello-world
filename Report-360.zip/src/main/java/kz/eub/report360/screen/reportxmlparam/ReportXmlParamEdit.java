package kz.eub.report360.screen.reportxmlparam;

import io.jmix.ui.component.CheckBox;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.DateField;
import io.jmix.ui.component.EntityPicker;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.TextArea;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.ReportXml;
import kz.eub.report360.entity.ReportXmlParType;
import kz.eub.report360.entity.ReportXmlParam;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

@UiController("r360_ReportXmlParam.edit")
@UiDescriptor("report-xml-param-edit.xml")
@EditedEntityContainer("reportXmlParamDc")
public class ReportXmlParamEdit extends StandardEditor<ReportXmlParam> {
    @Autowired
    private InstanceContainer<ReportXmlParam> reportXmlParamDc;
    @Autowired
    private TextArea<String> valueField;
    @Autowired
    private DateField<Date> valueDateField;
    @Autowired
    private ComboBox<ReportXmlParType> paramTypeField;
    @Autowired
    private EntityPicker<ReportXml> reportXmlField;
    @Autowired
    private CheckBox showParamField;
    @Autowired
    private CheckBox mandatoryParamField;
    private boolean notShowRepXml = false;
    private ReportXml reportXml;

    public void setReportXml(ReportXml reportXml) {
        this.reportXml = reportXml;
    }

    public void setNotShowRepXml(boolean in_notShowRepXml) {
        notShowRepXml = in_notShowRepXml;
    }

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        if (reportXml != null) {
            reportXmlParamDc.getItem().setReportXml(reportXml);
        }
        if (notShowRepXml) {
            reportXmlField.setVisible(false);
        }
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        if (reportXmlParamDc.getItem().getParamType() == null) {
            valueField.setVisible(false);
            valueDateField.setVisible(false);
        } else if (reportXmlParamDc.getItem().getParamType() == ReportXmlParType.STRING) {
            valueField.setVisible(true);
            valueDateField.setVisible(false);
        } else if (reportXmlParamDc.getItem().getParamType() == ReportXmlParType.STRING) {
            valueField.setVisible(false);
            valueDateField.setVisible(true);
        }
        if (reportXmlParamDc.getItem().getMandatoryParam() == null) {
            mandatoryParamField.setValue(false);
        }
        if (reportXmlParamDc.getItem().getShowParam() == null) {
            showParamField.setValue(false);
        }
    }

    @Subscribe("paramTypeField")
    public void onParamTypeFieldValueChange(HasValue.ValueChangeEvent<ReportXmlParType> event) {
        if (event.getValue() == ReportXmlParType.STRING && event.isUserOriginated()) {
            valueField.setVisible(true);
            valueDateField.setVisible(false);
            valueDateField.setValue(null);
        } else {
            valueField.setVisible(false);
            valueField.setValue(null);
            valueDateField.setVisible(true);
        }
    }

}