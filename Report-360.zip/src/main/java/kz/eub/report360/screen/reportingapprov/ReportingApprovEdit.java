package kz.eub.report360.screen.reportingapprov;

import io.jmix.core.security.CurrentAuthentication;
import io.jmix.ui.Notifications;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.CloseOriginType;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.DateField;
import io.jmix.ui.component.EntityPicker;
import io.jmix.ui.component.TextArea;
import io.jmix.ui.component.Window;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.Reporting;
import kz.eub.report360.entity.ReportingApprov;
import kz.eub.report360.entity.ReportingStatusType;
import kz.eub.report360.entity.User;
import kz.eub.report360.app.service.UtilityService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

@UiController("r360_ReportingApprov.edit")
@UiDescriptor("reporting-approv-edit.xml")
@EditedEntityContainer("reportingApprovDc")
public class ReportingApprovEdit extends StandardEditor<ReportingApprov> {
    @Autowired
    private EntityPicker<User> matchUserField;
    @Autowired
    private EntityPicker<Reporting> reportingField;
    @Autowired
    private DateField<Date> dateApprovField;
    @Autowired
    private DateField<Date> dateOnRepField;
    @Autowired
    private ComboBox<ReportingStatusType> statusField;
    @Autowired
    private UtilityService utilityService;
    @Autowired
    private InstanceContainer<ReportingApprov> reportingApprovDc;
    @Autowired
    private Notifications notifications;
    @Autowired
    private Button saveAndCloseBtn;
    @Autowired
    private TextArea<String> descriptionField;

    private User user;
    private Reporting reporting;
    @Autowired
    private CurrentAuthentication currentAuthentication;

    public void setParam(User user, Reporting reporting) {
        this.user = user;
        this.reporting = reporting;
    }

    @Subscribe
    private void onBeforeShow(BeforeShowEvent event) {
        matchUserField.setValue(user);
        reportingField.setValue(reporting);
        dateApprovField.setValue(new Date());
        statusField.setValue(ReportingStatusType.AGREED);

        if (reporting == null) {
            saveAndCloseBtn.setVisible(false);
            dateOnRepField.setEnabled(false);
            descriptionField.setEnabled(false);
            dateApprovField.setEnabled(false);
            statusField.setEnabled(false);
            matchUserField.setEnabled(false);
        }
    }

    @Subscribe
    public void onInitEntity(InitEntityEvent<ReportingApprov> event) {
        event.getEntity().setMatchUser((User) currentAuthentication.getUser());
    }

    @Subscribe("saveAndCloseBtn")
    public void onSaveAndCloseBtnClick(Button.ClickEvent event) {
        if (dateOnRepField.getValue() == null) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Внимание")
                    .withDescription("Необходимо указать дату отчета").show();
        }
        try {
            utilityService.saveChangeRepApprov(reportingApprovDc.getItem());
            this.close(WINDOW_DISCARD_AND_CLOSE_ACTION);
        } catch (Exception e) {
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Ошибка")
                    .withDescription("Описание ошибки: "+e.getMessage()).show();
        }
    }

    @Subscribe("exitBtn")
    public void onExitBtnClick(Button.ClickEvent event) {
        this.close(WINDOW_DISCARD_AND_CLOSE_ACTION);
    }

    @Subscribe(target = Target.FRAME)
    private void onBeforeCloseFrame(Window.BeforeCloseEvent event) {
        if (event.getCloseOrigin()== CloseOriginType.CLOSE_BUTTON) {
            event.preventWindowClose();
        }
    }
}