package kz.eub.report360.screen.dmpledgesnp;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DmPledgeSnp;

@UiController("r360_DmPledgeSnp.edit")
@UiDescriptor("dm-pledge-snp-edit.xml")
@EditedEntityContainer("dmPledgeSnpDc")
public class DmPledgeSnpEdit extends StandardEditor<DmPledgeSnp> {
}