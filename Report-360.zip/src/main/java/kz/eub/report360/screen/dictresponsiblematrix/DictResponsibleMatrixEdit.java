package kz.eub.report360.screen.dictresponsiblematrix;

import io.jmix.core.DataManager;
import io.jmix.ui.Notifications;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictDepartment;
import kz.eub.report360.entity.DictResponsibleMatrix;
import kz.eub.report360.entity.User;
import kz.eub.report360.entity.UserGroup;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

@UiController("r360_DictResponsibleMatrix.edit")
@UiDescriptor("dict-responsible-matrix-edit.xml")
@EditedEntityContainer("dictResponsibleMatrixDc")
public class DictResponsibleMatrixEdit extends StandardEditor<DictResponsibleMatrix> {
    @Autowired
    private InstanceContainer<DictResponsibleMatrix> dictResponsibleMatrixDc;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private Notifications notifications;

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        getUserGroupDep();
    }

    private void getUserGroupDep() {

        if (Objects.requireNonNull(dictResponsibleMatrixDc.getItemOrNull()).getDrmUserGroupId() != null
                || Objects.requireNonNull(dictResponsibleMatrixDc.getItemOrNull()).getDrmUserId() != null
                || Objects.requireNonNull(dictResponsibleMatrixDc.getItemOrNull()).getDrmBranchId() != null) {

            List<DictResponsibleMatrix> matrixList = Collections.singletonList(dictResponsibleMatrixDc.getItemOrNull());

            for (DictResponsibleMatrix matrix : matrixList) {
                UserGroup userGroup = dataManager.load(UserGroup.class).id(matrix.getDrmUserGroupId()).one();
                matrix.setUserGroup(userGroup);

                User user = dataManager.load(User.class).id(matrix.getDrmUserId()).one();
                matrix.setUser(user);

                DictDepartment department = dataManager.load(DictDepartment.class).id(matrix.getDrmBranchId()).one();
                matrix.setBranch(department);
            }
        }
    }

    @Subscribe
    public void onBeforeCommitChanges(BeforeCommitChangesEvent event) {
        if ((getEditedEntity().getUserGroup() != null && getEditedEntity().getUser() != null && getEditedEntity().getBranch() != null)
                || (getEditedEntity().getUserGroup() == null && getEditedEntity().getUser() != null && getEditedEntity().getBranch() != null)
                || (getEditedEntity().getUserGroup() != null && getEditedEntity().getUser() == null && getEditedEntity().getBranch() != null)
                || (getEditedEntity().getUserGroup() != null && getEditedEntity().getUser() != null && getEditedEntity().getBranch() == null)) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Внимание")
                    .withDescription("Должно быть заполнено только одно из 3х полей:\n" +
                            "Группа пользователей или Подразделение или Пользователь").show();
            event.preventCommit();
        }
    }

    @Subscribe
    public void onAfterCommitChanges(AfterCommitChangesEvent event) {
        notifications.create()
                .withCaption("Успешно сохранен!")
                .show();
    }
}