package kz.eub.report360.screen.dictsources;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictSources;

@UiController("r360_DictSources.browse")
@UiDescriptor("dict-sources-browse.xml")
@LookupComponent("dictSourcesTable")
public class DictSourcesBrowse extends StandardLookup<DictSources> {
}