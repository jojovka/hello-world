package kz.eub.report360.screen.reportxml;

import io.jmix.ui.Notifications;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.CheckBox;
import io.jmix.ui.component.DateField;
import io.jmix.ui.component.SourceCodeEditor;
import io.jmix.ui.component.TextField;
import io.jmix.ui.download.DownloadFormat;
import io.jmix.ui.download.Downloader;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.*;
import kz.eub.report360.entity.ReportXml;
import kz.eub.report360.entity.ReportXmlType;
import kz.eub.report360.app.service.UtilityService;
import kz.eub.report360.app.service.XMLService;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

@UiController("r360_ReportXmlRun.edit")
@UiDescriptor("report-xml-run-edit.xml")
@EditedEntityContainer("reportXmlDc")
public class ReportXmlRunEdit extends StandardEditor<ReportXml> {
    @Autowired
    private XMLService xmlService;
    @Autowired
    private UtilityService utilityService;
    @Autowired
    private InstanceContainer<ReportXml> reportXmlDc;
    @Autowired
    private SourceCodeEditor xmlFieldField;
    @Autowired
    private Notifications notifications;
    @Autowired
    private Downloader downloader;
    @Autowired
    private DateField<Date> dtRep;
    @Autowired
    private CheckBox checkBoxZip;
    @Autowired
    private TextField<String> codeField;
    @Autowired
    private CheckBox checkBoxManifest;
    Date dateRep;

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        dtRep.setValue(new Date());
    }

    @Subscribe("getReportBtn")
    public void onGetReportXmlClick(Button.ClickEvent event) {
        if (dtRep.isVisible()) {
            if (dtRep.getValue() == null) {
                notifications.create(Notifications.NotificationType.WARNING).withCaption("Следует указать дату отчета").show();
                return;
            }
            dateRep = dtRep.getValue();
        }

        if (reportXmlDc.getItem().getRepXmlType() == ReportXmlType.XML) {
            try {
                if (checkBoxZip.isChecked() && !checkBoxManifest.isChecked()) {
                    generateZip(xmlFieldField.getValue());
                } else if (checkBoxZip.isChecked() && checkBoxManifest.isChecked()) {
                    generateZipManifest(xmlFieldField.getValue());
                } else if (!checkBoxZip.isChecked() && checkBoxManifest.isChecked()) {
                    downloadXml(xmlFieldField.getValue());
                    downloadManifest();
                } else {
                    downloadXml(xmlFieldField.getValue());
                }
            } catch (Exception e) {
                notifications.create(Notifications.NotificationType.ERROR)
                        .withCaption("Ошибка")
                        .withDescription("При формировании xml произошла ошибка: " + e.getMessage())
                        .show();
            }
        } else if (reportXmlDc.getItem().getRepXmlType() == ReportXmlType.TXT) {
            try {
                downloadXmlTxt(reportXmlDc.getItem().getFunctionField());
            } catch (Exception e) {
                notifications.create(Notifications.NotificationType.ERROR)
                        .withCaption("Ошибка")
                        .withDescription("При формировании текстового файла произошла ошибка: " + e.getMessage())
                        .show();
            }
        }
    }

    private void downloadXmlZip(byte[] content) {
        downloader.download(content, createXmlAndZipName() + ".zip", DownloadFormat.ZIP);
    }

    public void generateZip(String xml) throws Exception {
        byte[] xmlContent = xmlService.getXml(xml, getEditedEntity().getDataStore());
        downloadXmlZip(xmlService.getZipFile(packXml(xmlContent)));
    }

    public void generateZipManifest(String xml) throws Exception {
        byte[] xmlContent = xmlService.getXml(xml, getEditedEntity().getDataStore());
        downloadXmlZip(xmlService.getZipFile(packXmlManifest(xmlContent)));
    }

    public void downloadXml(String xml) throws Exception {
        byte[] xmlContent = xmlService.getXml(xml, getEditedEntity().getDataStore());
        downloader.download(xmlContent, createXmlAndZipName() + ".xml", DownloadFormat.XML);
    }

    public void downloadManifest() throws Exception {
        dateRep = dtRep.getValue();
        String codeManifestContent = utilityService.getAppSettingVal("XML_MANIFEST_CODE");
        if (codeManifestContent.equals("No results")) {
            codeManifestContent = reportXmlDc.getItem().getCode();
        }
        String nameManifest = "usci_manifest";
        byte[] manifestContent = xmlService.getManifestXml(dateRep, codeManifestContent);
        downloader.download(manifestContent, nameManifest + ".xml", DownloadFormat.XML);
    }

    public void downloadXmlTxt(String func) throws Exception {
        String xmlContent = xmlService.getTxtResult(func, getEditedEntity().getDataStore());
        downloader.download(xmlContent.getBytes(), createXmlAndZipName() + ".txt", DownloadFormat.TEXT);
    }

    public HashMap<String, byte[]> packXml(byte[] xmlContent) {
        HashMap<String, byte[]> map;
        map = new HashMap<>();
        map.put(createXmlAndZipName() + ".xml", xmlContent);
        return map;
    }

    public HashMap<String, byte[]> packXmlManifest(byte[] xmlContent) throws Exception {
        dateRep = dtRep.getValue();
        String nameManifest = "usci_manifest";
        HashMap<String, byte[]> map;
        String codeXmlManifest = utilityService.getAppSettingVal("XML_MANIFEST_CODE");
        if (codeXmlManifest.equals("No results")) {
            codeXmlManifest = reportXmlDc.getItem().getCode();
        }
        byte[] outManifest = xmlService.getManifestXml(dateRep, codeXmlManifest);
        map = new HashMap<>();
        map.put(createXmlAndZipName() + ".xml", xmlContent);
        map.put(nameManifest + ".xml", outManifest);
        return map;
    }

    public String createXmlAndZipName() {
        String formatPattern = "ddMMyyyy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(formatPattern);
        String currentDate = simpleDateFormat.format(new Date());
        return codeField.getValue() + "_" + currentDate;
    }
}