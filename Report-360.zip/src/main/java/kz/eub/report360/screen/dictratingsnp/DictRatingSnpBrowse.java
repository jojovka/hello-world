package kz.eub.report360.screen.dictratingsnp;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictRatingSnp;

@UiController("r360_DictRatingSnp.browse")
@UiDescriptor("dict-rating-snp-browse.xml")
@LookupComponent("dictRatingSnpsTable")
public class DictRatingSnpBrowse extends StandardLookup<DictRatingSnp> {
}