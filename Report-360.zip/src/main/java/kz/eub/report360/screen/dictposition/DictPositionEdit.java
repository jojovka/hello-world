package kz.eub.report360.screen.dictposition;

import io.jmix.ui.screen.*;
import kz.eub.report360.entity.DictPosition;

@UiController("r360_DictPosition.edit")
@UiDescriptor("dict-position-edit.xml")
@EditedEntityContainer("dictPositionDc")
public class DictPositionEdit extends StandardEditor<DictPosition> {
}