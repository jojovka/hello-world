package kz.eub.report360;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Report360ApplicationTests {

	@Test
	void contextLoads() {
	}

}
