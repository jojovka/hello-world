package kz.eub.rm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RmApplicationTests {

	@Test
	void contextLoads() {
	}

}
