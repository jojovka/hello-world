package kz.eub.rm.filter;

import com.google.common.base.Strings;
import io.jmix.core.Metadata;
import io.jmix.core.MetadataTools;
import io.jmix.core.QueryUtils;
import io.jmix.core.entity.EntityValues;
import io.jmix.core.metamodel.model.MetaClass;
import io.jmix.core.metamodel.model.MetaProperty;
import io.jmix.core.metamodel.model.MetaPropertyPath;
import io.jmix.core.querycondition.Condition;
import io.jmix.data.impl.jpql.generator.ConditionGenerationContext;
import io.jmix.data.impl.jpql.generator.ConditionGenerator;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Nullable;

@Component("data_CustomPropertyConditionGenerator")
public class CustomPropertyConditionGenerator implements ConditionGenerator {

    protected MetadataTools metadataTools;
    protected Metadata metadata;

    @Autowired
    public CustomPropertyConditionGenerator(MetadataTools metadataTools, Metadata metadata) {
        this.metadataTools = metadataTools;
        this.metadata = metadata;
    }

    @Override
    public boolean supports(ConditionGenerationContext context) {
        return context.getCondition() instanceof CustomPropertyCondition;
    }

    @Override
    public String generateJoin(ConditionGenerationContext context) {
        CustomPropertyCondition customPropertyCondition = (CustomPropertyCondition) context.getCondition();
        if (customPropertyCondition == null||context.getEntityName()==null) {
            return "";
        }

        String propertyName = customPropertyCondition.getProperty();

        StringBuilder joinBuilder = new StringBuilder();
        StringBuilder joinPropertyBuilder = new StringBuilder(context.getEntityAlias());
        MetaClass metaClass = metadata.getClass(context.getEntityName());

        while (propertyName.contains(".")) {
            String basePropertyName = StringUtils.substringBefore(propertyName, ".");
            String childProperty = StringUtils.substringAfter(propertyName, ".");

            MetaProperty metaProperty = metaClass.getProperty(basePropertyName);

            if (metaProperty.getRange().getCardinality().isMany()) {
                String joinAlias = basePropertyName.substring(0, 3) + RandomStringUtils.randomAlphabetic(3);
                context.setJoinAlias(joinAlias);
                context.setJoinProperty(childProperty);
                context.setJoinMetaClass(metaProperty.getRange().asClass());
                joinBuilder.append(" join " + joinPropertyBuilder + "." + basePropertyName + " " + joinAlias);
                joinPropertyBuilder = new StringBuilder(joinAlias);
            } else {
                joinPropertyBuilder.append(".").append(basePropertyName);
            }
            if (metaProperty.getRange().isClass()) {
                metaClass = metaProperty.getRange().asClass();
            } else {
                break;
            }

            propertyName = childProperty;
        }

        return joinBuilder.toString();
    }

    @Override
    public String generateWhere(ConditionGenerationContext context) {
        CustomPropertyCondition customPropertyCondition = (CustomPropertyCondition) context.getCondition();
        if (customPropertyCondition == null) {
            return "";
        }

        if (context.getJoinAlias() != null && context.getJoinProperty() != null) {
            String property = getProperty(context.getJoinProperty(), context.getJoinMetaClass().getName());
            return generateWhere(customPropertyCondition, context.getJoinAlias(), property);
        } else {
            String entityAlias = context.getEntityAlias();
            String property = getProperty(customPropertyCondition.getProperty(), context.getEntityName());
            return generateWhere(customPropertyCondition, entityAlias, property);
        }

    }

    @Nullable
    @Override
    public Object generateParameterValue(@Nullable Condition condition, @Nullable Object parameterValue,
                                         @Nullable String entityName) {
        CustomPropertyCondition customPropertyCondition = (CustomPropertyCondition) condition;
        if (customPropertyCondition == null || parameterValue == null) {
            return null;
        }

        if (parameterValue instanceof String) {
            switch (customPropertyCondition.getOperation()) {
                case CustomPropertyCondition.Operation.CONTAINS:
                case CustomPropertyCondition.Operation.NOT_CONTAINS:
                    return QueryUtils.CASE_INSENSITIVE_MARKER + "%" + parameterValue + "%";
                case CustomPropertyCondition.Operation.STARTS_WITH:
                    return QueryUtils.CASE_INSENSITIVE_MARKER + parameterValue + "%";
                case CustomPropertyCondition.Operation.ENDS_WITH:
                    return QueryUtils.CASE_INSENSITIVE_MARKER + "%" + parameterValue;
            }
        } else if (EntityValues.isEntity(parameterValue)
                && isCrossDataStoreReference(customPropertyCondition.getProperty(), entityName)) {
            return EntityValues.getId(parameterValue);
        }
        return parameterValue;
    }

    protected String generateWhere(CustomPropertyCondition customPropertyCondition, String entityAlias, String property) {
        if (PropertyConditionUtils.isUnaryOperation(customPropertyCondition)) {
            return String.format("%s.%s %s",
                    entityAlias,
                    property,
                    PropertyConditionUtils.getJpqlOperation(customPropertyCondition));
        } else if (PropertyConditionUtils.isInIntervalOperation(customPropertyCondition)) {
            return PropertyConditionUtils.getJpqlOperation(customPropertyCondition);
        } else {
            return String.format("%s.%s %s :%s",
                    entityAlias,
                    property,
                    PropertyConditionUtils.getJpqlOperation(customPropertyCondition),
                    customPropertyCondition.getParameterName());
        }
    }

    protected String getProperty(String property, @Nullable String entityName) {
        if (Strings.isNullOrEmpty(entityName)
                || !isCrossDataStoreReference(property, entityName)) {
            return property;
        }

        MetaClass metaClass = metadata.getClass(entityName);
        MetaPropertyPath mpp = metaClass.getPropertyPath(property);
        if (mpp == null) {
            return property;
        }

        String referenceIdProperty = metadataTools.getCrossDataStoreReferenceIdProperty(
                metaClass.getStore().getName(),
                mpp.getMetaProperty());

        //noinspection ConstantConditions
        return property.lastIndexOf(".") > 0
                ? property.substring(0, property.lastIndexOf(".") + 1) + referenceIdProperty
                : referenceIdProperty;
    }

    protected boolean isCrossDataStoreReference(String property, @Nullable String entityName) {
        if (Strings.isNullOrEmpty(entityName)) {
            return false;
        }

        MetaClass metaClass = metadata.getClass(entityName);
        MetaPropertyPath mpp = metaClass.getPropertyPath(property);
        if (mpp == null) {
            return false;
        }

        return metadataTools.getCrossDataStoreReferenceIdProperty(
                metaClass.getStore().getName(), mpp.getMetaProperty()) != null;
    }
}
