package kz.eub.rm.filter;

import io.jmix.core.MetadataTools;
import io.jmix.core.metamodel.model.MetaClass;
import io.jmix.core.metamodel.model.MetaPropertyPath;
import io.jmix.ui.component.HasValue;

import org.dom4j.Element;

import static kz.eub.rm.filter.PropertyConditionUtils.generateParameterName;

public class PropertyFilterLoader extends AbstractSingleFilterComponentLoader<CustomPropertyFilter<?>> {

    @Override
    public void createComponent() {
        resultComponent = factory.create(CustomPropertyFilter.NAME);
        loadId(resultComponent, element);
    }

    @Override
    protected void loadAttributesBeforeValueComponent() {
        super.loadAttributesBeforeValueComponent();

        loadString(element, "property", resultComponent::setProperty);
        loadEnum(element, CustomPropertyFilter.Operation.class, "operation", resultComponent::setOperation);
        loadBoolean(element, "operationEditable", resultComponent::setOperationEditable);

        resultComponent.setParameterName(loadString(element, "parameterName")
                .orElse(generateParameterName(resultComponent.getProperty())));
    }

    @Override
    public void loadComponent() {
        super.loadComponent();

        loadBoolean(element, "operationCaptionVisible", resultComponent::setOperationCaptionVisible);
        loadDefaultValue(resultComponent, element);
    }

    @Override
    protected HasValue generateValueComponent() {
        MetaClass metaClass = resultComponent.getDataLoader().getContainer().getEntityMetaClass();
        return getSingleFilterSupport().generateValueComponent(metaClass,
                resultComponent.getProperty(), resultComponent.getOperation());
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    protected void loadDefaultValue(CustomPropertyFilter component, Element element) {
        if (element.attribute("defaultValue") != null) {
            String defaultValue = element.attributeValue("defaultValue");
            MetaClass metaClass = component.getDataLoader().getContainer().getEntityMetaClass();
            MetaPropertyPath mpp = getMetadataTools().resolveMetaPropertyPathOrNull(metaClass, component.getProperty());
            if (mpp != null) {
                Object value = getPropertyFilterSupport().parseDefaultValue(mpp.getMetaProperty(),
                        component.getOperation().getType(), defaultValue);
                component.setValue(value);
            }
        }
    }

    protected PropertyFilterSupport getPropertyFilterSupport() {
        return applicationContext.getBean(PropertyFilterSupport.class);
    }

    protected MetadataTools getMetadataTools() {
        return applicationContext.getBean(MetadataTools.class);
    }
}
