package kz.eub.rm.validation.pozsegmentationdictionary.save;

import kz.eub.dud.jmix.platform.validation.ConditionDoesNotMatchException;
import kz.eub.dud.jmix.platform.validation.ConditionsMatchValidator;
import kz.eub.dud.jmix.platform.validation.SingleConditionMatchValidator;
import kz.eub.rm.entity.dwh.PozSegmentationDictionary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("rm_pozSegmentationDictionaryAllConditionsSaveValidator")
public class PozSegmentationDictionaryAllConditionsSaveValidator implements ConditionsMatchValidator<PozSegmentationDictionary> {
    private final Class<PozSegmentationDictionary> entityType;

    private final List<SingleConditionMatchValidator<PozSegmentationDictionary>> singleConditionMatchValidators;

    public PozSegmentationDictionaryAllConditionsSaveValidator(@Autowired List<SingleConditionMatchValidator<PozSegmentationDictionary>> singleConditionMatchValidators) {
        entityType = PozSegmentationDictionary.class;
        this.singleConditionMatchValidators = singleConditionMatchValidators;
    }

    @Override
    public void check(PozSegmentationDictionary entity) throws ConditionDoesNotMatchException {
        for (SingleConditionMatchValidator<PozSegmentationDictionary> singleConditionMatchValidator: singleConditionMatchValidators){
            singleConditionMatchValidator.check(entity);
        }
    }

    @Override
    public Class<PozSegmentationDictionary> getEntityType() {
        return entityType;
    }
}
