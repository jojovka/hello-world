package kz.eub.rm.simple.report;

import io.jmix.core.DevelopmentException;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

public class SimpleReportData<T>{
    protected SimpleReportDataConfiguration configuration;

    protected List<T> entityRows;

    public SimpleReportData(SimpleReportDataConfiguration configuration) {
        this.configuration = configuration;
    }

    public Object getPropertyValue(int rowNumber, int column) {
        List<String> nodes = configuration.getPropertyPath(column);
        return extractValue(entityRows.get(rowNumber), nodes);

    }

    public int getDataRowsNumber(){
        return entityRows.size();
    }

    public int getColumnsNumber() {
        return configuration.getPropertiesNumber();
    }

    protected void loadData(){
        entityRows = (List<T>) configuration.getDataLoadingDelegate().get();
    }

    protected Object extractValue(T entityRow, List<String> nodes) {
        Object result = entityRow;
        for (String node : nodes) {
            result = getFieldValueWithGetter(result, node);
            if (result == null) {
                break;
            }
        }
        return result;
    }

    private Object getFieldValueWithGetter(Object obj, String fieldName) {
        Object result;
        try {
            Method getterMethod = obj
                    .getClass()
                    .getDeclaredMethod(
                            String.format("get%s%s",
                                    fieldName.substring(0,1).toUpperCase(),
                                    fieldName.substring(1)
                            )
                    );
            result = getterMethod.invoke(obj);
        } catch (IllegalAccessException e) {
            throw new DevelopmentException(
                    String.format("can't access method get%s%s, setAccessible method must be invoked",
                            fieldName.substring(0,1).toUpperCase(),
                            fieldName.substring(1)),
                    e);

        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(
                    String.format("Wrong configuration settings, couldn't find method get%s%s",
                            fieldName.substring(0,1).toUpperCase(),
                            fieldName.substring(1)),
                    e);
        }
        return result;
    }

//    protected Object extractValue(T entityRow, List<String> nodes) {
//        Object result = entityRow;
//        for (String node : nodes) {
//            try {
//                Field field = result.getClass().getDeclaredField(node);
//                field.setAccessible(true);
//                result = field.get(result);
//            } catch (IllegalAccessException e) {
//                throw new DevelopmentException(String.format("can't access field %s, setAccessible method must be invoked", node), e);
//            } catch (NoSuchFieldException e) {
//                throw new RuntimeException(String.format("Wrong configuration settings, couldn't find property %s",node), e);
//            }
//            if (result == null) {
//                break;
//            }
//        }
//        return result;
//    }
}
