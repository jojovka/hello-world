package kz.eub.rm.simple.report;

import java.util.List;
import java.util.Map;

public class SimpleReportRenderConfiguration {
    private int maxRowsPerSheet;
    public SimpleReportRenderConfiguration(int maxRowsPerSheet) {
        this.maxRowsPerSheet = maxRowsPerSheet;
    }

    public int getMaxRowsPerSheet() {
        return maxRowsPerSheet;
    }
}
