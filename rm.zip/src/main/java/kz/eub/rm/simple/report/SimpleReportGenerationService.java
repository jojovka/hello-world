package kz.eub.rm.simple.report;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;

public interface SimpleReportGenerationService {
    <T> ByteArrayOutputStream generate(Class<T> cls, SimpleReportDataConfiguration configuration, SimpleReportRenderConfiguration renderConfiguration);
}
