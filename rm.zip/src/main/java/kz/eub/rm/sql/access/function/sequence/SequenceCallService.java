package kz.eub.rm.sql.access.function.sequence;

public interface SequenceCallService {
    Long getLongFromSequence(SequenceName sequenceName);
}
