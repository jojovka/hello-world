package kz.eub.rm;

import io.jmix.core.DataManager;
import io.jmix.core.Messages;
import io.jmix.core.security.SystemAuthenticator;
import io.jmix.reports.runner.ReportRunner;
import io.jmix.ui.UiComponents;
import kz.eub.rm.file.FileGenerationButtonFactory;
import kz.eub.rm.service.ReportsBundleService;
import kz.eub.rm.service.SimpleRouteGenerator;
import kz.eub.rm.service.UserService;
import kz.eub.rm.service.email.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Configuration
public class FactoriesConfiguration {
    @Value("${rm.reports.bundle.generation.threads.max}")
    private int maxThreads;

    @Bean
    public FileGenerationButtonFactory fileGenerationButtonFactory(
            @Autowired ReportRunner reportRunner,
            @Autowired UiComponents uiComponents,
            @Autowired ReportsBundleService reportsBundleService,
            @Autowired UserService userService,
            @Autowired SystemAuthenticator systemAuthenticator,
            @Autowired Messages messages,
            @Autowired EmailService emailService,
            @Autowired DataManager dataManager,
            @Autowired SimpleRouteGenerator simpleRouteGenerator)
    {
        ExecutorService executorService = Executors.newFixedThreadPool(maxThreads);
        return new FileGenerationButtonFactory(reportRunner, uiComponents, executorService, reportsBundleService, simpleRouteGenerator, userService, systemAuthenticator, messages, emailService, dataManager);
    }
}
