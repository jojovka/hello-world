package kz.eub.rm.event;

import org.springframework.context.ApplicationEvent;

import java.util.EventObject;

public class GlobalConfigurationChangedEvent extends ApplicationEvent {
    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public GlobalConfigurationChangedEvent(Object source) {
        super(source);
    }
}
