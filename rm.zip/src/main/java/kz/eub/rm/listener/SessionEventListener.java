package kz.eub.rm.listener;

import com.vaadin.server.VaadinSession;
import io.jmix.ui.App;
import io.jmix.ui.AppUI;
import kz.eub.rm.event.GlobalConfigurationChangedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import java.util.List;

@Component
public class SessionEventListener {
    @EventListener
    public void onGlobalConfigurationChangedEvent(GlobalConfigurationChangedEvent event) {
        VaadinSession session = VaadinSession.getCurrent();
        session.access(() -> {
            if (session.getState().equals(VaadinSession.State.OPEN)) {
                List<AppUI> appUIList = App.getInstance().getAppUIs();
                for (AppUI ui: appUIList){
                    ui.getScreens().removeAll();
                }
            }
        });
    }
}
