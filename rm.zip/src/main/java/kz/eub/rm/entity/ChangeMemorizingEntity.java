package kz.eub.rm.entity;

public interface ChangeMemorizingEntity extends ChangerUserMemorizingEntity, ChangeDateMemorizingEntity{
}
