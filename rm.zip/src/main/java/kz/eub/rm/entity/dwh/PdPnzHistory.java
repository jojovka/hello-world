package kz.eub.rm.entity.dwh;

import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.*;
import java.util.Date;

@JmixEntity
@Store(name = "dwhstore")
@Table(name = "pd_pnz_history", schema = "dwh_risk")
@Entity(name = "rm_PdPnzHistory")
public class PdPnzHistory {

    @Column(name = "pph_run_id", nullable = false)
    @Id
    @InstanceName
    private String runId;

    @Column(name = "pph_user")
    private String user;

    @Column(name = "pph_date_from")
    @Temporal(TemporalType.DATE)
    private Date dateFrom;

    @Column(name = "pph_date_to")
    @Temporal(TemporalType.DATE)
    private Date dateTo;

    @Column(name = "pph_approved")
    private Boolean approved;

    @Column(name = "pph_approver")
    private String approver;

    @Column(name = "pph_approved_date")
    @Temporal(TemporalType.DATE)
    private Date dateApproved;

    public void setUser(String user) {
        this.user = user;
    }

    public String getUser() {
        return user;
    }

    public void setApprover(String approver) {
        this.approver = approver;
    }

    public String getApprover() {
        return approver;
    }

    public Date getDateApproved() {
        return dateApproved;
    }

    public void setDateApproved(Date dateApproved) {
        this.dateApproved = dateApproved;
    }

    public Boolean getApproved() {
        return approved;
    }

    public void setApproved(Boolean approved) {
        this.approved = approved;
    }

    public Date getDateTo() {
        return dateTo;
    }

    public void setDateTo(Date dateTo) {
        this.dateTo = dateTo;
    }

    public Date getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(Date dateFrom) {
        this.dateFrom = dateFrom;
    }

    public String getRunId() {
        return runId;
    }

    public void setRunId(String runId) {
        this.runId = runId;
    }

}