package kz.eub.rm.entity.listener.support;

import io.jmix.core.event.EntitySavingEvent;
import kz.eub.rm.entity.dwh.StandardDictionaryEntityWithLongIdentifier;
import kz.eub.rm.sql.access.function.sequence.SequenceName;

public interface DictionaryRowWithLongIdentifierAdjustmentSupport {
    void adjustOnSave(EntitySavingEvent<? extends StandardDictionaryEntityWithLongIdentifier> event, SequenceName sequenceName);
}
