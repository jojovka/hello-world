package kz.eub.rm.entity.dwh;

public interface StandardDictionaryEntityWithLongIdentifier extends StandardDictionaryEntity,HasLongIdentifier{
}
