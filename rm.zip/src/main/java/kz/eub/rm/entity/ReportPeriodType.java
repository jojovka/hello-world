package kz.eub.rm.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum ReportPeriodType implements EnumClass<String> {

    YEAR("year"),
    MONTH("month"),
    QUARTER("quarter");

    private String id;

    ReportPeriodType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static ReportPeriodType fromId(String id) {
        for (ReportPeriodType at : ReportPeriodType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}