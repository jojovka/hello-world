package kz.eub.rm.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum ReportsBundleStatus implements EnumClass<Integer> {

    IN_PROGRESS(10),
    SUCCESS(20),
    ERROR(30);

    private Integer id;

    ReportsBundleStatus(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static ReportsBundleStatus fromId(Integer id) {
        for (ReportsBundleStatus at : ReportsBundleStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}