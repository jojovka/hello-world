package kz.eub.rm.entity;

import kz.eub.rm.entity.User;

import java.util.UUID;

public interface ChangerUserMemorizingEntity {
    public UUID getChangerUserId();
    public void setChangerUserId(UUID id);
}
