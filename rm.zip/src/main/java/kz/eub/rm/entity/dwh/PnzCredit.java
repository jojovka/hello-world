package kz.eub.rm.entity.dwh;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;
import io.jmix.data.DdlGeneration;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@DdlGeneration(value = DdlGeneration.DbScriptGenerationMode.DISABLED)
@JmixEntity
@Store(name = "dwhstore")
@Table(name = "pnz_credits", schema = "dwh_risk")
@Entity(name = "rm_PnzCredit")
public class PnzCredit {
    @JmixGeneratedValue
    @Column(name = "pc_uuid")
    @Id
    private UUID id;

    @Column(name = "pc_id")
    private Integer pc;

    @Column(name = "pc_act_fin_date")
    @Temporal(TemporalType.DATE)
    private Date pcActFinDate;

    @Column(name = "pc_all_sum")
    private BigDecimal pcAllSum;

    @Column(name = "pc_bankrupt_date")
    @Temporal(TemporalType.DATE)
    private Date pcBankruptDate;

    @Column(name = "pc_basket_mon_beg")
    private Integer pcBasketMonBeg;

    @Column(name = "pc_basket_rep_date")
    private Integer pcBasketRepDate;

    @Column(name = "pc_cession_value")
    @Lob
    private String pcCessionValue;

    @Column(name = "pc_cgrp_name")
    @Lob
    private String pcCgrpName;

    @Column(name = "pc_class")
    @Lob
    private String pcClass;

    @Column(name = "pc_cli_iin_bin")
    @Lob
    private String pcCliIinBin;

    @Column(name = "pc_cli_oked_cd")
    @Lob
    private String pcCliOkedCd;

    @Column(name = "pc_cli_rati_out")
    @Lob
    private String pcCliRatiOut;

    @Column(name = "pc_cli_rating")
    @Lob
    private String pcCliRating;

    @Column(name = "pc_cli_rating_date")
    @Temporal(TemporalType.DATE)
    private Date pcCliRatingDate;

    @Column(name = "pc_cli_type", length = 3)
    private String pcCliType;

    @Column(name = "pc_clnt_gid")
    private Long pcClntGid;

    @Column(name = "pc_clnt_name")
    @Lob
    private String pcClntName;

    @Column(name = "pc_control_list")
    @Lob
    private String pcControlList;

    @Column(name = "pc_court_date")
    @Temporal(TemporalType.DATE)
    private Date pcCourtDate;

    @Column(name = "pc_cr_rate_month_beg")
    private BigDecimal pcCrRateMonthBeg;

    @Column(name = "pc_cr_rate_rep_date")
    private BigDecimal pcCrRateRepDate;

    @Column(name = "pc_credit_dep")
    @Lob
    private String pcCreditDep;

    @Column(name = "pc_creditsum")
    private BigDecimal pcCreditsum;

    @Column(name = "pc_creditsum_kzt")
    private BigDecimal pcCreditsumKzt;

    @Column(name = "pc_cur_cd")
    private Long pcCurCd;

    @Column(name = "pc_cur_code", length = 3)
    private String pcCurCode;

    @Column(name = "pc_deal_rating")
    @Lob
    private String pcDealRating;

    @Column(name = "pc_deal_rating_date")
    @Lob
    private String pcDealRatingDate;

    @Column(name = "pc_death_date")
    @Temporal(TemporalType.DATE)
    private Date pcDeathDate;

    @Column(name = "pc_default_date")
    @Temporal(TemporalType.DATE)
    private Date pcDefaultDate;

    @Column(name = "pc_dog_num")
    @Lob
    private String pcDogNum;

    @Column(name = "pc_dprt_gid")
    private Long pcDprtGid;

    @Column(name = "pc_dprt_name")
    @Lob
    private String pcDprtName;

    @Column(name = "pc_duration")
    private Integer pcDuration;

    @Column(name = "pc_eff_rate")
    private BigDecimal pcEffRate;

    @Column(name = "pc_esector")
    @Lob
    private String pcEsector;

    @Column(name = "pc_exp_days")
    private Integer pcExpDays;

    @Column(name = "pc_exp_days_op_perc")
    private Integer pcExpDaysOpPerc;

    @Column(name = "pc_ext_exp_days")
    private Integer pcExtExpDays;

    @Column(name = "pc_first_paym_date")
    @Temporal(TemporalType.DATE)
    private Date pcFirstPaymDate;

    @Column(name = "pc_gen_date")
    @Temporal(TemporalType.DATE)
    private Date pcGenDate;

    @Column(name = "pc_gid")
    private Long pcGid;

    @Column(name = "pc_kod_ip")
    @Lob
    private String pcKodIp;

    @Column(name = "pc_last_fin_date")
    @Temporal(TemporalType.DATE)
    private Date pcLastFinDate;

    @Column(name = "pc_max_default_date")
    @Temporal(TemporalType.DATE)
    private Date pcMaxDefaultDate;

    @Column(name = "pc_mod_date")
    @Temporal(TemporalType.DATE)
    private Date pcModDate;

    @Column(name = "pc_mod_npv")
    private BigDecimal pcModNpv;

    @Column(name = "pc_mod_substantial")
    private Integer pcModSubstantial;

    @Column(name = "pc_model_transform")
    @Lob
    private String pcModelTransform;

    @Column(name = "pc_modif")
    @Lob
    private String pcModif;

    @Column(name = "pc_mon_date")
    @Temporal(TemporalType.DATE)
    private Date pcMonDate;

    @Column(name = "pc_mon_per")
    @Lob
    private String pcMonPer;

    @Column(name = "pc_msfo_rate")
    private BigDecimal pcMsfoRate;

    @Column(name = "pc_non_market_fl")
    private Boolean pcNonMarketFl;

    @Column(name = "pc_oked")
    @Lob
    private String pcOked;

    @Column(name = "pc_open_date")
    @Temporal(TemporalType.DATE)
    private Date pcOpenDate;

    @Column(name = "pc_operation_is_write_off")
    @Temporal(TemporalType.DATE)
    private Date pcOperationIsWriteOff;

    @Column(name = "pc_operation_pay_off_system")
    @Temporal(TemporalType.DATE)
    private Date pcOperationPayOffSystem;

    @Column(name = "pc_operation_pay_off_system_amount")
    private BigDecimal pcOperationPayOffSystemAmount;

    @Column(name = "pc_out_sum_all_debt")
    private BigDecimal pcOutSumAllDebt;

    @Column(name = "pc_out_sum_all_debt_mon_beg")
    private BigDecimal pcOutSumAllDebtMonBeg;

    @Column(name = "pc_out_sum_com")
    private BigDecimal pcOutSumCom;

    @Column(name = "pc_out_sum_com_delay")
    private BigDecimal pcOutSumComDelay;

    @Column(name = "pc_out_sum_corr_esp")
    private BigDecimal pcOutSumCorrEsp;

    @Column(name = "pc_out_sum_debt_1860_kzt")
    private BigDecimal pcOutSumDebt1860Kzt;

    @Column(name = "pc_out_sum_dev")
    private BigDecimal pcOutSumDev;

    @Column(name = "pc_out_sum_dis_1434")
    private BigDecimal pcOutSumDis1434;

    @Column(name = "pc_out_sum_dis_2794")
    private BigDecimal pcOutSumDis2794;

    @Column(name = "pc_out_sum_dz_1877_kzt")
    private BigDecimal pcOutSumDz1877Kzt;

    @Column(name = "pc_out_sum_kik")
    private BigDecimal pcOutSumKik;

    @Column(name = "pc_out_sum_lesion")
    private BigDecimal pcOutSumLesion;

    @Column(name = "pc_out_sum_mod_1435")
    private BigDecimal pcOutSumMod1435;

    @Column(name = "pc_out_sum_msfo_1428")
    private BigDecimal pcOutSumMsfo1428;

    @Column(name = "pc_out_sum_msfo_per")
    private BigDecimal pcOutSumMsfoPer;

    @Column(name = "pc_out_sum_neg_corr")
    private BigDecimal pcOutSumNegCorr;

    @Column(name = "pc_out_sum_od")
    private BigDecimal pcOutSumOd;

    @Column(name = "pc_out_sum_od_delay")
    private BigDecimal pcOutSumOdDelay;

    @Column(name = "pc_out_sum_od_odd")
    private BigDecimal pcOutSumOdOdd;

    @Column(name = "pc_out_sum_od_odd_mon_beg")
    private BigDecimal pcOutSumOdOddMonBeg;

    @Column(name = "pc_out_sum_outsys")
    private BigDecimal pcOutSumOutsys;

    @Column(name = "pc_out_sum_outsys_sum")
    private BigDecimal pcOutSumOutsysSum;

    @Column(name = "pc_out_sum_pen_kzt")
    private BigDecimal pcOutSumPenKzt;

    @Column(name = "pc_out_sum_perc")
    private BigDecimal pcOutSumPerc;

    @Column(name = "pc_out_sum_perc_delay")
    private BigDecimal pcOutSumPercDelay;

    @Column(name = "pc_out_sum_perc_od")
    private BigDecimal pcOutSumPercOd;

    @Column(name = "pc_out_sum_prov_1877_kzt")
    private BigDecimal pcOutSumProv1877Kzt;

    @Column(name = "pc_out_sum_prov_com_1845")
    private BigDecimal pcOutSumProvCom1845;

    @Column(name = "pc_out_sum_reser_kzt")
    private BigDecimal pcOutSumReserKzt;

    @Column(name = "pc_paym_date")
    @Temporal(TemporalType.DATE)
    private Date pcPaymDate;

    @Column(name = "pc_payment_loans_date")
    @Temporal(TemporalType.DATE)
    private Date pcPaymentLoansDate;

    @Column(name = "pc_prison_date")
    @Temporal(TemporalType.DATE)
    private Date pcPrisonDate;

    @Column(name = "pc_problem")
    @Lob
    private String pcProblem;

    @Column(name = "pc_prod_name")
    @Lob
    private String pcProdName;

    @Column(name = "pc_rate")
    private BigDecimal pcRate;

    @Column(name = "pc_recovery_date")
    @Temporal(TemporalType.DATE)
    private Date pcRecoveryDate;

    @Column(name = "pc_recovery_ready")
    private Boolean pcRecoveryReady;

    @Column(name = "pc_report_date")
    @Temporal(TemporalType.DATE)
    private Date pcReportDate;

    @Column(name = "pc_run_id")
    @Lob
    private String runId;

    @Column(name = "pc_sd_cd")
    @Lob
    private String pcSdCd;

    @Column(name = "pc_segment")
    @Lob
    private String pcSegment;

    @Column(name = "pc_state")
    @Lob
    private String pcState;

    @Column(name = "pc_tarif")
    @Lob
    private String pcTarif;

    @Column(name = "pc_trg_2")
    private Boolean pcTrg2;

    @Column(name = "pc_trg_3")
    private Boolean pcTrg3;

    @Column(name = "pc_trg_4")
    private Boolean pcTrg4;

    @Column(name = "pc_uf_dmrsz")
    @Lob
    private String pcUfDmrsz;

    @Column(name = "pc_uf_dmrsz_date")
    @Temporal(TemporalType.DATE)
    private Date pcUfDmrszDate;

    @Column(name = "pc_uf_dokisa")
    @Lob
    private String pcUfDokisa;

    @Column(name = "pc_uf_dokisa_date")
    @Temporal(TemporalType.DATE)
    private Date pcUfDokisaDate;

    @Column(name = "pc_uf_drpz")
    @Lob
    private String pcUfDrpz;

    @Column(name = "pc_uf_drpz_date")
    @Temporal(TemporalType.DATE)
    private Date pcUfDrpzDate;

    @Column(name = "pc_uf_restr_date")
    @Temporal(TemporalType.DATE)
    private Date pcUfRestrDate;

    @Column(name = "pc_uf_wor_fin_con_date")
    @Temporal(TemporalType.DATE)
    private Date pcUfWorFinConDate;

    @Column(name = "pc_uni_all_sum")
    private BigDecimal pcUniAllSum;

    @Column(name = "pc_uniform")
    private Boolean pcUniform;

    @Column(name = "pc_user_cred_type")
    @Lob
    private String pcUserCredType;

    @Column(name = "pc_zero_date")
    @Temporal(TemporalType.DATE)
    private Date pcZeroDate;

    public Date getPcZeroDate() {
        return pcZeroDate;
    }

    public void setPcZeroDate(Date pcZeroDate) {
        this.pcZeroDate = pcZeroDate;
    }

    public String getPcUserCredType() {
        return pcUserCredType;
    }

    public void setPcUserCredType(String pcUserCredType) {
        this.pcUserCredType = pcUserCredType;
    }

    public Boolean getPcUniform() {
        return pcUniform;
    }

    public void setPcUniform(Boolean pcUniform) {
        this.pcUniform = pcUniform;
    }

    public BigDecimal getPcUniAllSum() {
        return pcUniAllSum;
    }

    public void setPcUniAllSum(BigDecimal pcUniAllSum) {
        this.pcUniAllSum = pcUniAllSum;
    }

    public Date getPcUfWorFinConDate() {
        return pcUfWorFinConDate;
    }

    public void setPcUfWorFinConDate(Date pcUfWorFinConDate) {
        this.pcUfWorFinConDate = pcUfWorFinConDate;
    }

    public Date getPcUfRestrDate() {
        return pcUfRestrDate;
    }

    public void setPcUfRestrDate(Date pcUfRestrDate) {
        this.pcUfRestrDate = pcUfRestrDate;
    }

    public Date getPcUfDrpzDate() {
        return pcUfDrpzDate;
    }

    public void setPcUfDrpzDate(Date pcUfDrpzDate) {
        this.pcUfDrpzDate = pcUfDrpzDate;
    }

    public String getPcUfDrpz() {
        return pcUfDrpz;
    }

    public void setPcUfDrpz(String pcUfDrpz) {
        this.pcUfDrpz = pcUfDrpz;
    }

    public Date getPcUfDokisaDate() {
        return pcUfDokisaDate;
    }

    public void setPcUfDokisaDate(Date pcUfDokisaDate) {
        this.pcUfDokisaDate = pcUfDokisaDate;
    }

    public String getPcUfDokisa() {
        return pcUfDokisa;
    }

    public void setPcUfDokisa(String pcUfDokisa) {
        this.pcUfDokisa = pcUfDokisa;
    }

    public Date getPcUfDmrszDate() {
        return pcUfDmrszDate;
    }

    public void setPcUfDmrszDate(Date pcUfDmrszDate) {
        this.pcUfDmrszDate = pcUfDmrszDate;
    }

    public String getPcUfDmrsz() {
        return pcUfDmrsz;
    }

    public void setPcUfDmrsz(String pcUfDmrsz) {
        this.pcUfDmrsz = pcUfDmrsz;
    }

    public Boolean getPcTrg4() {
        return pcTrg4;
    }

    public void setPcTrg4(Boolean pcTrg4) {
        this.pcTrg4 = pcTrg4;
    }

    public Boolean getPcTrg3() {
        return pcTrg3;
    }

    public void setPcTrg3(Boolean pcTrg3) {
        this.pcTrg3 = pcTrg3;
    }

    public Boolean getPcTrg2() {
        return pcTrg2;
    }

    public void setPcTrg2(Boolean pcTrg2) {
        this.pcTrg2 = pcTrg2;
    }

    public String getPcTarif() {
        return pcTarif;
    }

    public void setPcTarif(String pcTarif) {
        this.pcTarif = pcTarif;
    }

    public String getPcState() {
        return pcState;
    }

    public void setPcState(String pcState) {
        this.pcState = pcState;
    }

    public String getPcSegment() {
        return pcSegment;
    }

    public void setPcSegment(String pcSegment) {
        this.pcSegment = pcSegment;
    }

    public String getPcSdCd() {
        return pcSdCd;
    }

    public void setPcSdCd(String pcSdCd) {
        this.pcSdCd = pcSdCd;
    }

    public String getRunId() {
        return runId;
    }

    public void setRunId(String pcRun) {
        this.runId = pcRun;
    }

    public Date getPcReportDate() {
        return pcReportDate;
    }

    public void setPcReportDate(Date pcReportDate) {
        this.pcReportDate = pcReportDate;
    }

    public Boolean getPcRecoveryReady() {
        return pcRecoveryReady;
    }

    public void setPcRecoveryReady(Boolean pcRecoveryReady) {
        this.pcRecoveryReady = pcRecoveryReady;
    }

    public Date getPcRecoveryDate() {
        return pcRecoveryDate;
    }

    public void setPcRecoveryDate(Date pcRecoveryDate) {
        this.pcRecoveryDate = pcRecoveryDate;
    }

    public BigDecimal getPcRate() {
        return pcRate;
    }

    public void setPcRate(BigDecimal pcRate) {
        this.pcRate = pcRate;
    }

    public String getPcProdName() {
        return pcProdName;
    }

    public void setPcProdName(String pcProdName) {
        this.pcProdName = pcProdName;
    }

    public String getPcProblem() {
        return pcProblem;
    }

    public void setPcProblem(String pcProblem) {
        this.pcProblem = pcProblem;
    }

    public Date getPcPrisonDate() {
        return pcPrisonDate;
    }

    public void setPcPrisonDate(Date pcPrisonDate) {
        this.pcPrisonDate = pcPrisonDate;
    }

    public Date getPcPaymentLoansDate() {
        return pcPaymentLoansDate;
    }

    public void setPcPaymentLoansDate(Date pcPaymentLoansDate) {
        this.pcPaymentLoansDate = pcPaymentLoansDate;
    }

    public Date getPcPaymDate() {
        return pcPaymDate;
    }

    public void setPcPaymDate(Date pcPaymDate) {
        this.pcPaymDate = pcPaymDate;
    }

    public BigDecimal getPcOutSumReserKzt() {
        return pcOutSumReserKzt;
    }

    public void setPcOutSumReserKzt(BigDecimal pcOutSumReserKzt) {
        this.pcOutSumReserKzt = pcOutSumReserKzt;
    }

    public BigDecimal getPcOutSumProvCom1845() {
        return pcOutSumProvCom1845;
    }

    public void setPcOutSumProvCom1845(BigDecimal pcOutSumProvCom1845) {
        this.pcOutSumProvCom1845 = pcOutSumProvCom1845;
    }

    public BigDecimal getPcOutSumProv1877Kzt() {
        return pcOutSumProv1877Kzt;
    }

    public void setPcOutSumProv1877Kzt(BigDecimal pcOutSumProv1877Kzt) {
        this.pcOutSumProv1877Kzt = pcOutSumProv1877Kzt;
    }

    public BigDecimal getPcOutSumPercOd() {
        return pcOutSumPercOd;
    }

    public void setPcOutSumPercOd(BigDecimal pcOutSumPercOd) {
        this.pcOutSumPercOd = pcOutSumPercOd;
    }

    public BigDecimal getPcOutSumPercDelay() {
        return pcOutSumPercDelay;
    }

    public void setPcOutSumPercDelay(BigDecimal pcOutSumPercDelay) {
        this.pcOutSumPercDelay = pcOutSumPercDelay;
    }

    public BigDecimal getPcOutSumPerc() {
        return pcOutSumPerc;
    }

    public void setPcOutSumPerc(BigDecimal pcOutSumPerc) {
        this.pcOutSumPerc = pcOutSumPerc;
    }

    public BigDecimal getPcOutSumPenKzt() {
        return pcOutSumPenKzt;
    }

    public void setPcOutSumPenKzt(BigDecimal pcOutSumPenKzt) {
        this.pcOutSumPenKzt = pcOutSumPenKzt;
    }

    public BigDecimal getPcOutSumOutsysSum() {
        return pcOutSumOutsysSum;
    }

    public void setPcOutSumOutsysSum(BigDecimal pcOutSumOutsysSum) {
        this.pcOutSumOutsysSum = pcOutSumOutsysSum;
    }

    public BigDecimal getPcOutSumOutsys() {
        return pcOutSumOutsys;
    }

    public void setPcOutSumOutsys(BigDecimal pcOutSumOutsys) {
        this.pcOutSumOutsys = pcOutSumOutsys;
    }

    public BigDecimal getPcOutSumOdOddMonBeg() {
        return pcOutSumOdOddMonBeg;
    }

    public void setPcOutSumOdOddMonBeg(BigDecimal pcOutSumOdOddMonBeg) {
        this.pcOutSumOdOddMonBeg = pcOutSumOdOddMonBeg;
    }

    public BigDecimal getPcOutSumOdOdd() {
        return pcOutSumOdOdd;
    }

    public void setPcOutSumOdOdd(BigDecimal pcOutSumOdOdd) {
        this.pcOutSumOdOdd = pcOutSumOdOdd;
    }

    public BigDecimal getPcOutSumOdDelay() {
        return pcOutSumOdDelay;
    }

    public void setPcOutSumOdDelay(BigDecimal pcOutSumOdDelay) {
        this.pcOutSumOdDelay = pcOutSumOdDelay;
    }

    public BigDecimal getPcOutSumOd() {
        return pcOutSumOd;
    }

    public void setPcOutSumOd(BigDecimal pcOutSumOd) {
        this.pcOutSumOd = pcOutSumOd;
    }

    public BigDecimal getPcOutSumNegCorr() {
        return pcOutSumNegCorr;
    }

    public void setPcOutSumNegCorr(BigDecimal pcOutSumNegCorr) {
        this.pcOutSumNegCorr = pcOutSumNegCorr;
    }

    public BigDecimal getPcOutSumMsfoPer() {
        return pcOutSumMsfoPer;
    }

    public void setPcOutSumMsfoPer(BigDecimal pcOutSumMsfoPer) {
        this.pcOutSumMsfoPer = pcOutSumMsfoPer;
    }

    public BigDecimal getPcOutSumMsfo1428() {
        return pcOutSumMsfo1428;
    }

    public void setPcOutSumMsfo1428(BigDecimal pcOutSumMsfo1428) {
        this.pcOutSumMsfo1428 = pcOutSumMsfo1428;
    }

    public BigDecimal getPcOutSumMod1435() {
        return pcOutSumMod1435;
    }

    public void setPcOutSumMod1435(BigDecimal pcOutSumMod1435) {
        this.pcOutSumMod1435 = pcOutSumMod1435;
    }

    public BigDecimal getPcOutSumLesion() {
        return pcOutSumLesion;
    }

    public void setPcOutSumLesion(BigDecimal pcOutSumLesion) {
        this.pcOutSumLesion = pcOutSumLesion;
    }

    public BigDecimal getPcOutSumKik() {
        return pcOutSumKik;
    }

    public void setPcOutSumKik(BigDecimal pcOutSumKik) {
        this.pcOutSumKik = pcOutSumKik;
    }

    public BigDecimal getPcOutSumDz1877Kzt() {
        return pcOutSumDz1877Kzt;
    }

    public void setPcOutSumDz1877Kzt(BigDecimal pcOutSumDz1877Kzt) {
        this.pcOutSumDz1877Kzt = pcOutSumDz1877Kzt;
    }

    public BigDecimal getPcOutSumDis2794() {
        return pcOutSumDis2794;
    }

    public void setPcOutSumDis2794(BigDecimal pcOutSumDis2794) {
        this.pcOutSumDis2794 = pcOutSumDis2794;
    }

    public BigDecimal getPcOutSumDis1434() {
        return pcOutSumDis1434;
    }

    public void setPcOutSumDis1434(BigDecimal pcOutSumDis1434) {
        this.pcOutSumDis1434 = pcOutSumDis1434;
    }

    public BigDecimal getPcOutSumDev() {
        return pcOutSumDev;
    }

    public void setPcOutSumDev(BigDecimal pcOutSumDev) {
        this.pcOutSumDev = pcOutSumDev;
    }

    public BigDecimal getPcOutSumDebt1860Kzt() {
        return pcOutSumDebt1860Kzt;
    }

    public void setPcOutSumDebt1860Kzt(BigDecimal pcOutSumDebt1860Kzt) {
        this.pcOutSumDebt1860Kzt = pcOutSumDebt1860Kzt;
    }

    public BigDecimal getPcOutSumCorrEsp() {
        return pcOutSumCorrEsp;
    }

    public void setPcOutSumCorrEsp(BigDecimal pcOutSumCorrEsp) {
        this.pcOutSumCorrEsp = pcOutSumCorrEsp;
    }

    public BigDecimal getPcOutSumComDelay() {
        return pcOutSumComDelay;
    }

    public void setPcOutSumComDelay(BigDecimal pcOutSumComDelay) {
        this.pcOutSumComDelay = pcOutSumComDelay;
    }

    public BigDecimal getPcOutSumCom() {
        return pcOutSumCom;
    }

    public void setPcOutSumCom(BigDecimal pcOutSumCom) {
        this.pcOutSumCom = pcOutSumCom;
    }

    public BigDecimal getPcOutSumAllDebtMonBeg() {
        return pcOutSumAllDebtMonBeg;
    }

    public void setPcOutSumAllDebtMonBeg(BigDecimal pcOutSumAllDebtMonBeg) {
        this.pcOutSumAllDebtMonBeg = pcOutSumAllDebtMonBeg;
    }

    public BigDecimal getPcOutSumAllDebt() {
        return pcOutSumAllDebt;
    }

    public void setPcOutSumAllDebt(BigDecimal pcOutSumAllDebt) {
        this.pcOutSumAllDebt = pcOutSumAllDebt;
    }

    public BigDecimal getPcOperationPayOffSystemAmount() {
        return pcOperationPayOffSystemAmount;
    }

    public void setPcOperationPayOffSystemAmount(BigDecimal pcOperationPayOffSystemAmount) {
        this.pcOperationPayOffSystemAmount = pcOperationPayOffSystemAmount;
    }

    public Date getPcOperationPayOffSystem() {
        return pcOperationPayOffSystem;
    }

    public void setPcOperationPayOffSystem(Date pcOperationPayOffSystem) {
        this.pcOperationPayOffSystem = pcOperationPayOffSystem;
    }

    public Date getPcOperationIsWriteOff() {
        return pcOperationIsWriteOff;
    }

    public void setPcOperationIsWriteOff(Date pcOperationIsWriteOff) {
        this.pcOperationIsWriteOff = pcOperationIsWriteOff;
    }

    public Date getPcOpenDate() {
        return pcOpenDate;
    }

    public void setPcOpenDate(Date pcOpenDate) {
        this.pcOpenDate = pcOpenDate;
    }

    public String getPcOked() {
        return pcOked;
    }

    public void setPcOked(String pcOked) {
        this.pcOked = pcOked;
    }

    public Boolean getPcNonMarketFl() {
        return pcNonMarketFl;
    }

    public void setPcNonMarketFl(Boolean pcNonMarketFl) {
        this.pcNonMarketFl = pcNonMarketFl;
    }

    public BigDecimal getPcMsfoRate() {
        return pcMsfoRate;
    }

    public void setPcMsfoRate(BigDecimal pcMsfoRate) {
        this.pcMsfoRate = pcMsfoRate;
    }

    public String getPcMonPer() {
        return pcMonPer;
    }

    public void setPcMonPer(String pcMonPer) {
        this.pcMonPer = pcMonPer;
    }

    public Date getPcMonDate() {
        return pcMonDate;
    }

    public void setPcMonDate(Date pcMonDate) {
        this.pcMonDate = pcMonDate;
    }

    public String getPcModif() {
        return pcModif;
    }

    public void setPcModif(String pcModif) {
        this.pcModif = pcModif;
    }

    public String getPcModelTransform() {
        return pcModelTransform;
    }

    public void setPcModelTransform(String pcModelTransform) {
        this.pcModelTransform = pcModelTransform;
    }

    public Integer getPcModSubstantial() {
        return pcModSubstantial;
    }

    public void setPcModSubstantial(Integer pcModSubstantial) {
        this.pcModSubstantial = pcModSubstantial;
    }

    public BigDecimal getPcModNpv() {
        return pcModNpv;
    }

    public void setPcModNpv(BigDecimal pcModNpv) {
        this.pcModNpv = pcModNpv;
    }

    public Date getPcModDate() {
        return pcModDate;
    }

    public void setPcModDate(Date pcModDate) {
        this.pcModDate = pcModDate;
    }

    public Date getPcMaxDefaultDate() {
        return pcMaxDefaultDate;
    }

    public void setPcMaxDefaultDate(Date pcMaxDefaultDate) {
        this.pcMaxDefaultDate = pcMaxDefaultDate;
    }

    public Date getPcLastFinDate() {
        return pcLastFinDate;
    }

    public void setPcLastFinDate(Date pcLastFinDate) {
        this.pcLastFinDate = pcLastFinDate;
    }

    public String getPcKodIp() {
        return pcKodIp;
    }

    public void setPcKodIp(String pcKodIp) {
        this.pcKodIp = pcKodIp;
    }

    public Long getPcGid() {
        return pcGid;
    }

    public void setPcGid(Long pcGid) {
        this.pcGid = pcGid;
    }

    public Date getPcGenDate() {
        return pcGenDate;
    }

    public void setPcGenDate(Date pcGenDate) {
        this.pcGenDate = pcGenDate;
    }

    public Date getPcFirstPaymDate() {
        return pcFirstPaymDate;
    }

    public void setPcFirstPaymDate(Date pcFirstPaymDate) {
        this.pcFirstPaymDate = pcFirstPaymDate;
    }

    public Integer getPcExtExpDays() {
        return pcExtExpDays;
    }

    public void setPcExtExpDays(Integer pcExtExpDays) {
        this.pcExtExpDays = pcExtExpDays;
    }

    public Integer getPcExpDaysOpPerc() {
        return pcExpDaysOpPerc;
    }

    public void setPcExpDaysOpPerc(Integer pcExpDaysOpPerc) {
        this.pcExpDaysOpPerc = pcExpDaysOpPerc;
    }

    public Integer getPcExpDays() {
        return pcExpDays;
    }

    public void setPcExpDays(Integer pcExpDays) {
        this.pcExpDays = pcExpDays;
    }

    public String getPcEsector() {
        return pcEsector;
    }

    public void setPcEsector(String pcEsector) {
        this.pcEsector = pcEsector;
    }

    public BigDecimal getPcEffRate() {
        return pcEffRate;
    }

    public void setPcEffRate(BigDecimal pcEffRate) {
        this.pcEffRate = pcEffRate;
    }

    public Integer getPcDuration() {
        return pcDuration;
    }

    public void setPcDuration(Integer pcDuration) {
        this.pcDuration = pcDuration;
    }

    public String getPcDprtName() {
        return pcDprtName;
    }

    public void setPcDprtName(String pcDprtName) {
        this.pcDprtName = pcDprtName;
    }

    public Long getPcDprtGid() {
        return pcDprtGid;
    }

    public void setPcDprtGid(Long pcDprtGid) {
        this.pcDprtGid = pcDprtGid;
    }

    public String getPcDogNum() {
        return pcDogNum;
    }

    public void setPcDogNum(String pcDogNum) {
        this.pcDogNum = pcDogNum;
    }

    public Date getPcDefaultDate() {
        return pcDefaultDate;
    }

    public void setPcDefaultDate(Date pcDefaultDate) {
        this.pcDefaultDate = pcDefaultDate;
    }

    public Date getPcDeathDate() {
        return pcDeathDate;
    }

    public void setPcDeathDate(Date pcDeathDate) {
        this.pcDeathDate = pcDeathDate;
    }

    public String getPcDealRatingDate() {
        return pcDealRatingDate;
    }

    public void setPcDealRatingDate(String pcDealRatingDate) {
        this.pcDealRatingDate = pcDealRatingDate;
    }

    public String getPcDealRating() {
        return pcDealRating;
    }

    public void setPcDealRating(String pcDealRating) {
        this.pcDealRating = pcDealRating;
    }

    public String getPcCurCode() {
        return pcCurCode;
    }

    public void setPcCurCode(String pcCurCode) {
        this.pcCurCode = pcCurCode;
    }

    public Long getPcCurCd() {
        return pcCurCd;
    }

    public void setPcCurCd(Long pcCurCd) {
        this.pcCurCd = pcCurCd;
    }

    public BigDecimal getPcCreditsumKzt() {
        return pcCreditsumKzt;
    }

    public void setPcCreditsumKzt(BigDecimal pcCreditsumKzt) {
        this.pcCreditsumKzt = pcCreditsumKzt;
    }

    public BigDecimal getPcCreditsum() {
        return pcCreditsum;
    }

    public void setPcCreditsum(BigDecimal pcCreditsum) {
        this.pcCreditsum = pcCreditsum;
    }

    public String getPcCreditDep() {
        return pcCreditDep;
    }

    public void setPcCreditDep(String pcCreditDep) {
        this.pcCreditDep = pcCreditDep;
    }

    public BigDecimal getPcCrRateRepDate() {
        return pcCrRateRepDate;
    }

    public void setPcCrRateRepDate(BigDecimal pcCrRateRepDate) {
        this.pcCrRateRepDate = pcCrRateRepDate;
    }

    public BigDecimal getPcCrRateMonthBeg() {
        return pcCrRateMonthBeg;
    }

    public void setPcCrRateMonthBeg(BigDecimal pcCrRateMonthBeg) {
        this.pcCrRateMonthBeg = pcCrRateMonthBeg;
    }

    public Date getPcCourtDate() {
        return pcCourtDate;
    }

    public void setPcCourtDate(Date pcCourtDate) {
        this.pcCourtDate = pcCourtDate;
    }

    public String getPcControlList() {
        return pcControlList;
    }

    public void setPcControlList(String pcControlList) {
        this.pcControlList = pcControlList;
    }

    public String getPcClntName() {
        return pcClntName;
    }

    public void setPcClntName(String pcClntName) {
        this.pcClntName = pcClntName;
    }

    public Long getPcClntGid() {
        return pcClntGid;
    }

    public void setPcClntGid(Long pcClntGid) {
        this.pcClntGid = pcClntGid;
    }

    public String getPcCliType() {
        return pcCliType;
    }

    public void setPcCliType(String pcCliType) {
        this.pcCliType = pcCliType;
    }

    public Date getPcCliRatingDate() {
        return pcCliRatingDate;
    }

    public void setPcCliRatingDate(Date pcCliRatingDate) {
        this.pcCliRatingDate = pcCliRatingDate;
    }

    public String getPcCliRating() {
        return pcCliRating;
    }

    public void setPcCliRating(String pcCliRating) {
        this.pcCliRating = pcCliRating;
    }

    public String getPcCliRatiOut() {
        return pcCliRatiOut;
    }

    public void setPcCliRatiOut(String pcCliRatiOut) {
        this.pcCliRatiOut = pcCliRatiOut;
    }

    public String getPcCliOkedCd() {
        return pcCliOkedCd;
    }

    public void setPcCliOkedCd(String pcCliOkedCd) {
        this.pcCliOkedCd = pcCliOkedCd;
    }

    public String getPcCliIinBin() {
        return pcCliIinBin;
    }

    public void setPcCliIinBin(String pcCliIinBin) {
        this.pcCliIinBin = pcCliIinBin;
    }

    public String getPcClass() {
        return pcClass;
    }

    public void setPcClass(String pcClass) {
        this.pcClass = pcClass;
    }

    public String getPcCgrpName() {
        return pcCgrpName;
    }

    public void setPcCgrpName(String pcCgrpName) {
        this.pcCgrpName = pcCgrpName;
    }

    public String getPcCessionValue() {
        return pcCessionValue;
    }

    public void setPcCessionValue(String pcCessionValue) {
        this.pcCessionValue = pcCessionValue;
    }

    public Integer getPcBasketRepDate() {
        return pcBasketRepDate;
    }

    public void setPcBasketRepDate(Integer pcBasketRepDate) {
        this.pcBasketRepDate = pcBasketRepDate;
    }

    public Integer getPcBasketMonBeg() {
        return pcBasketMonBeg;
    }

    public void setPcBasketMonBeg(Integer pcBasketMonBeg) {
        this.pcBasketMonBeg = pcBasketMonBeg;
    }

    public Date getPcBankruptDate() {
        return pcBankruptDate;
    }

    public void setPcBankruptDate(Date pcBankruptDate) {
        this.pcBankruptDate = pcBankruptDate;
    }

    public BigDecimal getPcAllSum() {
        return pcAllSum;
    }

    public void setPcAllSum(BigDecimal pcAllSum) {
        this.pcAllSum = pcAllSum;
    }

    public Date getPcActFinDate() {
        return pcActFinDate;
    }

    public void setPcActFinDate(Date pcActFinDate) {
        this.pcActFinDate = pcActFinDate;
    }

    public Integer getPc() {
        return pc;
    }

    public void setPc(Integer pc) {
        this.pc = pc;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}