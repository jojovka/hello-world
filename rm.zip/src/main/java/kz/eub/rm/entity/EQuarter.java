package kz.eub.rm.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum EQuarter implements EnumClass<String> {

    FIRST_QUARTER("Первый квартал"),
    SECOND_QUARTER("Второй квартал"),
    THIRD_QUARTER("Третий квартал"),
    FOURTH_QUARTER("Четвертый квартал");

    private String id;

    EQuarter(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static EQuarter fromId(String id) {
        for (EQuarter at : EQuarter.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}