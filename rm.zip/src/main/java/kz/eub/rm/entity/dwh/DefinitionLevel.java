package kz.eub.rm.entity.dwh;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum DefinitionLevel implements EnumClass<String> {

    CREDIT("CREDIT"),
    POZ("POZ"),
    CLIENT("CLIENT"),
    SEGMENT("SEGMENT"),
    CLIENT_POZ("CLIENTPOZ");

    private String id;

    DefinitionLevel(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static DefinitionLevel fromId(String id) {
        for (DefinitionLevel at : DefinitionLevel.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}