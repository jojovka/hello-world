package kz.eub.rm.entity.dwh;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.SystemLevel;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;
import io.jmix.core.metamodel.annotation.Store;
import kz.eub.rm.entity.User;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhstore")
@Table(name = "s00_dict_snp_pnz_macrocorrect", schema = "dwh_risk", indexes = {
        @Index(name = "IDX_S00DICTSNPNP_SDNSMUSERUUI", columnList = "sdnsm_user_uuid")
})
@Entity(name = "rm_PnzMacroAdjustmentDictionary")
public class PnzMacroAdjustmentDictionary implements StandardDictionaryEntity {

    @Column(name = "sdnsm_uuid", nullable = false)
    @JmixGeneratedValue
    @Id
    private UUID id;

    @Column(name = "sdnsm_segm")
    private String segmentName;

    @Column(name = "sdnsm_delta_coef", precision = 19, scale = 2)
    private BigDecimal deltaCoefficient;

    @Column(name = "sdnsm_is_actual")
    private Boolean isActual;

    @Column(name = "sdnsm$start_date")
    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Column(name = "sdnsm$end_date")
    @Temporal(TemporalType.DATE)
    private Date endDate;

    @Column(name = "sdnsm$change_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date changeDate;

    @SystemLevel
    @Column(name = "sdnsm_user_uuid")
    private UUID changerUserId;

    @DependsOnProperties({"changerUserId"})
    @JmixProperty
    @Transient
    private User changerUser;

    public User getChangerUser() {
        return changerUser;
    }

    public void setChangerUser(User changerUser) {
        this.changerUser = changerUser;
    }

    @Override
    public UUID getChangerUserId() {
        return changerUserId;
    }

    @Override
    public void setChangerUserId(UUID userId) {
        this.changerUserId = userId;
    }

    @Override
    public Date getChangeDate() {
        return changeDate;
    }

    @Override
    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Boolean getIsActual() {
        return isActual;
    }

    public void setIsActual(Boolean isActual) {
        this.isActual = isActual;
    }

    public BigDecimal getDeltaCoefficient() {
        return deltaCoefficient;
    }

    public void setDeltaCoefficient(BigDecimal deltaCoefficient) {
        this.deltaCoefficient = deltaCoefficient;
    }

    public String getSegmentName() {
        return segmentName;
    }

    public void setSegmentName(String segmentName) {
        this.segmentName = segmentName;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}