package kz.eub.rm.entity.dwh;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhstore")
@Table(name = "stages_dict", schema = "dwh_risk")
@Entity(name = "rm_RunStage")
public class RunStage {

    @Column(name = "sd_id", nullable = false)
    private UUID id;

    @InstanceName
    @Column(name = "sd_stage_name")
    private String name;

    @Column(name = "sd_function_name")
    private String functionName;

    @Column(name = "sd_order")
    private Integer order;

    @Column(name = "sd_is_actual")
    private Boolean isActual;

    @Column(name = "sd_alias")
    @Id
    private String alias;

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public Boolean getIsActual() {
        return isActual;
    }

    public void setIsActual(Boolean isActual) {
        this.isActual = isActual;
    }

    public Integer getOrder() {
        return order;
    }

    public void setOrder(Integer order) {
        this.order = order;
    }

    public String getFunctionName() {
        return functionName;
    }

    public void setFunctionName(String functionName) {
        this.functionName = functionName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}