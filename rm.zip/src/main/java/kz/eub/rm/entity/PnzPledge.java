package kz.eub.rm.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;
import io.jmix.data.DbView;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@DbView
@JmixEntity
@Store(name = "dwhstore")
@Table(name = "pnz_pledges_view", schema = "dwh_risk")
@Entity(name = "rm_PnzPledge")
public class PnzPledge {
    @JmixGeneratedValue
    @Column(name = "uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "KIND_ENS")
    private String kindEns;

    @Column(name = "DATE_NOK")
    @Temporal(TemporalType.DATE)
    private Date dateNok;

    @Column(name = "PRICE_ENS", precision = 19, scale = 2)
    private BigDecimal priceEns;

    @Column(name = "PRICE_KZT_ENS", precision = 19, scale = 2)
    private BigDecimal priceKztEns;

    @Column(name = "DATE_MON")
    @Temporal(TemporalType.DATE)
    private Date dateMon;

    @Column(name = "al_price")
    private BigDecimal alPrice;

    @Column(name = "clnt_full_name")
    @Lob
    private String clntFullName;

    @Column(name = "clnt_iin_bin")
    @Lob
    private String clntIinBin;

    @Column(name = "coeff")
    private BigDecimal coeff;

    @Column(name = "dlpled_cur_cd")
    private Long dlpledCurCd;

    @Column(name = "dlpled_dog_num", length = 30)
    private String dlpledDogNum;

    @Column(name = "dlpled_gid")
    private Long dlpledGid;

    @Column(name = "dlpled_open_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dlpledOpenDate;

    @Column(name = "dlpled_price")
    private BigDecimal dlpledPrice;

    @Column(name = "dlpled_price_nat")
    private BigDecimal dlpledPriceNat;

    @Column(name = "dlpled_status", length = 250)
    private String dlpledStatus;

    @Column(name = "lr_typename")
    @Lob
    private String lrTypename;

    @Column(name = "pc_id")
    private Integer pledgeId;

    @Column(name = "pc_cli_iin_bin")
    @Lob
    private String pcCliIinBin;

    @Column(name = "pc_clnt_name")
    @Lob
    private String pcClntName;

    @Column(name = "pc_cur_code", length = 3)
    private String pcCurCode;

    @Column(name = "pc_dog_num")
    @Lob
    private String pcDogNum;

    @Column(name = "pc_dprt_name")
    @Lob
    private String pcDprtName;

    @Column(name = "pc_report_date")
    @Temporal(TemporalType.DATE)
    private Date pcReportDate;

    @Column(name = "pc_run_id")
    @Lob
    private String runId;

    @Column(name = "pc_state")
    @Lob
    private String pcState;

    @Column(name = "pledobj_gid")
    private Long pledobjGid;

    public Date getDateMon() {
        return dateMon;
    }

    public void setDateMon(Date dateMon) {
        this.dateMon = dateMon;
    }

    public BigDecimal getPriceKztEns() {
        return priceKztEns;
    }

    public void setPriceKztEns(BigDecimal priceKztEns) {
        this.priceKztEns = priceKztEns;
    }

    public BigDecimal getPriceEns() {
        return priceEns;
    }

    public void setPriceEns(BigDecimal priceEns) {
        this.priceEns = priceEns;
    }

    public Date getDateNok() {
        return dateNok;
    }

    public void setDateNok(Date dateNok) {
        this.dateNok = dateNok;
    }

    public String getKindEns() {
        return kindEns;
    }

    public void setKindEns(String kindEns) {
        this.kindEns = kindEns;
    }

    public Long getPledobjGid() {
        return pledobjGid;
    }

    public void setPledobjGid(Long pledobjGid) {
        this.pledobjGid = pledobjGid;
    }

    public String getPcState() {
        return pcState;
    }

    public void setPcState(String pcState) {
        this.pcState = pcState;
    }

    public String getRunId() {
        return runId;
    }

    public void setRunId(String pcRun) {
        this.runId = pcRun;
    }

    public Date getPcReportDate() {
        return pcReportDate;
    }

    public void setPcReportDate(Date pcReportDate) {
        this.pcReportDate = pcReportDate;
    }

    public String getPcDprtName() {
        return pcDprtName;
    }

    public void setPcDprtName(String pcDprtName) {
        this.pcDprtName = pcDprtName;
    }

    public String getPcDogNum() {
        return pcDogNum;
    }

    public void setPcDogNum(String pcDogNum) {
        this.pcDogNum = pcDogNum;
    }

    public String getPcCurCode() {
        return pcCurCode;
    }

    public void setPcCurCode(String pcCurCode) {
        this.pcCurCode = pcCurCode;
    }

    public String getPcClntName() {
        return pcClntName;
    }

    public void setPcClntName(String pcClntName) {
        this.pcClntName = pcClntName;
    }

    public String getPcCliIinBin() {
        return pcCliIinBin;
    }

    public void setPcCliIinBin(String pcCliIinBin) {
        this.pcCliIinBin = pcCliIinBin;
    }

    public Integer getPledgeId() {
        return pledgeId;
    }

    public void setPledgeId(Integer pc) {
        this.pledgeId = pc;
    }

    public String getLrTypename() {
        return lrTypename;
    }

    public void setLrTypename(String lrTypename) {
        this.lrTypename = lrTypename;
    }

    public String getDlpledStatus() {
        return dlpledStatus;
    }

    public void setDlpledStatus(String dlpledStatus) {
        this.dlpledStatus = dlpledStatus;
    }

    public BigDecimal getDlpledPriceNat() {
        return dlpledPriceNat;
    }

    public void setDlpledPriceNat(BigDecimal dlpledPriceNat) {
        this.dlpledPriceNat = dlpledPriceNat;
    }

    public BigDecimal getDlpledPrice() {
        return dlpledPrice;
    }

    public void setDlpledPrice(BigDecimal dlpledPrice) {
        this.dlpledPrice = dlpledPrice;
    }

    public Date getDlpledOpenDate() {
        return dlpledOpenDate;
    }

    public void setDlpledOpenDate(Date dlpledOpenDate) {
        this.dlpledOpenDate = dlpledOpenDate;
    }

    public Long getDlpledGid() {
        return dlpledGid;
    }

    public void setDlpledGid(Long dlpledGid) {
        this.dlpledGid = dlpledGid;
    }

    public String getDlpledDogNum() {
        return dlpledDogNum;
    }

    public void setDlpledDogNum(String dlpledDogNum) {
        this.dlpledDogNum = dlpledDogNum;
    }

    public Long getDlpledCurCd() {
        return dlpledCurCd;
    }

    public void setDlpledCurCd(Long dlpledCurCd) {
        this.dlpledCurCd = dlpledCurCd;
    }

    public BigDecimal getCoeff() {
        return coeff;
    }

    public void setCoeff(BigDecimal coeff) {
        this.coeff = coeff;
    }

    public String getClntIinBin() {
        return clntIinBin;
    }

    public void setClntIinBin(String clntIinBin) {
        this.clntIinBin = clntIinBin;
    }

    public String getClntFullName() {
        return clntFullName;
    }

    public void setClntFullName(String clntFullName) {
        this.clntFullName = clntFullName;
    }

    public BigDecimal getAlPrice() {
        return alPrice;
    }

    public void setAlPrice(BigDecimal alPrice) {
        this.alPrice = alPrice;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}