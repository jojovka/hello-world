package kz.eub.rm.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;
import io.jmix.core.metamodel.annotation.Store;
import kz.eub.rm.entity.dwh.HasId;
import kz.eub.rm.entity.dwh.RunStage;

import javax.persistence.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhstore")
@Table(name = "pnz_run_history2", schema = "dwh_risk")
@Entity(name = "rm_PnzRunHistory")
public class PnzRunHistory implements HasId {
    @JmixGeneratedValue
    @Column(name = "prh_id", nullable = false)
    @Id
    private UUID id;

    @Column(name = "prh_report_date")
    @Temporal(TemporalType.DATE)
    private Date reportDate;

    @Column(name = "prh_creation_date")
    @Temporal(TemporalType.DATE)
    private Date creationDate;

    @Column(name = "prh_creation_by")
    private String createdBy;

    @Column(name = "prh_run_number")
    private Integer runNumber;

    @Column(name = "prh_is_approved")
    private Boolean isApproved;

    @Column(name = "prh_run_id")
    private String runId;

    @JoinColumn(name = "prh_stage_text")
    @ManyToOne(fetch = FetchType.LAZY)
    private RunStage status;

    @JmixProperty
    @Transient
    @InstanceName
    private String name;

    public RunStage getStatus() {
        return status;
    }

    public void setStatus(RunStage status) {
        this.status = status;
    }

    @PostLoad
    private void onLoad() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy");
        name=String.format("%s #%s %s", simpleDateFormat.format(reportDate), runNumber, (isApproved!=null && isApproved)?"утвержденный":"");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRunId() {
        return runId;
    }

    public void setRunId(String runId) {
        this.runId = runId;
    }

    public Boolean getIsApproved() {
        return isApproved;
    }

    public void setIsApproved(Boolean isApproved) {
        this.isApproved = isApproved;
    }

    public Integer getRunNumber() {
        return runNumber;
    }

    public void setRunNumber(Integer runNumber) {
        this.runNumber = runNumber;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Date getReportDate() {
        return reportDate;
    }

    public void setReportDate(Date reportDate) {
        this.reportDate = reportDate;
    }

    @Override
    public UUID getId() {
        return id;
    }

    @Override
    public void setId(UUID id) {
        this.id = id;
    }
}