package kz.eub.rm.entity.dwh;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum TriggerType implements EnumClass<String> {

    DEFAULT("Default"),
    RECOVERY("Recovery"),
    BASKET("Basket");

    private String id;

    TriggerType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static TriggerType fromId(String id) {
        for (TriggerType at : TriggerType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}