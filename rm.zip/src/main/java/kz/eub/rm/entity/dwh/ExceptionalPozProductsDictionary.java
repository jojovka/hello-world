package kz.eub.rm.entity.dwh;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;
import io.jmix.core.metamodel.annotation.Store;
import kz.eub.rm.entity.ChangeDateMemorizingEntity;
import kz.eub.rm.entity.User;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

//справочник продуктов исключений ПОЗ??
@JmixEntity
@Store(name = "dwhstore")
@Table(name = "s00_dict_snp_poz_product", schema = "dwh_risk", indexes = {
        @Index(name = "IDX_SDSPP_PRD_ID", columnList = "sdspp_prd_uuid")
})
@Entity(name = "rm_ExceptionalPozProductsDictionary")
public class ExceptionalPozProductsDictionary implements ChangeDateMemorizingEntity {
    @JmixGeneratedValue
    @Column(name = "sdspp_uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "\"sdspp$change_date\"")
    @Temporal(TemporalType.TIMESTAMP)
    private Date changeDate;

    @Column(name = "\"sdspp$start_date\"")
    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Column(name = "\"sdspp$end_date\"")
    @Temporal(TemporalType.DATE)
    private Date endDate;

    @InstanceName
    @Column(name = "\"sdspp$row_status\"", length = 10)
    private String rowStatus;

    @JoinColumn(name = "sdspp_prd_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private ProductReferenceDictionary prdId;

    @Column(name = "sdspp_user_uuid")
    private UUID userId;

    @JmixProperty
    @Transient
    private User user;

    public void setPrdId(ProductReferenceDictionary prdId) {
        this.prdId = prdId;
    }

    public ProductReferenceDictionary getPrdId() {
        return prdId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public String getRowStatus() {
        return rowStatus;
    }

    public void setRowStatus(String rowStatus) {
        this.rowStatus = rowStatus;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    @Override
    public Date getChangeDate() {
        return changeDate;
    }

    @Override
    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @PrePersist
    public void prePersist() {
        userId = null;
        if (user != null) {
            userId = user.getId();
        }
    }
}