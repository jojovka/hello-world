package kz.eub.rm.entity.dwh;

import io.jmix.core.metamodel.annotation.JmixEntity;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@JmixEntity(name = "rm_CreditContractsId")
@Embeddable
public class CreditContractsId implements Serializable {
    @Column(name = "c_gid")
    private Long gid;

    @Column(name = "cs_run_id")
    private String runId;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (!(o instanceof CreditContractsId)) return false;

        CreditContractsId that = (CreditContractsId) o;

        return new EqualsBuilder().append(gid, that.gid).append(runId, that.runId).isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37).append(gid).append(runId).toHashCode();
    }

    public String getRunId() {
        return runId;
    }

    public void setRunId(String runId) {
        this.runId = runId;
    }

    public Long getGid() {
        return gid;
    }

    public void setGid(Long gid) {
        this.gid = gid;
    }
}