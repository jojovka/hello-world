package kz.eub.rm.entity.listener.support;

import io.jmix.core.event.EntitySavingEvent;
import kz.eub.rm.entity.ChangeMemorizingEntity;
import kz.eub.rm.entity.dwh.StandardDictionaryEntity;

public interface DictionaryRowAdjustmentSupport {
    void adjustOnSave(EntitySavingEvent<? extends ChangeMemorizingEntity> event);
}
