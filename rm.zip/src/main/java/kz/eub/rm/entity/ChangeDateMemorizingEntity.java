package kz.eub.rm.entity;

import java.util.Date;

//интерфейс сущности записи, хранящей информацию о дате изменения
public interface ChangeDateMemorizingEntity {
    Date getChangeDate();

    void setChangeDate(Date date);
}
