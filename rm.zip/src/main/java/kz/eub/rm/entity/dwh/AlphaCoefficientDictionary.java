package kz.eub.rm.entity.dwh;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.SystemLevel;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;
import io.jmix.core.metamodel.annotation.Store;
import kz.eub.rm.entity.User;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "s00_dict_snp_alf", schema = "dwh_risk", indexes = {
        @Index(name = "IDX_S00DICTSNPALF_SDSASGMUUID", columnList = "sdsa_sgm_uuid")
})
@Store(name = "dwhstore")
@Entity(name = "rm_AlphaCoefficientDictionary")
public class AlphaCoefficientDictionary implements StandardDictionaryEntity {

    @JoinColumn(name = "sdsa_sgm_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private PozSegmentationDictionary pozSegment;

    @Column(name = "sdsa_depth")
    private Integer depth;

    @Column(name = "sdsa_term_pdlt")
    private Integer pdltTerm;

    @Column(name = "sdsa_moda_percent", precision = 19, scale = 2)
    private BigDecimal modaPercent;

    @Column(name = "sdsa_is_actual")
    private Boolean isActual;

    @Column(name = "sdsa$start_date")
    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Column(name = "sdsa$end_date")
    @Temporal(TemporalType.DATE)
    private Date endDate;

    @Column(name = "sdsa_prov_cnt", precision = 19, scale = 2)
    private BigDecimal monthNumberRrForProvisions;

    @Column(name = "sdsa$change_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date changeDate;

    @SystemLevel
    @Column(name = "sdsa_user_uuid")
    private UUID changerUserId;

    @Column(name = "sdsa_uuid", nullable = false)
    @JmixGeneratedValue
    @Id
    private UUID id;

    @Column(name = "sdsa_dr_alf_period")
    private Integer alphaDrPeriod;

    @DependsOnProperties({"changerUserId"})
    @JmixProperty
    @Transient
    private User changerUser;

    @Column(name = "sdsa_tv_depth")
    private Integer tvDepth;

    public Integer getTvDepth() {
        return tvDepth;
    }

    public void setTvDepth(Integer tvDepth) {
        this.tvDepth = tvDepth;
    }

    public BigDecimal getMonthNumberRrForProvisions() {
        return monthNumberRrForProvisions;
    }

    public void setMonthNumberRrForProvisions(BigDecimal monthNumberRrForProvisions) {
        this.monthNumberRrForProvisions = monthNumberRrForProvisions;
    }

    public Integer getPdltTerm() {
        return pdltTerm;
    }

    public void setPdltTerm(Integer pdltTerm) {
        this.pdltTerm = pdltTerm;
    }

    public Integer getAlphaDrPeriod() {
        return alphaDrPeriod;
    }

    public void setAlphaDrPeriod(Integer alphaDrPeriod) {
        this.alphaDrPeriod = alphaDrPeriod;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID uuid) {
        this.id = uuid;
    }

    public User getChangerUser() {
        return changerUser;
    }

    public void setChangerUser(User changerUser) {
        this.changerUser = changerUser;
    }

    @Override
    public UUID getChangerUserId() {
        return changerUserId;
    }

    @Override
    public void setChangerUserId(UUID changerId) {
        this.changerUserId = changerId;
    }

    @Override
    public Date getChangeDate() {
        return changeDate;
    }

    @Override
    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Boolean getIsActual() {
        return isActual;
    }

    public void setIsActual(Boolean isActual) {
        this.isActual = isActual;
    }

    public BigDecimal getModaPercent() {
        return modaPercent;
    }

    public void setModaPercent(BigDecimal modaPercent) {
        this.modaPercent = modaPercent;
    }

    public Integer getDepth() {
        return depth;
    }

    public void setDepth(Integer depth) {
        this.depth = depth;
    }

    public PozSegmentationDictionary getPozSegment() {
        return pozSegment;
    }

    public void setPozSegment(PozSegmentationDictionary pozSegment) {
        this.pozSegment = pozSegment;
    }

}