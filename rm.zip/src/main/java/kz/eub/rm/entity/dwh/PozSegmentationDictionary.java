package kz.eub.rm.entity.dwh;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.Store;
import kz.eub.rm.entity.ChangeDateMemorizingEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;
import java.util.UUID;

@JmixEntity
@Store(name = "dwhstore")
@Table(name = "s00_dict_snp_poz_segm", schema = "dwh_risk", indexes = {
        @Index(name = "IDX_SDSPS_POZ_UUID", columnList = "sdsps_poz_uuid")
})
@Entity(name = "rm_PozSegmentationDictionary")
public class PozSegmentationDictionary implements ChangeDateMemorizingEntity {
    @JmixGeneratedValue
    @Column(name = "sdsps_uuid", nullable = false)
    @Id
    private UUID id;

    @Column(name = "sdsps_change_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date changeDate;

    @JoinColumn(name = "sdsps_poz_uuid")
    @ManyToOne(fetch = FetchType.LAZY)
    private PozDictionary pozId;

    @InstanceName
    @Column(name = "sdsps_segm")
    private String segment;

    @Column(name = "sdsps_amount_min", precision = 19, scale = 2)
    private BigDecimal amountMin;

    @Column(name = "sdsps_amount_max", precision = 19, scale = 2)
    private BigDecimal amountMax;

    @Column(name = "sdsps_duration_min", precision = 19, scale = 2)
    private BigDecimal durationMin;

    @Column(name = "sdsps_duration_max", precision = 19, scale = 2)
    private BigDecimal durationMax;

    public BigDecimal getDurationMax() {
        return durationMax;
    }

    public void setDurationMax(BigDecimal durationMax) {
        this.durationMax = durationMax;
    }

    public BigDecimal getDurationMin() {
        return durationMin;
    }

    public void setDurationMin(BigDecimal durationMin) {
        this.durationMin = durationMin;
    }

    public BigDecimal getAmountMax() {
        return amountMax;
    }

    public void setAmountMax(BigDecimal amountMax) {
        this.amountMax = amountMax;
    }

    public BigDecimal getAmountMin() {
        return amountMin;
    }

    public void setAmountMin(BigDecimal amountMin) {
        this.amountMin = amountMin;
    }

    public String getSegment() {
        return segment;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public PozDictionary getPozId() {
        return pozId;
    }

    public void setPozId(PozDictionary pozId) {
        this.pozId = pozId;
    }

    @Override
    public Date getChangeDate() {
        return changeDate;
    }

    @Override
    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PozSegmentationDictionary that = (PozSegmentationDictionary) o;
        return segment.equals(that.segment);
    }

    @Override
    public int hashCode() {
        return Objects.hash(segment);
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}