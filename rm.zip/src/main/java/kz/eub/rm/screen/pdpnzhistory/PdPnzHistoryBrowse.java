package kz.eub.rm.screen.pdpnzhistory;

import io.jmix.ui.component.Button;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.Table;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.PdPnzHistory;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("rm_PdPnzHistory.browse")
@UiDescriptor("pd-pnz-history-browse.xml")
@LookupComponent("pdPnzHistoriesTable")
public class PdPnzHistoryBrowse extends StandardLookup<PdPnzHistory> {
    @Autowired
    private Button approveButton;
    @Autowired
    private GroupTable<PdPnzHistory> pdPnzHistoryTable;

    @Subscribe("approveButton")
    public void onApproveButtonClick(Button.ClickEvent event) {

    }

    @Subscribe("pdPnzHistoryTable")
    public void onPdPnzHistoryTableSelection(Table.SelectionEvent<PdPnzHistory> event) {
        toggleApproveButton();
    }

    private void toggleApproveButton() {
        approveButton.setEnabled(pdPnzHistoryTable.getSingleSelected()!=null);
    }
}