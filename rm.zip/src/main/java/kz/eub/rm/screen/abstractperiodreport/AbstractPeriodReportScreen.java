package kz.eub.rm.screen.abstractperiodreport;

import io.jmix.reportsui.runner.UiReportRunner;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.DateField;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.file.FileDownloadButtonFactory;
import kz.eub.rm.file.FileGenerationButtonFactory;
import kz.eub.rm.file.ReportDownloadButtonConfiguration;
import kz.eub.rm.file.ReportDownloadButtonConfigurationBuilder;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;

/*
 * базовый экран для всех отчетов с выгрузкой за период
 * добавляет поля выбора дат начала и окончания
 * добавляет кнопку генерации и выгрузки отчета downloadReportButton
 * добавляет параметры dateFrom и dateTo в отчет
 */
@UiController("rm_AbstractPeriodReportScreen")
@UiDescriptor("abstract-period-report-screen.xml")
public abstract class AbstractPeriodReportScreen extends Screen {
    @Autowired
    protected FileDownloadButtonFactory fileDownloadButtonFactory;

    @Autowired
    protected UiReportRunner uiReportRunner;

    protected Button downloadReportButton;

    @Autowired
    protected DateField dateFromField;
    @Autowired
    protected DateField dateToField;
    @Autowired
    protected ButtonsPanel buttonsPanel;

    public AbstractPeriodReportScreen() {
        addInitListener(this::onInit);
    }

    public void onInit(InitEvent event) {
        setupDownloadReportButton();
    }

    protected void setupDownloadReportButton() {
        downloadReportButton = fileDownloadButtonFactory.createForReport(buildDownloadReportButtonConfiguration());
        downloadReportButton.setEnabled(false);
        buttonsPanel.add(downloadReportButton);
    }

    private ReportDownloadButtonConfiguration buildDownloadReportButtonConfiguration() {
        return ReportDownloadButtonConfiguration.builder(uiReportRunner, getReportCode())
                .onClickParametersAdjustmentDelegate(this::onClickParametersAdjustmentDelegate).build();
    }

    protected void onClickParametersAdjustmentDelegate(Map<String, Object> parameters) {
        parameters.put("dateFrom", dateFromField.getValue());
        parameters.put("dateTo", dateToField.getValue());
    }

    @Subscribe("dateFromField")
    public void onDateFromFieldValueChange(HasValue.ValueChangeEvent event) {
        toggleDownloadReportButton();
    }

    @Subscribe("dateToField")
    public void onDateToFieldValueChange(HasValue.ValueChangeEvent event) {
        toggleDownloadReportButton();
    }

    protected void toggleDownloadReportButton() {
        downloadReportButton.setEnabled(needEnableDownloadReportButton());
    }

    protected boolean needEnableDownloadReportButton() {
        return dateFromField.getValue()!=null && dateToField.getValue()!=null;
    }

    protected abstract String getReportCode();
}