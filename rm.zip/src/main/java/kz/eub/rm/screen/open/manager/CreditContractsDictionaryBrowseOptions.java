package kz.eub.rm.screen.open.manager;

import io.jmix.ui.screen.ScreenOptions;

import java.util.Optional;

public class CreditContractsDictionaryBrowseOptions implements ScreenOptions {
    private String idOfLatestRun;

    private FilterMode filterMode;

    public CreditContractsDictionaryBrowseOptions(String idOfLatestRun, FilterMode filterMode) {
        this.idOfLatestRun = idOfLatestRun;
        this.filterMode = Optional.ofNullable(filterMode).orElse(FilterMode.NO_FILTER);
    }

    public String getIdOfLatestRun() {
        return idOfLatestRun;
    }

    public void setIdOfLatestRun(String idOfLatestRun) {
        this.idOfLatestRun = idOfLatestRun;
    }

    public FilterMode getFilterMode() {
        return filterMode;
    }

    public void setFilterMode(FilterMode filterMode) {
        this.filterMode = filterMode;
    }

    public enum FilterMode {
        NO_FILTER,
        FOURTH_BASKET
    }
}
