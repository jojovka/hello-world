package kz.eub.rm.screen.dictionary.snp.alphacoefficientdictionary;

import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.AlphaCoefficientDictionary;

@UiController("rm_AlphaCoefficientDictionary.edit")
@UiDescriptor("alpha-coefficient-dictionary-edit.xml")
@EditedEntityContainer("alphaCoefficientDictionaryDc")
public class AlphaCoefficientDictionaryEdit extends StandardEditor<AlphaCoefficientDictionary> {
}