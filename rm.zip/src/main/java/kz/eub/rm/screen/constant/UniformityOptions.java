package kz.eub.rm.screen.constant;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class UniformityOptions {
    public static final List<String> LIST = new ArrayList<>();
    static {
        LIST.add("Однородные");
        LIST.add("Неоднородные");
        LIST.add("Однородные/Неоднородные");
    }
}
