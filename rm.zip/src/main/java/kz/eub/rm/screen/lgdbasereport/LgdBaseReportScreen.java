package kz.eub.rm.screen.lgdbasereport;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.screen.pozsegmentchoicereport.PozSegmentChoiceReportScreen;
import kz.eub.rm.screen.segmentandpozchoicereport.SegmentAndPozChoiceReportScreen;

@UiController("rm_LgdBaseReportScreen")
@UiDescriptor("lgd-base-report-screen.xml")
public class LgdBaseReportScreen extends SegmentAndPozChoiceReportScreen {
    @Override
    protected String getReportCode() {
        return "lgd-base-report";
    }
}