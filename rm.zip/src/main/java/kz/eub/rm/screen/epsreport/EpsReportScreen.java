package kz.eub.rm.screen.epsreport;

import io.jmix.core.DataManager;
import io.jmix.core.Metadata;
import io.jmix.ui.Actions;
import io.jmix.ui.Notifications;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.entitypicker.EntityClearAction;
import io.jmix.ui.component.*;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.CreditContractsDictionary;
import kz.eub.rm.screen.pozuserfriendlyreport.PozUserFriendlyReportScreen;
import kz.eub.rm.ui.action.CreditContractsLookupAction;
import kz.eub.rm.ui.component.CustomEntitySuggestionField;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@UiController("rm_EpsReportScreen")
@UiDescriptor("eps-report-screen.xml")
public class EpsReportScreen extends PozUserFriendlyReportScreen {

    private CustomEntitySuggestionField<CreditContractsDictionary> creditSuggestionField;
    private ProgressBar progressBar;
    @Autowired
    private HBoxLayout searchHbox;

    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private Actions actions;
    @Autowired
    private Metadata metadata;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private Notifications notifications;

    //todo распихать конфигурацию по отдельным методам
    //todo переписать саджешшн филд с крутилкой в ашбоксе на единый композитный компонент
    @Subscribe
    public void onInit(InitEvent event) {
        creditSuggestionField = uiComponents.create(CustomEntitySuggestionField.NAME);
        creditSuggestionField.setMetaClass(metadata.getClass(CreditContractsDictionary.class));
        creditSuggestionField.setSearchExecutor(this::creditSuggestionFieldSearchExecutor);
        creditSuggestionField.addValueChangeListener(this::onCreditEntityPickerValueChange);

        creditSuggestionField.addAction(actions.create(CreditContractsLookupAction.ID));
        creditSuggestionField.addAction(actions.create(EntityClearAction.ID));

        creditSuggestionField.setOnSearchStart(this::onSearchStart);
        creditSuggestionField.setOnSearchDone(this::onSearchDone);
        creditSuggestionField.setOnSearchCancelled(this::onSearchCancelled);

        searchHbox.add(creditSuggestionField);

        progressBar = uiComponents.create(ProgressBar.class);
        progressBar.setStyleName("indeterminate-circle");
        progressBar.setAlignment(Component.Alignment.MIDDLE_CENTER);
        progressBar.setIndeterminate(true);
        progressBar.setVisible(false);

        searchHbox.add(progressBar);
    }

    public void onCreditEntityPickerValueChange(HasValue.ValueChangeEvent<CreditContractsDictionary> event) {
        toggleDownloadReportButton();
    }

    public void onSearchStart(Void v) {
        progressBar.setVisible(true);
    }

    public void onSearchDone(List<CreditContractsDictionary> searchResult){
        if (searchResult.isEmpty()) {
            notifications.create().withDescription("Ничего не найдено").withType(Notifications.NotificationType.HUMANIZED).show();
        }
        progressBar.setVisible(false);
    }

    public void onSearchCancelled(Void v){
        progressBar.setVisible(false);
    }

    protected void toggleDownloadReportButton() {
        downloadReportButton.setEnabled((runId != null)&&(creditSuggestionField.getValue()!=null));
    }

    @Override
    protected void adjustReportParameters(Map<String, Object> parameters) {
        super.adjustReportParameters(parameters);
        parameters.put("creditgid", creditSuggestionField.getValue().getCGid());
    }
    @Override
    protected String getReportCode() {
        return "eps-report";
    }

    private List<CreditContractsDictionary> creditSuggestionFieldSearchExecutor(String searchString, Map<String, Object> searchParams) {
        List<CreditContractsDictionary> creditContracts = dataManager.load(CreditContractsDictionary.class)
                .query("select c from rm_CreditContractsDictionary c where c.runId=:runId and c.basketOnReportDate=4 and lower(c.cDogNum) like lower(:searchString) escape '\\'")
                .parameter("searchString", "%"+searchString+"%")
                .parameter("runId", runId)
                .maxResults(10)
                .list()
                .stream()
                .distinct()
                .collect(Collectors.toList());

        return creditContracts;
    }

}