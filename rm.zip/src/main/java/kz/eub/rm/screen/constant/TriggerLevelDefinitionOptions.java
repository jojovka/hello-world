package kz.eub.rm.screen.constant;

import java.util.ArrayList;
import java.util.List;

public class TriggerLevelDefinitionOptions {
    public static final List<String> LIST = new ArrayList<>();
    static {
        LIST.add("ПОЗ");
        LIST.add("Заемщик");
        LIST.add("Займ");
    }
}
