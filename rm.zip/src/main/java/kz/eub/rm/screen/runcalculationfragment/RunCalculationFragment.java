package kz.eub.rm.screen.runcalculationfragment;

import io.jmix.ui.Notifications;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.CheckBox;
import io.jmix.ui.component.DatePicker;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.screen.ScreenFragment;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.service.constant.RunCalculationResultCode;
import kz.eub.rm.service.dto.CalculationLaunchResult;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

@UiController("rm_RunCalculationFragment")
@UiDescriptor("run-calculation-fragment.xml")
public abstract class RunCalculationFragment extends ScreenFragment {
    @Autowired
    protected DatePicker<Date> datePickerField;
    @Autowired
    protected Button runCalculationButton;

    @Autowired
    protected Notifications notifications;


    @Subscribe("runCalculationButton")
    public void onRunCalculationButtonClick(Button.ClickEvent event) {
        CalculationLaunchResult calculationLaunchResult = prepareCalculationResult();
        switch (calculationLaunchResult.getOperationResult()) {
            case RunCalculationResultCode.PREPARE_SUCCESS:
                notifications
                        .create()
                        .withHideDelayMs(10000)
                        .withDescription(String.format("Вы успешно запустили процесс расчета,\n" +
                                "по завершении процесса мы уведомим вас на электронную почту,\n" +
                                "также статус процесса можно отслеживать на данной странице\n" +
                                "runId:%s",
                                calculationLaunchResult.getAdditionalResultInfo()))
                        .show();
                break;
            case RunCalculationResultCode.ALREADY_IN_PROGRESS:
                notifications
                        .create()
                        .withHideDelayMs(6000)
                        .withDescription("Невозможно запустить процесс,\nт.к. расчет уже запущен,\nдождитесь его окончания")
                        .show();
                break;
            case RunCalculationResultCode.ERROR:
                notifications
                        .create()
                        .withHideDelayMs(10000)
                        .withDescription(String.format("Произошла внутренняя ошибка:%s", calculationLaunchResult.getAdditionalResultInfo()))
                        .show();
                break;
            case RunCalculationResultCode.ERROR_LATER_REPORT_EXISTS:
                notifications
                        .create()
                        .withHideDelayMs(10000)
                        .withDescription("Утвержденный расчет на более позднюю дату уже существует")
                        .show();
                break;
            default:
                notifications
                        .create()
                        .withHideDelayMs(5000)
                        .withDescription("Произошла непредвиденная ошибка, обратитесь к администратору системы")
                        .show();
        }
    }

    @Subscribe("datePickerField")
    public void onDatePickerFieldValueChange(HasValue.ValueChangeEvent event) {
        runCalculationButton.setEnabled(event.getValue() != null);
    }

    protected abstract CalculationLaunchResult prepareCalculationResult();
}