package kz.eub.rm.screen.abstractpnzdictionarybrowse;

import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.entity.PnzRunHistory;
import kz.eub.rm.service.PnzRunGlobalFilterConfigurationService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;

@UiController("rm_AbstractPnzDictionaryBrowse")
@UiDescriptor("abstract-pnz-dictionary-browse.xml")
public abstract class AbstractPnzDictionaryBrowse <T> extends StandardLookup<T> {
    private static final String FILTRATION_CONDITION = "where e.runId=:runId";

    @Autowired
    protected CollectionContainer<T> dictionaryDc;
    @Autowired
    protected CollectionLoader<T> dictionaryDl;
    @Autowired
    protected PnzRunGlobalFilterConfigurationService pnzRunGlobalFilterConfigurationService;

    public AbstractPnzDictionaryBrowse() {
        addInitListener(this::init);
    }

    public void init(InitEvent event) {
        setupRunIdFilterCondition();
    }

    protected void setupRunIdFilterCondition() {
        String runId = Optional.ofNullable(pnzRunGlobalFilterConfigurationService.getCurrent()).map(PnzRunHistory::getRunId).orElse(null);
        if (runId!=null) {
            dictionaryDl.setQuery(String.format("%s %s", dictionaryDl.getQuery(), FILTRATION_CONDITION));
            dictionaryDl.setParameter("runId", runId);
        }
    }
}