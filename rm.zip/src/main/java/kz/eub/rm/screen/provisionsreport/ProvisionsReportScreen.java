package kz.eub.rm.screen.provisionsreport;

import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.screen.segmentandpozchoicereport.SegmentAndPozChoiceReportScreen;

@UiController("rm_ProvisionsReportScreen")
@UiDescriptor("provisions-report-screen.xml")
public class ProvisionsReportScreen extends SegmentAndPozChoiceReportScreen {
    @Override
    protected String getReportCode() {
        return "provisions-report";
    }
}