package kz.eub.rm.screen.dictionary.credit.pledgesdictionary;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.*;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import io.jmix.ui.screen.LookupComponent;
import kz.eub.rm.entity.RunHistory;
import kz.eub.rm.entity.dwh.PledgesDictionary;
import kz.eub.rm.screen.open.manager.PledgesDictionaryBrowseOptions;
import kz.eub.rm.screen.poz.abstractpozdictionarybrowse.AbstractPozDictionaryBrowse;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreen;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreenOptions;
import kz.eub.rm.simple.report.PropertiesToRender;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;
import kz.eub.rm.ui.util.TableUtil;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

@UiController("rm_PledgesDictionary.browse")
@UiDescriptor("pledges-dictionary-browse.xml")
@LookupComponent("pledgesDictionariesTable")
public class PledgesDictionaryBrowse extends AbstractPozDictionaryBrowse<PledgesDictionary> {
    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private GroupTable<PledgesDictionary> pledgesDictionariesTable;
//    @Autowired
//    private CollectionLoader<PledgesDictionary> pledgesDictionariesDl;
//    @Autowired
//    private EntityComboBox<RunHistory> runIdFilterComboBox;

    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private FetchPlans fetchPlans;

    @Subscribe
    public void onInit(InitEvent event) {
//        setupInitialRunIdFilterValue(event);

        setupDownloadReportButton();
    }

    // выставление изначального значения фильтра по runId последнего запуска
//    public void setupInitialRunIdFilterValue(InitEvent event) {
//        if (event.getOptions() instanceof PledgesDictionaryBrowseOptions) {
//            PledgesDictionaryBrowseOptions pledgesDictionaryBrowseOptions = (PledgesDictionaryBrowseOptions) event.getOptions();
//            if (pledgesDictionaryBrowseOptions.getIdOfLatestRun()!=null) {
//                runIdFilterComboBox.setValue(
//                        dataManager
//                                .load(RunHistory.class)
//                                .query("select e from rm_RunHistory e where e.runId=:runId")
//                                .parameter("runId", pledgesDictionaryBrowseOptions.getIdOfLatestRun())
//                                .one()
//                );
//            }
//        }
//    }

    public void setupDownloadReportButton() {
        Button button = uiComponents.create(Button.class);
        button.setCaption("Выгрузить");
        button.setAction(new BaseAction("download-simple-report").withHandler((actionPerformedEvent)->{
            SimpleReportDownloadScreenOptions<PledgesDictionary> screenOptions = generateReportDownloadScreenOptions();
            screenBuilders.screen(this)
                    .withOptions(screenOptions)
                    .withScreenClass(SimpleReportDownloadScreen.class)
                    .withOpenMode(OpenMode.DIALOG)
                    .build()
                    .show();
        }));
        buttonsPanel.add(button);
    }

//    @Subscribe("runIdFilterComboBox")
//    public void onRunIdFilterComboBoxValueChange(HasValue.ValueChangeEvent<RunHistory> event) {
//        if (event.getValue()!=null) {
//            pledgesDictionariesDl.setQuery("select e from rm_PledgesDictionary e where e.runId=:runId");
//            pledgesDictionariesDl.setParameter("runId", event.getValue().getRunId());
//        } else {
//            pledgesDictionariesDl.setQuery("select e from rm_PledgesDictionary e");
//            pledgesDictionariesDl.removeParameter("runId");
//        }
//        pledgesDictionariesDl.load();
//    }

    private SimpleReportDownloadScreenOptions<PledgesDictionary> generateReportDownloadScreenOptions() {
        List<String> propertiesToRender = TableUtil.getTablePropertiesPaths(pledgesDictionariesTable);

        SimpleReportRenderConfiguration renderConfiguration =
                new SimpleReportRenderConfiguration(
                        1000000
                );
        SimpleReportDataConfiguration<PledgesDictionary> selectedRowsDataConfiguration = pledgesDictionariesTable.getSelected().isEmpty()?
                null:
                new SimpleReportDataConfiguration<>(
                        propertiesToRender,
                        () -> pledgesDictionariesTable.getSelected().stream().collect(Collectors.toList())
                );
        SimpleReportDataConfiguration<PledgesDictionary> allRowsDataConfiguration =
                new SimpleReportDataConfiguration<>(
                        propertiesToRender,
                        () -> dataManager
                                .load(PledgesDictionary.class)
                                .query(dictionaryDl.getQuery())
                                .parameter("runId", dictionaryDl.getParameter("runId"))
                                .fetchPlan(
                                        fetchPlans
                                                .builder(PledgesDictionary.class)
                                                .addFetchPlan(FetchPlan.BASE)
                                                .build())
                                .list()
                );
        return new SimpleReportDownloadScreenOptions<>(
                PledgesDictionary.class,
                renderConfiguration,
                allRowsDataConfiguration,
                selectedRowsDataConfiguration
        );
    }
}