package kz.eub.rm.screen.abstractuserfriendlyreport;

import io.jmix.core.Messages;
import io.jmix.reportsui.runner.UiReportRunner;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.file.FileDownloadButtonFactory;
import kz.eub.rm.file.ReportDownloadButtonConfiguration;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;

/*
 самый базовый экран выгрузки пользовательских расчетов зависящих от runid
 осуществляет неявное добавление текущего runid в параметры отчета
 добавляет таб с кнопкой выгрузки
 */
@UiController("rm_AbstractUserFriendlyReportScreen")
@UiDescriptor("abstract-user-friendly-report-screen.xml")
public abstract class AbstractUserFriendlyReportScreen extends Screen {
    protected String runId;

    @Autowired
    protected FileDownloadButtonFactory fileDownloadButtonFactory;

    @Autowired
    protected ButtonsPanel buttonsPanel;

    protected Button downloadReportButton;

    @Autowired
    protected UiReportRunner uiReportRunner;
    @Autowired
    protected Messages messages;

    public AbstractUserFriendlyReportScreen() {
        addInitListener(this::initialSetup);
        addAfterShowListener(this::afterShowSetup);
    }

    public void initialSetup(InitEvent event) {
        setupRunId();
        setupReportDownloadButton();
    }

    public void afterShowSetup(AfterShowEvent event) {
        toggleDownloadReportButton();
    }
    protected void setupReportDownloadButton() {
        downloadReportButton = fileDownloadButtonFactory.createForReport(
                ReportDownloadButtonConfiguration.builder(uiReportRunner, getReportCode())
                        .onClickParametersAdjustmentDelegate(this::adjustReportParameters)
                        .build()
        );
        buttonsPanel.add(downloadReportButton);
        downloadReportButton.setEnabled(false);
        downloadReportButton.setCaption(messages.getMessage("kz.eub.rm.screen.abstractuserfriendlyreport/abstractUserFriendlyReportScreen.downloadReportButton"));
    }

    protected void adjustReportParameters(Map<String, Object> map) {
        map.put("runid", runId);
    }

    protected void toggleDownloadReportButton() {
        downloadReportButton.setEnabled(runId!=null);
    }

    protected abstract String getReportCode();

    protected void setupRunId() {
        runId = fetchRunId();
    }

    protected abstract String fetchRunId();

}