package kz.eub.rm.screen.main;

import io.jmix.core.AccessManager;
import io.jmix.core.Messages;
import io.jmix.core.accesscontext.SpecificOperationAccessContext;
import io.jmix.core.common.event.EventHub;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.ScreenTools;
import io.jmix.ui.UiComponents;
import io.jmix.ui.component.*;
import io.jmix.ui.component.mainwindow.Drawer;
import io.jmix.ui.component.mainwindow.SideMenu;
import io.jmix.ui.icon.JmixIcon;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.navigation.Route;
import io.jmix.ui.screen.*;
import kz.eub.rm.bean.SessionEventPublisher;
import kz.eub.rm.entity.PnzRunHistory;
import kz.eub.rm.entity.RunHistory;
import kz.eub.rm.event.GlobalConfigurationChangedEvent;
import kz.eub.rm.event.UserTaskAssignedUiEvent;
import kz.eub.rm.screen.filterapplydialog.FilterApplyDialog;
import kz.eub.rm.screen.filterapplydialog.FilterApplyDialogOptions;
import kz.eub.rm.service.*;
import org.flowable.task.service.impl.persistence.entity.TaskEntityImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Async;
import org.springframework.transaction.event.TransactionalEventListener;

import java.util.Objects;

@UiController("rm_MainScreen")
@UiDescriptor("main-screen.xml")
@Route(path = "main", root = true)
public class MainScreen extends Screen implements Window.HasWorkArea {

    @Autowired
    private ScreenTools screenTools;
    @Autowired
    private Messages messages;
    @Autowired
    private AccessManager accessManager;
    @Autowired
    private ScreenBuilders screenBuilders;

    @Autowired
    private BpmUserTaskService bpmUserTaskService;

    @Autowired
    private AppWorkArea workArea;
    @Autowired
    private Drawer drawer;
    @Autowired
    private Button collapseDrawerButton;
    @Autowired
    private SideMenu sideMenu;
    @Autowired
    private CollectionLoader<RunHistory> pozRunHistoryCollectionDl;
    @Autowired
    private CollectionLoader<PnzRunHistory> pnzRunHistoryCollectionDl;
    @Autowired
    private EntityComboBox<RunHistory> pozRunIdComboBox;
    @Autowired
    private EntityComboBox<PnzRunHistory> pnzRunIdComboBox;
    @Autowired
    private Label pozLabel;
    @Autowired
    private Label pnzLabel;
    @Autowired
    private Button filterApplyButton;
    @Autowired
    private Button filterUpdateButton;

    private SideMenu.MenuItem pozMappingDictionaryItem;
    private String currentUserName;

    private boolean isPozAllowed;
    private boolean isPnzAllowed;

    @Autowired
    private PozMappingDictionaryService pozMappingDictionaryService;
    @Autowired
    private PnzRunGlobalFilterConfigurationService pnzRunGlobalFilterConfigurationService;
    @Autowired
    private PozRunGlobalFilterConfigurationService pozRunGlobalFilterConfigurationService;
    @Autowired
    @Qualifier("rm_PozRunHistoryService")
    private RunHistoryService<RunHistory> pozRunHistoryService;
    @Autowired
    @Qualifier("rm_PnzRunHistoryService")
    private RunHistoryService<PnzRunHistory> pnzRunHistoryService;

    @Override
    public AppWorkArea getWorkArea() {
        return workArea;
    }

    @Subscribe("collapseDrawerButton")
    private void onCollapseDrawerButtonClick(Button.ClickEvent event) {
        drawer.toggle();
        if (drawer.isCollapsed()) {
            collapseDrawerButton.setIconFromSet(JmixIcon.CHEVRON_RIGHT);
        } else {
            collapseDrawerButton.setIconFromSet(JmixIcon.CHEVRON_LEFT);
        }
    }

    @Subscribe
    public void onInit(InitEvent event) {
        setupGlobalFilterConstraints();
        setupGlobalConfigurationFilters();
        setupInitialGlobalConfiguration();
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        screenTools.openDefaultScreen(
                UiControllerUtils.getScreenContext(this).getScreens());

        screenTools.handleRedirect();

        setupDictionaryEmptyNewRecordCounterBadges();
    }

    public void updateMyTasksBadge() {
        SideMenu.MenuItem myTasks = sideMenu.getMenuItem("myTasks");
        if (myTasks == null) return;
        myTasks.setBadgeText(getCurrentUserTotalTasks());
    }

    private String getCurrentUserTotalTasks() {
//        long count = bpmUserTaskService.getUserActiveTasksCount(currentUserSubstitution.getEffectiveUser().getUsername());
        long count = bpmUserTaskService.getUserTaskApplications(currentUserName).size();
        return String.valueOf(count);
    }

    private void setupDictionaryEmptyNewRecordCounterBadges() {
        pozMappingDictionaryItem = sideMenu.getMenuItem("pozMappingDictionaryItem");
        updatePozMappingDictionaryCounterBadge();
    }

    public void updateDictionaryEmptyNewRecordCounterBadges() {
        updatePozMappingDictionaryCounterBadge();
    }

    public void updatePozMappingDictionaryCounterBadge() {
        Long amountOfNonFilledRows = pozMappingDictionaryService.getAmountOfNonFilledRows();
        updatePozMappingDictionaryCounterBadge(amountOfNonFilledRows);
    }

    public void updatePozMappingDictionaryCounterBadge(Long amountOfNonFilledRows) {
        if(isPozAllowed) {
            setPozMappingDictionaryBadgeText(String.valueOf(amountOfNonFilledRows));
            if (!amountOfNonFilledRows.equals(0L)) {
                pozMappingDictionaryItem.setDescription(messages.getMessage("kz.eub.rm.screen.dictionary.snp.pozmappingdictionary/pozMappingDictionaryBrowse.menu.description"));
            } else {
                pozMappingDictionaryItem.setDescription(null);
            }
        }
    }

    private void setPozMappingDictionaryBadgeText(String text) {
        pozMappingDictionaryItem.setBadgeText(text);
    }

    private void setupGlobalFilterConstraints() {
        SpecificOperationAccessContext pozAccessContext = new SpecificOperationAccessContext("main.poz.run.filter");
        accessManager.applyRegisteredConstraints(pozAccessContext);
        isPozAllowed = pozAccessContext.isPermitted();

        SpecificOperationAccessContext pnzAccessContext = new SpecificOperationAccessContext("main.pnz.run.filter");
        accessManager.applyRegisteredConstraints(pnzAccessContext);
        isPnzAllowed = pnzAccessContext.isPermitted();
    }

    private void setupGlobalConfigurationFilters() {
        if (isPozAllowed) {
            pozLabel.setVisible(true);
            pozRunIdComboBox.setVisible(true);
            pozRunHistoryCollectionDl.load();
        }
        if (isPnzAllowed) {
            pnzLabel.setVisible(true);
            pnzRunIdComboBox.setVisible(true);
            pnzRunHistoryCollectionDl.load();
        }
        if (isPozAllowed || isPnzAllowed) {
            filterApplyButton.setVisible(true);
            filterUpdateButton.setVisible(true);
        }
    }
    private void setupInitialGlobalConfiguration() {
        if (isPozAllowed) {
            RunHistory pozRunHistory = pozRunHistoryService.getLatestRun();
            pozRunIdComboBox.setValue(pozRunHistory);
            pozRunGlobalFilterConfigurationService.setCurrent(pozRunHistory);
        }
        if (isPnzAllowed) {
            PnzRunHistory pnzRunHistory = pnzRunHistoryService.getLatestRun();
            pnzRunIdComboBox.setValue(pnzRunHistory);
            pnzRunGlobalFilterConfigurationService.setCurrent(pnzRunHistory);
        }
    }

    @Async
    @TransactionalEventListener
    public void onTaskAssigned(UserTaskAssignedUiEvent event) {
        if (Objects.equals(currentUserName, event.getSource().getUsername())
                || Objects.equals(((TaskEntityImpl)event.getSource().getTask()).getOriginalAssignee(), currentUserName)
        ) {
            updateMyTasksBadge();
        }
    }

    @Subscribe("filterUpdateButton")
    public void onFilterUpdateButtonClick(Button.ClickEvent event) {
        setupGlobalConfigurationFilters();
        pozRunIdComboBox.setValue(pozRunGlobalFilterConfigurationService.reloadCurrent());
        pnzRunIdComboBox.setValue(pnzRunGlobalFilterConfigurationService.reloadCurrent());
    }

    @Subscribe("filterApplyButton")
    public void onFilterImplementButtonClick(Button.ClickEvent event) {
        screenBuilders.screen(this)
                .withScreenClass(FilterApplyDialog.class)
                .withOptions(new FilterApplyDialogOptions(pozRunIdComboBox.getValue(), pnzRunIdComboBox.getValue()))
                .withOpenMode(OpenMode.DIALOG)
                .build()
                .show();
    }
}
