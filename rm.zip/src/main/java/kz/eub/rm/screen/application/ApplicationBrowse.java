package kz.eub.rm.screen.application;

import io.jmix.ui.screen.LookupComponent;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.entity.Application;

@UiController("rm_Application.browse")
@UiDescriptor("application-browse.xml")
@LookupComponent("applicationsTable")
public class ApplicationBrowse extends StandardLookup<Application> {
}