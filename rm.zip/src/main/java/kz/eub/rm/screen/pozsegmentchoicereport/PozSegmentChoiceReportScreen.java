package kz.eub.rm.screen.pozsegmentchoicereport;

import io.jmix.core.DataManager;
import io.jmix.ui.component.EntitySuggestionField;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.screen.Install;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.entity.dwh.PozSegmentationDictionary;
import kz.eub.rm.screen.pozuserfriendlyreport.PozUserFriendlyReportScreen;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/*
 * добавляет в таб поле выбора сегмента и дополняет именем сегмента параметры отчета
 */
@UiController("rm_PozSegmentChoiceReportScreen")
@UiDescriptor("poz-segment-choice-report-screen.xml")
public abstract class PozSegmentChoiceReportScreen extends PozUserFriendlyReportScreen {
    @Autowired
    protected EntitySuggestionField<PozSegmentationDictionary> segmentSuggestionField;
    @Autowired
    protected DataManager dataManager;

    @Subscribe
    public void onInit(InitEvent event) {
        segmentSuggestionField.setSearchExecutor(this::segmentSuggestionFieldSearchExecutor);
    }

    @Override
    protected void adjustReportParameters(Map<String, Object> map) {
        super.adjustReportParameters(map);
        map.put("segment",segmentSuggestionField.getValue().getSegment());
    }

    @Override
    protected void toggleDownloadReportButton() {
        downloadReportButton.setEnabled((runId != null)&&(segmentSuggestionField.getValue()!=null));
    }

    @Subscribe("segmentSuggestionField")
    public void onSegmentEntityPickerValueChange(HasValue.ValueChangeEvent<PozSegmentationDictionary> event) {
        toggleDownloadReportButton();
    }

//    @Install(to = "segmentSuggestionField", subject = "searchExecutor")
    private List<PozSegmentationDictionary> segmentSuggestionFieldSearchExecutor(String searchString, Map<String, Object> searchParams) {
        return dataManager.load(PozSegmentationDictionary.class)
                .query("select c from rm_PozSegmentationDictionary c where lower(c.segment) like lower(:searchString) escape '\\'")
                .parameter("searchString", "%"+searchString+"%").list()
                .stream()
                .distinct()
                .collect(Collectors.toList());
    }
}