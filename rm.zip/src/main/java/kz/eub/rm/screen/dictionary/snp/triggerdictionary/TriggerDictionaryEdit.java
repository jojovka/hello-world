package kz.eub.rm.screen.dictionary.snp.triggerdictionary;

import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.TriggerDictionary;

@UiController("rm_TriggerDictionary.edit")
@UiDescriptor("trigger-dictionary-edit.xml")
@EditedEntityContainer("triggerDictionaryDc")
public class TriggerDictionaryEdit extends StandardEditor<TriggerDictionary> {
}