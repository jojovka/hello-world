package kz.eub.rm.screen.dictionary.snp.pnzmacroadjustmentdictionary;

import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.PnzMacroAdjustmentDictionary;

@UiController("rm_PnzMacroAdjustmentDictionary.edit")
@UiDescriptor("pnz-macro-adjustment-dictionary-edit.xml")
@EditedEntityContainer("pnzMacroAdjustmentDictionaryDc")
public class PnzMacroAdjustmentDictionaryEdit extends StandardEditor<PnzMacroAdjustmentDictionary> {
}