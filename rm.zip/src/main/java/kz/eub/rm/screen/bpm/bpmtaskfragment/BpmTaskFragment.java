package kz.eub.rm.screen.bpm.bpmtaskfragment;

import com.google.common.base.Strings;
import io.jmix.bpm.data.form.FormData;
import io.jmix.bpm.entity.ProcessInstanceData;
import io.jmix.bpm.entity.UserGroup;
import io.jmix.bpm.processform.ProcessFormDataExtractor;
import io.jmix.bpm.service.UserGroupService;
import io.jmix.bpmui.processform.ProcessFormScreens;
import io.jmix.bpmui.processform.TaskCompletion;
import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import io.jmix.ui.Dialogs;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.Action;
import io.jmix.ui.action.DialogAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.Component;
import io.jmix.ui.component.DialogWindow;
import io.jmix.ui.component.HBoxLayout;
import io.jmix.ui.component.Label;
import io.jmix.ui.component.PopupView;
import io.jmix.ui.component.VBoxLayout;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.MessageBundle;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.ScreenFragment;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.Target;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.HasRefreshableContent;
import kz.eub.rm.entity.Application;
import kz.eub.rm.entity.User;
import kz.eub.rm.security.DatabaseUserRepository;
import kz.eub.rm.service.BpmUserTaskService;
import kz.eub.rm.service.UserService;
import org.flowable.engine.TaskService;
import org.flowable.task.api.Task;
import org.flowable.task.api.TaskQuery;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@UiController("rm_BpmTaskFragment")
@UiDescriptor("bpm-task-fragment.xml")
public class BpmTaskFragment extends ScreenFragment {
    private static final Logger log = LoggerFactory.getLogger(BpmTaskFragment.class);

    @Autowired
    private InstanceContainer<ProcessInstanceData> processInstanceDataDc;
    @Autowired
    private VBoxLayout noTasksVbox;
    @Autowired
    private InstanceContainer<Application> applicationDc;
    @Autowired
    private VBoxLayout currentTaskContent;
    @Autowired
    private CurrentUserSubstitution currentUserSubstitution;
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private DatabaseUserRepository databaseUserRepository;
    @Autowired
    private MessageBundle messageBundle;
    @Autowired
    private Dialogs dialogs;
    @Autowired
    private ProcessFormDataExtractor processFormDataExtractor;
    @Autowired
    private ProcessFormScreens processFormScreens;
    @Autowired
    private TaskCompletion taskCompletion;
    @Autowired
    private UserGroupService userGroupService;
    @Autowired
    private BpmUserTaskService bpmUserTaskService;
    @Autowired
    private UserService userService;

    @Subscribe(target = Target.PARENT_CONTROLLER)
    public void onAfterShow(Screen.AfterShowEvent event) {
        refreshContent();
    }

    @Subscribe(id = "applicationDc", target = Target.DATA_CONTAINER)
    public void onApplicationDcItemPropertyChange(InstanceContainer.ItemPropertyChangeEvent<Application> event) {
        refreshContent();
    }

    public void setApplication(Application application) {
        applicationDc.setItem(application);
    }

    private void refreshContent() {
        ProcessInstanceData processInstanceData = processInstanceDataDc.getItemOrNull();
        Application application = applicationDc.getItemOrNull();
        if (processInstanceData == null
                || application == null)
            return;

        List<Task> currentUserTasks = bpmUserTaskService.getUserActiveTasksByProcId(
                application.getProcId(),
                currentUserSubstitution.getEffectiveUser().getUsername());

        resetContent(currentUserTasks.size() > 0);

        if (currentUserTasks.size() > 0) {
            currentUserTasks.forEach(taskData -> currentTaskContent.add(createTaskComponent(taskData)));
        }

        ((HasRefreshableContent)getHostScreen()).refreshContent();
    }

    void resetContent(boolean existTasks) {
        currentTaskContent.removeAll();
        currentTaskContent.setVisible(existTasks);
        noTasksVbox.setVisible(!existTasks);
    }

    private VBoxLayout createTaskComponent(Task task) {
        VBoxLayout responseComponent = uiComponents.create(VBoxLayout.NAME);
        responseComponent.setId(task.getExecutionId());
        responseComponent.setStyleName("card");
        responseComponent.setMargin(true);
        responseComponent.setSpacing(true);

        Label<String> taskNameLabel = uiComponents.create(Label.NAME);
        responseComponent.add(taskNameLabel);
        taskNameLabel.setValue(task.getName());
        taskNameLabel.setStyleName("bold h3 c-label");

        //Когда задача назначена на кого-то
        if (task.getAssignee() != null)
            createComponentsForAssignee(task, responseComponent);
        else
            //Когда задача назначена на группу пользователей
            createComponentsForCandidates(task, responseComponent);

        return responseComponent;
    }

    private void createComponentsForAssignee(Task task, VBoxLayout mainComponent) {
        User assignedUser = userService.reloadUserByUsername(task.getAssignee());
        if (assignedUser == null) return;

        mainComponent.add(createPopupViewForUserInfo(assignedUser,
                messageBundle.getMessage("assignedTo.caption") + " " + assignedUser.getFullName()));

        User currentUser = getCurrentUser();

        // Если задача назначена на текущего пользователя
        if (task.getAssignee().equals(currentUser.getUsername())) {
            HBoxLayout buttonsPanel = uiComponents.create(HBoxLayout.NAME);
            mainComponent.add(buttonsPanel);
            mainComponent.expand(buttonsPanel);

            buttonsPanel.setSpacing(true);
            buttonsPanel.setAlignment(Component.Alignment.TOP_CENTER);
            buttonsPanel.setWidthFull();

            createBtnsForAssignee(task, buttonsPanel);

            if (!task.getTaskDefinitionKey().startsWith("errorTask")) {
                dialogs.createOptionDialog()
//                          .withType(Dialogs.MessageType.CONFIRMATION)
                        .withCaption(messageBundle.getMessage("taskExist.caption"))
                        .withMessage("\"" + task.getName() + "\"\n" + messageBundle.getMessage("confirmTaskAccept.caption"))
                        .withActions(
                                new DialogAction(DialogAction.Type.YES).withHandler(e -> {
                                    FormData formData = processFormDataExtractor.getTaskFormData(task.getId());
                                    switch (formData.getType()) {
                                        case "input-dialog":
                                            showInputDialogForm(task);
                                            break;
                                        case "no-form":
                                            showDefaultTaskForm(task);
                                            break;
                                        case "jmix-screen":
                                            showJmixScreenTaskForm(task);
                                            break;
                                        case "custom":
                                            showCustomTaskForm(task);
                                    }
                                }),
                                new DialogAction(DialogAction.Type.NO)
                        );
//                        .show();
            }
        }
    }

    private Component createPopupViewForUserInfo(User user, String popupLabel) {
        PopupView result = uiComponents.create(PopupView.class);
        result.setMinimizedValue(popupLabel);

        VBoxLayout userInfoVBox = uiComponents.create(VBoxLayout.class);
        result.setPopupContent(userInfoVBox);
        userInfoVBox.setSpacing(true);
        userInfoVBox.setMargin(true);

        Label<String> fullNameLabel = uiComponents.create(Label.NAME);
        userInfoVBox.add(fullNameLabel);
        fullNameLabel.setStyleName("h2");
        String fullName = user.getFullName();
        fullNameLabel.setValue(fullName);

        if (!Strings.isNullOrEmpty(user.getEmail())) {
            Label<String> phoneLabel = uiComponents.create(Label.NAME);
            userInfoVBox.add(phoneLabel);
            phoneLabel.setValue(messageBundle.getMessage("popupView.userInfo.email") + " " + user.getEmail());
        }
        return result;
    }


    private void createBtnsForAssignee(Task task, HBoxLayout buttonsPanel) {
        FormData formData = processFormDataExtractor.getTaskFormData(task.getId());

        if (formData != null) {

            Button openTaskButton = uiComponents.create(Button.class);
            if (formData.getType().equals("jmix-screen")
                    || formData.getType().equals("input-dialog")
                    || formData.getType().equals("custom")
            ) {
                buttonsPanel.add(openTaskButton);
                openTaskButton.setAlignment(Component.Alignment.TOP_LEFT);
                openTaskButton.setStyleName("primary");
                openTaskButton.setCaption(messageBundle.getMessage("openTask.caption"));
            }

            switch (formData.getType()) {
                case "custom":
                    openTaskButton.addClickListener(clickEvent -> showCustomTaskForm(task));
                    //кнопки для задач-согласований
//                    if(taskData.getTaskDefinitionKey().startsWith(MicroCreditApplication.CONSENT_TASK_CODE)){
//                        addOutcomesForConsentTask(buttonsPanel,formData, taskData);
//                    }
//                    //выборка пользователя
//                    if(taskData.getTaskDefinitionKey().startsWith(MicroCreditApplication.SELECT_EMPLOYEE_TASK_CODE)){
//                        addSelectionOutcomes(buttonsPanel,formData, taskData);
//                    }

                    break;
                case "no-form":
                    //кнопки для задач-ошибок
                    if (task.getTaskDefinitionKey().startsWith("errorTask")) {
                        addOutcomesForErrorTask(task, buttonsPanel);
                        break;
                    }
                    break;
                case "input-dialog":
                    openTaskButton.addClickListener(clickEvent -> showInputDialogForm(task));
                    break;
                case "jmix-screen":
                    openTaskButton.addClickListener(clickEvent -> showJmixScreenTaskForm(task));
            }
        }
    }


    private void showCustomTaskForm(Task taskData) {
        Screen bpmTaskForm = processFormScreens.createTaskProcessForm(taskData, this);
        bpmTaskForm.addAfterCloseListener(afterCloseEvent -> refreshContent());
        bpmTaskForm.show();
    }

    private void showJmixScreenTaskForm(Task task) {
        Screen bpmTaskForm = processFormScreens.createTaskProcessForm(task, this);
        bpmTaskForm.addAfterCloseListener(afterCloseEvent -> refreshContent());
        bpmTaskForm.show();
    }

    private void showInputDialogForm(Task task) {
        Screen bpmTaskForm = processFormScreens.createTaskProcessForm(task, this);
        DialogWindow dialogWindow = (DialogWindow) bpmTaskForm.getWindow().getFrameOwner().getWindow();
        dialogWindow.setDialogWidth("800px");
        // dialogWindow.setWindowMode(DialogWindow.WindowMode.MAXIMIZED);
        // dialogWindow.setResizable(false);
        bpmTaskForm.show();
        bpmTaskForm.addAfterCloseListener(afterCloseEvent -> refreshContent());
    }


    private void showDefaultTaskForm(Task task) {
        Screen bpmTaskForm = processFormScreens.createTaskProcessForm(task, this);
        bpmTaskForm.addAfterShowListener(event -> {
            if (!Strings.isNullOrEmpty(task.getAssignee())) {
                // event.getSource(). confirmationLbl.setValue(messageBundle.formatMessage("completeTaskProcessFormLabel", taskData.getName()));
                bpmTaskForm.getWindow().setCaption(task.getName());
            } else {
                // confirmationLbl.setValue(messageBundle.formatMessage("claimTaskProcessFormLabel", taskData.getName()));
                bpmTaskForm.getWindow().setCaption(task.getName());
            }
        });
        bpmTaskForm.getWindow().getFrameOwner().getWindow().setMinWidth("1000px");
        bpmTaskForm.addAfterCloseListener(afterCloseEvent -> refreshContent());
        bpmTaskForm.show();
    }


    private void addOutcomesForErrorTask(Task task, HBoxLayout buttonsPanel) {
        String skipVariableName = task.getTaskDefinitionKey() + "Skip";

        Button repeatBtn = uiComponents.create(Button.class);
        buttonsPanel.add(repeatBtn);
        repeatBtn.setAlignment(Component.Alignment.TOP_LEFT);
        repeatBtn.setStyleName("danger");

        repeatBtn.setCaption(messageBundle.getMessage("repeatTaskBtn.caption"));

        Map<String, Object> variables = new HashMap<>();

        repeatBtn.addClickListener(clickEvent -> {
            variables.put(skipVariableName, false);
            taskCompletion.withTask(task)
                    .saveInjectedProcessVariables()
                    .withProcessVariables(variables)
                    .complete();
            refreshContent();
            getScreenData().loadAll();
        });

        if (task.getTaskDefinitionKey().equals("errorTaskSaveEkd")) {
            Button skipBtn = uiComponents.create(Button.class);
            buttonsPanel.add(skipBtn);
            skipBtn.setAlignment(Component.Alignment.TOP_LEFT);
            skipBtn.setStyleName("danger");

            skipBtn.setCaption(messageBundle.getMessage("skipTaskBtn.caption"));

            skipBtn.addClickListener(clickEvent -> {
                variables.put(skipVariableName, true);
                taskCompletion.withTask(task)
                        .withProcessVariables(variables)
                        .complete();
                refreshContent();
                getScreenData().loadAll();
            });
        }
    }


    @Autowired
    private TaskService taskService;

    private void createComponentsForCandidates(Task task, VBoxLayout mainComponent) {

        //Когда задача назначена на группу лиц
        TaskQuery candidatesTaskDataQuery = taskService.createTaskQuery();
        List<String> userGroupCodes = getUserGroupCodes();
        if (!userGroupCodes.isEmpty()) {
            candidatesTaskDataQuery.taskCandidateGroupIn(userGroupCodes);
        }
        candidatesTaskDataQuery.taskCandidateUser(getCurrentUser().getUsername());

        if (candidatesTaskDataQuery.active().executionId(task.getExecutionId()).count() > 0) {
            Button claimTaskBtn = uiComponents.create(Button.class);
            mainComponent.add(claimTaskBtn);
            claimTaskBtn.setAlignment(Component.Alignment.TOP_LEFT);
            claimTaskBtn.setStyleName("primary");

            claimTaskBtn.setCaption(messageBundle.getMessage("claim.task"));

            claimTaskBtn.addClickListener(clickEvent -> dialogs.createOptionDialog()
                    .withCaption(messageBundle.getMessage("claim.task"))
                    .withMessage("Задача будет назначена на вас")
                    .withActions(
                            new DialogAction(DialogAction.Type.YES, Action.Status.PRIMARY).withHandler(e -> {
                                taskService.claim(task.getId(), getCurrentUser().getUsername());
                                refreshContent();
                            }),
                            new DialogAction(DialogAction.Type.NO)
                    )
                    .show());
        }
    }

    protected List<String> getUserGroupCodes() {
        List<UserGroup> userGroups = userGroupService.getUserGroups(getCurrentUser().getUsername());
        return userGroups.stream()
                .map(UserGroup::getCode)
                .collect(Collectors.toList());
    }

    private Component createPopupViewForGroup(List<User> users, String popupLabel) {
        PopupView result = uiComponents.create(PopupView.class);
        result.setMinimizedValue(popupLabel);

        VBoxLayout mainVbox = uiComponents.create(VBoxLayout.class);
        result.setPopupContent(mainVbox);
        mainVbox.setSpacing(true);
        mainVbox.setMargin(true);

        users.forEach(user -> {
            Label<String> label = uiComponents.create(Label.NAME);
            mainVbox.add(label);
            label.setValue(user.getFullName() + " (" + user.getEmail() + ")");
        });

        return result;
    }

    private User getCurrentUser() {
        String username = currentUserSubstitution.getEffectiveUser().getUsername();
        return databaseUserRepository.loadUserByUsername(username);
    }

}