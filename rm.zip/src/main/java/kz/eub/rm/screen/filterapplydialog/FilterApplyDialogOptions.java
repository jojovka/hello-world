package kz.eub.rm.screen.filterapplydialog;

import io.jmix.ui.screen.ScreenOptions;
import kz.eub.rm.entity.PnzRunHistory;
import kz.eub.rm.entity.RunHistory;

public class FilterApplyDialogOptions implements ScreenOptions {
    private final RunHistory pozRun;
    private final PnzRunHistory pnzRun;

    public FilterApplyDialogOptions(RunHistory pozRun, PnzRunHistory pnzRun) {
        this.pozRun = pozRun;
        this.pnzRun = pnzRun;
    }

    public RunHistory getPozRun() {
        return pozRun;
    }

    public PnzRunHistory getPnzRun() {
        return pnzRun;
    }
}
