package kz.eub.rm.screen.dictionary.credit.creditcontractsdictionary;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlans;
import io.jmix.core.Messages;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.*;
import io.jmix.ui.component.filter.configuration.RunTimeConfiguration;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import io.jmix.ui.screen.LookupComponent;
import kz.eub.rm.entity.RunHistory;
import kz.eub.rm.entity.dwh.CreditContractsDictionary;
import kz.eub.rm.screen.open.manager.CreditContractsDictionaryBrowseOptions;
import kz.eub.rm.screen.poz.abstractpozdictionarybrowse.AbstractPozDictionaryBrowse;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreen;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreenOptions;
import kz.eub.rm.service.PozCreditContractsDictionaryService;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;
import kz.eub.rm.ui.util.TableUtil;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

import static kz.eub.rm.screen.open.manager.CreditContractsDictionaryBrowseOptions.FilterMode.FOURTH_BASKET;

@UiController("rm_CreditContractsDictionary.browse")
@UiDescriptor("credit-contracts-dictionary-browse.xml")
@LookupComponent("creditContractsDictionariesTable")

public class CreditContractsDictionaryBrowse extends AbstractPozDictionaryBrowse<CreditContractsDictionary> {
    @Autowired
    private Filter filter;
    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private GroupTable<CreditContractsDictionary> creditContractsDictionariesTable;
    @Autowired
    private CollectionLoader<CreditContractsDictionary> dictionaryDl;
//    @Autowired
//    private EntityComboBox<RunHistory> runIdFilterComboBox;

    @Autowired
    private DataManager dataManager;
    @Autowired
    private FetchPlans fetchPlans;
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private Messages messages;

    @Autowired
    private PozCreditContractsDictionaryService pozCreditContractsDictionaryService;

    @Subscribe
    public void onInit(InitEvent event) {
        setupFilterConfigurations();

        implementOptions(event);

        setupDownloadReportButton();
    }

    public void setupFilterConfigurations() {
        setupFourthBasketFilter();
    }

    public void setupFourthBasketFilter() {
        PropertyFilter<Integer> basketOnReportDateFilter = createEqualsFilter("basketOnReportDate", 4);

        GroupFilter groupFilter = uiComponents.create(GroupFilter.class);
        groupFilter.setDataLoader(dictionaryDl);
        groupFilter.add(basketOnReportDateFilter);

        RunTimeConfiguration fourthBasketFilterConfiguration = new RunTimeConfiguration(FOURTH_BASKET.name(), groupFilter,filter);
        fourthBasketFilterConfiguration.setName(messages.getMessage("kz.eub.rm.screen.dictionary.credit.creditcontractsdictionary/creditContractsDictionaryBrowse.fourthBasketFilterConfiguration"));

        filter.addConfiguration(fourthBasketFilterConfiguration);
    }

    public <T>PropertyFilter<T> createEqualsFilter(String property, T value) {
        PropertyFilter<T> equalsFilter = uiComponents.create(PropertyFilter.NAME);
        equalsFilter.setDataLoader(dictionaryDl);
        equalsFilter.setProperty(property);
        equalsFilter.setOperation(PropertyFilter.Operation.EQUAL);
        equalsFilter.getQueryCondition().setParameterValue(value);
        equalsFilter.setValue(value);
        equalsFilter.setParameterName(io.jmix.core.querycondition.PropertyConditionUtils.generateParameterName(equalsFilter.getProperty()));

        return equalsFilter;
    }

    public void implementOptions(InitEvent event) {
        if (event.getOptions() instanceof CreditContractsDictionaryBrowseOptions) {
            CreditContractsDictionaryBrowseOptions options = (CreditContractsDictionaryBrowseOptions) event.getOptions();

//            setupInitialRunIdFilterValue(options.getIdOfLatestRun());
            setupPropertiesFilter(options.getFilterMode());

        }
    }

    // выставление изначального значения фильтра по runId последнего запуска
//    public void setupInitialRunIdFilterValue(String idOfLatestRun) {
//        if (idOfLatestRun!=null) {
//            runIdFilterComboBox.setValue(
//                    dataManager
//                            .load(RunHistory.class)
//                            .query("select e from rm_RunHistory e where e.runId=:runId")
//                            .parameter("runId", idOfLatestRun)
//                            .one()
//            );
//        }
//    }

    public void setupPropertiesFilter(CreditContractsDictionaryBrowseOptions.FilterMode filterMode) {
        switch (filterMode) {
            case FOURTH_BASKET:
                filter.setCurrentConfiguration(filter.getConfiguration(FOURTH_BASKET.name()));
                break;
            default:
                filter.setCurrentConfiguration(filter.getEmptyConfiguration());
                break;
        }
    }

    public void setupDownloadReportButton() {
        Button button = uiComponents.create(Button.class);
        button.setCaption("Выгрузить");
        button.setAction(new BaseAction("download-simple-report").withHandler((actionPerformedEvent)->{
            SimpleReportDownloadScreenOptions<CreditContractsDictionary> screenOptions = generateReportDownloadScreenOptions();
            screenBuilders.screen(this)
                    .withOptions(screenOptions)
                    .withScreenClass(SimpleReportDownloadScreen.class)
                    .withOpenMode(OpenMode.DIALOG)
                    .build()
                    .show();
        }));
        buttonsPanel.add(button);
    }

    private SimpleReportDownloadScreenOptions<CreditContractsDictionary> generateReportDownloadScreenOptions() {
        List<String> propertiesToRender = TableUtil.getTablePropertiesPaths(creditContractsDictionariesTable);

        SimpleReportRenderConfiguration renderConfiguration =
                new SimpleReportRenderConfiguration(
                        1000000
                );
        SimpleReportDataConfiguration<CreditContractsDictionary> selectedRowsDataConfiguration = creditContractsDictionariesTable.getSelected().isEmpty()?
                null:
                new SimpleReportDataConfiguration<>(
                        propertiesToRender,
                        () -> creditContractsDictionariesTable.getSelected().stream().collect(Collectors.toList())
                );
        SimpleReportDataConfiguration<CreditContractsDictionary> allRowsDataConfiguration =
                new SimpleReportDataConfiguration<>(
                        propertiesToRender,
                        () -> pozCreditContractsDictionaryService.getAllDataWithFetchedChildNames(pozRunGlobalFilterConfigurationService.getCurrent().getRunId())
                );
        return new SimpleReportDownloadScreenOptions<>(
                CreditContractsDictionary.class,
                renderConfiguration,
                allRowsDataConfiguration,
                selectedRowsDataConfiguration
        );
    }

//    @Subscribe("runIdFilterComboBox")
//    public void onRunIdFilterComboBoxValueChange(HasValue.ValueChangeEvent<RunHistory> event) {
//        if (event.getValue()!=null) {
//            dictionaryDl.setQuery("select e from rm_CreditContractsDictionary e where e.runId=:runId");
//            dictionaryDl.setParameter("runId", event.getValue().getRunId());
//        } else {
//            dictionaryDl.setQuery("select e from rm_CreditContractsDictionary e");
//            dictionaryDl.removeParameter("runId");
//        }
//        dictionaryDl.load();
//    }
}