package kz.eub.rm.screen.pdmatrixreport;

import io.jmix.core.DataManager;
import io.jmix.core.Messages;
import io.jmix.reportsui.runner.UiReportRunner;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.CheckBox;
import io.jmix.ui.component.EntitySuggestionField;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.entity.dwh.PozSegmentationDictionary;
import kz.eub.rm.file.FileDownloadButtonFactory;
import kz.eub.rm.file.MultipleReportsGenerationButtonConfiguration;
import kz.eub.rm.file.ReportDownloadButtonConfiguration;
import kz.eub.rm.screen.pozsegmentchoicereport.PozSegmentChoiceReportScreen;
import kz.eub.rm.screen.segmentandpozchoicereport.SegmentAndPozChoiceReportScreen;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@UiController("rm_PdMatrixReportScreen")
@UiDescriptor("pd-matrix-report-screen.xml")
public class PdMatrixReportScreen extends SegmentAndPozChoiceReportScreen {
    @Autowired
    private EntitySuggestionField<PozSegmentationDictionary> segmentSuggestionField;
    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private CheckBox needBaseCheckBox;
    @Autowired
    private CheckBox needBaseCheckBoxPozTab;

    @Autowired
    private UiReportRunner uiReportRunner;
    @Autowired
    private Messages messages;

    @Autowired
    private FileDownloadButtonFactory fileDownloadButtonFactory;


    @Override
    protected void setupReportDownloadButton() {
        downloadReportButton = fileDownloadButtonFactory.createForReport(
                ReportDownloadButtonConfiguration.builder(uiReportRunner, getReportCode())
                        .onClickParametersAdjustmentDelegate(
                                (map) -> {
                                    map.put("runid", runId);
                                    map.put("segment", segmentSuggestionField.getValue().getSegment());
                                })
                        .onClickTemplateSelectionDelegate((v) -> Boolean.TRUE.equals(needBaseCheckBox.getValue()) ? "PD_WITH_BASE" : "DEFAULT")
                        .build()
        );
        buttonsPanel.add(downloadReportButton);
        downloadReportButton.setEnabled(false);
        downloadReportButton.setCaption(messages.getMessage("kz.eub.rm.screen.abstractuserfriendlyreport/abstractUserFriendlyReportScreen.downloadReportButton"));
    }

    @Override
    protected MultipleReportsGenerationButtonConfiguration buildMultipleReportsZipGenerationButtonConfiguration() {
        return MultipleReportsGenerationButtonConfiguration
                .builder(notifications, getReportCode())
                .onClickParametersAdjustmentDelegate(this::generationButtonOnClickParametersAdjustmentDelegate)
                .onClickTemplateSelectionDelegate((v) -> Boolean.TRUE.equals(needBaseCheckBoxPozTab.getValue()) ? "PD_WITH_BASE" : "DEFAULT")
                .blockingValueSupplier(() -> getReportCode().concat(pozSuggestionField.getValue().getPozName()))
                .build();
    }

    @Override
    protected String getReportCode() {
        return "pd-matrix";
    }
}