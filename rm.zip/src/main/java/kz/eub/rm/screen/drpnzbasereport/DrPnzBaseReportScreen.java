package kz.eub.rm.screen.drpnzbasereport;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.screen.abstractperiodtypereport.AbstractPeriodTypeReportScreen;

@UiController("rm_DrPnzBaseReportScreen")
@UiDescriptor("dr-pnz-base-report-screen.xml")
public class DrPnzBaseReportScreen extends AbstractPeriodTypeReportScreen {
    @Override
    protected String getReportCode() {
        return "dr-pnz-base";
    }
}