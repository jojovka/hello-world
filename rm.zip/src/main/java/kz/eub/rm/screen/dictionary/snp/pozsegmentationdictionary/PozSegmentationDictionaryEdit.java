package kz.eub.rm.screen.dictionary.snp.pozsegmentationdictionary;

import io.jmix.ui.screen.*;
import kz.eub.dud.jmix.platform.ui.action.ValidateCommitAndCloseAction;
import kz.eub.rm.entity.dwh.PozSegmentationDictionary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("rm_PozSegmentationDictionary.edit")
@UiDescriptor("poz-segmentation-dictionary-edit.xml")
@EditedEntityContainer("pozSegmentationDictionaryDc")
public class PozSegmentationDictionaryEdit extends StandardEditor<PozSegmentationDictionary> {
    private static final Logger log = LoggerFactory.getLogger(PozSegmentationDictionaryEdit.class);

    @Autowired
    private ValidateCommitAndCloseAction windowCommitAndClose;

    @Subscribe
    public void onInit(InitEvent event) {
        windowCommitAndClose.setEditorScreen(this);
    }
}