package kz.eub.rm.screen.calculations;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("rm_CalculationsScreen")
@UiDescriptor("calculations-screen.xml")
public class CalculationsScreen extends Screen {
}