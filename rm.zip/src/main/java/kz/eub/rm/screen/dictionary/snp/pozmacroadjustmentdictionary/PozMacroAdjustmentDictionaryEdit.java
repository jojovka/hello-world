package kz.eub.rm.screen.dictionary.snp.pozmacroadjustmentdictionary;

import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.PozMacroAdjustmentDictionary;

@UiController("rm_PozMacroAdjustmentDictionary.edit")
@UiDescriptor("poz-macro-adjustment-dictionary-edit.xml")
@EditedEntityContainer("pozMacroAdjustmentDictionaryDc")
public class PozMacroAdjustmentDictionaryEdit extends StandardEditor<PozMacroAdjustmentDictionary> {
}