package kz.eub.rm.screen.reportdownload;

import io.jmix.ui.screen.ScreenOptions;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;

public class SimpleReportDownloadScreenOptions<T> implements ScreenOptions {
    private Class<T> entityClass;
    private SimpleReportRenderConfiguration renderConfiguration;
    private SimpleReportDataConfiguration<T> allRowsDataConfiguration;
    private SimpleReportDataConfiguration<T> selectedRowsDataConfiguration;
    public SimpleReportDownloadScreenOptions(
            Class<T> entityClass,
            SimpleReportRenderConfiguration renderConfiguration,
            SimpleReportDataConfiguration<T> allRowsDataConfiguration,
            SimpleReportDataConfiguration<T> selectedRowsDataConfiguration
    ) {
        this.entityClass = entityClass;
        this.renderConfiguration = renderConfiguration;
        this.allRowsDataConfiguration = allRowsDataConfiguration;
        this.selectedRowsDataConfiguration = selectedRowsDataConfiguration;
    }

    public Class<T> getEntityClass() {
        return entityClass;
    }

    public SimpleReportRenderConfiguration getRenderConfiguration() {
        return renderConfiguration;
    }

    public SimpleReportDataConfiguration<T> getAllRowsDataConfiguration() {
        return allRowsDataConfiguration;
    }

    public SimpleReportDataConfiguration<T> getSelectedRowsDataConfiguration() {
        return selectedRowsDataConfiguration;
    }
}
