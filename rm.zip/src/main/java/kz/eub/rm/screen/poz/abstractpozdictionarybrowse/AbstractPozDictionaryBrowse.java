package kz.eub.rm.screen.poz.abstractpozdictionarybrowse;

import io.jmix.core.querycondition.JpqlCondition;
import io.jmix.core.querycondition.PropertyCondition;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.PnzRunHistory;
import kz.eub.rm.entity.RunHistory;
import kz.eub.rm.service.PozRunGlobalFilterConfigurationService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@UiController("rm_AbstractPozDictionaryBrowse")
@UiDescriptor("abstract-poz-dictionary-browse.xml")
public abstract class AbstractPozDictionaryBrowse <T> extends StandardLookup<T> {
    private static final String FILTRATION_CONDITION = "where e.runId=:runId";

    @Autowired
    protected CollectionContainer<T> dictionaryDc;
    @Autowired
    protected CollectionLoader<T> dictionaryDl;
    @Autowired
    protected PozRunGlobalFilterConfigurationService pozRunGlobalFilterConfigurationService;

    public AbstractPozDictionaryBrowse() {
        addInitListener(this::init);
    }

    public void init(InitEvent event) {
        setupRunIdFilterCondition();
    }

    protected void setupRunIdFilterCondition() {
        String runId = Optional.ofNullable(pozRunGlobalFilterConfigurationService.getCurrent()).map(RunHistory::getRunId).orElse(null);
        dictionaryDl.setQuery(String.format("%s %s", dictionaryDl.getQuery(), FILTRATION_CONDITION));
        dictionaryDl.setParameter("runId", runId);
    }

}