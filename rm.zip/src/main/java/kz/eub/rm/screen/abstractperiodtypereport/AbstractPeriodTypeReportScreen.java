package kz.eub.rm.screen.abstractperiodtypereport;

import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.entity.ReportPeriodType;
import kz.eub.rm.screen.abstractperiodreport.AbstractPeriodReportScreen;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/*
 * добавляет выпадающий список выбора типа периода : Год, Месяц, Квартал
 * добавляет в параметры отчета periodType
 */
@UiController("rm_AbstractPeriodTypeReportScreen")
@UiDescriptor("abstract-period-type-report-screen.xml")
public abstract class AbstractPeriodTypeReportScreen extends AbstractPeriodReportScreen {
    @Autowired
    protected ComboBox<ReportPeriodType> periodTypeComboBox;

    public AbstractPeriodTypeReportScreen() {
        addInitListener(this::onInit_AbstractPeriodReportScreen);
    }
    public void onInit_AbstractPeriodReportScreen(InitEvent event) {
        setupPeriodTypeComboBox();
    }

    @Subscribe("periodTypeComboBox")
    public void onPeriodTypeComboBoxValueChange(HasValue.ValueChangeEvent event) {
        toggleDownloadReportButton();
    }

    @Override
    protected void onClickParametersAdjustmentDelegate(Map<String, Object> parameters) {
        super.onClickParametersAdjustmentDelegate(parameters);
        parameters.put("periodType", periodTypeComboBox.getValue().getId());
    }

    protected void setupPeriodTypeComboBox() {
        periodTypeComboBox.setOptionsEnum(ReportPeriodType.class);
    }

    @Override
    protected boolean needEnableDownloadReportButton() {
        return super.needEnableDownloadReportButton() && periodTypeComboBox.getValue() != null;
    }

}