package kz.eub.rm.screen.pnzcalculationsviewfragment;

import io.jmix.ui.component.Button;
import io.jmix.ui.component.Table;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.entity.PnzRunHistory;
import kz.eub.rm.screen.calculationsviewfragment.CalculationsViewFragment;
import kz.eub.rm.service.calculation.PnzCalculationService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;

@UiController("rm_PnzCalculationsViewFragment")
@UiDescriptor("pnz-calculations-view-fragment.xml")
public class PnzCalculationsViewFragment extends CalculationsViewFragment<PnzRunHistory> {
    @Autowired
    protected PnzCalculationService calculationService;

    @Override
    protected void handleApproveCalculationButtonClick(Button.ClickEvent event) {
        calculationService.approveCalculation(runHistoryTable.getSingleSelected().getRunId());
    }

    @Override
    protected void handleRunHistoryTableSelection(Table.SelectionEvent<PnzRunHistory> event) {
        PnzRunHistory run = runHistoryTable.getSingleSelected();
        if (run == null) {
            approveCalculationButton.setEnabled(false);
        } else if (calculationService.isAllowedToApproveCalculation(run.getId())) {
            approveCalculationButton.setEnabled(true);
        } else {
            approveCalculationButton.setEnabled(false);
        }
    }
}