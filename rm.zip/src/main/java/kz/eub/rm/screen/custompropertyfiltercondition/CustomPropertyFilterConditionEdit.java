package kz.eub.rm.screen.custompropertyfiltercondition;

import com.google.common.base.Strings;
import io.jmix.core.*;
import io.jmix.core.metamodel.model.MetaClass;
import io.jmix.core.metamodel.model.MetaPropertyPath;
import io.jmix.ui.UiComponents;
import io.jmix.ui.app.filter.condition.FilterConditionEdit;
import io.jmix.ui.component.*;
import io.jmix.ui.component.filter.FilterMetadataTools;
import kz.eub.rm.filter.CustomPropertyFilter;
import kz.eub.rm.filter.PropertyConditionUtils;
import kz.eub.rm.filter.PropertyFilterSupport;
import kz.eub.rm.filter.SingleFilterSupport;
import io.jmix.ui.entity.FilterValueComponent;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.CustomPropertyFilterCondition;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;
import java.util.function.Predicate;

@UiController("rm_CustomPropertyFilterCondition.edit")
@UiDescriptor("custom-property-filter-condition-edit.xml")
@EditedEntityContainer("customPropertyFilterConditionDc")
public class CustomPropertyFilterConditionEdit extends FilterConditionEdit<CustomPropertyFilterCondition> {

    @Autowired
    protected PropertyFilterSupport propertyFilterSupport;
    @Autowired
    protected FilterMetadataTools filterMetadataTools;
    @Autowired
    protected SingleFilterSupport singleFilterSupport;
    @Autowired
    protected UiComponents uiComponents;
    @Autowired
    protected MetadataTools metadataTools;

    @Autowired
    protected InstanceContainer<CustomPropertyFilterCondition> customPropertyFilterConditionDc;

    @Autowired
    protected ComboBox<String> propertyField;
    @Autowired
    protected Metadata metadata;
    @Autowired
    protected MessageTools messageTools;
    @Autowired
    protected TextField<String> parameterNameField;
    @Autowired
    protected ComboBox<CustomPropertyFilter.Operation> operationField;
    @Autowired
    protected HBoxLayout defaultValueBox;

    protected HasValue defaultValueField;

    protected MetaClass filterMetaClass;
    protected String query;
    protected Predicate<MetaPropertyPath> propertiesFilterPredicate;

    @Override
    public InstanceContainer<CustomPropertyFilterCondition> getInstanceContainer() {
        return customPropertyFilterConditionDc;
    }

    @Override
    public void setCurrentConfiguration(Filter.Configuration currentConfiguration) {
        super.setCurrentConfiguration(currentConfiguration);

        filterMetaClass = currentConfiguration.getOwner().getDataLoader().getContainer().getEntityMetaClass();
        query = currentConfiguration.getOwner().getDataLoader().getQuery();
        propertiesFilterPredicate = currentConfiguration.getOwner().getPropertiesFilterPredicate();
    }

    @Subscribe
    protected void onAfterShow(AfterShowEvent event) {
        initPropertyField();
        initOperationField();
        initDefaultValueField();
    }

    protected void initPropertyField() {
        if (filterMetaClass != null) {
            List<MetaPropertyPath> paths = filterMetadataTools.getPropertyPaths(filterMetaClass, query,
                    propertiesFilterPredicate);
            Map<String, String> properties = new TreeMap<>();
            for (MetaPropertyPath mpp : paths) {
                String property = mpp.toPathString();
                String caption = propertyFilterSupport.getPropertyFilterCaption(filterMetaClass, property);
                properties.put(caption, property);
            }
            propertyField.setOptionsMap(properties);
        }
    }

    @SuppressWarnings("unchecked")
    protected void initOperationField() {
        List<CustomPropertyFilter.Operation> operations;
        if (filterMetaClass != null && getEditedEntity().getProperty() != null) {
            EnumSet<CustomPropertyFilter.Operation> availableOperations = propertyFilterSupport
                    .getAvailableOperations(filterMetaClass, getEditedEntity().getProperty());
            operations = new ArrayList<>(availableOperations);
        } else {
            operations = Collections.EMPTY_LIST;
        }

        operationField.setOptionsList(operations);
    }

    @SuppressWarnings("unchecked")
    protected void initDefaultValueField() {
        if (filterMetaClass != null
                && getEditedEntity().getProperty() != null
                && getEditedEntity().getOperation() != null) {
            defaultValueField = singleFilterSupport.generateValueComponent(filterMetaClass,
                    getEditedEntity().getProperty(), getEditedEntity().getOperation());

            if (getEditedEntity().getValueComponent() != null
                    && getEditedEntity().getValueComponent().getDefaultValue() != null) {
                String modelDefaultValue = getEditedEntity().getValueComponent().getDefaultValue();
                MetaPropertyPath mpp = metadataTools.resolveMetaPropertyPathOrNull(filterMetaClass,
                        getEditedEntity().getProperty());
                if (mpp != null) {
                    Object defaultValue = propertyFilterSupport.parseDefaultValue(mpp.getMetaProperty(),
                            getEditedEntity().getOperation().getType(), modelDefaultValue);
                    defaultValueField.setValue(defaultValue);
                }
            }
        } else {
            defaultValueField = uiComponents.create(TextField.TYPE_STRING);
            defaultValueField.setEnabled(false);
        }

        defaultValueBox.removeAll();
        defaultValueBox.add(defaultValueField);
        defaultValueField.setWidthFull();
    }

    @Install(to = "operationField", subject = "optionCaptionProvider")
    protected String operationFieldOptionCaptionProvider(CustomPropertyFilter.Operation operation) {
        return propertyFilterSupport.getOperationCaption(operation);
    }

    @Subscribe("propertyField")
    protected void onPropertyFieldValueChange(HasValue.ValueChangeEvent<String> event) {
        String property = event.getValue();
        if (StringUtils.isNotEmpty(property) && event.isUserOriginated()) {
            String parameterName = PropertyConditionUtils.generateParameterName(property);
            getEditedEntity().setParameterName(parameterName);

            EnumSet<CustomPropertyFilter.Operation> availableOperations = propertyFilterSupport
                    .getAvailableOperations(filterMetaClass, property);
            operationField.setOptionsList(new ArrayList<>(availableOperations));
            if (operationField.getValue() != null && !availableOperations.contains(operationField.getValue())) {
                operationField.setValue(null);
            }

            resetDefaultValue();
            initDefaultValueField();
        }
    }

    @Subscribe("operationField")
    protected void onOperationFieldValueChange(HasValue.ValueChangeEvent<CustomPropertyFilter.Operation> event) {
        CustomPropertyFilter.Operation operation = event.getValue();
        if (operation != null && event.isUserOriginated()) {
            resetDefaultValue();
            initDefaultValueField();
        }
    }

    protected void resetDefaultValue() {
        FilterValueComponent valueComponent = getEditedEntity().getValueComponent();
        if (valueComponent != null) {
            valueComponent.setDefaultValue(null);
        }
    }

    @Subscribe
    protected void onBeforeCommitChanges(BeforeCommitChangesEvent event) {
        if (defaultValueField != null
                && getEditedEntity().getProperty() != null
                && getEditedEntity().getOperation() != null) {
            MetaPropertyPath mpp = metadataTools.resolveMetaPropertyPathOrNull(filterMetaClass,
                    getEditedEntity().getProperty());
            String modelDefaultValue = null;
            if (mpp != null) {
                modelDefaultValue = propertyFilterSupport.formatDefaultValue(mpp.getMetaProperty(),
                        getEditedEntity().getOperation().getType(), defaultValueField.getValue());
            }

            FilterValueComponent valueComponent = getEditedEntity().getValueComponent();
            valueComponent.setDefaultValue(modelDefaultValue);
            valueComponent.setComponentName(singleFilterSupport.getValueComponentName(defaultValueField));

            String caption = getEditedEntity().getCaption();
            String localizedCaption;
            if (!Strings.isNullOrEmpty(caption)) {
                localizedCaption = caption;
            } else {
                localizedCaption = propertyFilterSupport.getPropertyFilterCaption(filterMetaClass,
                        getEditedEntity().getProperty(), getEditedEntity().getOperation(),
                        getEditedEntity().getOperationCaptionVisible()
                                && !getEditedEntity().getOperationEditable());
            }
            getEditedEntity().setLocalizedCaption(localizedCaption);
        }
    }
}