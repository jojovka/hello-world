package kz.eub.rm.screen.dictionary.common.productreferencedictionary;

import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.ProductReferenceDictionary;

@UiController("rm_ProductReferenceDictionary.edit")
@UiDescriptor("product-reference-dictionary-edit.xml")
@EditedEntityContainer("productReferenceDictionaryDc")
public class ProductReferenceDictionaryEdit extends StandardEditor<ProductReferenceDictionary> {
}