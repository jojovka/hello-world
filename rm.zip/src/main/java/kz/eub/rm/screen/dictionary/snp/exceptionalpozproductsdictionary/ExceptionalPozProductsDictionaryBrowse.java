package kz.eub.rm.screen.dictionary.snp.exceptionalpozproductsdictionary;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.ExceptionalPozProductsDictionary;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreen;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreenOptions;
import kz.eub.rm.simple.report.PropertiesToRender;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.stream.Collectors;

@UiController("rm_ExceptionalPozProductsDictionary.browse")
@UiDescriptor("exceptional-poz-products-dictionary-browse.xml")
@LookupComponent("exceptionalPozProductsDictionariesTable")
public class ExceptionalPozProductsDictionaryBrowse extends StandardLookup<ExceptionalPozProductsDictionary> {
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private GroupTable<ExceptionalPozProductsDictionary> exceptionalPozProductsDictionariesTable;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private FetchPlans fetchPlans;

    @Subscribe
    public void onInit(InitEvent event) {
        setupDownloadReportButton();
    }

    public void setupDownloadReportButton() {
        Button button = uiComponents.create(Button.class);
        button.setCaption("Выгрузить");
        button.setAction(new BaseAction("download-simple-report").withHandler((actionPerformedEvent)->{
            SimpleReportDownloadScreenOptions<ExceptionalPozProductsDictionary> screenOptions = generateReportDownloadScreenOptions();
            screenBuilders.screen(this)
                    .withOptions(screenOptions)
                    .withScreenClass(SimpleReportDownloadScreen.class)
                    .withOpenMode(OpenMode.DIALOG)
                    .build()
                    .show();
        }));
        buttonsPanel.add(button);
    }

    private SimpleReportDownloadScreenOptions<ExceptionalPozProductsDictionary> generateReportDownloadScreenOptions() {
        SimpleReportRenderConfiguration renderConfiguration =
                new SimpleReportRenderConfiguration(
                        1000000
                );
        SimpleReportDataConfiguration<ExceptionalPozProductsDictionary> selectedRowsDataConfiguration = exceptionalPozProductsDictionariesTable.getSelected().isEmpty()?
                null:
                new SimpleReportDataConfiguration<>(
                        PropertiesToRender.EXCEPTIONAL_POZ_PRODUCTS_PRODUCTS_PROPERTIES,
                        () -> exceptionalPozProductsDictionariesTable.getSelected().stream().collect(Collectors.toList())
                );
        SimpleReportDataConfiguration<ExceptionalPozProductsDictionary> allRowsDataConfiguration =
                new SimpleReportDataConfiguration<>(
                        PropertiesToRender.EXCEPTIONAL_POZ_PRODUCTS_PRODUCTS_PROPERTIES,
                        () -> dataManager
                                .load(ExceptionalPozProductsDictionary.class)
                                .query("select p from rm_ExceptionalPozProductsDictionary p")
                                .fetchPlan(
                                        fetchPlans
                                                .builder(ExceptionalPozProductsDictionary.class)
                                                .addFetchPlan(FetchPlan.BASE)
                                                .add("prdId")
                                                .add("user")
                                                .build())
                                .list()
                );
        return new SimpleReportDownloadScreenOptions<>(
                ExceptionalPozProductsDictionary.class,
                renderConfiguration,
                allRowsDataConfiguration,
                selectedRowsDataConfiguration
        );
    }
}