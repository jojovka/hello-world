package kz.eub.rm.screen.pnzuserfriendlyreport;

import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.rm.screen.abstractuserfriendlyreport.AbstractUserFriendlyReportScreen;
import kz.eub.rm.service.PnzRunGlobalFilterConfigurationService;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("rm_PnzUserFriendlyReportScreen")
@UiDescriptor("pnz-user-friendly-report-screen.xml")
public abstract class PnzUserFriendlyReportScreen extends AbstractUserFriendlyReportScreen {
    @Autowired
    protected PnzRunGlobalFilterConfigurationService pnzRunGlobalFilterConfigurationService;

    @Override
    protected String fetchRunId() {
        return pnzRunGlobalFilterConfigurationService.getCurrent().getRunId();
    }
}