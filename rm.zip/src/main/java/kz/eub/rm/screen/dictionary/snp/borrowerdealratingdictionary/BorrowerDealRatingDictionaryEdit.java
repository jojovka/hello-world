package kz.eub.rm.screen.dictionary.snp.borrowerdealratingdictionary;

import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.BorrowerDealRatingDictionary;

@UiController("rm_BorrowerDealRatingDictionary.edit")
@UiDescriptor("borrower-deal-rating-dictionary-edit.xml")
@EditedEntityContainer("borrowerDealRatingDictionaryDc")
public class BorrowerDealRatingDictionaryEdit extends StandardEditor<BorrowerDealRatingDictionary> {
}