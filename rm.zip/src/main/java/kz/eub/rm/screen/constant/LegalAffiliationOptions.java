package kz.eub.rm.screen.constant;

import java.util.ArrayList;
import java.util.List;

public class LegalAffiliationOptions {
    public static final List<String> LIST = new ArrayList<>();
    static {
        LIST.add("Фл");
        LIST.add("Юл");
        LIST.add("Фл/Юл");
    }
}
