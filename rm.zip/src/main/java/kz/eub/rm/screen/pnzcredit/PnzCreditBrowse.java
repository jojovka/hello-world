package kz.eub.rm.screen.pnzcredit;

import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.screen.*;
import kz.eub.rm.entity.dwh.PnzCredit;
import kz.eub.rm.screen.abstractpnzdictionarybrowse.AbstractPnzDictionaryBrowse;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreen;
import kz.eub.rm.screen.reportdownload.SimpleReportDownloadScreenOptions;
import kz.eub.rm.service.PnzCreditService;
import kz.eub.rm.simple.report.SimpleReportDataConfiguration;
import kz.eub.rm.simple.report.SimpleReportRenderConfiguration;
import kz.eub.rm.ui.util.TableUtil;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

@UiController("rm_PnzCredit.browse")
@UiDescriptor("pnz-credit-browse.xml")
@LookupComponent("pnzCreditsTable")
public class PnzCreditBrowse extends AbstractPnzDictionaryBrowse<PnzCredit> {
    @Autowired
    private PnzCreditService pnzCreditService;

    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private GroupTable<PnzCredit> pnzCreditsTable;

    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private ScreenBuilders screenBuilders;

    @Subscribe
    public void onInit(InitEvent event) {
        setupDownloadReportButton();
    }

    public void setupDownloadReportButton() {
        Button button = uiComponents.create(Button.class);
        button.setCaption("Выгрузить");
        button.setAction(new BaseAction("download-simple-report").withHandler((actionPerformedEvent)->{
            SimpleReportDownloadScreenOptions<PnzCredit> screenOptions = generateReportDownloadScreenOptions();
            screenBuilders.screen(this)
                    .withOptions(screenOptions)
                    .withScreenClass(SimpleReportDownloadScreen.class)
                    .withOpenMode(OpenMode.DIALOG)
                    .build()
                    .show();
        }));
        buttonsPanel.add(button);
    }

    private SimpleReportDownloadScreenOptions<PnzCredit> generateReportDownloadScreenOptions() {
        List<String> propertiesToRender = TableUtil.getTablePropertiesPaths(pnzCreditsTable);

        SimpleReportRenderConfiguration renderConfiguration =
                new SimpleReportRenderConfiguration(
                        1000000
                );
        SimpleReportDataConfiguration<PnzCredit> selectedRowsDataConfiguration = pnzCreditsTable.getSelected().isEmpty()?
                null:
                new SimpleReportDataConfiguration<>(
                        propertiesToRender,
                        () -> pnzCreditsTable.getSelected().stream().collect(Collectors.toList())
                );
        SimpleReportDataConfiguration<PnzCredit> allRowsDataConfiguration =
                new SimpleReportDataConfiguration<>(
                        propertiesToRender,
                        () -> pnzCreditService.getAllData()
                );
        return new SimpleReportDownloadScreenOptions<>(
                PnzCredit.class,
                renderConfiguration,
                allRowsDataConfiguration,
                selectedRowsDataConfiguration
        );
    }

}