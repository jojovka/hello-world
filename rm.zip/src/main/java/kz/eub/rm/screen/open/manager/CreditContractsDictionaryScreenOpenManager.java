package kz.eub.rm.screen.open.manager;

import io.jmix.ui.AppUI;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.builder.LookupClassBuilder;
import io.jmix.ui.component.EntityPicker;
import io.jmix.ui.screen.OpenMode;
import io.jmix.ui.screen.Screen;
import kz.eub.rm.entity.RunHistory;
import kz.eub.rm.entity.dwh.CreditContractsDictionary;
import kz.eub.rm.screen.dictionary.credit.creditcontractsdictionary.CreditContractsDictionaryBrowse;
import kz.eub.rm.service.RunHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("rm_CreditContractsDictionaryScreenOpenManager")
public class CreditContractsDictionaryScreenOpenManager {
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    @Qualifier("rm_PozRunHistoryService")
    private RunHistoryService<RunHistory> runHistoryService;

    public CreditContractsDictionaryBrowse buildAsLookup(EntityPicker entityPicker) {
        String idOfLatestRun = runHistoryService.getIdOfLatestRun();
        final Screen ownerFrame = AppUI.getCurrent().getTopLevelWindowNN().getFrameOwner();
        return (CreditContractsDictionaryBrowse) screenBuilders.lookup(entityPicker)
                .withScreenClass(CreditContractsDictionaryBrowse.class)
                .withOptions(new CreditContractsDictionaryBrowseOptions(idOfLatestRun, CreditContractsDictionaryBrowseOptions.FilterMode.FOURTH_BASKET)).build();
    }
    public void openBrowseScreen() {
        String idOfLatestRun = runHistoryService.getIdOfLatestRun();
        final Screen ownerFrame = AppUI.getCurrent().getTopLevelWindowNN().getFrameOwner();
        screenBuilders.screen(ownerFrame)
                .withScreenClass(CreditContractsDictionaryBrowse.class)
                .withOptions(new CreditContractsDictionaryBrowseOptions(idOfLatestRun, CreditContractsDictionaryBrowseOptions.FilterMode.NO_FILTER))
                .withOpenMode(OpenMode.NEW_TAB)
                .build()
                .show();
    }
}
