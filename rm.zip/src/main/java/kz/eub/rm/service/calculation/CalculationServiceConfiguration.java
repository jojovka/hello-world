package kz.eub.rm.service.calculation;

import io.jmix.core.security.SystemAuthenticator;
import kz.eub.rm.service.UserService;
import kz.eub.rm.service.email.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;

@Configuration
public class CalculationServiceConfiguration {
    @PersistenceContext(unitName = "dwhstore")
    private EntityManager entityManager;

    @Qualifier("dwhstoreEntityManagerFactory")
    @Autowired
    private EntityManagerFactory entityManagerFactory;


    @Autowired
    private UserService userService;
    @Autowired
    private EmailService emailService;

    @Autowired
    private SystemAuthenticator systemAuthenticator;

    @Bean("rm_PozCalculationService")
    public AbstractCalculationService getPozCalculationService() {
        return new PozCalculationService(entityManager, entityManagerFactory, userService, emailService, systemAuthenticator);
    }

    @Bean("rm_PnzCalculationService")
    public AbstractCalculationService getPnzCalculationService() {
        return new PnzCalculationService(entityManager, entityManagerFactory, userService, emailService, systemAuthenticator);
    }
}
