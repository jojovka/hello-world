package kz.eub.rm.service;

import io.jmix.core.DataManager;
import io.jmix.core.SaveContext;
import io.jmix.core.querycondition.LogicalCondition;
import io.jmix.core.querycondition.PropertyCondition;
import io.jmix.core.security.CurrentAuthentication;
import io.jmix.security.model.ResourceRole;
import io.jmix.security.role.ResourceRoleRepository;
import io.jmix.security.role.assignment.RoleAssignmentRoleType;
import io.jmix.securitydata.entity.RoleAssignmentEntity;
import io.jmix.securityui.model.ResourceRoleModel;
import io.jmix.securityui.model.RoleModelConverter;
import kz.eub.rm.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component("rm_UserSecService")
public class UserSecService {

    public static final String ROLE_CODE_SYSTEM_FULL_ACCESS = "system-full-access";

    @Autowired
    private DataManager dataManager;
    @Autowired
    private CurrentAuthentication currentAuthentication;
    @Autowired
    private ResourceRoleRepository roleRepository;
    @Autowired
    private RoleModelConverter roleModelConverter;

    public boolean currentUserHasRole(String roleCode) {
        return currentAuthentication.getAuthentication().getAuthorities().stream()
                .anyMatch(grantedAuthority ->
                        grantedAuthority.getAuthority().equals(roleCode));
    }

    public boolean userHasRole(String username, String roleCode) {
        return dataManager.load(RoleAssignmentEntity.class)
                .condition(
                        LogicalCondition.and(
                                PropertyCondition.equal("username", username),
                                PropertyCondition.equal("roleCode", roleCode)
                        )
                )
                .list().size() > 0;
    }

    public List<User> loadUsersHavingRole(String roleCode) {
        List<String> usernameList = getUsernameListHavingRole(roleCode);
        if (usernameList.size() == 0) return Collections.emptyList();
        return dataManager.load(User.class)
                .condition(PropertyCondition.inList("username", usernameList))
                .list();
    }

    private List<String> getUsernameListHavingRole(String roleCode) {
        return dataManager.load(RoleAssignmentEntity.class)
                .condition(PropertyCondition.equal("roleCode", roleCode))
                .list().stream()
                .map(RoleAssignmentEntity::getUsername)
                .collect(Collectors.toList());
    }

    public void bulkRoleAssignment(Collection<User> userList, String roleCode) {
        ResourceRole role = roleRepository.getRoleByCode(roleCode);
        SaveContext saveContext = new SaveContext();
        List<RoleAssignmentEntity> roleAssignmentList = userList.stream().map(e -> {
            RoleAssignmentEntity roleAssignment = dataManager.create(RoleAssignmentEntity.class);
            roleAssignment.setRoleCode(role.getCode());
            roleAssignment.setRoleType(RoleAssignmentRoleType.RESOURCE);
            roleAssignment.setUsername(e.getUsername());
            return roleAssignment;
        }).collect(Collectors.toList());
        roleAssignmentList.forEach(saveContext::saving);
        dataManager.save(saveContext);
    }

    public List<ResourceRoleModel> getUserRoles(User user) {
        List<RoleAssignmentEntity> roleAssignmentEntities = dataManager.load(RoleAssignmentEntity.class)
                .condition(PropertyCondition.equal("username", user.getUsername()))
                .list();
        List<String> roleCodes = roleAssignmentEntities.stream()
                .map(RoleAssignmentEntity::getRoleCode)
                .collect(Collectors.toList());
        Collection<ResourceRole> allRoles = roleRepository.getAllRoles();
        return allRoles.stream()
                .filter(r -> roleCodes.contains(r.getCode()))
                .map(roleModelConverter::createResourceRoleModel)
                .sorted(Comparator.comparing(ResourceRoleModel::getName))
                .collect(Collectors.toList());
    }

    public void bulkRoleRevocation(Set<User> userList, String roleCode) {
        List<String> usernameList = userList.stream()
                .map(User::getUsername)
                .collect(Collectors.toList());
        List<RoleAssignmentEntity> roleAssignmentEntities = dataManager.load(RoleAssignmentEntity.class)
                .condition(
                        LogicalCondition.and(
                            PropertyCondition.equal("roleCode", roleCode),
                            PropertyCondition.inList("username", usernameList)
                        )
                )
                .list();
        dataManager.remove(roleAssignmentEntities);
    }

}