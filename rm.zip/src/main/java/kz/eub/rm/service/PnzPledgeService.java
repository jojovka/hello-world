package kz.eub.rm.service;

import kz.eub.rm.entity.PnzPledge;

import java.util.List;

public interface PnzPledgeService {
    List<PnzPledge> getAllData();
}
