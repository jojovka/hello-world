package kz.eub.rm.service;

import kz.eub.rm.entity.dwh.CreditContractsDictionary;

import java.util.List;


public interface PozCreditContractsDictionaryService {
    public List<CreditContractsDictionary> getAllDataWithFetchedChildNames(String runId);
}
