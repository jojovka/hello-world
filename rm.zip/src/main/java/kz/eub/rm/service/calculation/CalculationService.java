package kz.eub.rm.service.calculation;

import kz.eub.rm.service.dto.CalculationLaunchResult;

import java.util.Date;
import java.util.UUID;

public interface CalculationService {
    CalculationLaunchResult runCalculation(Date date, boolean needReloadCreditPortfolio);

    void approveCalculation(String runId);

    boolean isAllowedToApproveCalculation(UUID uuid);
}
