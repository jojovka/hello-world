package kz.eub.rm.service.dto;

public class CalculationLaunchResult {
    private String operationResult;
    private String additionalResultInfo;

    public String getOperationResult() {
        return operationResult;
    }

    public void setOperationResult(String operationResult) {
        this.operationResult = operationResult;
    }

    public String getAdditionalResultInfo() {
        return additionalResultInfo;
    }

    public void setAdditionalResultInfo(String additionalResultInfo) {
        this.additionalResultInfo = additionalResultInfo;
    }
}
