package kz.eub.rm.service.email;

import io.jmix.email.EmailException;
import io.jmix.emailtemplates.exception.ReportParameterTypeChangedException;
import io.jmix.emailtemplates.exception.TemplateNotFoundException;

import java.util.Map;

public interface EmailService {
    public void sendEmail(EmailMessageTemplate emailMessageTemplate, String recipients, Map<String, Object> parameters) throws TemplateNotFoundException, EmailException, ReportParameterTypeChangedException;
}
