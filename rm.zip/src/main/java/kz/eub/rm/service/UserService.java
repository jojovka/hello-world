package kz.eub.rm.service;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.core.querycondition.PropertyCondition;
import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import kz.eub.rm.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;
import java.util.UUID;

@Service("rm_UserService")
public class UserService {

    @Autowired
    private FetchPlans fetchPlans;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private CurrentUserSubstitution currentUserSubstitution;
    @PersistenceContext
    private EntityManager em;


    public User getCurrentUser() {
        try {
            return reloadUserByUsername(currentUserSubstitution.getEffectiveUser().getUsername());
        } catch (UsernameNotFoundException e) {
            return null;
        }
    }

    public User reloadUserById(UUID id) {
        if (id == null)
            return null;
        FetchPlan fetchPlan = getUserFetchPlan();
        return dataManager.load(User.class)
                .id(id)
                .fetchPlan(fetchPlan)
                .optional().orElse(null);
    }

    public User reloadUserByUsername(String username) {
        if (username == null)
            return null;
        FetchPlan fetchPlan = getUserFetchPlan();
        return dataManager.load(User.class)
                .condition(PropertyCondition.equal("username", username))
                .fetchPlan(fetchPlan)
                .optional().orElse(null);
    }

    public User reloadUserWithFetchPlan(User user, FetchPlan fetchPlan) {
        return dataManager.load(User.class)
                .id(user.getId())
                .fetchPlan(fetchPlan)
                .one();
    }

    public FetchPlan getUserFetchPlan() {
        return fetchPlans.builder(User.class)
                .addFetchPlan(FetchPlan.BASE)
                .build();
    }

    public boolean checkUserExistsByUsername(String username) {
        return em.createNativeQuery("select u.id from rm_user u " +
                        "where u.username = ?")
                .setParameter(1, username)
                .getResultList()
                .size() > 0;
    }

    public List<User> searchUser(String fio) {
        return dataManager.load(User.class)
                .query("select c from rm_User c " +
                        "where c.fullName like :name")
                .parameter("name", "(?i)%" + fio + "%")
                .list();
    }

    public User loadUserByPayrollNumber(String payrollNumber) {
        return dataManager.load(User.class)
                .condition(PropertyCondition.equal("payrollNumber", payrollNumber))
                .fetchPlan(getUserFetchPlan())
                .optional().orElse(null);
    }
}