package kz.eub.rm.service;

import kz.eub.rm.entity.dwh.PnzCredit;
import kz.eub.rm.util.ExtractorCounter;
import org.eclipse.persistence.config.QueryHints;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
public class PnzCreditServiceImpl implements PnzCreditService{
    @PersistenceContext(unitName = "dwhstore")
    private EntityManager entityManager;

    @Override
    public List<PnzCredit> getAllData() {
        return ((Stream<Object[]>)entityManager
                .createNativeQuery("SELECT \n" +
                        "pc_uuid,\n" +
                        "pc_report_date,\n" +
                        "pc_dog_num,\n" +
                        "pc_cur_code,\n" +
                        "pc_dprt_name,\n" +
                        "pc_clnt_name,\n" +
                        "pc_cgrp_name,\n" +
                        "pc_out_sum_od,\n" +
                        "pc_out_sum_od_delay,\n" +
                        "pc_out_sum_perc,\n" +
                        "pc_out_sum_perc_delay,\n" +
                        "pc_out_sum_perc_od,\n" +
                        "pc_out_sum_com,\n" +
                        "pc_out_sum_com_delay,\n" +
                        "pc_out_sum_pen_kzt,\n" +
                        "pc_out_sum_msfo_per,\n" +
                        "pc_out_sum_neg_corr,\n" +
                        "pc_out_sum_dis_1434,\n" +
                        "pc_out_sum_dis_2794,\n" +
                        "pc_out_sum_corr_esp,\n" +
                        "pc_out_sum_dev,\n" +
                        "pc_out_sum_mod_1435,\n" +
                        "pc_out_sum_msfo_1428,\n" +
                        "pc_out_sum_prov_com_1845,\n" +
                        "pc_out_sum_prov_1877_kzt,\n" +
                        "pc_out_sum_debt_1860_kzt,\n" +
                        "pc_out_sum_kik,\n" +
                        "pc_out_sum_dz_1877_kzt,\n" +
                        "pc_out_sum_reser_kzt,\n" +
                        "pc_out_sum_outsys,\n" +
                        "pc_out_sum_od_odd,\n" +
                        "pc_out_sum_all_debt,\n" +
                        "pc_out_sum_od_odd_mon_beg,\n" +
                        "pc_out_sum_all_debt_mon_beg,\n" +
                        "pc_msfo_rate,\n" +
                        "pc_out_sum_outsys_sum,\n" +
                        "pc_out_sum_lesion,\n" +
                        "pc_cr_rate_month_beg,\n" +
                        "pc_cr_rate_rep_date,\n" +
                        "pc_prod_name,\n" +
                        "pc_tarif,\n" +
                        "pc_user_cred_type,\n" +
                        "pc_dprt_gid,\n" +
                        "pc_cli_rating,\n" +
                        "pc_cli_rating_date,\n" +
                        "pc_deal_rating,\n" +
                        "pc_deal_rating_date,\n" +
                        "pc_mon_date, \n" +
                        "pc_act_fin_date,\n" +
                        "pc_mon_per,\n" +
                        "pc_last_fin_date, \n" +
                        "pc_cli_rati_out,\n" +
                        "pc_cli_iin_bin,\n" +
                        "pc_cli_type,\n" +
                        "pc_sd_cd, \n" +
                        "pc_kod_ip, \n" +
                        "pc_exp_days,\n" +
                        "pc_exp_days_op_perc,\n" +
                        "pc_ext_exp_days,\n" +
                        "pc_open_date, \n" +
                        "pc_paym_date,\n" +
                        "pc_first_paym_date,\n" +
                        "pc_oked, \n" +
                        "pc_cli_oked_cd,\n" +
                        "pc_problem, \n" +
                        "pc_class, \n" +
                        "pc_modif, \n" +
                        "pc_mod_date, \n" +
                        "pc_basket_mon_beg,\n" +
                        "pc_rate, \n" +
                        "pc_eff_rate,\n" +
                        "pc_non_market_fl,\n" +
                        "pc_all_sum,\n" +
                        "pc_control_list,\n" +
                        "pc_state, \n" +
                        "pc_esector, \n" +
                        "pc_clnt_gid,\n" +
                        "pc_uf_drpz,\n" +
                        "pc_uf_drpz_date,\n" +
                        "pc_uf_dokisa,\n" +
                        "pc_uf_dokisa_date, \n" +
                        "pc_uf_dmrsz, \n" +
                        "pc_uf_dmrsz_date, \n" +
                        "pc_uf_wor_fin_con_date,\n" +
                        "pc_uf_restr_date,\n" +
                        "pc_uni_all_sum,\n" +
                        "pc_duration, \n" +
                        "pc_cur_cd, \n" +
                        "pc_creditsum,\n" +
                        "pc_creditsum_kzt,\n" +
                        "pc_death_date, \n" +
                        "pc_prison_date, \n" +
                        "pc_zero_date, \n" +
                        "pc_operation_is_write_off,\n" +
                        "pc_cession_value,\n" +
                        "pc_operation_pay_off_system, \n" +
                        "pc_bankrupt_date, \n" +
                        "pc_court_date, \n" +
                        "pc_payment_loans_date,\n" +
                        "pc_operation_pay_off_system_amount,\n" +
                        "pc_credit_dep, pc_gen_date,\n" +
                        "pc_mod_npv, \n" +
                        "pc_mod_substantial,\n" +
                        "pc_basket_rep_date, \n" +
                        "pc_trg_2, \n" +
                        "pc_trg_3, \n" +
                        "pc_trg_4, \n" +
                        "pc_recovery_ready,\n" +
                        "pc_default_date, \n" +
                        "pc_recovery_date, \n" +
                        "pc_max_default_date, \n" +
                        "pc_model_transform,\n" +
                        "pc_segment \n" +
                        "FROM dwh_risk.pnz_credits;")
                .setHint(QueryHints.JDBC_FETCH_SIZE, 250000)
                .getResultStream())
                .parallel().map(v -> mapToDictionaryRecord(v)).collect(Collectors.toList());
    }

    private PnzCredit mapToDictionaryRecord(Object[] objects) {
        ExtractorCounter extractorCounter = new ExtractorCounter();
        PnzCredit pnzCredit = new PnzCredit();
        pnzCredit.setId((UUID) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcReportDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcDogNum((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcCurCode((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcDprtName((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcClntName((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcCgrpName((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumOd((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumOdDelay((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumPerc((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumPercDelay((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumPercOd((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumCom((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumComDelay((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumPenKzt((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumMsfoPer((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumNegCorr((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumDis1434((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumDis2794((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumCorrEsp((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumDev((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumMod1435((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumMsfo1428((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumProvCom1845((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumProv1877Kzt((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumDebt1860Kzt((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumKik((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumDz1877Kzt((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumReserKzt((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumOutsys((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumOdOdd((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumAllDebt((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumOdOddMonBeg((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumAllDebtMonBeg((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcMsfoRate((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumOutsysSum((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOutSumLesion((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcCrRateMonthBeg((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcCrRateRepDate((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcProdName((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcTarif((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcUserCredType((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcDprtGid((Long) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcCliRating((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcCliRatingDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcDealRating((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcDealRatingDate((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcMonDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcActFinDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcMonPer((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcLastFinDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcCliRatiOut((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcCliIinBin((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcCliType((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcSdCd((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcKodIp((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcExpDays((Integer) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcExpDaysOpPerc((Integer) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcExtExpDays((Integer) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOpenDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcPaymDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcFirstPaymDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOked((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcCliOkedCd((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcProblem((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcClass((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcModif((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcModDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcBasketMonBeg((Integer) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcRate((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcEffRate((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcNonMarketFl((Boolean) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcAllSum((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcControlList((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcState((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcEsector((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcClntGid((Long) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcUfDrpz((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcUfDrpzDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcUfDokisa((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcUfDokisaDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcUfDmrsz((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcUfDmrszDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcUfWorFinConDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcUfRestrDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcUniAllSum((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcDuration((Integer) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcCurCd((Long) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcCreditsum((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcCreditsumKzt((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcDeathDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcPrisonDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcZeroDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOperationIsWriteOff((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcCessionValue((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOperationPayOffSystem((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcBankruptDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcCourtDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcPaymentLoansDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcOperationPayOffSystemAmount((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcCreditDep((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcGenDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcModNpv((BigDecimal) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcModSubstantial((Integer) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcBasketRepDate((Integer) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcTrg2((Boolean) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcTrg3((Boolean) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcTrg4((Boolean) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcRecoveryReady((Boolean) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcDefaultDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcRecoveryDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcMaxDefaultDate((Date) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcModelTransform((String) extractorCounter.getWithCounterIncrease(objects));
        pnzCredit.setPcSegment((String) extractorCounter.getWithCounterIncrease(objects));
        return pnzCredit;
    }
}
