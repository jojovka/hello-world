package kz.eub.rm.service;

import io.jmix.bpm.entity.ProcessInstanceData;
import io.jmix.bpm.util.FlowableEntitiesConverter;
import io.jmix.core.DataManager;
import kz.eub.rm.entity.Application;
import kz.eub.rm.entity.EApplicationStatus;
import org.flowable.common.engine.api.FlowableObjectNotFoundException;
import org.flowable.engine.HistoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.engine.runtime.ProcessInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("rm_ApplicationService")
public class ApplicationService {

    @Autowired
    protected RuntimeService runtimeService;
    @Autowired
    private HistoryService historyService;
    @Autowired
    private FlowableEntitiesConverter flowableEntitiesConverter;
    @Autowired
    private DataManager dataManager;

    public ProcessInstanceData loadApplicationProcessInstanceData(Application application) {
        if (application == null)
            throw new IllegalStateException("Передана пустая заявка для получения экземпляра процесса...");
        if (application.getProcId() != null) {
            ProcessInstance processInstance = runtimeService.createProcessInstanceQuery()
                    .processInstanceId(application.getProcId())
                    .singleResult();
            if (processInstance != null)
                return flowableEntitiesConverter.createProcessInstanceData(processInstance);

            HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery()
                    .processInstanceId(application.getProcId())
                    .singleResult();
            if (historicProcessInstance != null)
                return flowableEntitiesConverter.createHistoricProcessInstanceData(historicProcessInstance);
        }
        return null;
    }

    public boolean cancelApplicationProcess(Application application, String reason) {
        if (application == null)
            throw new IllegalStateException("Передана пустая заявка для получения экземпляра процесса...");
        if (application.getProcId() != null) {
            try {
                runtimeService.deleteProcessInstance(application.getProcId(), reason);
                application.setStatus(EApplicationStatus.REVOKED);
                dataManager.save(application);
                return true;
            } catch (FlowableObjectNotFoundException e) {
                throw new RuntimeException("Процесс не найден.", e);
            }
        }
        return false;
    }

    public void noobMethod() {}
}