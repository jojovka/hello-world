package kz.eub.rm.service;

import java.util.Date;
import java.util.List;

public interface RunHistoryService<T> {
    List<Integer> getRunNumbersForReportDate(Date date);
    String getRunId(Date date, Integer runNumber);

    String getIdOfLatestRun();

    T getLatestRun();
}
