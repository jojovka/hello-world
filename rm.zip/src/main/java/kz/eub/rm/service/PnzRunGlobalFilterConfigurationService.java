package kz.eub.rm.service;

import com.vaadin.spring.annotation.UIScope;
import io.jmix.core.DataManager;
import io.jmix.core.session.SessionData;
import kz.eub.rm.entity.PnzRunHistory;
import kz.eub.rm.entity.RunHistory;
import kz.eub.rm.service.constant.SessionDataKey;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.web.context.WebApplicationContext;

@Service("PnzRunGlobalFilterConfigurationService")
@UIScope
public class PnzRunGlobalFilterConfigurationService extends AbstractGlobalFilterConfigurationService<PnzRunHistory> {
    public PnzRunGlobalFilterConfigurationService(SessionData sessionData, DataManager dataManager) {
        super(sessionData, dataManager, PnzRunHistory.class, SessionDataKey.PNZ_RUN_KEY);
    }
}
