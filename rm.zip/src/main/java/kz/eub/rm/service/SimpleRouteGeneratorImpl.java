package kz.eub.rm.service;

import io.jmix.core.Metadata;
import io.jmix.core.entity.EntityValues;
import io.jmix.ui.WindowConfig;
import io.jmix.ui.WindowInfo;
import io.jmix.ui.navigation.RouteDefinition;
import io.jmix.ui.navigation.UrlIdSerializer;
import org.apache.catalina.connector.Connector;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatWebServer;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import org.springframework.stereotype.Component;

@Component("rm_SimpleRouteGeneratorImpl")
public class SimpleRouteGeneratorImpl implements SimpleRouteGenerator{
    @Autowired
    protected WindowConfig windowConfig;
    @Autowired
    protected Metadata metadata;
    @Value("${rm.base.url}")
    private String baseUrl;
    @Autowired
    private ServletWebServerApplicationContext servletWebServerApplicationContext;

    @Override
    public String generateForEditor(Object entity) {
        StringBuilder routeBuilder = new StringBuilder(baseUrl);
        String screenId = windowConfig.getEditorScreenId(metadata.getClass(entity));
        WindowInfo windowInfo = windowConfig.getWindowInfo(screenId);
        RouteDefinition routeDefinition = windowInfo.getRouteDefinition();
        if (routeDefinition == null || StringUtils.isEmpty(routeDefinition.getPath())) {
            throw new IllegalStateException(
                    String.format("Unable to generate route for screen '%s' - no registered route found", screenId));
        }
        routeBuilder
                .append("/#main/")
                .append(routeDefinition.getPath()).append(String.format("?id=%s", UrlIdSerializer.serializeId(EntityValues.getId(entity))));
        return routeBuilder.toString();
    }

    @Override
    public String generateForBrowse(Object entity) {
        StringBuilder routeBuilder = new StringBuilder(baseUrl);
        String screenId = windowConfig.getBrowseScreenId(metadata.getClass(entity));
        WindowInfo windowInfo = windowConfig.getWindowInfo(screenId);
        RouteDefinition routeDefinition = windowInfo.getRouteDefinition();
        if (routeDefinition == null || StringUtils.isEmpty(routeDefinition.getPath())) {
            throw new IllegalStateException(
                    String.format("Unable to generate route for screen '%s' - no registered route found", screenId));
        }
        routeBuilder
                .append("/#main/")
                .append(routeDefinition.getPath());
        return routeBuilder.toString();
    }
}
