package kz.eub.rm.service.constant;

public class RunCalculationResultCode {
    public static final String ERROR = "ERROR";
    public static final String PREPARE_SUCCESS = "SUCCESS";
    public static final String ALREADY_IN_PROGRESS = "ERROR_ALREADY_IN_PROGRESS";
    public static final String ERROR_LATER_REPORT_EXISTS = "ERROR_LATER_REPORT_EXISTS";
    public static final String UNKNOWN_EXCEPTION = "UNKNOWN_EXCEPTION";
}
