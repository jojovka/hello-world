package kz.eub.rm.ui.util;

import io.jmix.core.metamodel.model.MetaPropertyPath;
import io.jmix.ui.component.Table;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class TableUtil {

    public static <T> List<String> getTablePropertiesPaths(Table<T> table) {
        return table.getColumns().stream().map(v -> {
            List<String> pathProperties = Arrays.asList(((MetaPropertyPath)v.getId()).getPath());
            String path = "";
            for (int i=0;i< pathProperties.size();i++) {
                path = path.concat(pathProperties.get(i));
                if (i+1 != pathProperties.size()) {
                    path.concat(".");
                }
            }
            return path;
        }).collect(Collectors.toList());
    }
}
