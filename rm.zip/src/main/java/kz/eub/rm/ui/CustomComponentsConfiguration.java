package kz.eub.rm.ui;

import io.jmix.ui.sys.registration.ComponentRegistration;
import io.jmix.ui.sys.registration.ComponentRegistrationBuilder;
import kz.eub.rm.ui.component.CustomEntitySuggestionField;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CustomComponentsConfiguration {
    @Bean
    public ComponentRegistration customEntitySuggestionField() {
        return ComponentRegistrationBuilder.create(CustomEntitySuggestionField.NAME)
                .withComponentClass(CustomEntitySuggestionField.class)
                .build();
    }
}
