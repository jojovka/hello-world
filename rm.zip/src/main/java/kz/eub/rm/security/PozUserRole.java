package kz.eub.rm.security;

import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.security.role.annotation.SpecificPolicy;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import kz.eub.rm.entity.ReportsBundle;
import kz.eub.rm.entity.RunHistory;
import kz.eub.rm.entity.dwh.*;

@ResourceRole(name = "PozUserRole", code = "poz-user-role")
public interface PozUserRole {
    @MenuPolicy(menuIds = {"pozMappingDictionaryItem", "creditContractsDictionaryItem", "pledgesDictionaryItem", "rm_PozDictionary.browse", "rm_PozSegmentationDictionary.browse", "rm_PozMacroAdjustmentDictionary.browse", "rm_AlphaCoefficientDictionary.browse", "rm_LiquidityCoefficientDictionary.browse", "rm_PdMatrixReportScreen", "rm_LgdMatrixReportScreen", "rm_TvReportScreen", "rm_EpsReportScreen", "rm_ProvisionsReportScreen", "rm_TriggersReportScreen", "rm_LgdBaseReportScreen", "rm_ProvisionsCalculationBaseScreen", "rm_MacrocorrectionReportScreen", "rm_CalculationsScreen", "rm_ReportsBundle.browse", "rm_PozCalculationsScreen"})
    void beanMenuItems();

    @ScreenPolicy(screenIds = {"rm_CreditContractsDictionary.browse", "rm_PozMapping.browse", "rm_PozDictionary.browse", "rm_PozSegmentationDictionary.browse", "rm_PozMacroAdjustmentDictionary.browse", "rm_AlphaCoefficientDictionary.browse", "rm_LiquidityCoefficientDictionary.browse", "rm_PdMatrixReportScreen", "rm_LgdMatrixReportScreen", "rm_TvReportScreen", "rm_EpsReportScreen", "rm_ProvisionsReportScreen", "rm_TriggersReportScreen", "rm_LgdBaseReportScreen", "rm_ProvisionsCalculationBaseScreen", "rm_MacrocorrectionReportScreen", "rm_PledgesDictionary.browse", "rm_ReportsBundle.browse", "rm_PozCalculationsScreen", "rm_PozCalculationsViewFragment", "rm_PozRunCalculationFragment"})
    void screens();

    @SpecificPolicy(resources = "main.poz.run.filter")
    void specific();


    @EntityAttributePolicy(entityClass = CreditContractsDictionary.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = CreditContractsDictionary.class, actions = EntityPolicyAction.READ)
    void creditContractsDictionary();

    @EntityAttributePolicy(entityClass = PledgesDictionary.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = PledgesDictionary.class, actions = EntityPolicyAction.READ)
    void pledgesDictionary();

    @EntityAttributePolicy(entityClass = PozDictionary.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = PozDictionary.class, actions = EntityPolicyAction.READ)
    void pozDictionary();

    @EntityAttributePolicy(entityClass = PozMacroAdjustmentDictionary.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = PozMacroAdjustmentDictionary.class, actions = EntityPolicyAction.READ)
    void pozMacroAdjustmentDictionary();

    @EntityAttributePolicy(entityClass = PozMappingDictionary.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = PozMappingDictionary.class, actions = EntityPolicyAction.READ)
    void pozMappingDictionary();

    @EntityAttributePolicy(entityClass = AlphaCoefficientDictionary.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = AlphaCoefficientDictionary.class, actions = EntityPolicyAction.READ)
    void alphaCoefficientDictionary();

    @EntityAttributePolicy(entityClass = LiquidityCoefficientDictionary.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = LiquidityCoefficientDictionary.class, actions = EntityPolicyAction.READ)
    void liquidityCoefficientDictionary();

    @EntityAttributePolicy(entityClass = PozSegmentationDictionary.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = PozSegmentationDictionary.class, actions = EntityPolicyAction.READ)
    void pozSegmentationDictionary();

    @EntityAttributePolicy(entityClass = RunHistory.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = RunHistory.class, actions = EntityPolicyAction.READ)
    void runHistory();

    @EntityAttributePolicy(entityClass = ReportsBundle.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = ReportsBundle.class, actions = EntityPolicyAction.ALL)
    void reportsBundle();
}