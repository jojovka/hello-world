package kz.eub.rm.security;

import io.jmix.reports.entity.Report;
import io.jmix.reports.entity.ReportExecution;
import io.jmix.reports.entity.ReportGroup;
import io.jmix.reports.entity.ReportTemplate;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;

import static io.jmix.security.model.EntityAttributePolicyAction.VIEW;

@ResourceRole(name = "ReportsBasic", code = "reports-basic")
public interface ReportsBasicRole {

    @ScreenPolicy(screenIds = {"report_InputParameters.dialog", "report_Report.run", "report_ShowReportTable.screen", "report_ShowPivotTable.screen", "report_ShowChart.screen", "rm_PdMatrixReportScreen", "rm_LgdMatrixReportScreen", "rm_TvReportScreen", "rm_EpsReportScreen", "rm_ProvisionsReportScreen", "rm_TriggersReportScreen", "rm_SimpleReportDownloadScreen", "rm_LgdBaseReportScreen", "rm_ProvisionsCalculationBaseScreen", "rm_MacrocorrectionReportScreen"})
    @EntityPolicy(entityClass = Report.class, actions = {EntityPolicyAction.READ})
    @EntityPolicy(entityClass = ReportGroup.class, actions = {EntityPolicyAction.READ})
    @EntityPolicy(entityClass = ReportTemplate.class, actions = {EntityPolicyAction.READ})
    @EntityPolicy(entityClass = ReportExecution.class, actions = {EntityPolicyAction.CREATE, EntityPolicyAction.UPDATE})
    @EntityAttributePolicy(entityClass = Report.class, attributes = {"name", "localeNames", "description", "code", "updateTs", "group"}, action = VIEW)
    @EntityAttributePolicy(entityClass = ReportGroup.class, attributes = {"title", "localeNames"}, action = VIEW)
    @EntityAttributePolicy(entityClass = ReportTemplate.class, attributes = {"code", "name", "customDefinition", "custom", "alterable"}, action = VIEW)
    void reportsRun();

    @MenuPolicy(menuIds = {"rm_PdMatrixReportScreen", "rm_LgdMatrixReportScreen", "rm_TvReportScreen", "rm_EpsReportScreen", "rm_ProvisionsReportScreen", "rm_TriggersReportScreen", "rm_LgdBaseReportScreen", "rm_ProvisionsCalculationBaseScreen", "rm_MacrocorrectionReportScreen"})
    void screens();
}