package kz.eub.rm.security;

import io.jmix.reports.entity.Report;
import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.security.role.annotation.SpecificPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import io.jmix.ui.entity.FilterCondition;
import io.jmix.uidata.entity.FilterConfiguration;
import kz.eub.rm.entity.User;

@ResourceRole(name = "BasicRole", code = "basic-role")
public interface BasicRole {
    @ScreenPolicy(screenIds = {"ui_AddConditionScreen", "ui_GroupFilterCondition.edit", "ui_JpqlFilterCondition.edit", "ui_PropertyFilterCondition.edit", "rm_CustomPropertyFilterCondition.edit", "ui_FilterConfigurationModel.fragment", "ui_UiDataFilterConfigurationModel.fragment", "rm_SimpleReportDownloadScreen", "rm_FilterApplyDialog"})
    void screens();

    @EntityAttributePolicy(entityClass = Report.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = Report.class, actions = EntityPolicyAction.READ)
    void report();

    @SpecificPolicy(resources = {"ui.filter.modifyConfiguration", "ui.filter.modifyJpqlCondition"})
    void specific();

    @EntityAttributePolicy(entityClass = FilterConfiguration.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = FilterConfiguration.class, actions = EntityPolicyAction.READ)
    void filterConfiguration();

    @EntityAttributePolicy(entityClass = FilterCondition.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = FilterCondition.class, actions = EntityPolicyAction.READ)
    void filterCondition();

    @EntityAttributePolicy(entityClass = User.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = User.class, actions = EntityPolicyAction.READ)
    void user();
}