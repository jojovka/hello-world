package kz.eub.rm.file;

import io.jmix.ui.Notifications;

import java.util.*;
import java.util.function.Function;
import java.util.function.Supplier;

public class MultipleReportsGenerationButtonConfigurationBuilder {
    private String reportCode;

    private FileDownloadButtonAppearance fileDownloadButtonAppearance;

    private Supplier<List<Map<String, Object>>> onClickParametersCreationDelegate;

    private Function<Void, String> onClickTemplateSelectionDelegate;

    private Supplier<FileDownloadClickValidationResult> onClickAdditionalValidation;

    private Supplier<String> blockingValueSupplier;

    private Notifications notifications;

    protected MultipleReportsGenerationButtonConfigurationBuilder(Notifications notifications, String reportCode) {
        this.notifications = notifications;
        this.reportCode = reportCode;
    }

    public MultipleReportsGenerationButtonConfigurationBuilder fileDownloadButtonAppearance(FileDownloadButtonAppearance fileDownloadButtonAppearance) {
        this.fileDownloadButtonAppearance = fileDownloadButtonAppearance;
        return this;
    }

    public MultipleReportsGenerationButtonConfigurationBuilder onClickParametersAdjustmentDelegate(Supplier<List<Map<String, Object>>> onClickParametersAdjustmentDelegate){
        this.onClickParametersCreationDelegate = onClickParametersAdjustmentDelegate;
        return this;
    }

    public MultipleReportsGenerationButtonConfigurationBuilder onClickTemplateSelectionDelegate(Function<Void,String> onClickTemplateSelectionDelegate) {
        this.onClickTemplateSelectionDelegate = onClickTemplateSelectionDelegate;
        return this;
    }

    public MultipleReportsGenerationButtonConfigurationBuilder onClickAdditionalValidation(Supplier<FileDownloadClickValidationResult> onClickAdditionalValidation) {
        this.onClickAdditionalValidation = onClickAdditionalValidation;
        return this;
    }


    public MultipleReportsGenerationButtonConfigurationBuilder blockingValueSupplier(Supplier<String> blockingValueSupplier) {
        this.blockingValueSupplier = blockingValueSupplier;
        return this;
    }

    public MultipleReportsGenerationButtonConfiguration build() {
        MultipleReportsGenerationButtonConfiguration configuration = new MultipleReportsGenerationButtonConfiguration();
        configuration.setReportCode(this.reportCode);
        configuration.setParametersMaps(new ArrayList<>());
        if(this.onClickTemplateSelectionDelegate == null) {
            configuration.setOnClickTemplateSelectionDelegate( v -> "DEFAULT");
            configuration.setUseDefaultTemplate(true);
        } else {
            configuration.setOnClickTemplateSelectionDelegate(this.onClickTemplateSelectionDelegate);
        }
        configuration.setFileDownloadButtonAppearance(
                Optional.ofNullable(fileDownloadButtonAppearance).orElse(FileDownloadButtonAppearance.DEFAULT)
        );
        configuration.setOnClickParametersCreationDelegate(onClickParametersCreationDelegate == null? ArrayList::new : onClickParametersCreationDelegate);
        configuration.setOnClickAdditionalValidation(
                onClickAdditionalValidation == null?
                        () -> new FileDownloadClickValidationResult(FileDownloadClickValidationResult.Status.SUCCESS, null):
                        onClickAdditionalValidation
                );
        configuration.setBlockingValueSupplier(
                blockingValueSupplier == null?
                        () -> reportCode:
                        blockingValueSupplier
        );
        configuration.setNotifications(notifications);
        return configuration;
    }
}
