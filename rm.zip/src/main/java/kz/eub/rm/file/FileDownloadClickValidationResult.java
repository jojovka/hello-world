package kz.eub.rm.file;

public class FileDownloadClickValidationResult {
    final private Status status;
    final private String message;

    public FileDownloadClickValidationResult(Status status, String message) {
        this.status = status;
        this.message = message;
    }

    public Status getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public enum Status {
        SUCCESS,
        ERROR
    }
}
