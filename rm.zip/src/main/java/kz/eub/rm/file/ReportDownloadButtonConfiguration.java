package kz.eub.rm.file;

import io.jmix.reportsui.runner.UiReportRunner;
import io.jmix.ui.Notifications;

import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class ReportDownloadButtonConfiguration {
    // UiReportRunner Необходимо передавать в обработчик из контроллера, тк в singleton бинах не видна ui сессия
    private UiReportRunner uiReportRunner;
    private String reportCode;

    private Map<String, Object> parameters;

    private boolean useDefaultTemplate;

    private FileDownloadButtonAppearance fileDownloadButtonAppearance;

    private Consumer<Map<String, Object>> onClickParametersAdjustmentDelegate;

    private Function<Void, String> onClickTemplateSelectionDelegate;

    private Supplier<FileDownloadClickValidationResult> onClickAdditionalValidation;

    private Notifications notifications;

    public static ReportDownloadButtonConfigurationBuilder builder(UiReportRunner uiReportRunner, String reportCode) {
        return new ReportDownloadButtonConfigurationBuilder(uiReportRunner, null, reportCode);
    }

    public static ReportDownloadButtonConfigurationBuilder builder(UiReportRunner uiReportRunner, Notifications notifications, String reportCode) {
        return new ReportDownloadButtonConfigurationBuilder(uiReportRunner, notifications, reportCode);
    }

    protected ReportDownloadButtonConfiguration(){
    }

    public UiReportRunner getUiReportRunner() {
        return uiReportRunner;
    }

    public void setUiReportRunner(UiReportRunner uiReportRunner) {
        this.uiReportRunner = uiReportRunner;
    }

    public String getReportCode() {
        return reportCode;
    }

    public void setReportCode(String reportCode) {
        this.reportCode = reportCode;
    }

    public Map<String, Object> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, Object> parameters) {
        this.parameters = parameters;
    }

    public boolean isUseDefaultTemplate() {
        return useDefaultTemplate;
    }

    public void setUseDefaultTemplate(boolean useDefaultTemplate) {
        this.useDefaultTemplate = useDefaultTemplate;
    }

    public FileDownloadButtonAppearance getFileDownloadButtonAppearance() {
        return fileDownloadButtonAppearance;
    }

    public void setFileDownloadButtonAppearance(FileDownloadButtonAppearance fileDownloadButtonAppearance) {
        this.fileDownloadButtonAppearance = fileDownloadButtonAppearance;
    }

    public Consumer<Map<String, Object>> getOnClickParametersAdjustmentDelegate() {
        return onClickParametersAdjustmentDelegate;
    }

    public void setOnClickParametersAdjustmentDelegate(Consumer<Map<String, Object>> onClickParametersAdjustmentDelegate) {
        this.onClickParametersAdjustmentDelegate = onClickParametersAdjustmentDelegate;
    }

    public Function<Void, String> getOnClickTemplateSelectionDelegate() {
        return onClickTemplateSelectionDelegate;
    }

    public void setOnClickTemplateSelectionDelegate(Function<Void, String> onClickTemplateSelectionDelegate) {
        this.onClickTemplateSelectionDelegate = onClickTemplateSelectionDelegate;
    }

    public Supplier<FileDownloadClickValidationResult> getOnClickAdditionalValidation() {
        return onClickAdditionalValidation;
    }

    public void setOnClickAdditionalValidation(Supplier<FileDownloadClickValidationResult> onClickAdditionalValidation) {
        this.onClickAdditionalValidation = onClickAdditionalValidation;
    }

    public Notifications getNotifications() {
        return notifications;
    }

    public void setNotifications(Notifications notifications) {
        this.notifications = notifications;
    }
}
