package kz.eub.rm.file;

import io.jmix.reportsui.runner.UiReportRunner;
import io.jmix.ui.Notifications;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class ReportDownloadButtonConfigurationBuilder {
    private UiReportRunner uiReportRunner;
    private String reportCode;

    private Map<String, Object> parameters;

    private FileDownloadButtonAppearance fileDownloadButtonAppearance;

    private Consumer<Map<String, Object>> onClickParametersAdjustmentDelegate;

    private Function<Void, String> onClickTemplateSelectionDelegate;

    private Supplier<FileDownloadClickValidationResult> onClickAdditionalValidation;

    private Notifications notifications;

    protected ReportDownloadButtonConfigurationBuilder(UiReportRunner uiReportRunner, Notifications notifications, String reportCode) {
        this.uiReportRunner = uiReportRunner;
        this.notifications = notifications;
        this.reportCode = reportCode;
    }

    public ReportDownloadButtonConfigurationBuilder parameters(Map<String, Object> parameters) {
        this.parameters = parameters;
        return this;
    }

    public ReportDownloadButtonConfigurationBuilder fileDownloadButtonAppearance(FileDownloadButtonAppearance fileDownloadButtonAppearance) {
        this.fileDownloadButtonAppearance = fileDownloadButtonAppearance;
        return this;
    }

    public ReportDownloadButtonConfigurationBuilder onClickParametersAdjustmentDelegate(Consumer<Map<String, Object>> onClickParametersAdjustmentDelegate){
        this.onClickParametersAdjustmentDelegate = onClickParametersAdjustmentDelegate;
        return this;
    }

    public ReportDownloadButtonConfigurationBuilder onClickTemplateSelectionDelegate(Function<Void,String> onClickTemplateSelectionDelegate) {
        this.onClickTemplateSelectionDelegate = onClickTemplateSelectionDelegate;
        return this;
    }

    public ReportDownloadButtonConfigurationBuilder onClickAdditionalValidation(Supplier<FileDownloadClickValidationResult> onClickAdditionalValidation) {
        this.onClickAdditionalValidation = onClickAdditionalValidation;
        return this;
    }

    public ReportDownloadButtonConfiguration build() {
        ReportDownloadButtonConfiguration reportDownloadButtonConfiguration = new ReportDownloadButtonConfiguration();
        reportDownloadButtonConfiguration.setReportCode(this.reportCode);
        reportDownloadButtonConfiguration.setUiReportRunner(uiReportRunner);
        reportDownloadButtonConfiguration.setParameters(parameters!=null?parameters:new HashMap<>());
        if(this.onClickTemplateSelectionDelegate == null) {
            reportDownloadButtonConfiguration.setOnClickTemplateSelectionDelegate( v -> "DEFAULT");
            reportDownloadButtonConfiguration.setUseDefaultTemplate(true);
        } else {
            reportDownloadButtonConfiguration.setOnClickTemplateSelectionDelegate(this.onClickTemplateSelectionDelegate);
        }
        reportDownloadButtonConfiguration.setFileDownloadButtonAppearance(
                Optional.ofNullable(fileDownloadButtonAppearance).orElse(FileDownloadButtonAppearance.DEFAULT)
        );
        reportDownloadButtonConfiguration.setOnClickParametersAdjustmentDelegate(onClickParametersAdjustmentDelegate == null?(v)->{}:onClickParametersAdjustmentDelegate);
        reportDownloadButtonConfiguration.setOnClickAdditionalValidation(
                onClickAdditionalValidation == null?
                        () -> new FileDownloadClickValidationResult(FileDownloadClickValidationResult.Status.SUCCESS, null):
                        onClickAdditionalValidation
                );
        reportDownloadButtonConfiguration.setNotifications(notifications);
        return reportDownloadButtonConfiguration;
    }
}
