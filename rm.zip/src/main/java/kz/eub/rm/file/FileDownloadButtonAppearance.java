package kz.eub.rm.file;

import io.jmix.ui.icon.Icons;
import io.jmix.ui.icon.JmixIcon;

public enum FileDownloadButtonAppearance {
    EXCEL(JmixIcon.FILE_EXCEL_O, "Excel"),
    REPORT_FILE(JmixIcon.FILE_O, "Report"),
    DEFAULT(JmixIcon.DOWNLOAD, "Report");

    private final Icons.Icon icon;

    private final String caption;

    FileDownloadButtonAppearance(Icons.Icon icon, String caption){
        this.icon = icon;
        this.caption = caption;
    }

    public Icons.Icon getIcon() {
        return icon;
    }

    public String getCaption() {
        return caption;
    }
}