package kz.eub.rm.file;

import com.haulmont.yarg.reporting.ReportOutputDocument;
import io.jmix.core.DataManager;
import io.jmix.core.Messages;
import io.jmix.core.security.SystemAuthenticator;
import io.jmix.reports.runner.ReportRunner;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import kz.eub.rm.entity.ReportsBundle;
import kz.eub.rm.entity.ReportsBundleStatus;
import kz.eub.rm.entity.User;
import kz.eub.rm.service.ReportsBundleService;
import kz.eub.rm.service.SimpleRouteGenerator;
import kz.eub.rm.service.UserService;
import kz.eub.rm.service.email.EmailMessageTemplate;
import kz.eub.rm.service.email.EmailService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;

public class FileGenerationButtonFactory {
    Logger log = LoggerFactory.getLogger(FileGenerationButtonFactory.class);
    private static final SimpleDateFormat dateTimeFormat = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss");

    private final ReportRunner reportRunner;

    private final UiComponents uiComponents;

    private final ExecutorService executorService;

    private final ReportsBundleService reportsBundleService;

    private final SimpleRouteGenerator simpleRouteGenerator;

    private final UserService userService;

    private final SystemAuthenticator systemAuthenticator;

    private final Messages messages;

    private final EmailService emailService;

    private final DataManager dataManager;

    public FileGenerationButtonFactory(
            ReportRunner reportRunner,
            UiComponents uiComponents,
            ExecutorService executorService,
            ReportsBundleService reportsBundleService,
            SimpleRouteGenerator simpleRouteGenerator, UserService userService,
            SystemAuthenticator systemAuthenticator,
            Messages messages,
            EmailService emailService, DataManager dataManager) {
        this.reportRunner = reportRunner;
        this.uiComponents = uiComponents;
        this.reportsBundleService = reportsBundleService;
        this.executorService = executorService;
        this.simpleRouteGenerator = simpleRouteGenerator;
        this.userService = userService;
        this.systemAuthenticator = systemAuthenticator;
        this.messages = messages;
        this.emailService = emailService;
        this.dataManager = dataManager;
    }

    public Button createMultipleReportsZipGenerationButton(MultipleReportsGenerationButtonConfiguration configuration) {
        Button button = uiComponents.create(Button.class);
        button.setCaption("запуск");
        button.setAction(buildZipGenerationAndSavingAction(configuration));
        return button;
    }

    public BaseAction buildZipGenerationAndSavingAction (MultipleReportsGenerationButtonConfiguration configuration) {
        User user = userService.getCurrentUser();
        return new BaseAction(configuration.getReportCode()).withHandler(
                (event) -> {
                    Date launchDateTime = new Date();
                    String preferredName = String.format("%s_%s_%s", configuration.getReportCode(), user.getUsername(), dateTimeFormat.format(launchDateTime));
                    log.info("user {} launched generation of reports bundle with name {}", user.getUsername(), preferredName);
                    //генерация параметров для каждого отдельного отчета
                    configuration.setParametersMaps(configuration.getOnClickParametersCreationDelegate().get());

                    List<ReportsBundle> blockingReportBundles = dataManager.load(ReportsBundle.class)
                            .query("select e from rm_ReportsBundle e where e.blockingValue=:blockingValue and e.status=:status")
                            .parameter("blockingValue", configuration.getBlockingValueSupplier().get())
                            .parameter("status", ReportsBundleStatus.IN_PROGRESS)
                            .list();
                    if (!blockingReportBundles.isEmpty()) {
                        configuration.getNotifications()
                                .create()
                                .withDescription("Генерация архива с такими параметрами уже запущена.\nДождитесь ее окончания.")
                                .show();
                        return;
                    }

                    ReportsBundle reportsBundle = dataManager.create(ReportsBundle.class);
                    reportsBundle.setName(preferredName);
                    reportsBundle.setCreatedBy(user);
                    reportsBundle.setGenerationLaunchDateTime(launchDateTime);
                    reportsBundle.setBlockingValue(configuration.getBlockingValueSupplier().get());
                    reportsBundle.setStatus(ReportsBundleStatus.IN_PROGRESS);

                    reportsBundle = dataManager.save(reportsBundle);

                    UUID reportsBundleId = reportsBundle.getId();

                    configuration
                            .getNotifications()
                            .create()
                            .withDescription(messages.getMessage("kz.eub.rm.file.FileGenerationButtonFactory/generationLaunchedNotification"))
                            .show();

                    ReportsBundle finalReportsBundle = reportsBundle;
                    String link = simpleRouteGenerator.generateForBrowse(finalReportsBundle);
                    executorService.submit(() -> {
                        systemAuthenticator.withSystem(() -> {
                            try {
                                //генерация отчетов
                                List<ReportOutputDocument> reportOutputDocuments = runReports(configuration, preferredName);
                                //сохранение отчетов в файловой системе и обновление записи в таблице
                                reportsBundleService.saveReportsAsZipBundle(reportOutputDocuments, reportsBundleId);
                                log.info("reports bundle {} is ready", preferredName);
                                sendGenerationResultNotification(user.getEmail(), preferredName, ReportsBundleStatus.SUCCESS, link);
                            } catch (Exception e) {
                                log.error(String.format("failed to generate reports bundle %s", preferredName), e);
                                finalReportsBundle.setStatus(ReportsBundleStatus.ERROR);
                                dataManager.save(finalReportsBundle);
                                sendGenerationResultNotification(user.getEmail(), preferredName, ReportsBundleStatus.ERROR, link);
                            }
                            return null;
                        });
                    });
                }
        );
    }

    private void sendGenerationResultNotification(String email, String bundleName, ReportsBundleStatus status, String link) {
        try {
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("status", messages.getMessage(status));
            parameters.put("name", bundleName);
            parameters.put("link", link);
            emailService.sendEmail(EmailMessageTemplate.REPORTS_BUNDLE_GENERATION_FINISHED_TEMPLATE, email, parameters);
        } catch (Exception e) {
            log.error(String.format("failed to send email with template %s to %s", EmailMessageTemplate.REPORTS_BUNDLE_GENERATION_FINISHED_TEMPLATE.getTemplateCode(), email), e);
        }
    }


    private List<ReportOutputDocument> runReports(MultipleReportsGenerationButtonConfiguration configuration, String preferredName) {
        List<ReportOutputDocument> result = new ArrayList<>();
        final int reportsNumber = configuration.getParametersMaps().size();
        if (configuration.isUseDefaultTemplate()) {
            int reportsCounter = 1;
            for (Map<String, Object> parameters : configuration.getParametersMaps()) {
                log.info("started report generation {} of {} for bundle {}",reportsCounter,reportsNumber, preferredName);
                result.add(
                        reportRunner
                                .byReportCode(configuration.getReportCode())
                                .withParams(parameters)
                                .run()
                );
                log.info("ended report generation {} of {} for bundle {}",reportsCounter,reportsNumber, preferredName);
                reportsCounter++;
            }
        } else {
            int reportsCounter = 1;
            for (Map<String, Object> parameters : configuration.getParametersMaps()) {
                log.info("started report generation {} of {} for bundle {}",reportsCounter,reportsNumber, preferredName);
                result.add(
                        reportRunner
                                .byReportCode(configuration.getReportCode())
                                .withTemplateCode(configuration.getOnClickTemplateSelectionDelegate().apply(null))
                                .withParams(parameters)
                                .run()
                );
                log.info("ended report generation {} of {} for bundle {}",reportsCounter,reportsNumber, preferredName);
            }
        }
        return result;
    }
}
