package kz.eub.rm.util;

public class ExtractorCounter {
    int c = 0;
    public Object getWithCounterIncrease(Object[] objects) {
        return objects[c++];
    }
}
