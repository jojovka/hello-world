package kz.eub.rm.job;

import io.jmix.core.security.SystemAuthenticator;
import kz.eub.rm.service.ReportsBundleService;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("rm_ReportsBundleCleanJob")
public class ReportsBundleCleanJob implements Job {
    @Autowired
    private SystemAuthenticator systemAuthenticator;
    @Autowired
    private ReportsBundleService reportsBundleService;

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        systemAuthenticator.withSystem(() -> {
            reportsBundleService.removeAll();
            return null;
        });
    }
}
