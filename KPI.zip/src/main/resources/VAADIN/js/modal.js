

// Get the <span> element that closes the modal

// When the user clicks anywhere outside of the modal, close it


