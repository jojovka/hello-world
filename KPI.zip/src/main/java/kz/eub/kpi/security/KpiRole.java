package kz.eub.kpi.security;

import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import kz.eub.kpi.entity.Announce;
import kz.eub.kpi.entity.Application;
import kz.eub.kpi.entity.ApplicationComment;
import kz.eub.kpi.entity.ApplicationReviewResult;
import kz.eub.kpi.entity.ApplicationTask;
import kz.eub.kpi.entity.DictBusiness;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.DictPosition;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.EmployeeGroupType;
import kz.eub.kpi.entity.StaffApplication;
import kz.eub.kpi.entity.Unit;
import kz.eub.kpi.entity.User;
import kz.eub.kpi.entity.kpi.IntermediateAssessmentMeeting;
import kz.eub.kpi.entity.kpi.KpiApplication;
import kz.eub.kpi.entity.kpi.KpiCard;
import kz.eub.kpi.entity.kpi.KpiCompetence;
import kz.eub.kpi.entity.kpi.KpiEmplDevPlan;
import kz.eub.kpi.entity.kpi.KpiGoal;
import kz.eub.kpi.entity.kpi.KpiGoalAttachment;
import kz.eub.kpi.entity.kpi.KpiGoalComment;
import kz.eub.kpi.entity.kpi.KpiGoalDict;
import kz.eub.kpi.entity.kpi.KpiGoalDictFact;
import kz.eub.kpi.entity.kpi.KpiGoalDictPlan;
import kz.eub.kpi.entity.kpi.KpiGoalReviewResult;
import kz.eub.kpi.entity.kpi.KpiGoalSubCategory;
import kz.eub.kpi.entity.kpi.KpiPeriod;
import kz.eub.kpi.entity.kpi.KpiResult;
import kz.eub.kpi.entity.overtime.OrgChart;

@ResourceRole(name = "KPI", code = "kpi")
public interface KpiRole {
    @MenuPolicy(menuIds = {"kpi_CustomTaskScreen", "kpi_ApplicationBaseScreen", "kpi_KpiApplication.browse", "kpi_KpiMassiveApproval"})
    @ScreenPolicy(screenIds = {"kpi_KpiPeriod.browse", "kpi_KpiResult.browse", "kpi_KpiGoal.browse", "kpi_BlockGoals", "kpi_DepartmentTasks", "kpi_IndividualTasks", "kpi_Employee.browse", "kpi_DictPosition.browse", "kpi_DictDepartment.browse", "kpi_Unit.browse", "kpi_DictPosition.edit", "kpi_Employee.edit", "kpi_KpiPeriod.edit", "kpi_KpiResult.edit", "kpi_DictDepartment.edit", "buscal_AdditionalBusinessDayEdit.edit", "buscal_BusinessCalendarModel.browse", "buscal_BusinessCalendarModel.edit", "buscal_BusinessDayModel.edit", "buscal_HolidayModel.edit", "kpi_KpiGoal.edit", "kpi_KpiCompetence.browse", "kpi_KpiCompetence.edit", "kpi_Unit.edit", "kpi_KpiEmplDevPlan.browse", "kpi_KpiEmplDevPlan.edit", "kpi_IntermediateAssessmentMeeting.browse", "kpi_IntermediateAssessmentMeeting.edit", "kpi_KpiCard.edit", "kpi_KpiCard.view", "kpi_CustomTaskScreen", "kpi_BpmTaskHistoryFragment", "kpi_BpmTaskFragment", "kpi_Application.browse", "kpi_ApplicationTask.browse", "kpi_ApplicationBaseScreen", "kpi_KpiCard.hr", "kpi_KpiGoalAttachment.edit", "kpi_KpiCard.review", "kpi_KpiApplication.browse", "kpi_KpiGoalReviewResult.edit", "kpi_BankGoals", "kpi_KpiCard.browse", "kpi_KpiGoalComment.edit", "kpi_ApplicationComment.edit", "kpi_Employee.view", "kpi_KpiGoal.fact", "kpi_KpiMassiveApproval", "kpi_KpiGoalDict.browse", "kpi_KpiGoalSubCategory.browse", "kpi_KpiGoalDictPlan.browse", "kpi_DictDepartment.lookup", "kpi_DictBusiness.browse"})
    void screens();

    @EntityAttributePolicy(entityClass = Application.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = Application.class, actions = {EntityPolicyAction.CREATE, EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void application();

    @EntityAttributePolicy(entityClass = DictDepartment.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = DictDepartment.class, actions = EntityPolicyAction.READ)
    void dictDepartment();

    @EntityAttributePolicy(entityClass = DictPosition.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DictPosition.class, actions = EntityPolicyAction.ALL)
    void dictPosition();

    @EntityAttributePolicy(entityClass = Employee.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = Employee.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void employee();

    @EntityAttributePolicy(entityClass = KpiGoal.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = KpiGoal.class, actions = EntityPolicyAction.ALL)
    void kpiGoal();

    @EntityAttributePolicy(entityClass = KpiPeriod.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = KpiPeriod.class, actions = EntityPolicyAction.ALL)
    void kpiPeriod();

    @EntityAttributePolicy(entityClass = KpiResult.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = KpiResult.class, actions = EntityPolicyAction.ALL)
    void kpiResult();

    @EntityAttributePolicy(entityClass = Unit.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = Unit.class, actions = EntityPolicyAction.READ)
    void unit();

    @EntityPolicy(entityClass = User.class, actions = EntityPolicyAction.READ)
    @EntityAttributePolicy(entityClass = User.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    void user();

    @EntityAttributePolicy(entityClass = KpiEmplDevPlan.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = KpiEmplDevPlan.class, actions = EntityPolicyAction.ALL)
    void kpiEmplDevPlan();

    @EntityAttributePolicy(entityClass = KpiCompetence.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = KpiCompetence.class, actions = EntityPolicyAction.ALL)
    void kpiCompetence();

    @EntityAttributePolicy(entityClass = IntermediateAssessmentMeeting.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = IntermediateAssessmentMeeting.class, actions = EntityPolicyAction.ALL)
    void intermediateAssessmentMeeting();

    @EntityAttributePolicy(entityClass = KpiCard.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = KpiCard.class, actions = EntityPolicyAction.ALL)
    void kpiCard();

    @EntityAttributePolicy(entityClass = StaffApplication.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = StaffApplication.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE, EntityPolicyAction.CREATE})
    void staffApplication();

    @EntityAttributePolicy(entityClass = KpiApplication.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = KpiApplication.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE, EntityPolicyAction.CREATE})
    void kpiApplication();

    @EntityAttributePolicy(entityClass = EmployeeGroupType.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = EmployeeGroupType.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE, EntityPolicyAction.CREATE})
    void employeeGroupType();

    @EntityAttributePolicy(entityClass = KpiGoalAttachment.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = KpiGoalAttachment.class, actions = EntityPolicyAction.ALL)
    void kpiGoalAttachment();

    @EntityAttributePolicy(entityClass = OrgChart.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = OrgChart.class, actions = EntityPolicyAction.ALL)
    void orgChart();

    @EntityAttributePolicy(entityClass = ApplicationReviewResult.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = ApplicationReviewResult.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE, EntityPolicyAction.CREATE})
    void applicationReviewResult();

    @EntityAttributePolicy(entityClass = KpiGoalReviewResult.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = KpiGoalReviewResult.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE, EntityPolicyAction.CREATE})
    void kpiGoalReviewResult();

    @EntityAttributePolicy(entityClass = KpiGoalComment.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = KpiGoalComment.class, actions = EntityPolicyAction.ALL)
    void kpiGoalComment();

    @EntityAttributePolicy(entityClass = ApplicationComment.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = ApplicationComment.class, actions = EntityPolicyAction.ALL)
    void applicationComment();

    @EntityAttributePolicy(entityClass = ApplicationTask.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = ApplicationTask.class, actions = EntityPolicyAction.ALL)
    void applicationTask();

    @EntityAttributePolicy(entityClass = KpiGoalSubCategory.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = KpiGoalSubCategory.class, actions = EntityPolicyAction.READ)
    void kpiGoalSubCategory();

    @EntityAttributePolicy(entityClass = KpiGoalDict.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = KpiGoalDict.class, actions = EntityPolicyAction.READ)
    void kpiFdGoalDict();

    @EntityAttributePolicy(entityClass = KpiGoalDictFact.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    void kpiGoalDictFact();

    @EntityAttributePolicy(entityClass = KpiGoalDictPlan.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = KpiGoalDictPlan.class, actions = EntityPolicyAction.READ)
    void kpiGoalDictPlan();

    @EntityAttributePolicy(entityClass = DictBusiness.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = DictBusiness.class, actions = EntityPolicyAction.READ)
    void dictBusiness();

    @EntityAttributePolicy(entityClass = Announce.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = Announce.class, actions = EntityPolicyAction.READ)
    void announce();
}