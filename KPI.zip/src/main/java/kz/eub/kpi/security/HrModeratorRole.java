package kz.eub.kpi.security;

import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import kz.eub.kpi.entity.Announce;

@ResourceRole(name = "HR Moderator", code = HrModeratorRole.CODE, description = "Модератор HR")
public interface HrModeratorRole {

    public static final String CODE = "hr-moderator";

    @MenuPolicy(menuIds = {"kpi_Application.browse", "kpi_OvertimeApplication.browse", "kpi_KpiCard.browse", "kpi_BankGoals", "kpi_Employee.browse", "kpi_DictDepartment.browse", "kpi_DictPosition.browse", "kpi_Unit.browse", "buscal_BusinessCalendarModel.browse", "kpi_KpiPeriod.browse", "kpi_KpiResult.browse", "kpi_KpiGoal.browse", "kpi_BlockGoals", "kpi_DepartmentTasks", "kpi_IndividualTasks", "kpi_KpiCompetence.browse", "kpi_KpiEmplDevPlan.browse", "kpi_IntermediateAssessmentMeeting.browse", "kpi_Employee.roles", "kpi_Announce.browse"})
    @ScreenPolicy(screenIds = {"kpi_Application.browse", "kpi_OvertimeApplication.browse", "kpi_KpiCard.browse", "kpi_BankGoals", "kpi_Employee.browse", "kpi_DictDepartment.browse", "kpi_DictPosition.browse", "kpi_Unit.browse", "buscal_BusinessCalendarModel.browse", "kpi_KpiPeriod.browse", "kpi_KpiResult.browse", "kpi_KpiGoal.browse", "kpi_BlockGoals", "kpi_DepartmentTasks", "kpi_IndividualTasks", "kpi_KpiCompetence.browse", "kpi_KpiEmplDevPlan.browse", "kpi_IntermediateAssessmentMeeting.browse", "kpi_Employee.roles", "kpi_Announce.browse", "kpi_Announce.edit"})
    void screens();

    @EntityAttributePolicy(entityClass = Announce.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = Announce.class, actions = EntityPolicyAction.ALL)
    void announce();
}