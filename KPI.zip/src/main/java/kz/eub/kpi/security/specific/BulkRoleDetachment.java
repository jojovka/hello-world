package kz.eub.kpi.security.specific;

import io.jmix.core.accesscontext.SpecificOperationAccessContext;

public class BulkRoleDetachment extends SpecificOperationAccessContext {

    public static final String NAME = "bulkRoleDetachment";

    public BulkRoleDetachment() {
        super(NAME);
    }
}
