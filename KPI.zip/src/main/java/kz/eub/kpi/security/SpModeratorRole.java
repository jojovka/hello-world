package kz.eub.kpi.security;

import io.jmix.security.role.annotation.ResourceRole;

@ResourceRole(name = "SP Moderator", code = SpModeratorRole.CODE, description = "Модератор Стратегического Планирования")
public interface SpModeratorRole {

    public static final String CODE = "sp-moderator";

}