package kz.eub.kpi.security;

import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.security.role.annotation.SpecificPolicy;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.kpi.KpiApplication;
import kz.eub.kpi.entity.kpi.KpiGoal;
import kz.eub.kpi.entity.kpi.KpiGoalDict;
import kz.eub.kpi.entity.kpi.KpiGoalDictFact;
import kz.eub.kpi.entity.kpi.KpiGoalDictPlan;
import kz.eub.kpi.entity.kpi.KpiGoalFactImportDoc;
import kz.eub.kpi.entity.kpi.KpiGoalPlanImportDoc;
import kz.eub.kpi.entity.kpi.KpiGoalSubCategory;
import kz.eub.kpi.entity.kpi.KpiPeriod;

@ResourceRole(name = "FdHead", code = "fd-head")
public interface FdHeadRole {
    @EntityAttributePolicy(entityClass = KpiGoal.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = KpiGoal.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void kpiGoal();

    @EntityAttributePolicy(entityClass = KpiGoalDict.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = KpiGoalDict.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void kpiGoalDict();

    @EntityAttributePolicy(entityClass = KpiGoalDictFact.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = KpiGoalDictFact.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void kpiGoalDictFact();

    @EntityAttributePolicy(entityClass = KpiGoalFactImportDoc.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = KpiGoalFactImportDoc.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void kpiGoalFactImportDoc();

    @EntityAttributePolicy(entityClass = KpiGoalSubCategory.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = KpiGoalSubCategory.class, actions = EntityPolicyAction.READ)
    void kpiGoalSubCategory();

    @EntityAttributePolicy(entityClass = KpiPeriod.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = KpiPeriod.class, actions = EntityPolicyAction.READ)
    void kpiPeriod();

    @EntityAttributePolicy(entityClass = KpiApplication.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    void kpiApplication();

    @SpecificPolicy(resources = "FdFactImport")
    void specific();

    @EntityAttributePolicy(entityClass = Employee.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    void employee();

    @MenuPolicy(menuIds = {"kpi_KpiGoalFactImport.browse", "kpi_KpiGoalPlanImportDoc.browse"})
    @ScreenPolicy(screenIds = {"kpi_KpiGoalFactImport.browse", "kpi_KpiGoalFactImport.edit", "kpi_KpiGoalDictFact.edit", "kpi_KpiGoalPlanImportDoc.browse", "kpi_KpiGoalPlanImportDoc.edit", "kpi_KpiGoalDictPlan.edit"})
    void screens();

    @EntityAttributePolicy(entityClass = KpiGoalPlanImportDoc.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = KpiGoalPlanImportDoc.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void kpiGoalPlanImportDoc();

    @EntityAttributePolicy(entityClass = KpiGoalDictPlan.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = KpiGoalDictPlan.class, actions = {EntityPolicyAction.UPDATE, EntityPolicyAction.READ})
    void kpiGoalDictPlan();
}