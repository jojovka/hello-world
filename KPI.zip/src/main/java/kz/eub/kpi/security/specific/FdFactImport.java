package kz.eub.kpi.security.specific;

import io.jmix.core.accesscontext.SpecificOperationAccessContext;

public class FdFactImport extends SpecificOperationAccessContext {

    public static final String NAME = "FdFactImport";

    public FdFactImport() {
        super(NAME);
    }
}
