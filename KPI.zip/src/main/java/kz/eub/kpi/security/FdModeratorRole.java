package kz.eub.kpi.security;

import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import kz.eub.kpi.entity.kpi.KpiGoal;
import kz.eub.kpi.entity.kpi.KpiGoalDict;
import kz.eub.kpi.entity.kpi.KpiGoalDictFact;
import kz.eub.kpi.entity.kpi.KpiGoalDictPlan;
import kz.eub.kpi.entity.kpi.KpiGoalFactImportDoc;
import kz.eub.kpi.entity.kpi.KpiGoalPlanImportDoc;
import kz.eub.kpi.entity.kpi.KpiGoalSubCategory;

@ResourceRole(name = "FD Moderator", code = FdModeratorRole.CODE, description = "Модератор ФД")
public interface FdModeratorRole {

    public static final String CODE = "fd-moderator";

    @EntityAttributePolicy(entityClass = KpiGoalDict.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = KpiGoalDict.class, actions = EntityPolicyAction.ALL)
    void kpiGoalDict();

    @EntityAttributePolicy(entityClass = KpiGoalDictFact.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = KpiGoalDictFact.class, actions = EntityPolicyAction.ALL)
    void kpiGoalDictFact();

    @EntityAttributePolicy(entityClass = KpiGoalFactImportDoc.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = KpiGoalFactImportDoc.class, actions = EntityPolicyAction.ALL)
    void kpiGoalFactImportDoc();

    @EntityAttributePolicy(entityClass = KpiGoal.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = KpiGoal.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void kpiGoal();

    @EntityAttributePolicy(entityClass = KpiGoalSubCategory.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = KpiGoalSubCategory.class, actions = EntityPolicyAction.ALL)
    void kpiGoalSubCategory();

    @MenuPolicy(menuIds = {"kpi_KpiGoalDict.browse", "kpi_KpiGoalFactImport.browse", "kpi_KpiGoalSubCategory.browse", "kpi_KpiGoalPlanImportDoc.browse"})
    @ScreenPolicy(screenIds = {"kpi_KpiGoalDict.browse", "kpi_KpiGoalFactImport.browse", "kpi_KpiGoalSubCategory.browse", "kpi_KpiGoalFactImport.edit", "kpi_KpiGoalDictFact.edit", "kpi_KpiGoalDict.edit", "kpi_KpiGoalSubCategory.edit", "kpi_KpiGoalPlanImportDoc.browse", "kpi_KpiGoalPlanImportDoc.edit", "kpi_KpiGoalDictPlan.edit"})
    void screens();

    @EntityAttributePolicy(entityClass = KpiGoalPlanImportDoc.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = KpiGoalPlanImportDoc.class, actions = EntityPolicyAction.ALL)
    void kpiGoalPlanImportDoc();

    @EntityAttributePolicy(entityClass = KpiGoalDictPlan.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = KpiGoalDictPlan.class, actions = EntityPolicyAction.ALL)
    void kpiGoalDictPlan();
}