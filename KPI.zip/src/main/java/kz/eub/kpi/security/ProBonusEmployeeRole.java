package kz.eub.kpi.security;

import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import kz.eub.kpi.entity.AccountCustomStorage;
import kz.eub.kpi.entity.AccountCustomStorageValue;
import kz.eub.kpi.entity.AccountProfiles;
import kz.eub.kpi.entity.AccountVisits;
import kz.eub.kpi.entity.Accounts;
import kz.eub.kpi.entity.Award;
import kz.eub.kpi.entity.AwardType;
import kz.eub.kpi.entity.AwardUser;
import kz.eub.kpi.entity.BonusAuthority;
import kz.eub.kpi.entity.BonusAward;
import kz.eub.kpi.entity.BonusReport;
import kz.eub.kpi.entity.Competition;
import kz.eub.kpi.entity.Contracts;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.DictJobTitle;
import kz.eub.kpi.entity.DictPosition;
import kz.eub.kpi.entity.Duel;
import kz.eub.kpi.entity.DuelContest;
import kz.eub.kpi.entity.DuelQuestion;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.PointType;
import kz.eub.kpi.entity.PointUser;
import kz.eub.kpi.entity.QuestionAnswer;
import kz.eub.kpi.entity.RatingUser;
import kz.eub.kpi.entity.User;
import kz.eub.kpi.entity.analyze.DictBranch;

@ResourceRole(name = "ProBonusEmployee", code = "pro-bonus-employee")
public interface ProBonusEmployeeRole {

    @EntityAttributePolicy(entityClass = AccountCustomStorage.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = AccountCustomStorage.class, actions = EntityPolicyAction.ALL)
    void accountCustomStorage();

    @EntityAttributePolicy(entityClass = AccountCustomStorageValue.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = AccountCustomStorageValue.class, actions = EntityPolicyAction.ALL)
    void accountCustomStorageValue();

    @EntityAttributePolicy(entityClass = AccountProfiles.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = AccountProfiles.class, actions = EntityPolicyAction.ALL)
    void accountProfiles();

    @EntityAttributePolicy(entityClass = AccountVisits.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = AccountVisits.class, actions = EntityPolicyAction.ALL)
    void accountVisits();

    @EntityAttributePolicy(entityClass = Accounts.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = Accounts.class, actions = EntityPolicyAction.ALL)
    void accounts();

    @EntityAttributePolicy(entityClass = Award.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = Award.class, actions = EntityPolicyAction.ALL)
    void award();

    @EntityAttributePolicy(entityClass = AwardType.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = AwardType.class, actions = EntityPolicyAction.ALL)
    void awardType();

    @EntityAttributePolicy(entityClass = AwardUser.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = AwardUser.class, actions = EntityPolicyAction.ALL)
    void awardUser();

    @EntityAttributePolicy(entityClass = BonusAward.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = BonusAward.class, actions = EntityPolicyAction.ALL)
    void bonusAward();

    @EntityAttributePolicy(entityClass = BonusReport.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = BonusReport.class, actions = EntityPolicyAction.ALL)
    void bonusReport();

    @EntityAttributePolicy(entityClass = Competition.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = Competition.class, actions = EntityPolicyAction.ALL)
    void competition();

    @EntityAttributePolicy(entityClass = Contracts.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = Contracts.class, actions = EntityPolicyAction.ALL)
    void contracts();

    @EntityAttributePolicy(entityClass = DuelContest.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DuelContest.class, actions = EntityPolicyAction.ALL)
    void duelContest();

    @EntityAttributePolicy(entityClass = DuelQuestion.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DuelQuestion.class, actions = EntityPolicyAction.ALL)
    void duelQuestion();

    @EntityAttributePolicy(entityClass = PointType.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = PointType.class, actions = EntityPolicyAction.ALL)
    void pointType();

    @EntityAttributePolicy(entityClass = PointUser.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = PointUser.class, actions = EntityPolicyAction.ALL)
    void pointUser();

    @EntityAttributePolicy(entityClass = RatingUser.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = RatingUser.class, actions = EntityPolicyAction.ALL)
    void ratingUser();

    @EntityAttributePolicy(entityClass = DictBranch.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = DictBranch.class, actions = EntityPolicyAction.READ)
    void dictBranch();

    @EntityAttributePolicy(entityClass = DictDepartment.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = DictDepartment.class, actions = EntityPolicyAction.READ)
    void dictDepartment();

    @EntityAttributePolicy(entityClass = DictJobTitle.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = DictJobTitle.class, actions = EntityPolicyAction.READ)
    void dictJobTitle();

    @EntityAttributePolicy(entityClass = DictPosition.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = DictPosition.class, actions = EntityPolicyAction.READ)
    void dictPosition();

    @EntityAttributePolicy(entityClass = Duel.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = Duel.class, actions = EntityPolicyAction.ALL)
    void duel();

    @EntityAttributePolicy(entityClass = Employee.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = Employee.class, actions = EntityPolicyAction.READ)
    void employee();

    @EntityAttributePolicy(entityClass = QuestionAnswer.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = QuestionAnswer.class, actions = EntityPolicyAction.ALL)
    void questionAnswer();

    @EntityAttributePolicy(entityClass = User.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = User.class, actions = EntityPolicyAction.READ)
    void user();

    @EntityAttributePolicy(entityClass = BonusAuthority.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = BonusAuthority.class, actions = EntityPolicyAction.ALL)
    void bonusAuthority();

    @MenuPolicy(menuIds = {"bonus_administration_BonusProfileScreen", "bonus_KnowledgeScreen", "bonus_TutorialScreen", "dshbrd_HorizontalLayout.browse"})
    @ScreenPolicy(screenIds = {"bonus_administration_BonusProfileScreen", "bonus_KnowledgeScreen", "bonus_TutorialScreen", "dshbrd_HorizontalLayout.browse", "kpi_AccountProfiles.browse", "kpi_Accounts.browse", "kpi_Accounts.edit", "authorityAuthorityscreen", "kpi_Award.edit", "kpi_AwardType.browse", "kpi_AwardType.edit", "kpi_BonusAuthority.browse", "kpi_BonusAuthority.edit", "kpi_BonusAward.edit", "kpi_BonusAward.browse", "kpi_BonusBonusDescription", "kpi_BonusDescriptionOpzp", "kpi_BonusDescriptionPos", "kpi_BonusDescriptionVfk", "kpi_bonus_report.edit", "kpi_BonusReportDashboard", "kpi_CompetitionCreate", "kpi_CompetitionEditor", "kpi_CompetitionView", "kpi_Contracts.browse", "kpi_DuelContest", "kpi_DuelContestWithOpponent", "kpi_DuelCreate", "kpi_DuelEdit", "kpi_PointUser.browse", "kpi_PointUser.edit", "bonus_TournamentScreen", "bonus_Administration.browse"})
    void screens();
}