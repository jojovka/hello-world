package kz.eub.kpi.app.service;

import io.jmix.bpm.entity.TaskData;
import io.jmix.bpm.util.FlowableEntitiesConverter;
import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import kz.eub.kpi.entity.Application;
import kz.eub.kpi.entity.ApplicationTask;
import org.flowable.engine.HistoryService;
import org.flowable.engine.TaskService;
import org.flowable.task.api.Task;
import org.flowable.task.api.history.HistoricTaskInstance;
import org.flowable.variable.api.history.HistoricVariableInstance;
import org.flowable.variable.api.persistence.entity.VariableInstance;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

@Service("kpi_BpmUserTaskService")
public class BpmUserTaskService {

    @Autowired
    private TaskService taskService;
    @Autowired
    private FlowableEntitiesConverter flowableEntitiesConverter;

    @Autowired
    private HistoryService historyService;
    @Autowired
    private DataManager dataManager;

    public List<Task> getUserActiveTasksByProcId(String processInstanceId, String username) {
        return taskService.createTaskQuery()
                .processInstanceId(processInstanceId)
                .taskAssignee(username)
                .active()
                .orderByTaskCreateTime()
                .asc()
                .list();
    }

    public List<Task> getActiveTasksByProcId(String processInstanceId) {
        return taskService.createTaskQuery()
                .processInstanceId(processInstanceId)
                .orderByTaskCreateTime()
                .active()
                .asc()
                .list();
    }

    public List<HistoricTaskInstance> getHistoricTaskInstancesByProcId(String processInstanceId) {
        return historyService.createHistoricTaskInstanceQuery()
                .processInstanceId(processInstanceId)
                .orderByTaskCreateTime()
                .desc()
                .list();
    }

    public List<TaskData> getHistoricTaskDataListByProcId(String processInstanceId) {
        List<HistoricTaskInstance> historicTaskList = getHistoricTaskInstancesByProcId(processInstanceId);
        return getTaskDataListFromHistoricTaskList(historicTaskList);
    }


    public List<Task> getCurrentUserTasksByProcDefKey(String processInstanceDefKey, String businessKey, String username) {
        return taskService.createTaskQuery()
                .processDefinitionKey(processInstanceDefKey)
                .processInstanceBusinessKey(businessKey)
                .taskAssignee(username)
                .active()
                .orderByTaskCreateTime()
                .asc()
                .list();
    }

    public HistoricVariableInstance getHistoricVariableInstance(String processInstanceId, String variableName) {
        return historyService.createHistoricVariableInstanceQuery()
                .processInstanceId(processInstanceId)
                .variableName(variableName)
                .list().stream()
                .findFirst().orElse(null);
    }


    public VariableInstance getVariableInstance(@NotNull String taskId, String variableName) {
        return taskService.getVariableInstance(taskId, variableName);
    }

    public List<Application> getUserTaskApplications(String username) {
        List<Task> taskList = getUserActiveTasks(username);
        List<UUID> applicationIdList = getApplicationUuidList(taskList);
        return getApplicationList(applicationIdList);
    }

    public List<ApplicationTask> getUserApplicationTasks(String username) {
        List<Task> taskList = getUserActiveTasks(username);
        return taskList.stream()
                .map(task -> flowableEntitiesConverter.createTaskData(task))
                .filter(Objects::nonNull)
                .map(this::createApplicationTask)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    private ApplicationTask createApplicationTask(TaskData taskData) {
        VariableInstance variableInstance = taskService.getVariableInstance(taskData.getId(), Application.BPM_VARIABLE_NAME);
        if (variableInstance == null
                || variableInstance.getValue() == null)
            return null;
        Application application = (Application) variableInstance.getValue();
        if (application == null)
            return null;
        ApplicationTask appTask = dataManager.create(ApplicationTask.class);
        appTask.setId(application.getId());
        appTask.setApplication(application);
        appTask.setTaskData(taskData);
        return appTask;
    }

    public List<Task> getUserActiveTasks(String username) {
        if (username == null) return new ArrayList<>();
        return taskService.createTaskQuery()
                .taskAssignee(username)
                .active()
                .orderByTaskCreateTime()
                .asc()
                .list();
    }

    public long getUserActiveTasksCount(String username) {
        return taskService.createTaskQuery()
                .taskAssignee(username)
                .active()
                .orderByTaskCreateTime()
                .asc()
                .count();
    }


    public List<Application> getUserApplicationHistoricTasks(String username) {
        List<HistoricTaskInstance> taskList = getUserHistoricTasks(username);
        List<UUID> applicationIdList = getHistoricApplicationUuidList(taskList);
        return getApplicationList(applicationIdList);
    }

    public List<UUID> getApplicationUuidList(List<Task> taskList) {
        return taskList.stream()
                .map(t -> taskService.getVariableInstance(t.getId(), Application.BPM_VARIABLE_NAME))
                .map(v -> v != null ? (Application)v.getValue() : null)
                .map(a -> a != null ? a.getId() : null)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    private List<UUID> getHistoricApplicationUuidList(List<HistoricTaskInstance> taskList) {
        return taskList.stream()
                .map(t -> historyService.createHistoricVariableInstanceQuery()
                        .processInstanceId(t.getProcessInstanceId())
                        .variableName(Application.BPM_VARIABLE_NAME)
                        .singleResult()
                )
                .map(v -> v != null ? (Application) v.getValue() : null)
                .map(a -> a != null ? a.getId() : null)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    public List<Application> getApplicationList(List<UUID> applicationIdList) {
        return dataManager.load(Application.class)
                .query("select c from kpi_Application c " +
                        "where c.id in :idList")
                .parameter("idList", applicationIdList)
                .fetchPlan(fpg -> fpg.addFetchPlan(FetchPlan.BASE)
                        .add("author", f -> f.addFetchPlan(FetchPlan.BASE)
                                .add("department", FetchPlan.BASE)))
                .list();
    }

    public List<HistoricTaskInstance> getUserHistoricTasks(String username) {
        return historyService.createHistoricTaskInstanceQuery()
                .taskAssignee(username)
                .finished()
                .orderByTaskCreateTime()
                .asc()
                .list();
    }

    private List<TaskData> getTaskDataListFromHistoricTaskList(List<HistoricTaskInstance> historicTaskList) {
        return historicTaskList.stream()
                .map(task -> flowableEntitiesConverter.createTaskData(task))
                .collect(Collectors.toList());
    }

    private List<TaskData> getTaskDataListFromTaskList(List<Task> taskList) {
        List<TaskData> taskDataList = taskList.stream().map(task -> flowableEntitiesConverter.createTaskData(task)).collect(Collectors.toList());
        return taskDataList;
    }

}