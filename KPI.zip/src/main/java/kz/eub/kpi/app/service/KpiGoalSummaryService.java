package kz.eub.kpi.app.service;

import kz.eub.kpi.app.bean.KpiGeneralUtils;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.kpi.EKpiGoalAssessmentType;
import kz.eub.kpi.entity.Unit;
import kz.eub.kpi.entity.kpi.EKpiGoalCategory;
import kz.eub.kpi.entity.kpi.KpiGoal;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.Objects;

@Component("kpi_KpiGoalSummaryService")
public class KpiGoalSummaryService {

    public static final int MIN_GOAL_THRESHOLD_GENERAL = 80;
    public static final int MAX_GOAL_THRESHOLD_GENERAL = 150;

    public static final int MIN_GOAL_THRESHOLD_BCB = 76;            // Требование БЦБ: мин.порог 76%

    @Autowired
    private KpiGeneralUtils kpiGeneralUtils;

    public KpiGoal calcPerformanceAndEfficiency(KpiGoal goal) {
        validateGoalForAssessment(goal);
        if (Objects.equals(goal.getCategory(), EKpiGoalCategory.GVK_GOAL)) {
            calcGvkGoalProgress(goal);
        } else {
            switch (goal.getUnit().getId()) {
                case Unit.UNIT_WDAY:
                    calcWdayProgress(goal);
                    break;
                case Unit.UNIT_PERCENT:
                case Unit.UNIT_PCS:
                default:
                    calcQuantitativeProgress(goal);
            }
        }
        return goal;
    }

    private KpiGoal calcGvkGoalProgress(KpiGoal goal) {
        calcProgressForGvkGoal(goal);
        BigDecimal progress = validateGoalMinThreshold(goal);
        progress = progress.min(new BigDecimal(MAX_GOAL_THRESHOLD_GENERAL));
        calcGoalEfficiency(goal, progress);
        return goal;
    }

    /**
     * В соответствии с решением Правления №137-03 от 12.09.2022г. были утверждены изменения
     * в формуле расчета процента выполнения целевого показателя «Голос внутреннего клиента».
     * Минимальное значение целевого показателя – 3,8 баллов.
     *
     * Оценка индекса удовлетворенности будет производиться по следующей шкале:
     * --------------------------------------
     * |  Индекс сервиса  |   % Выполнения  |
     * |------------------|-----------------|
     * |       3.8	      |       80%       |
     * |       3.9	      |       90%       |
     * |       4.0	      |       100%      |
     * |       4.1	      |       105%      |
     * |       4.2	      |       110%      |
     * |       4.3	      |       115%      |
     * |       4.4	      |       120%      |
     * |       4.5	      |       125%      |
     * |       4.6	      |       130%      |
     * |       4.7	      |       135%      |
     * |       4.8	      |       140%      |
     * |       4.9	      |       145%      |
     * |       5.0	      |       150%      |
     * --------------------------------------
     */
    private KpiGoal calcProgressForGvkGoal(KpiGoal goal) {
        if (goal.getPlan() == null
                || goal.getPlan().equals(BigDecimal.ZERO))
            return goal;
        final BigDecimal THREE = new BigDecimal(3);
        final BigDecimal FOUR = new BigDecimal(4);
        final BigDecimal HUNDRED = new BigDecimal(100);

        if (goal.getFact().compareTo(FOUR) <= 0) {
            BigDecimal progress = goal.getFact().subtract(THREE)
                    .multiply(HUNDRED);
            if (progress.compareTo(new BigDecimal(80)) < 0)
                progress = BigDecimal.ZERO;
            goal.setProgress(progress);
        } else {
            BigDecimal progress = goal.getFact().subtract(FOUR)
                    .multiply(HUNDRED)
                    .divide(new BigDecimal(2), 2, RoundingMode.HALF_EVEN)
                    .add(HUNDRED);
            if (progress.compareTo(new BigDecimal(150)) > 0)
                progress = new BigDecimal(150);
            goal.setProgress(progress);
        }
        return goal;
    }


    /**
     * @Efficiency
     * Excel: =ЕСЛИ( J7<80%; 0;
     *            ЕСЛИ( J7>=150%; 150%; J7 ))
     */
    private KpiGoal calcQuantitativeProgress(KpiGoal goal) {
        calcProgressByDefault(goal);
        BigDecimal progress = validateGoalMinThreshold(goal);
        progress = progress.min(new BigDecimal(MAX_GOAL_THRESHOLD_GENERAL));
        calcGoalEfficiency(goal, progress);
        return goal;
    }

    /**
     * Реализовать стандартные расчеты по умолчанию если для Ед.измерения не реализован конкретный расчет
     * Больше лучше: Исполнение = Факт / План
     * Меньше лучше: Исполнение = План / Факт
     * Равно: Исполнение = (План == Факт) ? 100 : 0;
     * @param goal
     */
    private KpiGoal calcProgressByDefault(KpiGoal goal) {
        if (goal.getAssessmentType().equals(EKpiGoalAssessmentType.MORE_IS_BETTER)) {
            if (goal.getPlan() != null
                    && !goal.getPlan().equals(BigDecimal.ZERO)) {
                BigDecimal progress = goal.getFact()
                        .divide(goal.getPlan(), 2, RoundingMode.HALF_EVEN)
                        .multiply(new BigDecimal(100));
                goal.setProgress(progress);
            }
        } else if (goal.getAssessmentType().equals(EKpiGoalAssessmentType.LESS_IS_BETTER)) {
            if (goal.getFact() != null) {
                BigDecimal progress;
                if (goal.getFact().compareTo(BigDecimal.ZERO) == 0) {
                    progress = new BigDecimal(150);
                    if (Objects.equals(goal.getCategory(), EKpiGoalCategory.FINANCIAL_GOAL))
                        progress = new BigDecimal(100);
                } else {
                    progress = goal.getPlan()
                            .divide(goal.getFact(), 2, RoundingMode.HALF_EVEN)
                            .multiply(new BigDecimal(100));
                }
                goal.setProgress(progress);
            }
        } else if (goal.getAssessmentType().equals(EKpiGoalAssessmentType.EQUALS)) {
            BigDecimal progress = BigDecimal.ZERO;
            if (goal.getPlan() != null
                    && goal.getFact() != null
                    && goal.getPlan().compareTo(goal.getFact()) == 0)
                progress = new BigDecimal(100);
            goal.setProgress(progress);
        }
        return goal;
    }

    @NotNull
    private BigDecimal validateGoalMinThreshold(KpiGoal goal) {
        BigDecimal progress = goal.getProgress();
        int minThreshold = MIN_GOAL_THRESHOLD_GENERAL;
        String bcbInfo = "";
        if (isBcbEmployeeGoal(goal)) {
            minThreshold = MIN_GOAL_THRESHOLD_BCB;
            bcbInfo = "для сотрудников БЦБ ";
        }
        if (progress.compareTo(new BigDecimal(minThreshold)) < 0) {
            String info = (goal.getInfo() != null) ? goal.getInfo() + " | " : "";
            info += String.format("Минимальный порог %s\"Результативности\" %d%%", bcbInfo, minThreshold);
            goal.setInfo(info);
            progress = BigDecimal.ZERO;
        }
        return progress;
    }

    /**
     *   @Progress
     *   (QuarterTotalDaysCount - (QuarterEndDate - PlanDate)) / (FactDate + 1 - QuarterStartDate)
     *   Excel: = ( (ДАТА(2022;7;1) - ДАТА(2022;4;1)) - (ДАТА(2022;6;30) - H13) ) / (I13 + 1 - ДАТА(2022;4;1))
     *
     *   @Efficiency
     *   Excel = ЕСЛИ( 100% - J13 <= 20%; J13;
     *              ЕСЛИ( 100% - J13 <= 30%; J13 * 50%;
     *                  ЕСЛИ( 100% - J13 < 70%; J13 * 0%)))
     */
    private KpiGoal calcWdayProgress(KpiGoal goal) {
        Date qs = kpiGeneralUtils.getQuarterStartDate(goal.getPeriod().getQuarter(), goal.getPeriod().getYear());
        Date qe = kpiGeneralUtils.getQuarterEndDate(goal.getPeriod().getQuarter(), goal.getPeriod().getYear());
        long quarterDays = kpiGeneralUtils.calcAgeInDays(qs, qe)+1;
        long qremain = kpiGeneralUtils.calcAgeInDays(goal.getPlanDate(), qe);
        long factDays = kpiGeneralUtils.calcAgeInDays(qs, goal.getFactDate())+1;

        BigDecimal dividend = new BigDecimal(quarterDays - qremain);
        BigDecimal divisor = new BigDecimal(factDays);
        BigDecimal progress = dividend.divide(divisor, 2, RoundingMode.HALF_EVEN)
                .multiply(new BigDecimal(100));
        progress = progress.min(new BigDecimal(MAX_GOAL_THRESHOLD_GENERAL));
        goal.setProgress(progress);

        if (isBcbEmployeeGoal(goal)) {
            if (progress.compareTo(new BigDecimal(MIN_GOAL_THRESHOLD_BCB)) < 0)
                progress = BigDecimal.ZERO;
        } else {
            // Понижающий коэффициент при отклонении от срока на <= 20% то 1
            if (progress.compareTo(new BigDecimal(80)) < 0
                    && progress.compareTo(new BigDecimal(70)) >= 0)         // <= 30% то 0.5
                progress = progress.multiply(new BigDecimal("0.5"));
            else if (progress.compareTo(new BigDecimal(70)) < 0)                 // > 30% то 0
                progress = BigDecimal.ZERO;
        }
        calcGoalEfficiency(goal, progress);
        return goal;
    }

    private void calcGoalEfficiency(KpiGoal goal, BigDecimal progress) {
        BigDecimal efficiency = BigDecimal.ZERO;
        if (goal.getProgress() != null && goal.getWeight() != null) {
            efficiency = progress.multiply(goal.getWeight())
                    .divide(new BigDecimal(100), 2, RoundingMode.HALF_EVEN);
        }
        goal.setEfficiency(efficiency);
    }

    /**
     * Относится ли цель к сотруднику "БЦБ"
     */
    private boolean isBcbEmployeeGoal(KpiGoal goal) {
        if (goal.getKpiCard() == null || goal.getKpiCard().getDepartment() == null)
            return false;
        return goal.getKpiCard().getDepartment().isEqualOrChildOfParentSapId(DictDepartment.BCB_SAP_ID);
    }


    private void validateGoalForAssessment(KpiGoal goal) {
        if (goal.getPlan() == null && goal.getPlanDate() == null)
            throw new IllegalArgumentException("План не указан");
        if (goal.getFact() == null && goal.getFactDate() == null)
            throw new IllegalArgumentException("Фактический показатель не указан");

        if (goal.getUnit() == null)
            throw new IllegalArgumentException("Единица измерения не указана");

        if (goal.getUnit().getId().equals(Unit.UNIT_WDAY)
                && goal.getPlanDate() == null
                && goal.getFactDate() == null)
            throw new IllegalArgumentException("План или факт даты не указаны...");

        if (!goal.getUnit().getId().equals(Unit.UNIT_WDAY)
                && goal.getPlan() == null
                && goal.getFact() == null)
            throw new IllegalArgumentException("План или фактический показатель не указаны...");

        if (!goal.getUnit().getId().equals(Unit.UNIT_WDAY)
                && goal.getAssessmentType() == null)
            throw new IllegalArgumentException("Признак оценки не указан");
    }

}