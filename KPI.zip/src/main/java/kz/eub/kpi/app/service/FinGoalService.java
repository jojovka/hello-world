package kz.eub.kpi.app.service;

import io.jmix.email.EmailException;
import io.jmix.emailtemplates.EmailTemplates;
import io.jmix.emailtemplates.exception.ReportParameterTypeChangedException;
import io.jmix.emailtemplates.exception.TemplateNotFoundException;
import kz.eub.kpi.entity.Application;
import kz.eub.kpi.entity.EApplicationStatus;
import kz.eub.kpi.entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component("finGoalService")
public class FinGoalService {

    @Autowired
    private EmployeeSecService employeeSecService;
    @Autowired
    private EmailTemplates emailTemplates;

    public void sendApproversNotification(Application doc, String link) throws TemplateNotFoundException {
        if (!doc.getStatus().equals(EApplicationStatus.NEW)) return;
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("application", doc);
            params.put("link", link);
            SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy");
            params.put("date", df.format(doc.getDate()));
            List<Employee> employees = employeeSecService.loadEmployeesHavingRole("fd-head");
            String recipients = employees.stream().distinct()
                    .map(Employee::getEmail)
                    .reduce("", (res, email) -> {
                        if (res.length() > 0) res += ", ";
                        return res + email;
                    });
            emailTemplates.buildFromTemplate("fin-goal-approval-notification")
                    .setBodyParameters(params)
                    .setTo(recipients)
                    .sendEmail();
        } catch (ReportParameterTypeChangedException | EmailException e) {
            throw new RuntimeException("Ошибка при попытке отправить уведомление", e);
        }
    }

}
