package kz.eub.kpi.app.service;

import com.google.common.base.Strings;
import io.jmix.bpm.data.outcome.Outcome;
import io.jmix.bpm.data.outcome.OutcomesContainer;
import io.jmix.bpm.entity.TaskData;
import io.jmix.core.Messages;
import io.jmix.reports.entity.ReportOutputType;
import io.jmix.reportsui.runner.ParametersDialogShowMode;
import io.jmix.reportsui.runner.UiReportRunner;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.kpi.KpiCard;
import kz.eub.kpi.entity.kpi.KpiPeriod;
import org.flowable.variable.api.history.HistoricVariableInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

@Component("kpi_KpiGoalExportService")
public class KpiGoalExportService {

    public static final Logger log = LoggerFactory.getLogger(KpiGoalExportService.class);

    public static final String BPM_HISTORY_TASK_MSG_PACK = "kz.eub.kpi.screen.bpm.bpmtaskhistoryfragment";

    @Autowired
    private BpmUserTaskService bpmUserTaskService;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private Messages messages;

    @Autowired
    private ObjectProvider<UiReportRunner> uiReportRunner;



    public void exportKpiGoals(List<KpiCard> kpiCards) {
        for (KpiCard card : kpiCards) {
            fillApprovalsToInfoField(card);
        }
        KpiCard card = kpiCards.stream().findFirst().orElse(null);
        if (card == null) return;
        KpiPeriod period = card.getPeriod();
        uiReportRunner.getIfAvailable().byReportCode(KpiCard.REP_EXPORT_KPI_CARDS_LIST_CODE)
                .withOutputType(ReportOutputType.XLSX)
                .withParametersDialogShowMode(ParametersDialogShowMode.NO)
                .addParam("year", period.getYear())
                .addParam("quarter", period.getQuarter())
                .addParam("kpiCards", kpiCards)
                .runAndShow();
    }

    public void fillApprovalsToInfoField(KpiCard card) {
        if (card.getProcId() == null) return;
        List<TaskData> taskDataList = bpmUserTaskService.getHistoricTaskDataListByProcId(card.getProcId());
        taskDataList = taskDataList.stream()
                .filter(t -> t != null && t.getEndTime() != null)
                .sorted(Comparator.comparing(TaskData::getEndTime))
                .collect(Collectors.toList());
        StringBuilder approvals = new StringBuilder("\nСогласования: \n");
        SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        int  i = 1;
        for (TaskData taskData : taskDataList) {
            String approvedTask = i + ". " + taskData.getName() + " | ";
            Employee assignedUser = employeeService.reloadEmployeeByUsername(taskData.getAssignee());
            if (assignedUser != null) {
                String assignee = assignedUser.getFullName();
                if (assignedUser.getPosition() != null
                        && !Strings.isNullOrEmpty(assignedUser.getPosition().getName())) {
                    assignee += " - " + assignedUser.getPosition().getName();
                }
                approvedTask += assignee + " | ";
            }
            String outcome = getTaskOutcome(taskData);
            approvedTask += outcome + " | " + df.format(taskData.getEndTime());
            approvals.append(approvedTask).append("\n");
            i++;
        }
        if (card.getInfo() == null) card.setInfo("");
        card.setInfo(card.getInfo() + approvals);
    }

    private String getTaskOutcome(TaskData taskData) {
        HistoricVariableInstance outcomeResult = bpmUserTaskService.getHistoricVariableInstance(
                taskData.getProcessInstanceId(),
                taskData.getTaskDefinitionKey() + "_result");
        List<Outcome> taskOutcomes = null;
        if (outcomeResult != null && outcomeResult.getValue() != null) {
            try {
                OutcomesContainer outcomesContainer = (OutcomesContainer) outcomeResult.getValue();
                taskOutcomes = outcomesContainer.getOutcomes();
            } catch (ClassCastException e) {
                log.error("Couldn't cast to OutcomesContainer class", e);
            }
        }
        if (taskOutcomes != null && taskOutcomes.size() > 0) {
            String outcomeText = getOutcomeCaption(taskOutcomes.get(0).getOutcomeId());
            if (!Strings.isNullOrEmpty(outcomeText)
                    && !outcomeText.contains(".caption")) {
                return outcomeText.toUpperCase(Locale.ROOT);
            }
        }
        return null;
    }

    private String getOutcomeCaption(String outcomeId) {
        return messages.getMessage(BPM_HISTORY_TASK_MSG_PACK, "outcomes." + outcomeId + ".caption");
    }
}
