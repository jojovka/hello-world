package kz.eub.kpi.app.service;

import io.jmix.core.DataManager;
import io.jmix.core.querycondition.LogicalCondition;
import io.jmix.core.querycondition.PropertyCondition;
import kz.eub.kpi.entity.EApplicationStatus;
import kz.eub.kpi.entity.Unit;
import kz.eub.kpi.entity.kpi.EKpiGoalAssessmentType;
import kz.eub.kpi.entity.kpi.EKpiGoalCategory;
import kz.eub.kpi.entity.kpi.KpiGoalDict;
import kz.eub.kpi.entity.kpi.KpiGoalDictPlan;
import kz.eub.kpi.entity.kpi.KpiGoalPlanImportDoc;
import kz.eub.kpi.entity.kpi.KpiGoalSubCategory;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

@Component("kpi_KpiGoalPlanImportService")
public class KpiGoalPlanImportService {

    public static final Logger log = LoggerFactory.getLogger(KpiGoalFactImportService.class);
    @Autowired
    private DataManager dataManager;

    public List<KpiGoalDictPlan> importGoalPans(byte[] fileByteArray, KpiGoalPlanImportDoc importDoc) throws IOException {
        List<KpiGoalDictPlan> goalDictFacts = new ArrayList<>();
        InputStream file = new ByteArrayInputStream(fileByteArray);
        Workbook workbook = new XSSFWorkbook(file);

        Sheet sheet = workbook.getSheetAt(0);
        Iterator<Row> iterator = sheet.iterator();
        iterator.next();    // skip header row
        while (iterator.hasNext()) {
            Row row = iterator.next();
            KpiGoalDictPlan goalPlan = dataManager.create(KpiGoalDictPlan.class);
            goalPlan.setGoalImportDoc(importDoc);
            goalPlan.setStatus(EApplicationStatus.NEW);
            goalPlan.setPeriod(importDoc.getPeriod());

            KpiGoalDict goalDict = getKpiGoalDictFromRow(row);
            if (goalDict == null) continue;
            goalPlan.setGoalDict(goalDict);

            Cell cell = row.getCell(5);
            if (cell.getCellType().equals(CellType.NUMERIC)) {
                double numericCellValue = cell.getNumericCellValue();
                if (numericCellValue == 0) continue;
                BigDecimal plan = new BigDecimal(numericCellValue);
                goalPlan.setPlan(plan);
            } else
                continue;

            goalDictFacts.add(goalPlan);
        }
        return goalDictFacts;
    }

    private KpiGoalDict getKpiGoalDictFromRow(Row row) {
        Cell cell = row.getCell(0);
        if (cell.getCellType().equals(CellType.STRING)) {
            String uuidStr = cell.getStringCellValue();
            UUID uuid = UUID.fromString(uuidStr);
            return dataManager.load(KpiGoalDict.class).id(uuid).optional().orElse(null);
        } else {
            cell = row.getCell(3);
            if (cell.getCellType().equals(CellType.STRING)) {
                String description = cell.getStringCellValue();
                KpiGoalDict goalDict = getKpiGoalDictByDescription(description);
                if (goalDict != null)
                    return goalDict;
                return getNewKpiGoalDictFromRow(row);
            }
        }
        return null;
    }

    private KpiGoalDict getKpiGoalDictByDescription(String description) {
        return dataManager.load(KpiGoalDict.class)
                .condition(PropertyCondition.equal("goalDescription", description))
                .optional().orElse(null);
    }

    private KpiGoalDict getNewKpiGoalDictFromRow(Row row) {
        KpiGoalDict dict = dataManager.create(KpiGoalDict.class);
        dict.setCategory(EKpiGoalCategory.FINANCIAL_GOAL);

        Cell cell = row.getCell(1);
        if (cell.getCellType().equals(CellType.STRING)) {
            String subCategoryName = cell.getStringCellValue();
            KpiGoalSubCategory subCategory = getKpiGoalSubCategoryByName(subCategoryName);
            dict.setSubCategory(subCategory);
        }

        cell = row.getCell(2);
        if (cell.getCellType().equals(CellType.STRING)) {
            String name = cell.getStringCellValue();
            dict.setName(name);
        }

        cell = row.getCell(3);
        if (cell.getCellType().equals(CellType.STRING)) {
            String description = cell.getStringCellValue();
            dict.setGoalDescription(description);
        }

        cell = row.getCell(4);
        if (cell.getCellType().equals(CellType.STRING)) {
            String source = cell.getStringCellValue();
            dict.setDataSource(source);
        }

        cell = row.getCell(6);
        if (cell.getCellType().equals(CellType.STRING)) {
            String unitName = cell.getStringCellValue();
            Unit unit = getUnitByName(unitName);
            dict.setUnit(unit);
        }

        cell = row.getCell(8);
        if (cell.getCellType().equals(CellType.STRING)) {
            String assessmentTypeId = cell.getStringCellValue();
            dict.setAssessmentMethod(EKpiGoalAssessmentType.fromId(assessmentTypeId));
        }

        cell = row.getCell(9);
        if (cell.getCellType().equals(CellType.STRING)) {
            String info = cell.getStringCellValue();
            dict.setInfo(info);
        }

        validateKpiGoalDict(dict);
        return dataManager.save(dict);
    }

    private void validateKpiGoalDict(KpiGoalDict dict) {
        if (dict == null)
            throw new IllegalArgumentException("Передан пустой цель");
        if (dict.getCategory() == null)
            throw new IllegalArgumentException("Пустая категория цели");
        if (dict.getName() == null)
            throw new IllegalArgumentException("Пустое название цели");
        if (dict.getGoalDescription() == null)
            throw new IllegalArgumentException("Пустое описание цели");
        if (dict.getDataSource() == null)
            throw new IllegalArgumentException("Пустой источник данных цели");
        if (dict.getAssessmentMethod() == null)
            throw new IllegalArgumentException("Пустой метод оценки цели");
        if (dict.getUnit() == null)
            throw new IllegalArgumentException("Пустая единица измерения цели");

        if (dict.getCategory().equals(EKpiGoalCategory.FINANCIAL_GOAL)
                && dict.getSubCategory() == null)
            throw new IllegalArgumentException("Подкатегория цели пустая");
    }

    private Unit getUnitByName(String unitName) {
        return dataManager.load(Unit.class)
                .condition(PropertyCondition.equal("name", unitName))
                .optional().orElse(null);
    }

    private KpiGoalSubCategory getKpiGoalSubCategoryByName(String subCategoryName) {
        return dataManager.load(KpiGoalSubCategory.class)
                .condition(PropertyCondition.equal("name", subCategoryName))
                .optional().orElse(null);
    }

}