package kz.eub.kpi.app;

import com.google.common.base.Strings;
import io.jmix.bpm.data.form.FormData;
import io.jmix.bpmui.processform.screencreator.ProcessFormScreenCreator;
import io.jmix.bpmui.screen.dynamicform.DynamicStartProcessForm;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.screen.OpenMode;
import io.jmix.ui.screen.Screen;
import kz.eub.kpi.screen.bpm.customtask.CustomTaskScreen;
import org.springframework.stereotype.Component;

import javax.annotation.Nullable;
import javax.inject.Inject;

@Component("kpi_CustomProcessFormScreenCreator")
public class CustomProcessFormScreenCreator implements ProcessFormScreenCreator {

    @Inject
    private ScreenBuilders screenBuilders;

    @Override
    public String isApplicableFor() {
        return "input-dialog";
    }

    @Override
    public Screen createStartProcessScreen(CreationContext creationContext) {
        DynamicStartProcessForm dynamicStartProcessForm = screenBuilders.screen(creationContext.getFrameOwner())
                .withScreenClass(DynamicStartProcessForm.class)
                .withOpenMode(getOpenMode(creationContext.getFormData()))
                .build();
        dynamicStartProcessForm.setProcessDefinition(creationContext.getProcessDefinition());
        return dynamicStartProcessForm;
    }

    @Override
    public Screen createUserTaskScreen(CreationContext creationContext) {
        CustomTaskScreen taskProcessForm = screenBuilders.screen(creationContext.getFrameOwner())
                .withScreenClass(CustomTaskScreen.class)
                .withOpenMode(getOpenMode(creationContext.getFormData()))
                .build();
        taskProcessForm.setTask(creationContext.getTask());
        return taskProcessForm;
    }

    protected OpenMode getOpenMode(@Nullable FormData formData) {
        return formData != null && !Strings.isNullOrEmpty(formData.getOpenMode()) ?
                OpenMode.valueOf(formData.getOpenMode()) :
                OpenMode.THIS_TAB;
    }
}