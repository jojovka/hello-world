package kz.eub.kpi.app.service;

import io.jmix.bpm.entity.ProcessInstanceData;
import io.jmix.bpm.util.FlowableEntitiesConverter;
import io.jmix.core.DataManager;
import kz.eub.kpi.entity.Application;
import kz.eub.kpi.entity.EApplicationStatus;
import org.flowable.common.engine.api.FlowableObjectNotFoundException;
import org.flowable.engine.HistoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.engine.runtime.ProcessInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("kpi_ApplicationService")
public class ApplicationService {

    public static final Logger log = LoggerFactory.getLogger(ApplicationService.class);

    @Autowired
    protected RuntimeService runtimeService;
    @Autowired
    private HistoryService historyService;
    @Autowired
    private FlowableEntitiesConverter flowableEntitiesConverter;
    @Autowired
    private DataManager dataManager;

    public ProcessInstanceData loadApplicationProcessInstanceData(Application application) {
        if (application == null)
            throw new IllegalStateException("Передана пустая заявка для получения экземпляра процесса...");
        if (application.getProcId() != null) {
            ProcessInstance processInstance = runtimeService.createProcessInstanceQuery()
                    .processInstanceId(application.getProcId())
                    .singleResult();
            if (processInstance != null)
                return flowableEntitiesConverter.createProcessInstanceData(processInstance);

            HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery()
                    .processInstanceId(application.getProcId())
                    .singleResult();
            if (historicProcessInstance != null)
                return flowableEntitiesConverter.createHistoricProcessInstanceData(historicProcessInstance);
        }
        return null;
    }

    public boolean cancelApplicationProcess(Application application, String reason) {
        if (application == null)
            throw new IllegalStateException("Передана пустая заявка для получения экземпляра процесса");
        if (application.getProcId() != null) {
            try {
                try {
                    runtimeService.deleteProcessInstance(application.getProcId(), reason);
                } catch (FlowableObjectNotFoundException e) {
                    log.error("Процесс не найден", e);
                }
                application.setStatus(EApplicationStatus.REVOKED);
                dataManager.save(application);
                return true;
            } catch (Exception e) {
                throw new RuntimeException("Ошибка при попытке отозвать заявку... Не удалось обновить статус заявки.", e);
            }
        }
        return false;
    }

    public void noobMethod() {}
}