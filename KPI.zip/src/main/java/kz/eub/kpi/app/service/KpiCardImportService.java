package kz.eub.kpi.app.service;

import io.jmix.core.DataManager;
import io.jmix.core.TimeSource;
import kz.eub.kpi.app.bean.KpiGeneralUtils;
import kz.eub.kpi.entity.EApplicationStatus;
import kz.eub.kpi.entity.EQuarter;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.Unit;
import kz.eub.kpi.entity.kpi.EKpiGoalAssessmentType;
import kz.eub.kpi.entity.kpi.EKpiCardStage;
import kz.eub.kpi.entity.kpi.EKpiGoalCategory;
import kz.eub.kpi.entity.kpi.EKpiGoalStatus;
import kz.eub.kpi.entity.kpi.KpiCard;
import kz.eub.kpi.entity.kpi.KpiGoal;
import kz.eub.kpi.entity.kpi.KpiPeriod;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Component("kpi_KpiCardImportService")
public class KpiCardImportService {

    private static final Logger log = LoggerFactory.getLogger(KpiCardImportService.class);

    @Autowired
    private DataManager dataManager;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private KpiCardService kpiCardService;
    @Autowired
    private KpiGoalService kpiGoalService;
    @Autowired
    private KpiGeneralUtils kpiGeneralUtils;
    @Autowired
    private TimeSource timeSource;


    public List<KpiCard> importKpiCards(byte[] fileByteArray, int sheetIndex) throws IOException {
        List<KpiCard> kpiCards = new ArrayList<>();
        InputStream file = new ByteArrayInputStream(fileByteArray);
        Workbook workbook = new XSSFWorkbook(file);

        Sheet sheet = workbook.getSheetAt(sheetIndex);
        Iterator<Row> iterator = sheet.iterator();
        KpiPeriod period = getKpiPeriod(iterator);
        if (period == null)
            throw new IllegalStateException("Период не найден...");

        while (iterator.hasNext()) {
            Row row = iterator.next();
            Cell cell1 = row.getCell(1);
            Cell cell2 = row.getCell(2);
            if (cell1.getCellType().equals(CellType.NUMERIC)
                    && cell2.getCellType().equals(CellType.STRING)) {
                KpiCard card = parseKpiCard(row, iterator, period);
                if (card != null) {
                    kpiCardService.validateKpiCard(card);
                    kpiCards.add(card);
                }
            }
        }
        return kpiCards;
    }

    private KpiPeriod getKpiPeriod(Iterator<Row> iterator) {
        if (iterator.hasNext()) {
            Row row = iterator.next();
            Cell cell = row.getCell(1);
            if (cell.getCellType().equals(CellType.NUMERIC)) {
                int q = (int) cell.getNumericCellValue();
                row = iterator.next();
                cell = row.getCell(1);
                if (cell.getCellType().equals(CellType.NUMERIC)) {
                    int year = (int) cell.getNumericCellValue();
                    EQuarter quarter = kpiGeneralUtils.getQuarterEnumFromInt(q);
                    int month = kpiGeneralUtils.getQuarterStartMonth(quarter);
                    return kpiGoalService.getKpiPeriod(month, year);
                }
            }
        }
        return null;
    }

    private KpiCard parseKpiCard(Row row, Iterator<Row> iterator, KpiPeriod period) {
        KpiCard card = dataManager.create(KpiCard.class);
        Employee employee = getEmployeeFromRow(row);
        if (employee == null) return null;

        String sn = kpiCardService.getApplicationSN();
        card.setSn(sn);
        card.setAuthor(employee);
        card.setPeriod(period);
        card.setDate(timeSource.currentTimestamp());
        card.setStage(EKpiCardStage.FIRST_STAGE);
        card.setStatus(EApplicationStatus.AGREED);
        card.setSupervisor(employee.getSupervisor());
        card.setLeader(employee.getLeader());
        card.setDepartment(employee.getDepartment());
        card.setPosition(employee.getPosition());
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy-HH:mm:ss");
        String info = "Импортирован: " + dateFormat.format(new Date());
        card.setInfo(info);

        List<KpiGoal> kpiGoals = getKpiGoals(row, iterator, card);
        card.setKpiGoals(kpiGoals);
        return card;
    }

    private Employee getEmployeeFromRow(Row row) {
        Cell cell = row.getCell(1);
        if (cell.getCellType().equals(CellType.NUMERIC)) {
            Long pn = (long) cell.getNumericCellValue();
            String payrollNumber = String.format("%08d", pn);
            Employee employee = employeeService.loadEmployeeByPayrollNumber(payrollNumber);
            cell = row.getCell(2);
            if (cell.getCellType().equals(CellType.STRING)) {
                String fio = cell.getStringCellValue();
                if (employee == null
                        && fio != null
                        && !fio.trim().isEmpty()) {
                    employee = employeeService.searchEmployee(fio.trim())
                            .stream().findFirst().orElse(null);
                    if (employee == null)
                        log.info("Employee not found: " + fio);
                }
                return employee;
            }
        }
        return null;
    }

    @NotNull
    private List<KpiGoal> getKpiGoals(Row row, Iterator<Row> iterator, KpiCard card) {
        List<KpiGoal> kpiGoals = new ArrayList<>();
        while (row.getCell(9).getCellType().equals(CellType.NUMERIC)) {
            Cell cell = row.getCell(11);
            if (cell.getCellType().equals(CellType.STRING)) {
                KpiGoal goal = dataManager.create(KpiGoal.class);
                String sn = kpiGoalService.getGoalNextSn();
                goal.setSn(sn);
                goal.setKpiCard(card);
                goal.setEmployee(card.getAuthor());
                goal.setDepartment(card.getDepartment());
                goal.setStatus(EKpiGoalStatus.APPROVED);
                goal.setPeriod(card.getPeriod());

                String goalName = cell.getStringCellValue();
                if (goalName != null
                        && !goalName.trim().isEmpty()) {
                    goal.setName(goalName);

                    cell = row.getCell(12);
                    if (cell.getCellType().equals(CellType.STRING)) {
                        String kpiDescription = cell.getStringCellValue();
                        goal.setKpiDescription(kpiDescription);
                    }

                    EKpiGoalCategory goalCategory = getRowGoalCategory(row);
                    goal.setCategory(goalCategory);

                    Unit unit = getRowUnit(row, goal);
                    goal.setUnit(unit);

                    EKpiGoalAssessmentType assessmentType = getRowAssessmentType(row);
                    goal.setAssessmentType(assessmentType);

                    String source = getRowDataSource(row);
                    goal.setDataSource(source);

                    BigDecimal weight = getRowWeight(row, goal);
                    goal.setWeight(weight);

                    setGoalRowPlan(row, goal, unit);

                    cell = row.getCell(21);
                    if (cell.getCellType().equals(CellType.STRING)) {
                        String info = cell.getStringCellValue();
                        goal.setInfo(info);
                    }

                    kpiGoals.add(goal);
                }
            }
            if (iterator.hasNext())
                row = iterator.next();
            else break;
        }
        return kpiGoals;
    }

    private EKpiGoalAssessmentType getRowAssessmentType(Row row) {
        Cell cell = row.getCell(14);
        if (cell.getCellType().equals(CellType.STRING)) {
            return EKpiGoalAssessmentType.fromId(cell.getStringCellValue());
        }
        return null;
    }

    private String getRowDataSource(Row row) {
        Cell cell = row.getCell(15);
        if (cell.getCellType().equals(CellType.STRING)) {
            return cell.getStringCellValue();
        }
        return null;
    }

    private EKpiGoalCategory getRowGoalCategory(Row row) {
        Cell cell = row.getCell(10);
        EKpiGoalCategory goalCategory;
        if (cell.getCellType().equals(CellType.STRING)) {
            String strValue = cell.getStringCellValue();
            return EKpiGoalCategory.fromId(strValue);
        }
        return null;
    }

    private Unit getRowUnit(Row row, KpiGoal goal) {
        Cell cell = row.getCell(13);
        if (cell.getCellType().equals(CellType.STRING)) {
            String unitStr = cell.getStringCellValue();
            if (unitStr == null || unitStr.isEmpty())
                throw new IllegalStateException("Единица измерения не указана для: " + goal.getName());
            Optional<Unit> unitOptional = kpiGoalService.loadUnit(unitStr);
            if (unitOptional.isEmpty())
                throw new IllegalStateException("Единица измерения [" + unitStr + "] не найдена.");
            return unitOptional.get();
        }
        return null;
    }

    @NotNull
    private BigDecimal getRowWeight(Row row, KpiGoal goal) {
        Cell cell = row.getCell(16);
        BigDecimal weight = BigDecimal.ZERO;
        if (cell.getCellType().equals(CellType.STRING)) {
            String stringCellValue = cell.getStringCellValue();
            if (stringCellValue == null || stringCellValue.isEmpty())
                throw new IllegalStateException("Вес не указан для цели: " + goal.getName());
            String strNumVal = stringCellValue.split("%")[0];
            strNumVal = strNumVal.replace(" ", "");
            weight = new BigDecimal(strNumVal);
        } else if (cell.getCellType().equals(CellType.NUMERIC)) {
            double numericCellValue = cell.getNumericCellValue();
            weight = new BigDecimal(numericCellValue);
        }
        return weight.multiply(new BigDecimal(100)).setScale(2, RoundingMode.HALF_EVEN);
    }

    private void setGoalRowPlan(Row row, KpiGoal goal, Unit unit) {
        Cell cell;
        cell = row.getCell(17);
        if (cell.getCellType().equals(CellType.STRING)) {
            String stringCellValue = cell.getStringCellValue();
            if (stringCellValue == null || stringCellValue.isEmpty())
                throw new IllegalStateException("Целевое значение не указана для: " + goal.getName());
            if (Objects.equals(unit.getId(), Unit.UNIT_WDAY)) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
                try {
                    Date planDate = dateFormat.parse(stringCellValue);
                    goal.setPlanDate(planDate);
                } catch (ParseException e) {
                    throw new IllegalStateException("Формат даты неправильный: " + stringCellValue);
                }
            } else {
                String strNumVal = stringCellValue.split("%")[0];
                strNumVal = strNumVal.replace(" ", "");
                BigDecimal plan = new BigDecimal(strNumVal);
                goal.setPlan(plan);
            }
        } else if (cell.getCellType().equals(CellType.NUMERIC)) {
            double numericCellValue = cell.getNumericCellValue();
            BigDecimal plan = new BigDecimal(numericCellValue);
            if (Objects.equals(unit.getId(), Unit.UNIT_PERCENT)
                    && plan.compareTo(BigDecimal.ONE) <= 0)
                plan = plan.multiply(new BigDecimal(100)).setScale(2, RoundingMode.HALF_EVEN);
            goal.setPlan(plan);
        }
    }

}