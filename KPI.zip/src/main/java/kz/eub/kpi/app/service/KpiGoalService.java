package kz.eub.kpi.app.service;

import io.jmix.core.DataManager;
import io.jmix.core.querycondition.LogicalCondition;
import io.jmix.core.querycondition.PropertyCondition;
import io.jmix.data.Sequence;
import io.jmix.data.Sequences;
import kz.eub.kpi.app.bean.KpiGeneralUtils;
import kz.eub.kpi.entity.EQuarter;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.Unit;
import kz.eub.kpi.entity.kpi.EKpiGoalAssessmentType;
import kz.eub.kpi.entity.kpi.EKpiGoalCategory;
import kz.eub.kpi.entity.kpi.EKpiGoalStatus;
import kz.eub.kpi.entity.kpi.KpiCard;
import kz.eub.kpi.entity.kpi.KpiGoal;
import kz.eub.kpi.entity.kpi.KpiGoalSubCategory;
import kz.eub.kpi.entity.kpi.KpiPeriod;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class KpiGoalService {

    @Autowired
    private DataManager dataManager;
    @Autowired
    private KpiGeneralUtils kpiGeneralUtils;
    @Autowired
    private Sequences sequences;
    @Autowired
    private EmployeeService employeeService;

    public String getGoalNextSn() {
        long number = sequences.createNextValue(Sequence.withName(KpiGoal.SEQUENCE_NAME));
        return String.format("%06d", number);
    }

    public KpiGoal initKpiGoal(KpiGoal goal) {
        String sn = getGoalNextSn();
        goal.setSn(sn);
        Employee employee = employeeService.getCurrentEmployee();
        goal.setEmployee(employee);
        if (employee != null)
            goal.setDepartment(employee.getDepartment());
        if (goal.getKpiCard() != null)
            goal.setPeriod(goal.getKpiCard().getPeriod());
        return goal;
    }

    public KpiGoal createDefaultGvkGoal(KpiCard card) {
        KpiGoal goal = dataManager.create(KpiGoal.class);
        goal.setKpiCard(card);
        initKpiGoal(goal);
        goal.setPeriod(card.getPeriod());
        goal.setCategory(EKpiGoalCategory.GVK_GOAL);
        Optional<Unit> unitOptional = loadUnit(Unit.UNIT_OTHER);
        unitOptional.ifPresent(goal::setUnit);
        goal.setPlan(new BigDecimal(4));
        goal.setAssessmentType(EKpiGoalAssessmentType.MORE_IS_BETTER);
        goal.setName("Достижение целевого показателя подразделением, измеряемого на основе индекса в отчете \"Голос внутреннего клиента\"");
        goal.setKpiDescription("Улучшение предоставляемого отделом сервиса внутренним клиентам");
        goal.setWeight(new BigDecimal(10));
        goal.setDataSource("Отчет УСП");
        return goal;
    }

    public KpiGoal updateStatus(KpiGoal kpiGoal, EKpiGoalStatus status) {
        if (kpiGoal == null)
            throw new IllegalArgumentException("Цель пустая...");
        if (status == null)
            throw new IllegalArgumentException("Передан пустой статус.");
        kpiGoal = reloadKpiGoal(kpiGoal);
        if (kpiGoal.getStatus() == null
                || !kpiGoal.getStatus().equals(status)) {
            kpiGoal.setStatus(status);
            kpiGoal = dataManager.save(kpiGoal);
        }
        return kpiGoal;
    }

    public KpiGoal updateStatus(KpiGoal kpiGoal, String statusStr) {
        if (statusStr == null)
            throw new IllegalArgumentException("Передан пустой статус.");
        EKpiGoalStatus status = EKpiGoalStatus.fromId(statusStr);
        return updateStatus(kpiGoal, status);
    }

    public KpiGoal reloadKpiGoal(KpiGoal kpiGoal) {
        if (kpiGoal == null
                || kpiGoal.getId() == null) return null;
        kpiGoal = dataManager.load(KpiGoal.class)
                .id(kpiGoal.getId())
                .one();
        return kpiGoal;
    }

    public KpiPeriod getCurrentKpiPeriod() {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        return getKpiPeriod(month, year);
    }

    public KpiPeriod getPreviousPeriod(KpiPeriod period) {
        Date qs = kpiGeneralUtils.getQuarterStartDate(period.getQuarter(), period.getYear());
        Calendar cal = Calendar.getInstance();
        cal.setTime(qs);
        cal.add(Calendar.MONTH, -1);
        return getKpiPeriod(cal.get(Calendar.MONTH), cal.get(Calendar.YEAR));
    }

    public KpiPeriod getKpiPeriod(int month, int year) {
        EQuarter quarter = kpiGeneralUtils.getCurrentQuarter(month);
        KpiPeriod kpiPeriod = loadKpiPeriod(year, quarter);
        if (kpiPeriod != null) return kpiPeriod;
        kpiPeriod = dataManager.create(KpiPeriod.class);
        kpiPeriod.setQuarter(quarter);
        kpiPeriod.setYear(year);
        return dataManager.save(kpiPeriod);
    }

    @Nullable
    private KpiPeriod loadKpiPeriod(int year, EQuarter quarter) {
        KpiPeriod kpiPeriod = dataManager.load(KpiPeriod.class)
                .query("select c from kpi_KpiPeriod c " +
                        "where c.year = :year " +
                        "and c.quarter = :quarter")
                .parameter("year", year)
                .parameter("quarter", quarter)
                .optional().orElse(null);
        return kpiPeriod;
    }

    public long getDaysPassedFromQuarterStart(@NotNull KpiPeriod period) {
        Date qs = kpiGeneralUtils.getQuarterStartDate(period.getQuarter(), period.getYear());
        return kpiGeneralUtils.calcAgeInDays(qs, new Date());
    }

    public long getQuarterPeriodDays(@NotNull KpiPeriod period) {
        Date qs = kpiGeneralUtils.getQuarterStartDate(period.getQuarter(), period.getYear());
        Date qe = kpiGeneralUtils.getQuarterEndDate(period.getQuarter(), period.getYear());
        return kpiGeneralUtils.calcAgeInDays(qs, qe);
    }

    public long getDaysToNextQuarter(@NotNull KpiPeriod period) {
        Calendar cal = Calendar.getInstance();
        Date qe = kpiGeneralUtils.getQuarterEndDate(period.getQuarter(), period.getYear());
        return kpiGeneralUtils.calcAgeInDays(cal.getTime(), qe);
    }

    public KpiPeriod getNextPeriod(@NotNull KpiPeriod period) {
        Date qe = kpiGeneralUtils.getQuarterEndDate(period.getQuarter(), period.getYear());
        Calendar cal = Calendar.getInstance();
        cal.setTime(qe);
        cal.add(Calendar.MONTH, 1);
        return getKpiPeriod(cal.get(Calendar.MONTH), cal.get(Calendar.YEAR));
    }

    public List<KpiGoalSubCategory> loadGoalSubCategories(EKpiGoalCategory category) {
        if (category == null) return new ArrayList<>();
        return dataManager.load(KpiGoalSubCategory.class)
                .condition(PropertyCondition.equal("category", category))
                .list();
    }

    public Optional<Unit> loadUnit(String unitStr) {
        return dataManager.load(Unit.class)
                .condition(
                        LogicalCondition.or(
                                PropertyCondition.equal("id", unitStr),
                                PropertyCondition.equal("name", unitStr),
                                PropertyCondition.equal("code", unitStr)
                        )
                )
                .optional();
    }
}