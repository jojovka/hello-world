package kz.eub.kpi.app.service;

import io.jmix.core.DataManager;
import io.jmix.core.FileStorage;
import io.jmix.core.FileStorageLocator;
import io.jmix.ui.UiComponents;
import io.jmix.ui.component.FileUploadField;
import io.jmix.ui.component.GroupBoxLayout;
import io.jmix.ui.component.Label;
import io.jmix.ui.icon.JmixIcon;
import kz.eub.kpi.entity.Announce;
import kz.eub.kpi.entity.AnnounceType;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Component("kpi_AnnounceService")
public class AnnounceService {

    @Autowired
    private DataManager dataManager;
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private FileStorageLocator fileStorageLocator;

    public List<Announce> loadAnnounces() {
        return dataManager.load(Announce.class)
                .query("select c from kpi_Announce c " +
                        "where c.dateStart <= current_date " +
                        "and c.dateEnd > current_date ")
                .list();
    }

    @NotNull
    public GroupBoxLayout getAnnounceCard(Announce announce) throws IOException {
        GroupBoxLayout groupBox = uiComponents.create(GroupBoxLayout.class);
        groupBox.setCaption(announce.getTitle());
        groupBox.setShowAsPanel(true);
        groupBox.addStyleName("word-wrapping");

        JmixIcon icon = getAnnounceIcon(announce.getType());
        groupBox.setIconFromSet(icon);
        groupBox.setStyleName("card");

        Label label = uiComponents.create(Label.class);
        label.setHtmlEnabled(true);
        label.setValue(announce.getDescription());
        label.setHeightAuto();
        label.setWidthAuto();
        label.addStyleName("word-wrapping");
        groupBox.add(label);

        if (announce.getAttachment() != null) {
            FileUploadField fileUploadField = getFileUploadField(announce);
            groupBox.add(fileUploadField);
        }
        return groupBox;
    }

    @NotNull
    private JmixIcon getAnnounceIcon(AnnounceType type) {
        if (type == null) return JmixIcon.COMMENT;
        switch (type) {
            case SUCCESS: return JmixIcon.CHECK_CIRCLE_O;
            case WARNING: return JmixIcon.WARNING;
            default : return JmixIcon.COMMENT;
        }
    }

    @NotNull
    private FileUploadField getFileUploadField(Announce announce) throws IOException {
        FileUploadField fileUploadField = uiComponents.create(FileUploadField.class);
        FileStorage fileStorage = fileStorageLocator.getDefault();
        try (InputStream inputStream = fileStorage.openStream(announce.getAttachment())) {
            fileUploadField.setValue(inputStream.readAllBytes());
            fileUploadField.setEditable(false);
            fileUploadField.setEnabled(true);
            fileUploadField.setFileName(announce.getAttachment().getFileName());
            fileUploadField.setShowFileName(true);
        }
        return fileUploadField;
    }
}