package kz.eub.kpi.app.service;

import io.jmix.core.DataManager;
import kz.eub.kpi.app.bean.KpiGeneralUtils;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.screen.organigram.OrganigramScreen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Component("kpi_OrgChartService")
public class OrgChartService {

    private static final Logger log = LoggerFactory.getLogger(OrganigramScreen.class);

    public static final String NO_PHOTO_IMG = "/VAADIN/img/avatar-person.svg";
    public static final String DEPARTMENT_IMG = "/VAADIN/img/eub_dark.png";

    @Autowired
    private NamedParameterJdbcTemplate jdbcTemplate;
    @PersistenceContext
    private EntityManager em;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private KpiGeneralUtils kpiGeneralUtils;
    @Autowired
    private EmployeeService employeeService;

    public List<DictDepartment> getDepartmentList(UUID id) {
        List<UUID> depIdList = getDepartmentSubTreeIdList(id);
        return dataManager.load(DictDepartment.class)
                .query("e.id in :depIdList ")
                .parameter("depIdList", depIdList)
                .list();
    }

    public List<UUID> getDepartmentSubTreeIdList(UUID id) {
        String query = "with RECURSIVE cte as " +
                "( " +
                "   select id from kpi_dict_department where id = #depId " +
                "   union all " +
                "   select e.id from kpi_dict_department e inner join cte on e.parent_id=cte.id " +
                "   where e.end_date > CURRENT_DATE " +
                ") " +
                "select cte.id from cte";
        List<UUID> depIdList = em.createNativeQuery(query, DictDepartment.class)
                .setParameter("depId", id)
                .getResultList();
        return depIdList;
    }

    public List<UUID> getAllSubTreeEmployeeIdList(UUID depId) {
        String query = "with RECURSIVE cte as " +
                "( " +
                "  select * from kpi_dict_department where id = :depId " +
                "  union all " +
                "  select e.* from kpi_dict_department e inner join cte on e.parent_id=cte.id " +
                ") " +
                "select u.id from cte " +
                "inner join kpi_employee as e on e.department_id = cte.id " +
                "inner join kpi_user as u on u.id = e.id " +
                "where u.active = true";
        MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
        mapSqlParameterSource.addValue("depId", depId);
        List<UUID> employeeIdList = new ArrayList<>();
        return jdbcTemplate.query(query, mapSqlParameterSource, rs -> {
            while (rs.next()) {
                employeeIdList.add(rs.getObject(1, UUID.class));
            }
            return employeeIdList;
        });
    }

    public DictDepartment searchByFio(Employee employee) {
        DictDepartment department = dataManager.load(DictDepartment.class)
                .query("select d from kpi_DictDepartment d " +
                        "inner join kpi_Employee e on e.department = d " +
                        "where e = :employee " +
                        "and e.active = true ").parameter("employee", employee).one();

        return department.getParent();
    }

    public List<Employee> getOrgChartEmployeeList(DictDepartment selectedDepartment) {
        List<DictDepartment> departments = getDepartmentList(selectedDepartment.getId());
        List<Employee> employeeList = getEmloyeeList(selectedDepartment.getId());
        return dfs(departments, employeeList, Arrays.asList(selectedDepartment), null);
    }

    public List<Employee> getEmloyeeList(UUID id) {
        return dataManager.load(Employee.class)
                .query("select e from kpi_Employee e " +
                        "where e.active = true and e.id in :idList")
                .parameter("idList", getAllSubTreeEmployeeIdList(id))
                .fetchPlan(employeeService.getEmployeeFetchPlan())
                .list();
    }

    private List<Employee> dfs(List<DictDepartment> globalList, List<Employee> employeeList, List<DictDepartment> departments, Employee parentNode) {
        List<Employee> orgChartEmployees = new ArrayList<>();
        for (DictDepartment department : departments) {
            List<Employee> employees = getDepartmentEmployees(employeeList, department);
            Employee childParentNode = reorderUnderSupervisor(employees, department, parentNode);
            orgChartEmployees.addAll(employees);

            List<DictDepartment> childDepartments = getChildDepartments(globalList, department);
            List<Employee> dfs = dfs(globalList, employeeList, childDepartments, childParentNode);
            orgChartEmployees.addAll(dfs);
        }
        orgChartEmployees.sort(this::compareByDepAndFullName);
        return orgChartEmployees;
    }

    private List<Employee> getDepartmentEmployees(List<Employee> employeeList, DictDepartment department) {
        List<Employee> employees = employeeList.stream()
                .filter(e -> e.getDepartment().getId().equals(department.getId()))
                .collect(Collectors.toList());
        return employees;
    }

    private List<DictDepartment> getChildDepartments(List<DictDepartment> departments, DictDepartment parentDepartment) {
        return departments.stream()
                .filter(d -> d.getParent() != null
                        && d.getParent().getId().equals(parentDepartment.getId()))
                .collect(Collectors.toList());
    }

    private Employee reorderUnderSupervisor(List<Employee> employeeList, DictDepartment department, Employee parentNode) {
        Employee supervisor = dataManager.create(Employee.class);
        if (employeeList.contains(department.getEmployee())) {
            supervisor = employeeList.stream()
                    .filter(e -> e.getId().equals(department.getEmployee().getId()))
                    .findFirst().orElse(null);
        } else {
            // Fake Supervisor
            supervisor.setFullName(department.getName());
            supervisor.setDepartment(department);
            employeeList.add(supervisor);
        }
        supervisor.setSupervisor(parentNode);
        joinSeparateBranchesWithFakeSupervisor(employeeList, supervisor);
        return supervisor;
    }

    public List<Employee> joinSeparateBranchesWithFakeSupervisor(List<Employee> employeeList, Employee fakeSupervisor) {
        for (Employee employee : employeeList) {
            if (employee.getSupervisor() == null
                    || employee.getId().equals(employee.getSupervisor().getId())
                    || !employeeList.contains(employee.getSupervisor())) {
                if (fakeSupervisor != null
                        && !employee.getId().equals(fakeSupervisor.getId()))
                    employee.setSupervisor(fakeSupervisor);
            }
        }
        return employeeList;
    }



    public String getImageUrl(Employee employee) {
        if (employee.getPhoto() != null) {
            try {
                String base64img = kpiGeneralUtils.getBase64FromFileRef(employee.getPhoto());
                return "data:image/jpeg;base64, " + base64img;
            } catch (Exception e) {
                log.debug("Error while trying to retrieve base64img: ", e);
                return NO_PHOTO_IMG;
            }
        } else {
            if (isDepartment(employee)) {
                return DEPARTMENT_IMG;
            } else {
                return NO_PHOTO_IMG;
            }
        }
    }

    public boolean isDepartment(Employee employee) {
        if (employee == null) return false;
        return employee.getFullName() != null
                && employee.getDepartment() != null
                && employee.getFullName().equals(employee.getDepartment().getName());
    }

    public int compareByDepAndFullName(Employee e1, Employee e2) {
        if (e1 == e2) return 0;
        if (isDepartment(e1)) {
            if (isDepartment(e2))
                return e1.compareTo(e2);
            return -1;
        } else if (isDepartment(e2)) {
            return 1;
        }
        return e1.compareTo(e2);
    }

}