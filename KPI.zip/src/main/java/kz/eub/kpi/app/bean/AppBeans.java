package kz.eub.kpi.app.bean;

import io.jmix.core.DataManager;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class AppBeans implements InitializingBean {

    @Autowired
    private ApplicationContext context;

    private static AppBeans instance;

    @Override
    public void afterPropertiesSet() throws Exception {
        instance = this;
    }

    public static AppBeans getInstance() {
        return instance;
    }

    /**
     * Return the bean instance that matches the given object type.
     * If the provided bean class contains a public static field <code>NAME</code>, this name is used to look up the
     * bean to improve performance.
     * @param beanType type the bean must match; can be an interface or superclass. {@code null} is disallowed.
     * @return an instance of the single bean matching the required type
     */
    public <T> T getBean(Class<T> beanType) {
        return context.getBean(beanType);
    }

    /**
     * Return an instance of the specified bean.
     * @param name  the name of the bean to retrieve
     * @return      bean instance
     * @see         org.springframework.beans.factory.BeanFactory#getBean(java.lang.String)
     */
    @SuppressWarnings("unchecked")
    public <T> T getBean(String name) {
        return (T) context.getBean(name);
    }

    private DataManager getDataManager() {
        return getBean(DataManager.class);
    }

}
