package kz.eub.kpi.app.userprovider;

import io.jmix.bpm.provider.UserProvider;
import io.jmix.core.DataManager;
import io.jmix.core.entity.KeyValueEntity;
import io.jmix.core.querycondition.PropertyCondition;
import io.jmix.security.role.assignment.RoleAssignmentRoleType;
import kz.eub.kpi.app.service.EmployeeSecService;
import kz.eub.kpi.entity.Application;
import kz.eub.kpi.entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@UserProvider(value = "kpi_GeneralUserProvider")
public class GeneralUserProvider {

    @Autowired
    protected DataManager dataManager;
    @Autowired
    private EmployeeSecService employeeSecService;

    public List<Employee> getUsersByRoleCode(String roleCode) {
        return employeeSecService.loadEmployeesHavingRole(roleCode);
    }

    public String getAuthorSupervisor(Application application) {
        Employee author = application.getAuthor();
        return author.getSupervisor().getUsername();
    }

}
