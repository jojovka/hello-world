package kz.eub.kpi.app.service;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.core.querycondition.PropertyCondition;
import io.jmix.core.security.CurrentAuthentication;
import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import kz.eub.kpi.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;


import static kz.eub.kpi.screen.bonusprofile.BonusProfileScreen.NEW_DEBET_COUNT;

@Service("kpi_ProBonusService")
public class ProBonusService {
    @Autowired
    private FetchPlans fetchPlans;
    @Autowired
    private DataManager dataManager;
    @PersistenceContext
    private EntityManager entityManager;


    public Accounts reloadAccountById(Integer id) {
        if (id == null)
            return null;
        FetchPlan fetchPlan = getAccountFetchPlan();
        return dataManager.load(Accounts.class)
                .query("select c from kpi_Accounts c " +
                        "where c.id = :id")
                .parameter("id", id)
                .fetchPlan(fetchPlan)
                .optional().orElse(null);
    }

    public Competition reloadCompetitionUserById(Integer id) {
        if (id == null)
            return null;
        FetchPlan fetchPlan = getCompetitionPlan();
        return dataManager.load(Competition.class)
                .query("select c from kpi_Competition c " +
                        "where c.id = :id")
                .parameter("id", id)
                .fetchPlan(fetchPlan)
                .optional().orElse(null);
    }

    public AccountProfiles reloadAccountProfileById(Integer id) {
        if (id == null)
            return null;
        FetchPlan fetchPlan = getAccountProfilesFetchPlan();
        return dataManager.load(AccountProfiles.class)
                .query("select c from kpi_AccountProfiles c " +
                        "where c.id = :id")
                .parameter("id", id)
                .fetchPlan(fetchPlan)
                .optional().orElse(null);
    }

    public AccountVisits searchVisitByAccount(Integer accountId) {
        if (accountId == null)
            return null;
        Date date = new Date();
        return dataManager.load(AccountVisits.class)
                .query("select c from accountVisits c " +
                        "where c.accountId = :accountId and c.visited_at = :date")
                .parameter("accountId", accountId)
                .parameter("date", date)
                .optional().orElse(null);
    }

    public Employee reloadEmployeeByPayroll(String payroll) {
        if (payroll == null)
            return null;
        return dataManager.load(Employee.class)
                .query("select c from kpi_Employee c " +
                        "where c.payrollNumber = :payroll")
                .parameter("payroll", payroll)
                .optional().orElse(null);
    }

    public List<AccountProfiles> searchAccountByFio(String fio) {
        return dataManager.load(AccountProfiles.class)
                .query("select c from kpi_AccountProfiles c " +
                        "where c.lastname like :name " +
                        " or c.firstname like :name")
                .parameter("name", "(?i)%" + fio + "%")
                .list();
    }

    public Accounts reloadAccountsByPayroll(String payroll) {
        if (payroll == null)
            return null;
        return dataManager.load(Accounts.class)
                .query("select c from kpi_Accounts c " +
                        "where c.identityProperty = :payroll")
                .parameter("payroll", payroll)
                .fetchPlan(getAccountFetchPlan())
                .optional().orElse(null);
    }

    //TotalPremiBonus
    public PointUser reloadPointUserByType(Integer id, Integer typeId, Date lastMonth) {
        if (id == null)
            return null;
        FetchPlan fetchPlan = getPointUserFetchPlan();
        return dataManager.load(PointUser.class)
                .query("select c from kpi_PointUser c " +
                        "where c.accountId = :id and c.typeId = :typeId and c.createdAt > :lastMonth order by c.createdAt desc ")
                .parameter("id", id)
                .parameter("typeId", typeId)
                .parameter("lastMonth", lastMonth)
                .fetchPlan(fetchPlan)
                .optional()
                .orElse(dataManager.create(PointUser.class));
    }

    public RatingUser reloadRatingUserAuthority(Integer id, Integer typeId) {
        if (id == null)
            return null;
        FetchPlan fetchPlan = getRatingUserFetchPlan();
        return dataManager.load(RatingUser.class)
                .query("select c from kpi_RatingUser c " +
                        "where c.accountId.id = :id and c.typeId = :typeId order by c.createdAt desc ")
                .parameter("id", id)
                .parameter("typeId", typeId)
                .fetchPlan(fetchPlan)
                .optional()
                .orElse(dataManager.create(RatingUser.class));
    }

    public Duel reloadDuel(Integer id) {
        if (id == null)
            return null;
        return dataManager.load(Duel.class)
                .query("select c from kpi_Duel c " +
                        "where c.id = :id ")
                .parameter("id", id)
                .optional()
                .orElse(dataManager.create(Duel.class));
    }

    public List<Duel> reloadAllDuel() {
        return dataManager.load(Duel.class)
                .query("select c from kpi_Duel c ")
                .list();
    }

    public List<DuelContest> reloadAllContests() {
        return dataManager.load(DuelContest.class)
                .query("select c from kpi_DuelContest c where c.winner is not null")
                .list();
    }

    public List<BonusAuthority> reloadBonusAuthority() {
        return dataManager.load(BonusAuthority.class)
                .query("select c from kpi_BonusAuthority c")
                .fetchPlan(getBonusAuthorityFetchPlan())
                .list();
    }

    public Duel reloadDuelById(Integer id) {
        if (id == null)
            return null;
        FetchPlan fetchPlan = getDuelFetchPlan();
        return dataManager.load(Duel.class)
                .query("select c from kpi_Duel c " +
                        "where c.id = :id ")
                .parameter("id", id)
                .fetchPlan(fetchPlan)
                .optional()
                .orElse(dataManager.create(Duel.class));
    }

    public Award reloadAwardById(UUID id) {
        if (id == null)
            return null;
        FetchPlan fetchPlan = getAwardFetchPlan();
        return dataManager.load(Award.class)
                .query("select c from kpi_Award c " +
                        "where c.id = :id ")
                .parameter("id", id)
                .fetchPlan(fetchPlan)
                .optional()
                .orElse(dataManager.create(Award.class));
    }

    public DuelContest reloadOpenDuelContest() {
        FetchPlan fetchPlan = getDuelContestFetchPlan();
        return dataManager.load(DuelContest.class)
                .query("select c from kpi_DuelContest c " +
                        "where c.winner is null")
                .optional()
                .orElse(dataManager.create(DuelContest.class));
    }

    public List<PointUser> reloadPointUserByPN(Integer accountId, Date date) {
        if (accountId == null)
            return null;

        List resultList = entityManager.createNativeQuery(
                        "select distinct on (type_id) p.id " +
                                "from probonus.point_user p where p.account_id = #accountId " +
                                "and p.created_at > #date " +
                                "order by p.type_id, p.created_at desc")
                .setParameter("accountId", accountId)
                .setParameter("date", date)
                .getResultList();

        List<Integer> collect = new ArrayList<>();
        for (Iterator it = resultList.iterator(); it.hasNext(); ) {
            Integer b = (Integer) it.next();
            collect.add(b);
        }
        List<PointUser> ratingUsers = new ArrayList<>();
        if (collect.size() == 0) return ratingUsers;
        ratingUsers = dataManager.load(PointUser.class)
                .condition(PropertyCondition.inList("id", collect))
                .list();

        return ratingUsers;
    }

    public List<PointUser> reloadPointUserOldDate(Integer accountId, Date date, Date oldDate) {
        if (accountId == null)
            return null;

        List resultList = entityManager.createNativeQuery(
                        "select distinct on (type_id) p.id " +
                                "from probonus.point_user p where p.account_id = #accountId " +
                                "and p.created_at < #date and p.created_at > #oldDate " +
                                "order by p.type_id, p.created_at desc")
                .setParameter("accountId", accountId)
                .setParameter("date", date)
                .setParameter("oldDate", oldDate)
                .getResultList();

        List<Integer> collect = new ArrayList<>();
        for (Iterator it = resultList.iterator(); it.hasNext(); ) {
            Integer b = (Integer) it.next();
            collect.add(b);
        }
        if (collect.size() == 0) return Collections.emptyList();
        List<PointUser> ratingUsers = dataManager.load(PointUser.class)
                .condition(PropertyCondition.inList("id", collect))
                .list();

        return ratingUsers;
    }

    public List<Employee> loadDepPositions(String department, String position) {
        List resultList = entityManager.createNativeQuery(
                        "select ke.id from kpi_employee ke " +
                                "inner join ( " +
                                "                select a2.identity_property as pn from probonus.kpi_account_custom_storage a " +
                                "inner join probonus.accounts a2 on a2.id = a.account_id  " +
                                "                where value->> 'department' = #department " +
                                "                and value->> 'position' = #position " +
                                "        ) as pb on pb.pn = ke.payroll_number ")
                .setParameter("department", department)
                .setParameter("position", position)
                .getResultList();

        List<UUID> collect = new ArrayList<>();
        for (Iterator it = resultList.iterator(); it.hasNext(); ) {
            UUID b = (UUID) it.next();
            collect.add(b);
        }
        if (collect.size() == 0) return Collections.emptyList();
        List<Employee> ratingUsers = dataManager.load(Employee.class)
                .condition(PropertyCondition.inList("id", collect))
                .list();

        return ratingUsers;
    }

    public List<String> loadPositionsByDep(String department) {
        List resultList = entityManager.createNativeQuery(
                        "select distinct value->>'position' from probonus.kpi_account_custom_storage a " +
                                "where value->>'department' = #department")
                .setParameter("department", department)
                .getResultList();
        return resultList;
    }

    public String loadDepartmentByAccount(Integer accountId) {
        var result = entityManager.createNativeQuery(
                        "select distinct value->>'department' from probonus.kpi_account_custom_storage a " +
                                "where a.account_id = #accountId")
                .setParameter("accountId", accountId);

        if (result.getSingleResult() == null)
            return null;
        return result.getSingleResult().toString();
    }

    public DuelContest reloadOpenDuelContestByType(Integer duelId) {
        FetchPlan fetchPlan = getDuelContestFetchPlan();
        return dataManager.load(DuelContest.class)
                .query("select c from kpi_DuelContest c " +
                        "where c.winner is null and c.duelId.id = :id ")
                .parameter("id", duelId)
                .optional()
                .orElse(dataManager.create(DuelContest.class));
    }


    public PointUser reloadPointUserOldDateByType(Integer id, Integer typeId, Date lastMonth) {
        if (id == null)
            return null;
        FetchPlan fetchPlan = getPointUserFetchPlan();
        return dataManager.load(PointUser.class)
                .query("select c from kpi_PointUser c " +
                        "where c.accountId = :id and c.typeId = :typeId and c.createdAt < :lastMonth order by c.createdAt desc ")
                .parameter("id", id)
                .parameter("typeId", typeId)
                .parameter("lastMonth", lastMonth)
                .fetchPlan(fetchPlan)
                .optional()
                .orElse(dataManager.create(PointUser.class));
    }

    public RatingUser reloadRatingUserOldDateByType(Integer id, Integer typeId, Date lastMonth) {
        if (id == null)
            return null;
        FetchPlan fetchPlan = getRatingUserFetchPlan();
        return dataManager.load(RatingUser.class)
                .query("select c from kpi_RatingUser c " +
                        "where c.accountId.id = :id and c.typeId = :typeId and c.createdAt < :lastMonth order by c.createdAt desc ")
                .parameter("id", id)
                .parameter("typeId", typeId)
                .parameter("lastMonth", lastMonth)
                .fetchPlan(fetchPlan)
                .optional()
                .orElse(dataManager.create(RatingUser.class));
    }


    public List<PointUser> reloadPointTypeBetweenDateByType(Date dateStart, Date dateEnd, Integer typeId) {
        FetchPlan fetchPlan = getPointUserFetchPlan();
        return dataManager.load(PointUser.class)
                .query("select c from kpi_PointUser c " +
                        "where c.typeId = :typeId and (c.createdAt > :dateStart and c.createdAt < :dateEnd) ")
                .parameter("typeId", typeId)
                .parameter("dateStart", dateStart)
                .parameter("dateEnd", dateEnd)
                .fetchPlan(fetchPlan)
                .list();
    }

    public List<Contracts> zaimPdfCount(Integer id, Date lastMonth) {
        if (id == null)
            return null;
        return dataManager.load(Contracts.class)
                .query("select c from kpi_Contracts c " +
                        "where c.userId = :id and c.createdAt >= :lastMonth")
                .parameter("id", id)
                .parameter("lastMonth", lastMonth)
                .list();
    }

    public List<Contracts> zaimPdfCountOld(Integer id, Date lastMonth, Date currentDate) {
        if (id == null)
            return null;
        return dataManager.load(Contracts.class)
                .query("select c from kpi_Contracts c " +
                        "where c.userId = :id and c.createdAt <= :currentDate and c.createdAt >= :lastMonth")
                .parameter("id", id)
                .parameter("lastMonth", lastMonth)
                .parameter("currentDate", currentDate)
                .list();
    }

    public List<DuelContest> reloadAllContestsByDate(Date dateStart, Date dateEnd) {
        return dataManager.load(DuelContest.class)
                .query("select c from kpi_DuelContest c " +
                        "where (c.created_date >= :dateStart and c.created_date <= :dateEnd) order by c.created_date")
                .parameter("dateStart", dateStart)
                .parameter("dateEnd", dateEnd)
                .fetchPlan(getDuelContestFetchPlan())
                .list();
    }
    public List<AccountVisits> reloadVisitsBetweenDateByType(Date dateStart, Date dateEnd) {
        return dataManager.load(AccountVisits.class)
                .query("select c from accountVisits c " +
                        "where (c.visited_at >= :dateStart and c.visited_at <= :dateEnd) order by c.visited_at ")
                .parameter("dateStart", dateStart)
                .parameter("dateEnd", dateEnd)
                .list();
    }

    public List<RatingUser> loadRatings() {
        List resultList = entityManager.createNativeQuery(
                        "select id from ( " +
                                "                select row_number() over(partition by account_id " +
                                "                        order by account_id, created_at desc) rn, created_at, id, account_id, type_id, period_id, value " +
                                "                FROM probonus.rating_user x " +
                                "                where period_id in (1,103,104,105,107,108,109,114,120,112,116) " +
                                "        ) tt where rn = 1")
                .getResultList();

        List<Integer> collect = new ArrayList<>();

        for (Iterator it = resultList.iterator(); it.hasNext(); ) {
            Integer b = (Integer) it.next();
            collect.add(b);
        }
        if (collect.size() == 0) return Collections.emptyList();
        List<RatingUser> ratingUsers = dataManager.load(RatingUser.class)
                .condition(PropertyCondition.inList("id", collect))
                .list();

        return ratingUsers;
    }

    public List<RatingUser> loadRatingByDepPos(Integer positionId) {
        List resultList = entityManager.createNativeQuery(
                        "select id from ( " +
                                "                select row_number() over(partition by account_id " +
                                "                        order by account_id, created_at desc) rn, created_at, id, account_id, type_id, period_id, value " +
                                "                FROM probonus.rating_user x " +
                                "                where period_id in (1,103,104,105,107,108,109,114,120,112,116) and position = :position" +
                                "        ) tt where rn = 1")
                .setParameter("position", positionId)
                .getResultList();

        List<Integer> collect = new ArrayList<>();

        for (Iterator it = resultList.iterator(); it.hasNext(); ) {
            Integer b = (Integer) it.next();
            collect.add(b);
        }
        if (collect.size() == 0) return Collections.emptyList();
        List<RatingUser> ratingUsers = dataManager.load(RatingUser.class)
                .condition(PropertyCondition.inList("id", collect))
                .list();

        return ratingUsers;
    }

    public RatingUser loadRatingUserByPayroll(String pn) {
        List resultList = entityManager.createNativeQuery(
                        "select ru.id from probonus.rating_user ru " +
                                "left join probonus.accounts a on a.id = ru.account_id " +
                                " where a.identity_property = #pn " +
                                " and ru.period_id in (1,103,104,105,107,108,109,114,120,112,116) ")
                .setParameter("pn", pn)
                .getResultList();

        if (resultList.size() == 0) {
            resultList = entityManager.createNativeQuery(
                            "select ru.id from probonus.rating_user ru " +
                                    "left join probonus.accounts a on a.id = ru.account_id " +
                                    " where a.identity_property = #pn " +
                                    " and ru.value = 0")
                    .setParameter("pn", pn)
                    .getResultList();
        }
        List<Integer> collect = new ArrayList<>();

        for (Iterator it = resultList.iterator(); it.hasNext(); ) {
            Integer b = (Integer) it.next();
            collect.add(b);
        }
        RatingUser ratingUsers = null;
        FetchPlan fetchPlan = getRatingUserPlan();
        if (collect.size() != 0) {
            ratingUsers = dataManager.load(RatingUser.class)
                    .query("select c from kpi_RatingUser c " +
                            "where c.id = :id")
                    .parameter("id", collect.get(0))
                    .fetchPlan(fetchPlan)
                    .optional().get();
        }
        return ratingUsers;
    }

    public List<Accounts> loadAccountsByCompetition(Competition competition) {
        List resultList = entityManager.createNativeQuery(
                        "select a.id from probonus.accounts a " +
                                "inner join kpi_employee ke on a.identity_property = ke.payroll_number " +
                                "inner join kpi_dict_position kdp on kdp.id = ke.position_id " +
                                "inner join kpi_dict_department kdd on kdd.id = ke.department_id " +
                                "where kdd.branch = #branch " +
                                "and kdp.name = #position ")
                .setParameter("branch", competition.getBranch())
                .setParameter("position", competition.getPosition())
                .getResultList();

        List<Integer> collect = new ArrayList<>();

        for (Iterator it = resultList.iterator(); it.hasNext(); ) {
            Integer b = (Integer) it.next();
            collect.add(b);
        }
        List<Accounts> accountsList = new ArrayList<>();
        FetchPlan fetchPlan = getAccountFetchPlan();
        collect.forEach(coll -> {
            Accounts account = dataManager.load(Accounts.class)
                    .query("select c from kpi_Accounts c " +
                            "where c.id = :id")
                    .parameter("id", coll)
                    .fetchPlan(fetchPlan)
                    .optional().get();

            Calendar myCal1 = Calendar.getInstance();
            myCal1.set(Calendar.YEAR, 2022);
            myCal1.set(Calendar.MONTH, 11);
            myCal1.set(Calendar.DAY_OF_MONTH, 30);
            Date theDate1 = myCal1.getTime();

            PointUser pointUser = reloadPointUserByType(account.getId(), NEW_DEBET_COUNT, theDate1);
            if (pointUser != null && pointUser.getValue() != null && pointUser.getValue() > competition.getAktivCard()) {
                account.setStateId(pointUser.getValue().intValue());
                accountsList.add(account);
            }

        });
        return accountsList;
    }

    private FetchPlan getAccountFetchPlan() {
        return fetchPlans.builder(Accounts.class)
                .addFetchPlan(FetchPlan.BASE)
                .add("profileId", FetchPlan.BASE)
                .add("employee", FetchPlan.BASE)
                .build();
    }

    private FetchPlan getCompetitionPlan() {
        return fetchPlans.builder(Competition.class)
                .addFetchPlan(FetchPlan.BASE)
                .build();
    }

    private FetchPlan getAccountProfilesFetchPlan() {
        return fetchPlans.builder(AccountProfiles.class)
                .addFetchPlan(FetchPlan.BASE)

                .build();
    }

    private FetchPlan getPointUserFetchPlan() {
        return fetchPlans.builder(PointUser.class)
                .addFetchPlan(FetchPlan.BASE)
                .build();
    }

    private FetchPlan getRatingUserFetchPlan() {
        return fetchPlans.builder(RatingUser.class)
                .addFetchPlan(FetchPlan.BASE)
                .build();
    }

    private FetchPlan getDuelContestFetchPlan() {
        return fetchPlans.builder(DuelContest.class)
                .addFetchPlan(FetchPlan.BASE)
                .add("contester")
                .add("opponent")
                .add("winnerStaff")
//                .add("duelId")
                .build();
    }


    private FetchPlan getBonusAuthorityFetchPlan() {
        return fetchPlans.builder(BonusAuthority.class)
                .addFetchPlan(FetchPlan.BASE)
                .add("employee", FetchPlan.BASE)
                .build();
    }
    private FetchPlan getDuelFetchPlan() {
        return fetchPlans.builder(Duel.class)
                .addFetchPlan(FetchPlan.BASE)

                .build();
    }

    private FetchPlan getAwardFetchPlan() {
        return fetchPlans.builder(Award.class)
                .addFetchPlan(FetchPlan.BASE)
                .add("employee", FetchPlan.BASE)
                .build();
    }

    private FetchPlan getRatingUserPlan() {
        return fetchPlans.builder(RatingUser.class)
                .addFetchPlan(FetchPlan.BASE)
                .add("accountId", FetchPlan.BASE)
                .add("createdAt", FetchPlan.BASE)
                .add("typeId", FetchPlan.BASE)
                .add("id", FetchPlan.BASE)
                .add("value", FetchPlan.BASE)
                .add("payrollNumber", FetchPlan.BASE)
                .build();
    }


    private FetchPlan getEmployeeFetchPlan() {
        return fetchPlans.builder(Employee.class)
                .addFetchPlan(FetchPlan.BASE)
                .add("fullName", FetchPlan.BASE)
                .build();
    }
}
