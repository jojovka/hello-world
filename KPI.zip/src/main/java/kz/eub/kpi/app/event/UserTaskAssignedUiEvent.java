package kz.eub.kpi.app.event;

import io.jmix.bpm.engine.events.UserTaskAssignedEvent;
import org.springframework.context.ApplicationEvent;

public class UserTaskAssignedUiEvent extends ApplicationEvent {

    public UserTaskAssignedUiEvent(UserTaskAssignedEvent source) {
        super(source);
    }

    @Override
    public UserTaskAssignedEvent getSource() {
        return (UserTaskAssignedEvent) super.getSource();
    }

}