package kz.eub.kpi.app.service;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.core.querycondition.PropertyCondition;
import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service("kpi_EmployeeService")
public class EmployeeService {

    public static final int TRIAL_PERIOD_DAYS = 90;

    @Autowired
    private FetchPlans fetchPlans;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private CurrentUserSubstitution currentUserSubstitution;
    @PersistenceContext
    private EntityManager em;
    @Autowired
    private OrgChartService orgChartService;


    public Employee getCurrentEmployee() {
        try {
            return reloadEmployeeByUsername(currentUserSubstitution.getEffectiveUser().getUsername(), getEmployeeFetchPlan());
        } catch (UsernameNotFoundException e) {
            return null;
        }
    }

    public Employee reloadEmployeeById(UUID id) {
        if (id == null)
            return null;
        FetchPlan fetchPlan = getEmployeeFetchPlan();
        return dataManager.load(Employee.class)
                .query("select c from kpi_Employee c " +
                        "where c.id = :id")
                .parameter("id", id)
                .fetchPlan(fetchPlan)
                .optional().orElse(null);
    }

    public Employee reloadEmployeeByUsername(String username) {
        if (username == null)
            return null;
        FetchPlan baseFetchPlan = fetchPlans.builder(Employee.class)
                .addFetchPlan(FetchPlan.BASE).build();
        return reloadEmployeeByUsername(username, baseFetchPlan);
    }

    public Employee reloadEmployeeByUsername(String username, FetchPlan fetchPlan) {
        if (username == null)
            return null;
        return dataManager.load(Employee.class)
                .query("select c from kpi_Employee c " +
                        "where c.username = :username")
                .parameter("username", username)
                .fetchPlan(fetchPlan)
                .optional().orElse(null);
    }

    public Employee reloadEmployeeWithFetchPlan(Employee employee, FetchPlan fetchPlan) {
        return dataManager.load(Employee.class)
                .id(employee.getId())
                .fetchPlan(fetchPlan)
                .one();
    }

    public FetchPlan getEmployeeFetchPlan() {
        return fetchPlans.builder(Employee.class)
                .addFetchPlan(FetchPlan.BASE)
                .add("department", FetchPlan.BASE)
                .add("orgUnit", FetchPlan.BASE)
                .add("position", FetchPlan.BASE)
                .add("supervisor", FetchPlan.BASE)
                .add("leader", FetchPlan.BASE)
                .build();
    }

    public boolean checkUserExistsByUsername(String username) {
        return em.createNativeQuery("select u.id from kpi_user u " +
                        "where u.username = ?")
                .setParameter(1, username)
                .getResultList()
                .size() > 0;
    }

    public boolean isHqEmployee(Employee employee) {
        if (employee == null
                || employee.getDepartment() == null
                || employee.getDepartment().getBranch() == null)
            return false;
        return employee.getDepartment().getBranch().startsWith("Головной");
    }

    public boolean isBranchEmployee(Employee employee) {
        if (employee == null
                || employee.getDepartment() == null
                || employee.getDepartment().getBranch() == null)
            return false;
        return employee.getDepartment().getBranch().startsWith("Филиал");
    }

    public List<Employee> searchEmployee(String fio) {
        return dataManager.load(Employee.class)
                .query("select c from kpi_Employee c " +
                        "where c.fullName like :name")
                .parameter("name", "(?i)%" + fio + "%")
                .list();
    }

    public List<Employee> getDepartmentEmployees(DictDepartment department) {
        return dataManager.load(Employee.class)
                .condition(PropertyCondition.equal("department", department))
                .list();
    }

    public List<Employee> getAllDepartmentSubTreeEmployees(DictDepartment department) {
        List<UUID> idList = orgChartService.getDepartmentSubTreeIdList(department.getId());
        if (idList.size() == 0) return Collections.emptyList();
        return dataManager.load(Employee.class)
                .condition(PropertyCondition.inList("department.id", idList))
                .list();
    }

    public Date getEmployeeTrialPeriodEndDate(Employee employee) {
        Date startDate = employee.getStartDate();
        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);
        cal.add(Calendar.DAY_OF_YEAR, TRIAL_PERIOD_DAYS);
        return cal.getTime();
    }

    public Employee getFunctionalManager(Employee employee) {
        employee = reloadEmployeeById(employee.getId());
        return employee.getFunctionalManager();
    }

    public Employee loadEmployeeByPayrollNumber(String payrollNumber) {
        return dataManager.load(Employee.class)
                .condition(PropertyCondition.equal("payrollNumber", payrollNumber))
                .fetchPlan(getEmployeeFetchPlan())
                .optional().orElse(null);
    }

    public DictDepartment getDepartmentById(UUID uuid) {
        return dataManager.load(DictDepartment.class)
                .id(uuid).optional().orElse(null);
    }

    public DictDepartment getDepartmentBySapId(String sapId) {
        return dataManager.load(DictDepartment.class)
                .query("select c from kpi_DictDepartment c " +
                        "where c.sapId = :sapId " +
                        "and c.endDate > current_date ")
                .parameter("sapId", sapId)
                .optional().orElse(null);
    }

}