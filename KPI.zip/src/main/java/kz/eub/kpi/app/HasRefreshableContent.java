package kz.eub.kpi.app;

public interface HasRefreshableContent {

    void refreshContent();

}
