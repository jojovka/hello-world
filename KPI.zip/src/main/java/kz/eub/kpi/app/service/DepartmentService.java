package kz.eub.kpi.app.service;

import com.google.common.base.Strings;
import io.jmix.core.DataManager;
import io.jmix.core.Sort;
import io.jmix.core.querycondition.LogicalCondition;
import io.jmix.core.querycondition.PropertyCondition;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.GvkDepartment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component("kpi_DepartmentService")
public class DepartmentService {

    @Autowired
    private DataManager dataManager;

    public DictDepartment reloadActualDepartmentBySapId(DictDepartment department) {
        if (department == null || department.getSapId() == null) return department;
        return dataManager.load(DictDepartment.class)
                .condition(
                        LogicalCondition.and(
                            PropertyCondition.equal("sapId", department.getSapId()),
                            PropertyCondition.greater("endDate", new Date())
                        )
                )
                .sort(Sort.by(Sort.Direction.DESC, "createdDate"))
                .maxResults(1)
                .optional().orElse(null);
    }

    public DictDepartment getDepartmentBySapId(String sapId) {
        if (Strings.isNullOrEmpty(sapId)) return null;
        return dataManager.load(DictDepartment.class)
                .condition(
                        LogicalCondition.and(
                                PropertyCondition.equal("sapId", sapId),
                                PropertyCondition.greater("endDate", new Date())
                        )
                )
                .sort(Sort.by(Sort.Direction.DESC, "createdDate"))
                .maxResults(1)
                .optional().orElse(null);
    }

    public boolean isEqualOrChildOfGvkDepartment(DictDepartment department) {
        List<GvkDepartment> gvkDepartments = dataManager.load(GvkDepartment.class)
                .all().list();
        for (GvkDepartment gvkDep : gvkDepartments) {
            if (department.isEqualOrChildOfParentSapId(gvkDep.getSapId()))
                return true;
        }
        return false;
    }

}