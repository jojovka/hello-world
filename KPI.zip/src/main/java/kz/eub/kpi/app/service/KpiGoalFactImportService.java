package kz.eub.kpi.app.service;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.SaveContext;
import io.jmix.core.querycondition.LogicalCondition;
import io.jmix.core.querycondition.PropertyCondition;
import kz.eub.kpi.entity.kpi.EKpiGoalCategory;
import kz.eub.kpi.entity.kpi.KpiCard;
import kz.eub.kpi.entity.kpi.KpiGoal;
import kz.eub.kpi.entity.kpi.KpiGoalDict;
import kz.eub.kpi.entity.kpi.KpiGoalDictFact;
import kz.eub.kpi.entity.kpi.KpiGoalDictPlan;
import kz.eub.kpi.entity.kpi.KpiGoalFactImportDoc;
import kz.eub.kpi.entity.kpi.KpiPeriod;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

@Component("kpi_KpiGoalFactImportService")
public class KpiGoalFactImportService {

    public static final Logger log = LoggerFactory.getLogger(KpiGoalFactImportService.class);
    @Autowired
    private DataManager dataManager;
    @Autowired
    private KpiCardService kpiCardService;
    @Autowired
    private KpiGoalSummaryService kpiGoalSummaryService;

    public List<KpiGoalDictFact> importGoalFacts(byte[] fileByteArray, KpiGoalFactImportDoc importDoc) throws IOException {
        List<KpiGoalDictFact> goalDictFacts = new ArrayList<>();
        InputStream file = new ByteArrayInputStream(fileByteArray);
        Workbook workbook = new XSSFWorkbook(file);

        Sheet sheet = workbook.getSheetAt(0);
        Iterator<Row> iterator = sheet.iterator();
        iterator.next();    // skip header row
        while (iterator.hasNext()) {
            Row row = iterator.next();
            KpiGoalDictFact goalFact = dataManager.create(KpiGoalDictFact.class);
            goalFact.setGoalImportDoc(importDoc);
            goalFact.setPeriod(importDoc.getPeriod());

            KpiGoalDictPlan goalDictPlan = getKpiGoalDictPlanFromRow(row);
            if (goalDictPlan == null) continue;
            goalFact.setGoalDict(goalDictPlan.getGoalDict());
            goalFact.setGoalDictPlan(goalDictPlan);

            Cell cell = row.getCell(7);
            if (cell.getCellType().equals(CellType.NUMERIC)) {
                double numericCellValue = cell.getNumericCellValue();
                BigDecimal fact = new BigDecimal(numericCellValue);
                goalFact.setFact(fact);
            } else
                continue;

            goalDictFacts.add(goalFact);
        }
        return goalDictFacts;
    }

    private KpiGoalDictPlan getKpiGoalDictPlanFromRow(Row row) {
        Cell cell = row.getCell(0);
        if (cell.getCellType().equals(CellType.STRING)) {
            String uuidStr = cell.getStringCellValue();
            UUID uuid = UUID.fromString(uuidStr);
            return dataManager.load(KpiGoalDictPlan.class)
                    .id(uuid)
                    .fetchPlan(fp -> fp.addFetchPlan(FetchPlan.BASE)
                            .add("goalDict", FetchPlan.BASE))
                    .optional().orElse(null);
        }
        return null;
    }


    public int distributeGoalFacts(EKpiGoalCategory category, KpiPeriod period, List<KpiGoalDictFact> goalDictFacts) {
        int count = 0;
        List<KpiGoal> goalsList = dataManager.load(KpiGoal.class)
                .condition(
                        LogicalCondition.and(
                                PropertyCondition.equal("category", category),
                                PropertyCondition.equal("period", period)
                        ))
                .fetchPlan(FetchPlan.BASE)
                .list();
        SaveContext saveContext = new SaveContext();
        List<KpiGoal> updatedGoalsList = new ArrayList<>();
        for (KpiGoalDictFact goalFact : goalDictFacts) {
            List<KpiGoal> goals = getGoalsByDict(goalFact.getGoalDict(), goalsList);
            for (KpiGoal goal : goals) {
                goal.setFact(goalFact.getFact());
                goal = kpiGoalSummaryService.calcPerformanceAndEfficiency(goal);
                updatedGoalsList.add(goal);
                saveContext.saving(goal);
                count++;
            }
        }
        dataManager.save(saveContext);
        updateTotalKpi(updatedGoalsList);
        return count;
    }

    private void updateTotalKpi(List<KpiGoal> updatedGoalsList) {
        List<UUID> uuidList = updatedGoalsList.stream()
                .map(KpiGoal::getKpiCard).map(KpiCard::getId)
                .distinct().collect(Collectors.toList());
        if (uuidList.size() == 0) return;
        List<KpiCard> cardList = dataManager.load(KpiCard.class)
                .condition(PropertyCondition.inList("id", uuidList))
                .list();
        SaveContext saveContext = new SaveContext();
        for (KpiCard card : cardList) {
            kpiCardService.calcTotalKpi(card);
            saveContext.saving(card);
        }
        dataManager.save(saveContext);
    }

    private List<KpiGoal> getGoalsByDict(KpiGoalDict goalDict, List<KpiGoal> goalsList) {
        List<KpiGoal> goals = new ArrayList<>();
        for (KpiGoal goal : goalsList) {
            if (Objects.equals(goal.getGoalDict(), goalDict))
                goals.add(goal);
        }
        return goals;
    }

}