package kz.eub.kpi.app.listener;

import com.vaadin.spring.annotation.UIScope;
import io.jmix.bpm.engine.events.UserTaskAssignedEvent;
import io.jmix.core.Messages;
import io.jmix.email.EmailException;
import io.jmix.emailtemplates.EmailTemplates;
import io.jmix.emailtemplates.exception.ReportParameterTypeChangedException;
import io.jmix.emailtemplates.exception.TemplateNotFoundException;
import io.jmix.ui.navigation.UrlRouting;
import kz.eub.kpi.app.bean.GlobalUiEventPublisher;
import kz.eub.kpi.app.event.UserTaskAssignedUiEvent;
import kz.eub.kpi.app.service.BpmUserTaskService;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.entity.Application;
import kz.eub.kpi.entity.Employee;
import org.flowable.task.api.Task;
import org.flowable.variable.api.persistence.entity.VariableInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.HashMap;
import java.util.Map;

@UIScope
@Component("kpi_UserTaskNotifier")
public class UserTaskNotifier {

    public static final Logger log = LoggerFactory.getLogger(UserTaskNotifier.class);

    public static final String TASK_NOTIFICATION_EMAIL_TEMPLATE = "task-notification";

    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private GlobalUiEventPublisher globalUiEventPublisher;
    @Autowired
    private EmailTemplates emailTemplates;
    @Autowired
    private BpmUserTaskService bpmUserTaskService;
    @Autowired
    private UrlRouting urlRouting;
    @Autowired
    private Messages messages;


    @EventListener
    public void onTaskAssigned(UserTaskAssignedEvent event) {
        try {
            Employee employee = employeeService.reloadEmployeeByUsername(event.getUsername());
            Task task = event.getTask();
            VariableInstance varApplication = bpmUserTaskService.getVariableInstance(task.getId(), Application.BPM_VARIABLE_NAME);
            Application application = (Application) varApplication.getValue();
//            String uriString = ServletUriComponentsBuilder.fromCurrentContextPath().build().toUriString();
//            uriString = uriString.concat("/" + application.getRouteUri());
            String route = urlRouting.getRouteGenerator().getEditorRoute(application);

            Map<String, Object> params = new HashMap<>();
            params.put(Application.BPM_VARIABLE_NAME, application);
            params.put("task", task);
            params.put("employee", employee);
            params.put("author", application.getAuthor());
            String status = messages.getMessage(application.getStatus());
            params.put("status", status);
            params.put("uri", route);
            sendEmailTemplateWithParams(TASK_NOTIFICATION_EMAIL_TEMPLATE, employee.getEmail(), params);

            UserTaskAssignedUiEvent customEvent = new UserTaskAssignedUiEvent(event);
            globalUiEventPublisher.publishEvent(customEvent);
        } catch (Exception e) {
            throw new RuntimeException("Error while trying to send a UserTaskNotification... ", e);
        }
    }

    public void sendEmailTemplateWithParams(String templateCode, String recipients, Map<String, Object> params) {
        try {
            emailTemplates.buildFromTemplate(templateCode)
                    .setTo(recipients)
                    .setBodyParameters(params)
                    .sendEmail();
        } catch (TemplateNotFoundException e) {
            throw new RuntimeException("Шаблон письма не найден: ", e);
        } catch (ReportParameterTypeChangedException e) {
            throw new RuntimeException("Тип параметра отчета изменен: ", e);
        } catch (EmailException e) {
            log.error("Ошибка при попытке отправить письмо: ", e);
        }
    }

}