package kz.eub.kpi.app.service;

import com.google.common.base.Strings;
import io.jmix.appsettings.AppSettings;
import io.jmix.audit.entity.EntityLogAttr;
import io.jmix.audit.entity.EntityLogItem;
import io.jmix.core.DataManager;
import io.jmix.core.EntityStates;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.core.SaveContext;
import io.jmix.core.querycondition.LogicalCondition;
import io.jmix.core.querycondition.PropertyCondition;
import kz.eub.kpi.app.bean.KpiGeneralUtils;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.DictPosition;
import kz.eub.kpi.entity.EQuarter;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.kpi.EKpiCardStage;
import kz.eub.kpi.entity.kpi.EKpiGoalCategory;
import kz.eub.kpi.entity.kpi.EKpiGoalStatus;
import kz.eub.kpi.entity.kpi.KpiCard;
import kz.eub.kpi.entity.kpi.KpiCardSettings;
import kz.eub.kpi.entity.kpi.KpiGoal;
import kz.eub.kpi.entity.kpi.KpiPeriod;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

@Service("kpi_KpiCardService")
public class KpiCardService extends ApplicationGenericService<KpiCard> {

    private static final Logger log = LoggerFactory.getLogger(KpiCardService.class);
    @Autowired
    private DataManager dataManager;
    @Autowired
    private FetchPlans fetchPlans;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private KpiGeneralUtils kpiGeneralUtils;
    @Autowired
    private EntityStates entityStates;
    @Autowired
    private DepartmentService departmentService;
    @Autowired
    private KpiGoalSummaryService kpiGoalSummaryService;
    @Autowired
    private AppSettings appSettings;
    @Autowired
    private KpiGoalService kpiGoalService;

    public KpiCardService() {
        super(KpiCard.class);
    }

    public boolean validateKpiCard(KpiCard card) {
        if (card.getAuthor() == null)
            throw new IllegalStateException("Укажите инициатора.");

        if (card.getKpiGoals() == null)
            throw new IllegalStateException("Цели отсутствуют.");

        if (card.getKpiGoals().size() < KpiCard.MIN_ALLOWED_GOALS
                && Objects.equals(card.getStage(), EKpiCardStage.FIRST_STAGE))
            throw new IllegalStateException(String.format("Количество целей должно быть не меньше %d.", KpiCard.MIN_ALLOWED_GOALS));

        if (card.getKpiGoals().size() > KpiCard.MAX_ALLOWED_GOALS)
            throw new IllegalStateException(String.format("Количество целей должно быть не больше %d.", KpiCard.MAX_ALLOWED_GOALS));

        validateKpiGoals(card);

        return true;
    }

    private void validateKpiGoals(KpiCard card) {
        List<KpiGoal> kpiGoals = card.getKpiGoals();
        BigDecimal totalWeight = BigDecimal.ZERO;
        for (KpiGoal goal : kpiGoals) {
            validateGoal(goal);
            totalWeight = totalWeight.add(goal.getWeight());
        }

        if (totalWeight.compareTo(new BigDecimal(100)) != 0)
            throw new IllegalStateException("Суммарный вес целей должна быть равна 100. Сотрудник: " + card.getAuthor().getFullName());
    }

    public void validateGoal(KpiGoal goal) {
        if (goal.getWeight() == null)
            throw new IllegalStateException(String.format("Вес цели не может иметь пустое значение.  Цель №%s", goal.getSn()));
        if (goal.getWeight().compareTo(BigDecimal.ZERO) < 0)
            throw new IllegalStateException(String.format("Вес цели не может иметь отрицательное значение.  Цель №%s", goal.getSn()));
        if (goal.getPlan() == null && goal.getPlanDate() == null)
            throw new IllegalStateException(String.format("Укажите плановое значение цели №%s", goal.getSn()));
        if (goal.getUnit() == null)
            throw new IllegalStateException(String.format("Укажите единицу измерения цели №%s", goal.getSn()));
        if (goal.getAssessmentType() == null)
            throw new IllegalStateException(String.format("Укажите признак оценки цели №%s", goal.getSn()));
        if (goal.getName() == null
                || Strings.isNullOrEmpty(goal.getName()))
            throw new IllegalStateException(String.format("Укажите название цели №%s", goal.getSn()));
        if (goal.getKpiDescription() == null
                || Strings.isNullOrEmpty(goal.getKpiDescription()))
            throw new IllegalStateException(String.format("Укажите описание цели №%s", goal.getSn()));
        if (goal.getPeriod() == null)
            throw new IllegalStateException(String.format("Укажите период оценки цели №%s", goal.getSn()));
        if (goal.getEmployee() == null)
            throw new IllegalStateException(String.format("Укажите сотрудника цели №%s", goal.getSn()));
        if (goal.getDepartment() == null)
            throw new IllegalStateException(String.format("Укажите подразделение цели №%s", goal.getSn()));
        if (goal.getCategory() == null)
            throw new IllegalStateException(String.format("Укажите категорию цели №%s", goal.getSn()));
    }

    public boolean hasGoalCategory(KpiCard card, String categoryId) {
        EKpiGoalCategory category = EKpiGoalCategory.fromId(categoryId);
        for (KpiGoal goal : card.getKpiGoals()) {
            if (goal.getCategory() != null
                    && goal.getCategory().equals(category)
                    && !Objects.equals(goal.getStatus(), EKpiGoalStatus.APPROVED))
                return true;
        }
        return false;
    }

    public boolean hasRejectedGoals(KpiCard card) {
        for (KpiGoal goal : card.getKpiGoals()) {
            if (!Objects.equals(goal.getStatus(), EKpiGoalStatus.APPROVED))
                return true;
        }
        return false;
    }

    public void approveGoalsByCategoryId(KpiCard card, String categoryId) {
        EKpiGoalCategory category = EKpiGoalCategory.fromId(categoryId);
        card = dataManager.load(KpiCard.class)
                .id(card.getId())
                .optional()
                .orElse(null);
        if (card == null) return;
        SaveContext saveContext = new SaveContext().setDiscardSaved(true);
        for (KpiGoal goal : card.getKpiGoals()) {
            if (goal.getCategory() != null
                    && goal.getCategory().equals(category)
                    && !Objects.equals(goal.getStatus(), EKpiGoalStatus.APPROVED)) {
                goal.setStatus(EKpiGoalStatus.APPROVED);
                saveContext.saving(goal);
            }
        }
        dataManager.save(saveContext);
    }

    public FetchPlan getEditFetchPlan() {
        return fetchPlans.builder(KpiCard.class)
                .addFetchPlan(FetchPlan.BASE)
                .add("kpiGoals", FetchPlan.BASE)
                .add("department")
                .add("period")
                .add("author")
                .build();
    }

    /**
     * 5. Требования для участия в КПЭ (2-4 часа) - DONE
     *     * Испытательный период должен быть пройден (запрет на создание до 3х месяцев с даты принятия)
     *     * Если в текущем квартале проработал менее 50% после испытательного периода
     */
    public boolean employeeHasWorkedMinRequiredDaysInCompany(Employee employee) {
        Date trialPeriodEndDate = employeeService.getEmployeeTrialPeriodEndDate(employee);
        int halfPeriod = 45;
        Calendar cal = Calendar.getInstance();
        EQuarter currentQuarter = kpiGeneralUtils.getCurrentQuarter(cal.get(Calendar.MONTH));
        Date qs = kpiGeneralUtils.getQuarterStartDate(currentQuarter, cal.get(Calendar.YEAR));
        cal.setTime(qs);
        cal.add(Calendar.DAY_OF_YEAR, halfPeriod);
        return cal.getTime().after(trialPeriodEndDate);
    }

    public boolean isTransferDuringPeriod(Date hireDate, KpiPeriod period) {
        Date startDate = kpiGeneralUtils.getQuarterStartDate(period.getQuarter(), period.getYear());
        Date endDate = kpiGeneralUtils.getQuarterEndDate(period.getQuarter(), period.getYear());
        return hireDate.after(startDate) && hireDate.before(endDate);
    }

    public List<KpiCard> loadAllKpiCardsById(List<UUID> uuidList) {
        if (uuidList.size() == 0) return Collections.emptyList();
        return dataManager.load(KpiCard.class)
                .condition(PropertyCondition.inList("id", uuidList))
                .list();
    }

    public KpiCard updateTotalKpi(KpiCard card) {
        if (card == null) return null;
        calcTotalKpi(card);
        return dataManager.save(card);
    }

    public void calcTotalKpi(KpiCard card) {
        if (card == null) return;
        BigDecimal totalKpi = calcAndGetTotalKpi(card);
        if (totalKpi == null) return;
        card.setTotalKpi(totalKpi);
    }

    public BigDecimal calcAndGetTotalKpi(KpiCard card) {
        BigDecimal totalKpi = BigDecimal.ZERO;
        if (card.getKpiGoals() == null)
            return null;
        for (KpiGoal goal : card.getKpiGoals()) {
            if (goal.getEfficiency() != null)
                totalKpi = totalKpi.add(goal.getEfficiency());
        }
        return totalKpi;
    }

    public KpiCard updateApplicationEmployeeData(KpiCard application) {
        application = updateApplicationCoordinators(application);
        if (entityStates.isNew(application))
            return application;
        return dataManager.save(application);
    }

    public KpiCard updateApplicationCoordinators(KpiCard application) {
        application = reloadApplication(application);
        Employee currentEmployee = employeeService.getCurrentEmployee();
        if (currentEmployee != null && application.getAuthor() != null
                && currentEmployee.getId().equals(application.getAuthor().getId())) {
            application.setSupervisor(currentEmployee.getSupervisor());
            application.setLeader(currentEmployee.getLeader());
        }
        return application;
    }

    public List<KpiCard> loadAllDepartmentKpiCards(KpiPeriod period, DictDepartment department) {
        if (department == null)
            throw new IllegalArgumentException("Передан пустой аргумент: Подразделение");
        if (period == null)
            throw new IllegalArgumentException("Передан пустой аргумент: Период");

        department = departmentService.reloadActualDepartmentBySapId(department);
        List<UUID> employeeIds = employeeService.getAllDepartmentSubTreeEmployees(department)
                .stream().filter(Employee::getActive)
                .map(Employee::getId)
                .collect(Collectors.toList());
        if (employeeIds.size() == 0) return Collections.emptyList();
        return dataManager.load(KpiCard.class)
                .condition(
                        LogicalCondition.and(
                            PropertyCondition.equal("period.id", period.getId()),
                            PropertyCondition.inList("author.id", employeeIds)
                        )
                )
                .list();
    }

    /**
     * Calc all period cards goal progress & efficiency
     */
    public int calcAllCardsGoalsPerformances(KpiPeriod period) {
        List<KpiCard> cards = dataManager.load(KpiCard.class)
                .condition(PropertyCondition.equal("period", period))
                .fetchPlan(fb -> fb.addFetchPlan(FetchPlan.BASE)
                        .add("kpiGoals", fp -> fp.addFetchPlan(FetchPlan.BASE)))
                .list();
        int count = 0;
        for (KpiCard card : cards) {
            if (calcGoalsPerformances(card))
                count++;
        }
        return count;
    }

    public boolean calcGoalsPerformances(KpiCard card) {
        boolean existsGoalWithFact = false;
        for (KpiGoal goal : card.getKpiGoals()) {
            if ((goal.getPlan() != null && goal.getFact() != null)
                || (goal.getPlanDate() != null && goal.getFactDate() != null)) {
                existsGoalWithFact = true;
                kpiGoalSummaryService.calcPerformanceAndEfficiency(goal);
            }
        }
        if (existsGoalWithFact)
            updateTotalKpi(card);
        return existsGoalWithFact;
    }

    public List<EntityLogItem> loadEntityLogs(UUID entityId, Date ds, Date de) {
        return dataManager.load(EntityLogItem.class)
                .query("select e from audit_EntityLog e " +
                        "where e.entityRef.entityId = :entityId " +
                        "and e.type = :type " +
                        "and e.createTs between :ds and :de " +
                        "order by e.eventTs desc")
                .parameter("entityId", entityId)
                .parameter("ds", ds)
                .parameter("de", de)
                .parameter("type", EntityLogItem.Type.MODIFY)
                .fetchPlan(FetchPlan.BASE)
                .list();
    }

    public boolean doRestoreDepAndPosCards(KpiCard card) {
        Date ds = kpiGeneralUtils.getQuarterStartDate(card.getPeriod().getQuarter(), card.getPeriod().getYear());
        Date de = kpiGeneralUtils.getQuarterEndDate(card.getPeriod().getQuarter(), card.getPeriod().getYear());
        List<EntityLogItem> entityLogItems = loadEntityLogs(card.getId(), ds, de);
        for (EntityLogItem item : entityLogItems) {
            for (EntityLogAttr attr : item.getAttributes()) {
                if (attr.getName().equals("position")) {
                    DictPosition position = getDictPosition(attr);
                    if (position != null) {
                        card.setPosition(position);
                        card.setDepartment(position.getDepartment());
                        dataManager.save(card);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @Nullable
    private DictPosition getDictPosition(EntityLogAttr attr) {
        return dataManager.load(DictPosition.class)
                .id(UUID.fromString(attr.getOldValueId()))
                .fetchPlan(fb -> fb.addFetchPlan(FetchPlan.INSTANCE_NAME)
                        .add("department", FetchPlan.INSTANCE_NAME))
                .optional().orElse(null);
    }


    public boolean doRestoreSupervisor(KpiCard card) {
        Date ds = kpiGeneralUtils.getQuarterStartDate(card.getPeriod().getQuarter(), card.getPeriod().getYear());
        Date de = kpiGeneralUtils.getQuarterEndDate(card.getPeriod().getQuarter(), card.getPeriod().getYear());
        List<EntityLogItem> entityLogItems = loadEntityLogs(card.getId(), ds, de);
        for (EntityLogItem item : entityLogItems) {
            for (EntityLogAttr attr : item.getAttributes()) {
                if (attr.getName().equals("supervisor")) {
                    Employee supervisor = employeeService.reloadEmployeeById(UUID.fromString(attr.getOldValueId()));
                    if (supervisor != null) {
                        card.setSupervisor(supervisor);
                        dataManager.save(card);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean doRestoreLeader(KpiCard card) {
        Date ds = kpiGeneralUtils.getQuarterStartDate(card.getPeriod().getQuarter(), card.getPeriod().getYear());
        Date de = kpiGeneralUtils.getQuarterEndDate(card.getPeriod().getQuarter(), card.getPeriod().getYear());
        List<EntityLogItem> entityLogItems = loadEntityLogs(card.getId(), ds, de);
        for (EntityLogItem item : entityLogItems) {
            for (EntityLogAttr attr : item.getAttributes()) {
                if (attr.getName().equals("leader")) {
                    Employee leader = employeeService.reloadEmployeeById(UUID.fromString(attr.getOldValueId()));
                    if (leader != null) {
                        card.setLeader(leader);
                        dataManager.save(card);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean checkEnableCreationDeadline() {
        KpiPeriod period = kpiGoalService.getCurrentKpiPeriod();
        KpiCardSettings cardSettings = appSettings.load(KpiCardSettings.class);
        long daysFromCurrentQuarter = kpiGoalService.getDaysPassedFromQuarterStart(period);
        return daysFromCurrentQuarter < cardSettings.getEnableCreationDaysFromCurrentQuarter();
    }

    public void rollBackCardToFirstStage(KpiCard card) {
        card.setStage(EKpiCardStage.FIRST_STAGE);
        dataManager.save(card);
    }
}