package kz.eub.kpi.app.bean;

import io.jmix.core.FileRef;
import io.jmix.core.FileStorage;
import kz.eub.kpi.entity.EQuarter;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;

@Component("kpi_KpiGeneralUtils")
public class KpiGeneralUtils {

    @Autowired
    private FileStorage fileStorage;

    public String getBase64FromFileRef(FileRef fileRef) throws IOException {
        if (!fileStorage.fileExists(fileRef))
            throw new IllegalStateException("File doesn't exist...");
        InputStream inputStream = fileStorage.openStream(fileRef);
        byte[] imageBytes = new byte[inputStream.available()];
        inputStream.read(imageBytes, 0, imageBytes.length);
        inputStream.close();
        return Base64.encodeBase64String(imageBytes);
    }

    public long calcAgeInDays(Date ds, Date de) {
        if (ds == null)
            throw new IllegalArgumentException("Дата начало пустое...");
        if (de == null)
            throw new IllegalArgumentException("Дата конец пустой...");
        return ChronoUnit.DAYS.between(new Date(ds.getTime()).toInstant(), new Date(de.getTime()).toInstant());
    }

    public Date getQuarterStartDate(EQuarter quarter, int year) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, getQuarterStartMonth(quarter));
        cal.set(Calendar.DATE, cal.getActualMinimum(Calendar.DATE));
        cal.set(Calendar.HOUR_OF_DAY, cal.getActualMinimum(Calendar.HOUR_OF_DAY));
        cal.set(Calendar.MINUTE, cal.getActualMinimum(Calendar.MINUTE));
        cal.set(Calendar.SECOND, cal.getActualMinimum(Calendar.SECOND));
        cal.set(Calendar.MILLISECOND, cal.getActualMinimum(Calendar.MILLISECOND));
        return cal.getTime();
    }

    public Date getQuarterEndDate(EQuarter quarter, int year) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, getQuarterEndMonth(quarter));
        cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
        cal.set(Calendar.HOUR_OF_DAY, cal.getActualMaximum(Calendar.HOUR_OF_DAY));
        cal.set(Calendar.MINUTE, cal.getActualMaximum(Calendar.MINUTE));
        cal.set(Calendar.SECOND, cal.getActualMaximum(Calendar.SECOND));
        cal.set(Calendar.MILLISECOND, cal.getActualMaximum(Calendar.MILLISECOND));
        return cal.getTime();
    }

    public EQuarter getCurrentQuarter(int monthOfYear) {
        EQuarter quarter = EQuarter.FIRST_QUARTER;
        if (monthOfYear > 2 && monthOfYear < 6) {
            quarter = EQuarter.SECOND_QUARTER;
        } else if (monthOfYear >= 6 && monthOfYear < 9) {
            quarter = EQuarter.THIRD_QUARTER;
        } else if (monthOfYear >= 9) {
            quarter = EQuarter.FOURTH_QUARTER;
        }
        return quarter;
    }

    public int getQuarterStartMonth(EQuarter quarter) {
        if (quarter == null)
            throw new IllegalArgumentException("Передан пустой аргумент...");
        return quarter.ordinal() * 3;
    }

    public int getQuarterEndMonth(EQuarter quarter) {
        if (quarter == null)
            throw new IllegalArgumentException("Передан пустой аргумент...");
        return (quarter.ordinal()+1) * 3-1;
    }

    public EQuarter getQuarterEnumFromInt(int q) {
        return EQuarter.values()[q-1];
    }
}