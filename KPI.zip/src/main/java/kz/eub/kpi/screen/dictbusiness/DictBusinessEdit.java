package kz.eub.kpi.screen.dictbusiness;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.DictBusiness;

@UiController("kpi_DictBusiness.edit")
@UiDescriptor("dict-business-edit.xml")
@EditedEntityContainer("dictBusinessDc")
public class DictBusinessEdit extends StandardEditor<DictBusiness> {
}