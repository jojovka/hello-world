package kz.eub.kpi.screen.kpi.kpigoal;

import io.jmix.ui.screen.LookupComponent;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.entity.kpi.KpiGoal;

@UiController("kpi_IndividualTasks")
@UiDescriptor("individual-tasks.xml")
@LookupComponent("kpiGoalsTable")
public class IndividualTasks extends StandardLookup<KpiGoal> {
}