package kz.eub.kpi.screen.bonusaward;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.BonusAward;

@UiController("kpi_BonusAward.edit")
@UiDescriptor("bonus-award-edit.xml")
@EditedEntityContainer("bonusAwardDc")
public class BonusAwardEdit extends StandardEditor<BonusAward> {
}