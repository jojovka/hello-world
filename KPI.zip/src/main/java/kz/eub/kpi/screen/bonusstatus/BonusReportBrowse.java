package kz.eub.kpi.screen.bonusstatus;

import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.DateField;
import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.BonusReport;
import kz.eub.kpi.entity.RatingUserOptions;
import kz.eub.kpi.screen.bonusbonusdescription.BonusBonusDescription;
import kz.eub.kpi.screen.bonusreportdashboard.BonusReportDashboard;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Calendar;
import java.util.Date;

@UiController("bonus_administration_BonusReport.browse")
@UiDescriptor("bonus-report-browse.xml")
public class BonusReportBrowse extends StandardLookup<BonusReport> {

    @Autowired
    private ScreenBuilders screenBuilders;

    @Autowired
    private DateField dateStartAuthority;

    @Autowired
    private DateField dateEndAuthority;
    @Autowired
    private DateField dateStartDuel;
    @Autowired
    private DateField dateEndDuel;
    @Autowired
    private Button btnVisitId;
    @Autowired
    private DateField dateStartVisit;
    @Autowired
    private DateField dateEndVisit;

    @Subscribe
    private void onInit(InitEvent event) {
        Calendar c1 = Calendar.getInstance();
        c1.set(Calendar.MONTH, c1.get(Calendar.MONTH));
        c1.set(Calendar.DAY_OF_MONTH, 1);
        Date theDateMinDayCurrentMonth = c1.getTime();
        Calendar c2 = Calendar.getInstance();
        c2.set(Calendar.MONTH, c2.get(Calendar.MONTH));
        c2.set(Calendar.DAY_OF_MONTH, c2.getActualMaximum(Calendar.DAY_OF_MONTH));
        Date theDateMaxDayCurrentMonth = c2.getTime();
        dateStartVisit.setValue(theDateMinDayCurrentMonth);
        dateEndVisit.setValue(theDateMaxDayCurrentMonth);

        dateStartAuthority.setValue(theDateMinDayCurrentMonth);
        dateEndAuthority.setValue(theDateMaxDayCurrentMonth);

        dateStartDuel.setValue(theDateMinDayCurrentMonth);
        dateEndDuel.setValue(theDateMaxDayCurrentMonth);

    }


    @Subscribe("duelBtn")
    public void onDuelBtnClick(Button.ClickEvent event) {
        Date v1 = (Date) dateStartDuel.getValue();
        Date v2 = (Date) dateEndDuel.getValue();
        if (v1 != null && v2 != null) {
            screenBuilders.screen(this)
                    .withScreenClass(BonusReportDashboard.class)
                    .withOptions(new RatingUserOptions(null, null, null, v1, v2, 3))
                    .build()
                    .show();
        }
    }

    @Subscribe("btnAuthorityId")
    public void btnAuth(Button.ClickEvent event) {
        Date v1 = (Date) dateStartAuthority.getValue();
        Date v2 = (Date) dateEndAuthority.getValue();
        if (v1 != null && v2 != null) {
            screenBuilders.screen(this)
                    .withScreenClass(BonusReportDashboard.class)
                    .withOptions(new RatingUserOptions(null, null, null, v1, v2, 4))
                    .show();
        }
    }

    @Subscribe("btnVisitId")
    public void onBtnVisitIdClick(Button.ClickEvent event) {
        Date v1 = (Date) dateStartVisit.getValue();
        Date v2 = (Date) dateEndVisit.getValue();
        if (v1 != null && v2 != null) {
            screenBuilders.screen(this)
                    .withScreenClass(BonusReportDashboard.class)
                    .withOptions(new RatingUserOptions(null, null, null, v1, v2, 0))
                    .show();
        }
    }
}