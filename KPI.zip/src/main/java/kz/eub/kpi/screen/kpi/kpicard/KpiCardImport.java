package kz.eub.kpi.screen.kpi.kpicard;

import io.jmix.core.DataManager;
import io.jmix.core.SaveContext;
import io.jmix.ui.Notifications;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.TextField;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.KpiCardImportService;
import kz.eub.kpi.entity.kpi.KpiCard;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@UiController("kpi_KpiCard.import")
@UiDescriptor("kpi-card-import.xml")
public class KpiCardImport extends StandardLookup<KpiCard> {

    public static final Logger log = LoggerFactory.getLogger(KpiCardImport.class);

    @Autowired
    private GroupTable<KpiCard> kpiCardsTable;
    @Autowired
    private KpiCardImportService kpiCardImportService;
    @Autowired
    private CollectionContainer<KpiCard> kpiCardsDc;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private Button importBtn;
    @Autowired
    private Notifications notifications;
    @Autowired
    private TextField<Integer> sheedIndexFld;

    @Subscribe
    public void onInit(InitEvent event) {
        initEnterPressHandler();
        initDoubleClickHandler();
    }

    private void initEnterPressHandler() {
        kpiCardsTable.setEnterPressAction(new BaseAction("enterPressAction")
                .withHandler(event -> openKpiCard()));
    }

    private void initDoubleClickHandler() {
        kpiCardsTable.setItemClickAction(new BaseAction("itemClickAction")
                .withHandler(event -> openKpiCard()));
    }

    private void openKpiCard() {
        KpiCard card = kpiCardsTable.getSingleSelected();
        if (card == null) return;
        Objects.requireNonNull(kpiCardsTable.getAction("view")).actionPerform(kpiCardsTable);
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        sheedIndexFld.setValue(0);
    }

    @Subscribe("fileUploadFld")
    public void onFileUploadFldValueChange(HasValue.ValueChangeEvent<byte[]> event) throws IOException {
        byte[] file = event.getValue();
        kpiCardsDc.getMutableItems().clear();
        List<KpiCard> kpiCards = new ArrayList<>();
        try {
            kpiCards = kpiCardImportService.importKpiCards(file, sheedIndexFld.getValue());
            kpiCardsDc.getMutableItems().addAll(kpiCards);
        } catch (Exception e) {
            log.error("Ошибка при импорте...", e);
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Ошибка при импорте...")
                    .withDescription(e.getMessage())
                    .show();
        } finally {
            if (kpiCards.size() > 0)
                importBtn.setEnabled(true);
        }
    }

    @Subscribe("importBtn")
    public void onImportBtnClick(Button.ClickEvent event) {
        SaveContext saveContext = new SaveContext();
        for (KpiCard card : kpiCardsDc.getMutableItems()) {
            saveContext.saving(card);
        }
        dataManager.save(saveContext);
        notifications.create()
                .withCaption("Импорт выполнен.")
                .withDescription("Успешно импортированы " + saveContext.getEntitiesToSave().size() + " Карт КПЭ.")
                        .show();
        kpiCardsDc.getMutableItems().clear();
        importBtn.setEnabled(false);
    }

}