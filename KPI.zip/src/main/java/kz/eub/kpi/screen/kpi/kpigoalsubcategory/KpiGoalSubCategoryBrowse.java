package kz.eub.kpi.screen.kpi.kpigoalsubcategory;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.KpiGoalSubCategory;

@UiController("kpi_KpiGoalSubCategory.browse")
@UiDescriptor("kpi-goal-sub-category-browse.xml")
@LookupComponent("kpiGoalSubCategoriesTable")
public class KpiGoalSubCategoryBrowse extends StandardLookup<KpiGoalSubCategory> {
}