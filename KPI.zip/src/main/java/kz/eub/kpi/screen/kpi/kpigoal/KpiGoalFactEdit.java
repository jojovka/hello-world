package kz.eub.kpi.screen.kpi.kpigoal;

import io.jmix.ui.Notifications;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.CurrencyField;
import io.jmix.ui.component.DateField;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.TabSheet;
import io.jmix.ui.component.Table;
import io.jmix.ui.component.ValidationException;
import io.jmix.ui.icon.JmixIcon;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.EditedEntityContainer;
import io.jmix.ui.screen.Install;
import io.jmix.ui.screen.MessageBundle;
import io.jmix.ui.screen.StandardEditor;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.Target;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.app.service.KpiGoalService;
import kz.eub.kpi.app.service.KpiGoalSummaryService;
import kz.eub.kpi.entity.kpi.EKpiGoalAssessmentType;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.kpi.EKpiGoalCategory;
import kz.eub.kpi.entity.kpi.KpiGoalAttachment;
import kz.eub.kpi.entity.Unit;
import kz.eub.kpi.entity.kpi.KpiGoal;
import kz.eub.kpi.entity.kpi.KpiGoalComment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

@UiController("kpi_KpiGoal.fact")
@UiDescriptor("kpi-goal-fact-edit.xml")
@EditedEntityContainer("kpiGoalDc")
public class KpiGoalFactEdit extends StandardEditor<KpiGoal> {

    private static final Logger log = LoggerFactory.getLogger(KpiGoalFactEdit.class);

    @Autowired
    private DateField<Date> planDateField;
    @Autowired
    private DateField<Date> factDateField;
    @Autowired
    private CurrencyField<BigDecimal> planField;
    @Autowired
    private CurrencyField<BigDecimal> factField;
    @Autowired
    private TabSheet tabSheet;
    @Autowired
    private MessageBundle messageBundle;
    @Autowired
    private KpiGoalService kpiGoalService;
    @Autowired
    private Button kpiGoalCommentsTableEditBtn;
    @Autowired
    private Button kpiGoalCommentsTableRemoveBtn;
    @Autowired
    private Table<KpiGoalComment> kpiGoalCommentsTable;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private Notifications notifications;
    @Autowired
    private ComboBox<EKpiGoalAssessmentType> assessmentTypeField;
    @Autowired
    private KpiGoalSummaryService kpiGoalSummaryService;

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        markAttachmentsCount();
        markCommentsCount();
        toggleFactFieldsIfFinGoal();
    }

    private void toggleFactFieldsIfFinGoal() {
        KpiGoal goal = getEditedEntity();
        if (Objects.equals(goal.getCategory(), EKpiGoalCategory.FINANCIAL_GOAL)) {
            factField.setEditable(false);
            factDateField.setEditable(false);
            assessmentTypeField.setEditable(false);
        }
    }

    private void markAttachmentsCount() {
        KpiGoal goal = getEditedEntity();
        String message = messageBundle.getMessage("attachments");
        int size = 0;
        if (goal.getAttachments() != null)
            size = goal.getAttachments().size();
        String color = "blue";
        JmixIcon icon = JmixIcon.CIRCLE_O;
        if (size > 0) {
            color = "red";
            icon = JmixIcon.CHECK_CIRCLE_O;
        }
        message = message + " <span style='color: " + color + "'><b>(" + size + ")</b></span>";
        tabSheet.setTabCaptionsAsHtml(true);
        TabSheet.Tab attachmentsTab = tabSheet.getTab("attachmentsTab");
        attachmentsTab.setIconFromSet(icon);
        attachmentsTab.setCaption(message);
    }

    private void markCommentsCount() {
        KpiGoal goal = getEditedEntity();
        String message = messageBundle.getMessage("comments");
        int size = 0;
        if (goal.getComments() != null)
            size = goal.getComments().size();
        String color = "blue";
        JmixIcon icon = JmixIcon.COMMENT_O;
        if (size > 0) {
            color = "red";
        }
        message = message + " <span style='color: " + color + "'><b>(" + size + ")</b></span>";
        tabSheet.setTabCaptionsAsHtml(true);
        TabSheet.Tab attachmentsTab = tabSheet.getTab("commentsTab");
        attachmentsTab.setIconFromSet(icon);
        attachmentsTab.setCaption(message);
    }

    @Subscribe("planField")
    public void onPlanFieldValueChange(HasValue.ValueChangeEvent<BigDecimal> event) {
        calcPerformance();
    }

    @Subscribe("planDateField")
    public void onPlanDateFieldValueChange(HasValue.ValueChangeEvent<Date> event) {
        calcPerformance();
    }

    @Subscribe("factField")
    public void onFactFieldValueChange(HasValue.ValueChangeEvent<BigDecimal> event) {
        calcPerformance();
    }

    @Subscribe("factDateField")
    public void onFactDateFieldValueChange(HasValue.ValueChangeEvent<Date> event) {
        calcPerformance();
    }

    private void calcPerformance() {
        try {
            KpiGoal goal = getEditedEntity();
            if ((goal.getPlan() == null && goal.getPlanDate() == null)
                    || (goal.getFact() == null && goal.getFactDate() == null))
                return;
            goal = kpiGoalSummaryService.calcPerformanceAndEfficiency(goal);
            setEntityToEdit(goal);
        } catch (Exception e) {
            log.error("Error", e);
            notifications.create()
                    .withCaption(e.getMessage())
                    .withDescription("Произошла ошибка при попытке расчета КПЭ...")
                    .show();
        }
    }

    @Subscribe("unitField")
    public void onUnitFieldValueChange(HasValue.ValueChangeEvent<Unit> event) {
        togglePlanFactFields(event.getValue());
        Unit unit = event.getValue();
        planField.setCurrency("");
        factField.setCurrency("");
        assessmentTypeField.setEditable(false);
        if (unit != null) {
            planField.setCurrency(unit.getCode());
            factField.setCurrency(unit.getCode());
            if (!unit.getId().equals(Unit.UNIT_WDAY))
                assessmentTypeField.setEditable(true);
        }
    }

    private void togglePlanFactFields(Unit unit) {
        planField.setVisible(true);
        planField.setRequired(true);
        factField.setVisible(true);
        planDateField.setValue(null);
        planDateField.setVisible(false);
        planDateField.setRequired(false);
        factDateField.setValue(null);
        factDateField.setVisible(false);
        if (unit == null) return;
        if (Objects.equals(unit.getId(), Unit.UNIT_WDAY)) {
            planDateField.setVisible(true);
            planDateField.setRequired(true);
            factDateField.setVisible(true);
            planField.setVisible(false);
            planField.setValue(null);
            planField.setRequired(false);
            factField.setVisible(false);
            factField.setValue(null);
        }
    }

    @Install(to = "weightField", subject = "validator")
    private void weightFieldValidator(BigDecimal weight) {
        validatePercentage(weight);
    }

    private void validatePercentage(BigDecimal value) {
        if (value == null) return;
        if (value.compareTo(BigDecimal.ZERO) <= 0)
            throw new ValidationException("Отрицательные числа и значение 0 не допустимы");
        if (value.compareTo(new BigDecimal(100)) > 0)
            throw new ValidationException("Максиммально допустимое значение: 100");
    }

    @Install(to = "planField", subject = "validator")
    private void planFieldValidator(BigDecimal plan) {
        validatePlan(plan);
    }

    private void validatePlan(BigDecimal value) {
        if (value == null) return;
        if (value.compareTo(BigDecimal.ZERO) <= 0)
            throw new ValidationException("Отрицательные числа и значение 0 не допустимы");
    }

    @Subscribe(id = "attachmentsDc", target = Target.DATA_CONTAINER)
    public void onAttachmentsDcCollectionChange(CollectionContainer.CollectionChangeEvent<KpiGoalAttachment> event) {
        markAttachmentsCount();
    }

    @Subscribe("kpiGoalCommentsTable")
    public void onKpiGoalCommentsTableSelection(Table.SelectionEvent<KpiGoalComment> event) {
        kpiGoalCommentsTableEditBtn.setEnabled(false);
        kpiGoalCommentsTableRemoveBtn.setEnabled(false);
        KpiGoalComment comment = kpiGoalCommentsTable.getSingleSelected();
        Employee employee = employeeService.getCurrentEmployee();
        if (comment != null && comment.getAuthor() != null
                && comment.getAuthor().getId().equals(employee.getId())) {
            kpiGoalCommentsTableEditBtn.setEnabled(true);
            kpiGoalCommentsTableRemoveBtn.setEnabled(true);
        }
    }

    @Subscribe("assessmentTypeField")
    public void onAssessmentTypeFieldValueChange(HasValue.ValueChangeEvent<EKpiGoalAssessmentType> event) {
        calcPerformance();
    }

}