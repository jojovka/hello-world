package kz.eub.kpi.screen.award;

import io.jmix.security.role.annotation.RowLevelRole;
import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.Award;

@UiController("kpi_Award.edit")
@UiDescriptor("award-edit.xml")
@EditedEntityContainer("awardDc")
public class AwardEdit extends StandardEditor<Award> {
}