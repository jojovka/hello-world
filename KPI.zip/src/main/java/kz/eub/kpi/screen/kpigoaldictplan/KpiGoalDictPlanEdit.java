package kz.eub.kpi.screen.kpigoaldictplan;

import io.jmix.ui.component.CurrencyField;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.screen.EditedEntityContainer;
import io.jmix.ui.screen.StandardEditor;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.entity.EApplicationStatus;
import kz.eub.kpi.entity.kpi.KpiGoalDict;
import kz.eub.kpi.entity.kpi.KpiGoalDictPlan;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

@UiController("kpi_KpiGoalDictPlan.edit")
@UiDescriptor("kpi-goal-dict-plan-edit.xml")
@EditedEntityContainer("kpiGoalDictPlanDc")
public class KpiGoalDictPlanEdit extends StandardEditor<KpiGoalDictPlan> {

    @Autowired
    private CurrencyField<BigDecimal> planField;

    @Subscribe
    public void onInitEntity(InitEntityEvent<KpiGoalDictPlan> event) {
        KpiGoalDictPlan fact = event.getEntity();
        fact.setPeriod(fact.getGoalImportDoc().getPeriod());
        fact.setStatus(EApplicationStatus.NEW);
    }

    @Subscribe("goalDictField")
    public void onGoalDictFieldValueChange(HasValue.ValueChangeEvent<KpiGoalDict> event) {
        KpiGoalDict goalDict = event.getValue();
        if (goalDict == null) return;
        planField.setCurrency(goalDict.getUnit().getCode());
    }

}