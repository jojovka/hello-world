package kz.eub.kpi.screen.kpi.kpiempldevplan;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.KpiEmplDevPlan;

@UiController("kpi_KpiEmplDevPlan.browse")
@UiDescriptor("kpi-empl-dev-plan-browse.xml")
@LookupComponent("kpiEmplDevPlansTable")
public class KpiEmplDevPlanBrowse extends StandardLookup<KpiEmplDevPlan> {
}