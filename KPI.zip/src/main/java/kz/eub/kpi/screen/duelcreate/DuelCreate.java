package kz.eub.kpi.screen.duelcreate;

import io.jmix.core.DataManager;
import io.jmix.ui.Dialogs;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.CheckBox;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.FileUploadField;
import io.jmix.ui.component.GroupBoxLayout;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.TextArea;
import io.jmix.ui.component.TextField;
import io.jmix.ui.component.TimeField;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.StandardOutcome;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.entity.Duel;
import kz.eub.kpi.entity.DuelQuestion;
import kz.eub.kpi.entity.QuestionAnswer;
import liquibase.pro.packaged.D;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@UiController("kpi_DuelCreate")
@UiDescriptor("duel-create.xml")
public class DuelCreate extends Screen {


    @Autowired
    private ComboBox<String> maritalStatusField;

    @Autowired
    private CollectionContainer<DuelQuestion> questionDc;
    @Autowired
    private GroupBoxLayout newQuestionId;
    @Autowired
    private TextArea textAreaId;
//    @Autowired
//    private FileUploadField fileRefId;
    @Autowired
    private TextField firstChoice;


    @Autowired
    private CheckBox firstChoiceCheck;
    @Autowired
    private TextField secondChoice;
    @Autowired
    private CheckBox secondChoiceCheck;
    @Autowired
    private TextField thirdChoice;
    @Autowired
    private CheckBox thirdChoiceCheck;
    @Autowired
    private TextField fourthChoice;
    @Autowired
    private CheckBox fourthChoiceCheck;
    @Autowired
    private Dialogs dialogs;

    private Boolean isNew;

    List<DuelQuestion> questions = new ArrayList<>();
    @Autowired
    private DataManager dataManager;
//    @Autowired
//    private TimeField timeDuration;
    @Autowired
    private TextField duelTitle;
    @Autowired
    private TextField pointsId;
    @Autowired
    private TextField questionCount;

    @Autowired
    private TimeField<Date> timeId;

    @Subscribe
    private void onInit(InitEvent event) {
        questionCount.setVisible(false);
        isNew = false;
        newQuestionId.setVisible(false);
        questions.clear();
        questionDc.getMutableItems().clear();

        List<String> list = new ArrayList<>();
        list.add("полный список");
        list.add("выбор количества вопросов");
        maritalStatusField.setOptionsList(list);

    }

    @Subscribe("addQuestionBtn")
    public void onAddQuestionBtnClick(Button.ClickEvent event) {
        if (isNew == true) {
            if (textAreaId.isEmpty() || firstChoice.isEmpty()) {
                dialogs.createMessageDialog()
                        .withCaption("Важно")
                        .withMessage("Заполните поля")
                        .show();
            } else {

                List<QuestionAnswer> answers = new ArrayList<>();
                DuelQuestion question = dataManager.create(DuelQuestion.class);
                question.setQuestionTitle(textAreaId.getValue().toString());
                QuestionAnswer answer1 = dataManager.create(QuestionAnswer.class);
                answer1.setAnswerTitle(firstChoice.getRawValue());
                answer1.setIsCorrect(firstChoiceCheck.isChecked());
                answers.add(answer1);
                if (!secondChoice.isEmpty()) {
                    QuestionAnswer answer2 = dataManager.create(QuestionAnswer.class);
                    answer2.setAnswerTitle(secondChoice.getRawValue());
                    answer2.setIsCorrect(secondChoiceCheck.isChecked());
                    answers.add(answer2);
                }
                if (!thirdChoice.isEmpty()) {
                    QuestionAnswer answer3 = dataManager.create(QuestionAnswer.class);
                    answer3.setAnswerTitle(thirdChoice.getRawValue());
                    answer3.setIsCorrect(thirdChoiceCheck.isChecked());
                    answers.add(answer3);
                }
                if (!fourthChoice.isEmpty()) {
                    QuestionAnswer answer4 = dataManager.create(QuestionAnswer.class);
                    answer4.setAnswerTitle(fourthChoice.getRawValue());
                    answer4.setIsCorrect(fourthChoiceCheck.isChecked());
                    answers.add(answer4);
                }
                question.setAnswers(answers);
                questionDc.getMutableItems().add(question);
                questions.add(question);
                clear();
                newQuestionId.setVisible(false);
                isNew = false;
            }
        } else {
            newQuestionId.setVisible(true);
            isNew = true;
        }
    }

    private void clear() {
        textAreaId.clear();
//        fileRefId.clear();
        firstChoice.clear();
        firstChoiceCheck.clear();
        secondChoice.clear();
        secondChoiceCheck.clear();
        thirdChoiceCheck.clear();
        thirdChoice.clear();
        fourthChoice.clear();
        fourthChoiceCheck.clear();
    }

    @Subscribe("saveDuel")
    public void onSaveDuelClick(Button.ClickEvent event) {
        Duel duel = dataManager.create(Duel.class);
        duel.setType(true);
        duel.setTitle(duelTitle.getValue().toString());
        duel.setPlayed(0);
        duel.setQuestionCount(questionDc.getMutableItems().size());
        duel.setPoints(Integer.parseInt(pointsId.getValue().toString()));
        if (!questionCount.isEmpty() && questionCount.getRawValue() != null) {
            duel.setQuestionCount(Integer.parseInt(questionCount.getRawValue()));
        }
        Calendar d = Calendar.getInstance();
        d.set(Calendar.DATE, Calendar.MONTH, Calendar.YEAR, Calendar.HOUR, timeId.getValue().getMinutes(), timeId.getValue().getSeconds());
        duel.setTimeDuration(d.getTime());
        duel.setStatus(true);
        dataManager.save(duel);

        questions.forEach(duelQuestion -> {
            duelQuestion.setDuel(duel);

        });
        questions.forEach(duelQuestion -> {
            duelQuestion.getAnswers().forEach(questionAnswer -> {
                questionAnswer.setDuelQuestion(duelQuestion);
            });
        });
        duel.setQuestions(questions);
        dataManager.save(duel);

        close(StandardOutcome.CLOSE);
    }

    @Subscribe("maritalStatusField")
    public void onMaritalStatusFieldValueChange(HasValue.ValueChangeEvent event) {
        if (event.getValue() == "выбор количества вопросов") {
            questionCount.setVisible(true);
        } else {
            questionCount.setVisible(false);
        }
    }

}