package kz.eub.kpi.screen.pointuser;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.PointUser;

@UiController("kpi_PointUser.edit")
@UiDescriptor("point-user-edit.xml")
@EditedEntityContainer("pointUserDc")
public class PointUserEdit extends StandardEditor<PointUser> {
}