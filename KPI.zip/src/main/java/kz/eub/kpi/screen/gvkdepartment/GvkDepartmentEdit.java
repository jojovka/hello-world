package kz.eub.kpi.screen.gvkdepartment;

import io.jmix.ui.component.HasValue;
import io.jmix.ui.screen.*;
import kz.eub.kpi.app.service.DepartmentService;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.GvkDepartment;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("kpi_GvkDepartment.edit")
@UiDescriptor("gvk-department-edit.xml")
@EditedEntityContainer("gvkDepartmentDc")
public class GvkDepartmentEdit extends StandardEditor<GvkDepartment> {

    @Autowired
    private DepartmentService departmentService;

    @Subscribe("departmentField")
    public void onDepartmentFieldValueChange(HasValue.ValueChangeEvent<DictDepartment> event) {
        DictDepartment department = event.getValue();
        if (department == null) return;
        GvkDepartment gvkDepartment = getEditedEntity();
        gvkDepartment.setSapId(department.getSapId());
        gvkDepartment.setCode(department.getCode());
        gvkDepartment.setName(department.getName());
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        getDepartment(getEditedEntity());
    }

    private void getDepartment(GvkDepartment gvkDep) {
        DictDepartment department = departmentService.getDepartmentBySapId(gvkDep.getSapId());
        gvkDep.setDepartment(department);
    }

}