package kz.eub.kpi.screen.dictposition;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.DictPosition;

@UiController("kpi_DictPosition.edit")
@UiDescriptor("dict-position-edit.xml")
@EditedEntityContainer("dictPositionDc")
public class DictPositionEdit extends StandardEditor<DictPosition> {
}