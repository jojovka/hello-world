package kz.eub.kpi.screen.employee;

import io.jmix.core.DataManager;
import io.jmix.core.FileRef;
import io.jmix.ui.Notifications;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.Image;
import io.jmix.ui.component.Table;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.EditedEntityContainer;
import io.jmix.ui.screen.PrimaryEditorScreen;
import io.jmix.ui.screen.StandardEditor;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.kpi.KpiCard;
import kz.eub.kpi.entity.kpi.KpiResult;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Objects;

@UiController("kpi_Employee.edit")
@UiDescriptor("employee-edit.xml")
@EditedEntityContainer("employeeDc")
@PrimaryEditorScreen(Employee.class)
public class EmployeeEdit extends StandardEditor<Employee> {

    @Autowired
    private Notifications notifications;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private CollectionContainer<Employee> employeesDc;
    @Autowired
    private Image<FileRef> photo;
    @Autowired
    private CollectionContainer<KpiResult> kpiResultsDc;
    @Autowired
    private CollectionContainer<KpiCard> kpiCardsDc;
    @Autowired
    private Table<KpiCard> kpiCardsTable;

    @Subscribe
    public void onInit(InitEvent event) {
        initEnterPressHandler();
        initDoubleClickHandler();
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        loadKpiCards();
        loadAccountableEmployees();
        loadKpiResults();
        togglePhoto();
    }

    private void initEnterPressHandler() {
        kpiCardsTable.setEnterPressAction(new BaseAction("enterPressAction")
                .withHandler(event -> openKpiCard()));
    }

    private void initDoubleClickHandler() {
        kpiCardsTable.setItemClickAction(new BaseAction("itemClickAction")
                .withHandler(event -> openKpiCard()));
    }

    private void openKpiCard() {
        KpiCard card = kpiCardsTable.getSingleSelected();
        if (card == null) return;
        Objects.requireNonNull(kpiCardsTable.getAction("view")).actionPerform(kpiCardsTable);
    }

    private void loadKpiCards() {
        kpiCardsDc.getMutableItems().clear();
        List<KpiCard> kpiCards = dataManager.load(KpiCard.class)
                .query("select c from kpi_KpiCard c " +
                        "where c.author = :employee")
                .parameter("employee", getEditedEntity())
                .list();
        kpiCardsDc.getMutableItems().addAll(kpiCards);
    }

    private void togglePhoto() {
        Employee employee = getEditedEntity();
        photo.setVisible(employee.getPhoto() != null);
        photo.setHeightFull();
    }

    private void loadAccountableEmployees() {
        employeesDc.getMutableItems().clear();
        List<Employee> employees = dataManager.load(Employee.class)
                .query("select c from kpi_Employee c " +
                        "where c.supervisor = :employee")
                .parameter("employee", getEditedEntity())
                .list();
        employeesDc.getMutableItems().addAll(employees);
    }

    private void loadKpiResults() {
        kpiResultsDc.getMutableItems().clear();
        List<KpiResult> kpiGoals = dataManager.load(KpiResult.class)
                .query("select c from kpi_KpiResult c " +
                        "where c.employee = :employee")
                .parameter("employee", getEditedEntity())
                .list();
        kpiResultsDc.getMutableItems().addAll(kpiGoals);
    }

    @Subscribe("photoField")
    public void onPhotoFieldValueChange(HasValue.ValueChangeEvent<FileRef> event) {
        togglePhoto();
    }

}