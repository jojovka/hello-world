package kz.eub.kpi.screen.kpi.kpiresult;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.KpiResult;

@UiController("kpi_KpiResult.browse")
@UiDescriptor("kpi-result-browse.xml")
@LookupComponent("kpiResultsTable")
public class KpiResultBrowse extends StandardLookup<KpiResult> {
}