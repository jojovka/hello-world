package kz.eub.kpi.screen.cmdb.cmdbispassport;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.cmdb.CmdbIsPassport;

@UiController("kpi_CmdbIsPassport.browse")
@UiDescriptor("cmdb-is-passport-browse.xml")
@LookupComponent("cmdbIsPassportsTable")
public class CmdbIsPassportBrowse extends StandardLookup<CmdbIsPassport> {
}