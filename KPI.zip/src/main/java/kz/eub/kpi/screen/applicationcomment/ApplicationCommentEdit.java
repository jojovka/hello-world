package kz.eub.kpi.screen.applicationcomment;

import io.jmix.ui.component.LayoutClickNotifier;
import io.jmix.ui.component.TextArea;
import io.jmix.ui.component.TextField;
import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.ApplicationComment;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("kpi_ApplicationComment.edit")
@UiDescriptor("application-comment-edit.xml")
@EditedEntityContainer("applicationCommentDc")
public class ApplicationCommentEdit extends StandardEditor<ApplicationComment> {

    @Autowired
    private TextField<String> subjectField;
    @Autowired
    private TextArea<String> commentField;

    public void setEditable() {
        setReadOnly(false);
        subjectField.setEditable(true);
        commentField.setEditable(true);
    }

    @Subscribe("editActions")
    public void onEditActionsLayoutClick(LayoutClickNotifier.LayoutClickEvent event) {
        System.out.println("test");
    }

}