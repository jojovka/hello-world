package kz.eub.kpi.screen.kpi.kpigoaldictplan;

import io.jmix.ui.component.Filter;
import io.jmix.ui.component.PropertyFilter;
import io.jmix.ui.screen.*;
import kz.eub.kpi.app.service.KpiGoalService;
import kz.eub.kpi.entity.kpi.KpiGoalDictPlan;
import kz.eub.kpi.entity.kpi.KpiPeriod;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("kpi_KpiGoalDictPlan.browse")
@UiDescriptor("kpi-goal-dict-plan-browse.xml")
@LookupComponent("kpiGoalDictPlansTable")
public class KpiGoalDictPlanBrowse extends StandardLookup<KpiGoalDictPlan> {

    @Autowired
    private PropertyFilter<KpiPeriod> filterPeriodField;
    @Autowired
    private KpiGoalService kpiGoalService;
    @Autowired
    private Filter filter;

    public void setFilterPeriod(KpiPeriod period) {
        filterPeriodField.setValue(period);
        filter.apply();
    }

}