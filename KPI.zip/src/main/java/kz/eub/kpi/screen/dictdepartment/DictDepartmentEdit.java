package kz.eub.kpi.screen.dictdepartment;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.DictDepartment;

@UiController("kpi_DictDepartment.edit")
@UiDescriptor("dict-department-edit.xml")
@EditedEntityContainer("dictDepartmentDc")
public class DictDepartmentEdit extends StandardEditor<DictDepartment> {
}