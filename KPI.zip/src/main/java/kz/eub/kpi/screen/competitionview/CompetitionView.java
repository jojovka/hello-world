package kz.eub.kpi.screen.competitionview;

import com.google.gson.Gson;
import io.jmix.core.DataManager;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.Label;
import io.jmix.ui.component.TextArea;
import io.jmix.ui.component.TextField;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.ScreenOptions;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.app.service.ProBonusService;
import kz.eub.kpi.entity.AccountCustomStorage;
import kz.eub.kpi.entity.AccountCustomStorageValue;
import kz.eub.kpi.entity.Accounts;
import kz.eub.kpi.entity.AwardUser;
import kz.eub.kpi.entity.Competition;
import kz.eub.kpi.entity.CompetitionUser;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.RatingUser;
import kz.eub.kpi.entity.RatingUserOptions;
import kz.eub.kpi.entity.analyze.DictBranch;
import kz.eub.kpi.screen.authority.Authorityscreen;
import kz.eub.kpi.screen.competition.CompetitionScreen;
import kz.eub.kpi.screen.competitioncreate.CompetitionCreate;
import org.springframework.beans.factory.annotation.Autowired;

import java.awt.*;
import java.util.List;

@UiController("kpi_CompetitionView")
@UiDescriptor("competition-view.xml")
public class CompetitionView extends Screen {
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private CollectionContainer<Competition> competitionDc;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private ProBonusService proBonusService;
//    @Autowired
    private GroupTable<Competition> competitionTable;
    @Autowired
    private CollectionContainer<Accounts> userDc;
    @Autowired
    private EmployeeService employeeService;

    private Integer competitionId;
    private Employee employee;
    @Autowired
    private TextField competitionTitleId;
    @Autowired
    private TextArea descriptionId;
    @Autowired
    private TextArea conditionId;
    @Autowired
    private TextField sloganId;
    @Autowired
    private TextField positionId;
    @Autowired
    private TextField branchId;
    @Autowired
    private Label typeID;


    @Subscribe
    private void onInit(InitEvent event) {
//        loadCompetitions();
//        addItemClickActions();
        ScreenOptions options = event.getOptions();
        if (options instanceof RatingUserOptions) {
            competitionId = ((RatingUserOptions) options).getAccountId();
            Competition competition  = proBonusService.reloadCompetitionUserById(competitionId);
            positionId.setValue(competition.getPosition());
            competitionTitleId.setValue(competition.getTitle());
            descriptionId.setValue(competition.getDescription());
            conditionId.setValue(competition.getPosition());
            sloganId.setValue(competition.getSlogan());
            typeID.setValue(competition.getType());
            branchId.setValue(competition.getBranch());
        }
    }

    private void loadSignedAccounts() {
        List<CompetitionUser> users = dataManager.load(CompetitionUser.class)
                .query("select c from kpi_CompetitionUser c where " +
                        "c.competitionId = :id ")
                .parameter("id", competitionId)
                .list();

        userDc.getMutableItems().clear();
        users.forEach(user -> {
            Accounts accounts = proBonusService.reloadAccountById(user.getAccountId());
            Employee employee = employeeService.reloadEmployeeById(user.getEmployee());
            accounts.setEmployee(employee);
            userDc.getMutableItems().add(accounts);
        });

    }

    private void addItemClickActions() {
        competitionTable.setItemClickAction(new BaseAction("itemClickAction")
                .withHandler(actionPerformedEvent -> {
                    if (competitionTable.getSingleSelected() != null) {
                        showAuthorityscreenDlg(competitionTable.getSingleSelected());
                    }
                }));
        competitionTable.setEnterPressAction(new BaseAction("enterPressAction")
                .withHandler(actionPerformedEvent -> {
                    if (competitionTable.getSingleSelected() != null) {
                        showAuthorityscreenDlg(competitionTable.getSingleSelected());
                    }
                }));
    }

    private void showAuthorityscreenDlg(Competition value) {
        screenBuilders.screen(this)
                .withScreenClass(CompetitionScreen.class)
                .withOptions(new RatingUserOptions(
                        value.getId(),
                        null,
                        null, null, null, null))
                .build()
                .show();
    }

    private void loadCompetitions() {
        List<Competition> list = dataManager.load(Competition.class)
                .query("from kpi_Competition c ")
                .list();
        competitionDc.getMutableItems().clear();
        competitionDc.getMutableItems().addAll(list);
    }


//    @Subscribe("createCompetitionBtn")
//    public void onCreateCompetitionBtnClick(Button.ClickEvent event) {
//        screenBuilders.screen(this)
//                .withScreenClass(CompetitionCreate.class)
//                .build()
//                .show();
//    }
}