package kz.eub.kpi.screen.dueledit;

import io.jmix.core.DataManager;
import io.jmix.ui.Dialogs;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.CheckBox;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.FileUploadField;
import io.jmix.ui.component.GroupBoxLayout;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.TextArea;
import io.jmix.ui.component.TextField;
import io.jmix.ui.component.TimeField;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.ScreenOptions;
import io.jmix.ui.screen.StandardOutcome;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.ProBonusService;
import kz.eub.kpi.entity.Duel;
import kz.eub.kpi.entity.DuelQuestion;
import kz.eub.kpi.entity.QuestionAnswer;
import kz.eub.kpi.entity.RatingUserOptions;
import org.opendope.questions.Question;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

@UiController("kpi_DuelEdit")
@UiDescriptor("duel-edit.xml")
public class DuelEdit extends Screen {


    @Autowired
    private ComboBox<String> maritalStatusField;

    DuelQuestion duelQuestion;

    QuestionAnswer questionAnswer;
    @Autowired
    private CollectionContainer<DuelQuestion> questionDc;
    @Autowired
    private GroupBoxLayout newQuestionId;
    @Autowired
    private TextArea textAreaId;
    @Autowired
    private FileUploadField fileRefId;
    @Autowired
    private TextField firstChoice;
    @Autowired
    private CheckBox firstChoiceCheck;
    @Autowired
    private TextField secondChoice;
    @Autowired
    private CheckBox secondChoiceCheck;
    @Autowired
    private TextField thirdChoice;
    @Autowired
    private CheckBox thirdChoiceCheck;
    @Autowired
    private TextField fourthChoice;
    @Autowired
    private CheckBox fourthChoiceCheck;
    @Autowired
    private Dialogs dialogs;

    private Boolean isNew;

    List<DuelQuestion> questions = new ArrayList<>();
    @Autowired
    private GroupTable<DuelQuestion> questionsGroupTable;

    private Integer duelId;

    private Duel duel;
    @Autowired
    private ProBonusService proBonusService;
    @Autowired
    private TextField duelTitleId;
    @Autowired
    private TimeField timeId;
    @Autowired
    private TextField pointId;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private TextField questionCount;
    @Autowired
    private Button updQuestionBtn;
    @Autowired
    private Button addQuestionBtn;

    private DuelQuestion selectedQuestion;
    @Subscribe
    private void onInit(InitEvent event) {
        addItemClickActions();

        updQuestionBtn.setVisible(false);
        isNew = false;
        newQuestionId.setVisible(false);
        questions.clear();
        questionDc.getMutableItems().clear();

        duelQuestion = new DuelQuestion();
        questionAnswer = new QuestionAnswer();

        ScreenOptions options = event.getOptions();
        if (options instanceof RatingUserOptions) {
            duelId = ((RatingUserOptions) options).getAccountId();
        }

        if (duelId != null) {
            duel = proBonusService.reloadDuelById(duelId);
            duelTitleId.setValue(duel.getTitle());
            duel.getQuestions().forEach(questions -> {
                questionDc.getMutableItems().add(questions);
            });
            if (duel.getType() == true) {
                maritalStatusField.setValue("полный список");
            } else {
                maritalStatusField.setValue("выбор количества вопросов");
                questionCount.setValue(duel.getQuestionCount().toString());
            }
            timeId.setValue(duel.getTimeDuration());
            pointId.setValue(duel.getPoints().toString());
        }


        List<String> list = new ArrayList<>();
        list.add("полный список");
        list.add("выбор количества вопросов");
        maritalStatusField.setOptionsList(list);
    }

    @Subscribe("addQuestionBtn")
    public void onAddQuestionBtnClick(Button.ClickEvent event) {
        if (isNew == true) {
            if (textAreaId.isEmpty() || firstChoice.isEmpty()) {
                dialogs.createMessageDialog()
                        .withCaption("Важно")
                        .withMessage("Заполните полю")
                        .show();
            } else {
                List<QuestionAnswer> answers = new ArrayList<>();
                DuelQuestion question = new DuelQuestion();
                question.setQuestionTitle(textAreaId.getValue().toString());
                QuestionAnswer answer1 = new QuestionAnswer();
                answer1.setAnswerTitle(firstChoice.getRawValue());
                answer1.setIsCorrect(firstChoiceCheck.isChecked());
                answers.add(answer1);
                if (!secondChoice.isEmpty()) {
                    QuestionAnswer answer2 = new QuestionAnswer();
                    answer2.setAnswerTitle(secondChoice.getRawValue());
                    answer2.setIsCorrect(secondChoiceCheck.isChecked());
                    answers.add(answer2);
                }
                if (!thirdChoice.isEmpty()) {
                    QuestionAnswer answer3 = new QuestionAnswer();
                    answer3.setAnswerTitle(thirdChoice.getRawValue());
                    answer3.setIsCorrect(thirdChoiceCheck.isChecked());
                    answers.add(answer3);
                }
                if (!fourthChoice.isEmpty()) {
                    QuestionAnswer answer4 = new QuestionAnswer();
                    answer4.setAnswerTitle(fourthChoice.getRawValue());
                    answer4.setIsCorrect(fourthChoiceCheck.isChecked());
                    answers.add(answer4);
                }
                question.setId(questionDc.getItems().size() + 1);
                question.setAnswers(answers);


                newQuestionId.setVisible(false);
                isNew = false;
            }
        } else {
            newQuestionId.setVisible(true);
            isNew = true;
        }
    }

    private void clear() {
        textAreaId.clear();
        fileRefId.clear();
        firstChoice.clear();
        firstChoiceCheck.clear();
        secondChoice.clear();
        secondChoiceCheck.clear();
        thirdChoiceCheck.clear();
        thirdChoice.clear();
        fourthChoice.clear();
        fourthChoiceCheck.clear();
    }

    @Subscribe("saveDuel")
    public void onSaveDuelClick(Button.ClickEvent event) {
        duel.setTitle(duelTitleId.getValue().toString());
        duel.setQuestionCount(questionDc.getMutableItems().size());
        duel.setPoints(Integer.parseInt(pointId.getValue().toString()));
        if (questionCount != null && questionCount.getRawValue() != "") {
            duel.setQuestionCount(Integer.parseInt(questionCount.getRawValue()));
        }
        Date date = new Date();
        date.setHours(0);
        date.setMinutes(2);
        date.setSeconds(0);
        duel.setTimeDuration(date);
        duel.setStatus(true);
        dataManager.save(duel);

        duel.getQuestions().forEach(duelQuestion -> {
            duelQuestion.setDuel(duel);
        });
        duel.getQuestions().forEach(duelQuestion -> {
            dataManager.save(duelQuestion);
            duelQuestion.getAnswers().forEach(questionAnswer -> {
                questionAnswer.setDuelQuestion(duelQuestion);
                dataManager.save(questionAnswer);
            });
        });

        duel.setQuestions(questions);

        dataManager.save(duel);
        close(StandardOutcome.CLOSE);
    }

    private void addItemClickActions() {
        questionsGroupTable.setItemClickAction(new BaseAction("itemClickAction")
                .withHandler(actionPerformedEvent -> {
                    if (questionsGroupTable.getSingleSelected() != null) {
                        selectedQuestion = questionsGroupTable.getSingleSelected();
                        addQuestionBtn.setVisible(false);
                        updQuestionBtn.setVisible(true);
                        newQuestionId.setVisible(true);
                        isNew = true;
                        textAreaId.setValue(questionsGroupTable.getSingleSelected().getQuestionTitle());
                        if (questionsGroupTable.getSingleSelected().getAnswers().size() > 0) {
                            QuestionAnswer answer1 = questionsGroupTable.getSingleSelected().getAnswers().get(0);
                            firstChoice.setValue(answer1.getAnswerTitle());
                        }
                        if (questionsGroupTable.getSingleSelected().getAnswers().size() > 1) {
                            QuestionAnswer answer = questionsGroupTable.getSingleSelected().getAnswers().get(1);
                            secondChoice.setValue(answer.getAnswerTitle());
                        }
                        if (questionsGroupTable.getSingleSelected().getAnswers().size() > 2) {
                            QuestionAnswer answer = questionsGroupTable.getSingleSelected().getAnswers().get(2);
                            thirdChoice.setValue(answer.getAnswerTitle());
                        }
                        if (questionsGroupTable.getSingleSelected().getAnswers().size() > 3) {
                            QuestionAnswer answer = questionsGroupTable.getSingleSelected().getAnswers().get(3);
                            fourthChoice.setValue(answer.getAnswerTitle());
                        }
                    }
                }));
    }

    @Subscribe("maritalStatusField")
    public void duelType(HasValue.ValueChangeEvent event) {
        if (event.getValue() == "выбор количества вопросов") {
            duel.setType(false);
            questionCount.setVisible(true);
        } else {
            duel.setType(true);
            questionCount.setVisible(false);
        }
    }

    @Subscribe("updQuestionBtn")
    public void onUpdQuestionBtnClick(Button.ClickEvent event) {
        addQuestionBtn.setVisible(false);

        List<QuestionAnswer> answers = new ArrayList<>();


        selectedQuestion.setQuestionTitle(textAreaId.getValue().toString());

        selectedQuestion.getAnswers().get(0).setAnswerTitle(secondChoice.getRawValue());
        selectedQuestion.getAnswers().get(0).setIsCorrect(secondChoiceCheck.isChecked());
        QuestionAnswer answer1 = selectedQuestion.getAnswers().get(0);
        answer1.setAnswerTitle(firstChoice.getRawValue());
        answer1.setIsCorrect(firstChoiceCheck.isChecked());
        answers.add(answer1);
        if (!secondChoice.isEmpty()) {

            selectedQuestion.getAnswers().get(1).setAnswerTitle(secondChoice.getRawValue());
            selectedQuestion.getAnswers().get(1).setIsCorrect(secondChoiceCheck.isChecked());

        }
        if (!thirdChoice.isEmpty()) {

            selectedQuestion.getAnswers().get(2).setAnswerTitle(secondChoice.getRawValue());
            selectedQuestion.getAnswers().get(2).setIsCorrect(secondChoiceCheck.isChecked());
            QuestionAnswer answer3 = selectedQuestion.getAnswers().get(2);
            answer3.setAnswerTitle(thirdChoice.getRawValue());
            answer3.setIsCorrect(thirdChoiceCheck.isChecked());
            answers.add(answer3);
        }
        if (!fourthChoice.isEmpty()) {

            selectedQuestion.getAnswers().get(3).setAnswerTitle(secondChoice.getRawValue());
            selectedQuestion.getAnswers().get(3).setIsCorrect(secondChoiceCheck.isChecked());
            QuestionAnswer answer4 = selectedQuestion.getAnswers().get(3);
            answer4.setAnswerTitle(fourthChoice.getRawValue());
            answer4.setIsCorrect(fourthChoiceCheck.isChecked());
            answers.add(answer4);
        }

//        selectedQuestion.setAnswers(answers);
        duel.getQuestions().forEach(quest -> {
            if (quest.getId() == selectedQuestion.getId()) {
                quest.setQuestionTitle(selectedQuestion.getQuestionTitle());
            }
        });
        newQuestionId.setVisible(false);
        isNew = false;
        updQuestionBtn.setVisible(false);
        addQuestionBtn.setVisible(true);
    }

}