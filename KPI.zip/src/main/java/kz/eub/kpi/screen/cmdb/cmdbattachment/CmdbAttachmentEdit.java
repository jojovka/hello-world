package kz.eub.kpi.screen.cmdb.cmdbattachment;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.cmdb.CmdbAttachment;

@UiController("kpi_CmdbAttachment.edit")
@UiDescriptor("cmdb-attachment-edit.xml")
@EditedEntityContainer("cmdbAttachmentDc")
public class CmdbAttachmentEdit extends StandardEditor<CmdbAttachment> {
}