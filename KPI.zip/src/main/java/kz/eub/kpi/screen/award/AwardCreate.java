package kz.eub.kpi.screen.award;

import io.jmix.core.DataManager;
import io.jmix.ui.Notifications;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.TextField;
import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.Award;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("kpi_Award.create")
@UiDescriptor("award-create.xml")
public class AwardCreate extends StandardLookup<Award> {
    @Autowired
    private TextField<String> titleField;
    @Autowired
    private TextField<String> descriptionField;
    @Autowired
    private TextField<Double> pointField;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private Notifications notifications;

    @Subscribe("commitAndCloseBtn")
    public void onCommitAndCloseBtnClick(Button.ClickEvent event) {
        Award award = dataManager.create(Award.class);
        if (titleField.getRawValue().isEmpty()) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withDescription("Заполните название")
                    .show(); return;
        }
        award.setTitle(titleField.getRawValue());
        if (descriptionField.getRawValue().isEmpty()) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withDescription("Заполните описание")
                    .show(); return;
        }
        award.setDescription(descriptionField.getRawValue());
        if (pointField.getRawValue().isEmpty()) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withDescription("Заполните баллы")
                    .show(); return;
        }
        award.setPoints(pointField.getValue());
        award.setStatus(true);
        dataManager.save(award);
        close(StandardOutcome.CLOSE);
    }

    @Subscribe("closeBtn")
    public void onCloseBtnClick(Button.ClickEvent event) {
        close(StandardOutcome.CLOSE);
    }
}