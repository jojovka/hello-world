package kz.eub.kpi.screen.employee;

import io.jmix.core.AccessManager;
import io.jmix.core.accesscontext.SpecificOperationAccessContext;
import io.jmix.security.model.ResourceRole;
import io.jmix.security.role.ResourceRoleRepository;
import io.jmix.securityui.model.ResourceRoleModel;
import io.jmix.securityui.model.RoleModelConverter;
import io.jmix.securityui.screen.rolefilter.RoleFilter;
import io.jmix.ui.Dialogs;
import io.jmix.ui.Notifications;
import io.jmix.ui.action.Action;
import io.jmix.ui.action.DialogAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.DataGrid;
import io.jmix.ui.component.EntityComboBox;
import io.jmix.ui.component.PopupView;
import io.jmix.ui.component.TextField;
import io.jmix.ui.component.TextInputField;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.LookupComponent;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.EmployeeSecService;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.security.specific.BulkRoleAssignment;
import kz.eub.kpi.security.specific.BulkRoleDetachment;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@UiController("kpi_Employee.roles")
@UiDescriptor("employee-roles.xml")
@LookupComponent("employeesTable")
public class EmployeeRoles extends StandardLookup<Employee> {

    @Autowired
    private CollectionContainer<ResourceRoleModel> roleModelsDc;
    @Autowired
    private ResourceRoleRepository roleRepository;
    @Autowired
    private RoleModelConverter roleModelConverter;

    @Autowired
    private EntityComboBox<ResourceRoleModel> rolesField;
    @Autowired
    private EntityComboBox<DictDepartment> departmentField;
    @Autowired
    private CollectionContainer<Employee> employeesDc;

    private RoleFilter roleFilter = new RoleFilter();
    @Autowired
    private EmployeeSecService employeeSecService;
    @Autowired
    private DataGrid<Employee> employeesTable;
    @Autowired
    private Notifications notifications;
    @Autowired
    private Dialogs dialogs;
    @Autowired
    private CollectionLoader<Employee> employeesDl;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private PopupView popupView;
    @Autowired
    private CollectionContainer<ResourceRoleModel> userRolesDc;
    @Autowired
    private TextField<String> searchFioFld;
    @Autowired
    private AccessManager accessManager;
    @Autowired
    private Button assignBtn;
    @Autowired
    private Button revokeBtn;

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        loadRoles();
        toggleAssignBtn();
        toggleDetachBtn();
    }

    private void toggleDetachBtn() {
        SpecificOperationAccessContext accessContext =
                new SpecificOperationAccessContext(BulkRoleDetachment.NAME);
        accessManager.applyRegisteredConstraints(accessContext);
        revokeBtn.setVisible(accessContext.isPermitted());
    }

    private void toggleAssignBtn() {
        SpecificOperationAccessContext accessContext =
                new SpecificOperationAccessContext(BulkRoleAssignment.NAME);
        accessManager.applyRegisteredConstraints(accessContext);
        assignBtn.setVisible(accessContext.isPermitted());
    }


    protected void loadRoles() {
        Collection<ResourceRole> roles = roleRepository.getAllRoles();
        List<ResourceRoleModel> roleModels = roles.stream()
                .filter(role -> roleFilter.matches(role))
                .map(roleModelConverter::createResourceRoleModel)
                .sorted(Comparator.comparing(ResourceRoleModel::getName))
                .collect(Collectors.toList());
        roleModelsDc.getMutableItems().clear();
        roleModelsDc.getMutableItems().addAll(roleModels);
    }

    @Subscribe("refreshBtn")
    public void onRefreshBtnClick(Button.ClickEvent event) {
        if (!searchByFio()) {
            loadEmployees();
        } else {
            searchByFio();
        }
    }

    private boolean searchByFio() {
        if (searchFioFld.getValue() == null
                || searchFioFld.getValue().isEmpty())
            return false;
        List<Employee> employeeList = employeeService.searchEmployee(searchFioFld.getValue().trim());
        resetEmployeeList(employeeList);
        return true;
    }

    private void loadEmployees() {
        ResourceRoleModel role = rolesField.getValue();
        DictDepartment department = departmentField.getValue();
        if (role == null && department == null) {
            employeesDl.load();
            return;
        } else if (role == null) {
            List<Employee> employeeList = employeeService.getAllDepartmentSubTreeEmployees(department);
            resetEmployeeList(employeeList);
            return;
        }
        List<Employee> employeeList = getEmployeesByRole(role);
        employeeList = filterEmployeesByDepartment(employeeList, department);
        resetEmployeeList(employeeList);
    }

    private void resetEmployeeList(List<Employee> employeeList) {
        employeesDc.getMutableItems().clear();
        employeesDc.getMutableItems().addAll(employeeList);
    }

    private List<Employee> getEmployeesByRole(ResourceRoleModel role) {
        if (role == null) return Collections.emptyList();
        return employeeSecService.loadEmployeesHavingRole(role.getCode());
    }

    private List<Employee> filterEmployeesByDepartment(List<Employee> employeeList, DictDepartment department) {
        if (department == null) return employeeList;
        return employeeList.stream()
                    .filter(e -> e.getDepartment().getId().equals(department.getId()))
                .collect(Collectors.toList());
    }

    @Subscribe("assignBtn")
    public void onAssignBtnClick(Button.ClickEvent event) {
        ResourceRoleModel role = rolesField.getValue();
        if (role == null) {
            showWarningNotification("Выберите роль...");
            rolesField.focus();
            return;
        }
        dialogs.createOptionDialog()
                .withCaption("Потдвердите массовое назначение роли")
                .withMessage("Вы уверены что хотите назначить роль всем выбранным сотрудникам?")
                .withActions(
                        new DialogAction(DialogAction.Type.YES, Action.Status.PRIMARY)
                                .withHandler(e -> bulkRoleAssignment(role)),
                        new DialogAction(DialogAction.Type.NO)
                )
                .show();
    }

    private void bulkRoleAssignment(ResourceRoleModel role) {
        try {
            Set<Employee> employees = employeesTable.getSelected();
            if (role == null || employees.size() == 0) {
                showWarningNotification("Выберите сотрудников...");
                return;
            }

            employeeSecService.bulkRoleAssignment(employees, role.getCode());
            loadEmployees();
        } catch (Exception e) {
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Ошибка")
                    .withDescription(e.getMessage())
                    .show();
        }
    }

    private void showHumanizedNotification(String message) {
        notifications.create(Notifications.NotificationType.HUMANIZED)
                .withCaption(message)
                .show();
    }

    private void showWarningNotification(String message) {
        notifications.create(Notifications.NotificationType.WARNING)
                .withCaption(message)
                .show();
    }

    @Subscribe("employeesTable.showUserRoles")
    public void onEmployeesTableShowUserRoles(Action.ActionPerformedEvent event) {
        Employee employee = employeesTable.getSingleSelected();
        if (employee == null) return;
        employeesDc.setItem(employee);
        userRolesDc.getMutableItems().clear();
        List<ResourceRoleModel> userRoles = employeeSecService.getUserRoles(employee);
        userRolesDc.getMutableItems().addAll(userRoles);
        popupView.setVisible(true);
        popupView.setPopupVisible(true);
    }

    @Subscribe("revokeBtn")
    public void onRevokeBtnClick(Button.ClickEvent event) {
        ResourceRoleModel role = rolesField.getValue();
        if (role == null) {
            showWarningNotification("Выберите роль...");
            rolesField.focus();
            return;
        }
        dialogs.createOptionDialog()
                .withCaption("Потдвердите массовый отзыв роли")
                .withMessage("Вы уверены что хотите отозвать роль у всех выбранных сотрудников?")
                .withActions(
                        new DialogAction(DialogAction.Type.YES, Action.Status.PRIMARY)
                                .withHandler(e -> massRoleRevokation(role)),
                        new DialogAction(DialogAction.Type.NO)
                )
                .show();
    }

    private void massRoleRevokation(ResourceRoleModel role) {
        try {
            Set<Employee> employees = employeesTable.getSelected();
            if (role == null || employees.size() == 0) {
                showWarningNotification("Выберите сотрудников...");
                return;
            }

            employeeSecService.bulkRoleRevocation(employees, role.getCode());
            loadEmployees();
        } catch (Exception e) {
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Ошибка")
                    .withDescription(e.getMessage())
                    .show();
        }
    }

    @Subscribe("searchFioFld")
    public void onSearchFioFldEnterPress(TextInputField.EnterPressEvent event) {
        searchByFio();
    }

}