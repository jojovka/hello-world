package kz.eub.kpi.screen.duelcontestwithopponent;

import io.jmix.core.DataManager;
import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.GroupBoxLayout;
import io.jmix.ui.component.Label;
import io.jmix.ui.component.Timer;
import io.jmix.ui.component.VBoxLayout;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.ScreenOptions;
import io.jmix.ui.screen.StandardOutcome;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.ProBonusService;
import kz.eub.kpi.entity.Accounts;
import kz.eub.kpi.entity.Award;
import kz.eub.kpi.entity.BonusAuthority;
import kz.eub.kpi.entity.Duel;
import kz.eub.kpi.entity.DuelContest;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.RatingUserOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Date;
import java.util.UUID;

@UiController("kpi_DuelContestWithOpponent")
@UiDescriptor("duel-contest-with-opponent.xml")
public class DuelContestWithOpponent extends Screen {

    DuelContest contest;

    @Autowired
    protected Timer timer;

    @Autowired
    GroupBoxLayout btn1;

    @Autowired
    GroupBoxLayout btn2;

    @Autowired
    GroupBoxLayout btn3;

    @Autowired
    GroupBoxLayout btn4;

    protected int seconds = 0;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private CurrentUserSubstitution currentUserSubstitution;
    @Autowired
    private Label userName;

    private Duel duel;
    @Autowired
    private ProBonusService proBonusService;
    @Autowired
    private Label questionOrder;

    private Integer questionIndex;
    @Autowired
    private Label questionId;
    @Autowired
    private Button answer1;
    @Autowired
    private Button answer2;
    @Autowired
    private Button answer3;
    @Autowired
    private Button answer4;
    @Autowired
    private Label pointOpponent;

    @Autowired
    private VBoxLayout questionAnswerShow;
    @Autowired
    private GroupBoxLayout questionTitleShowId;
    @Autowired
    private GroupBoxLayout resultShowId;

    private Accounts accoutContester;

    private Accounts accountOpponent;
    private Employee employee;
    @Autowired
    private Label userNameId;
    @Autowired
    private Label result;
    @Autowired
    private Label duelTimeId;
    @Autowired
    private Label opponentPointId;

    Integer time;



    @Subscribe
    private void onInit(InitEvent event) {
        btn1.setVisible(false);
        btn2.setVisible(false);
        btn3.setVisible(false);
        btn4.setVisible(false);
        result.setVisible(false);
        ScreenOptions options = event.getOptions();
        Integer account = 0;
        Integer duelId = 0;

        if (options instanceof RatingUserOptions) {
             account = ((RatingUserOptions) options).getAccountId();
             duelId =  ((RatingUserOptions) options).getTypeId();
        }

        pointOpponent.setValue(0);
        resultShowId.setVisible(false);

        contest = proBonusService.reloadOpenDuelContest();
        contest.setPointOpponent(0);
        questionIndex = 0;
        duel = proBonusService.reloadDuelById(duelId);
        loadCurrentEmployee();
        if (duel != null && duel.getTimeDuration() != null) {
            Integer minutValue = duel.getTimeDuration().getMinutes();
            Integer secondValue = duel.getTimeDuration().getSeconds();
            time = minutValue * 60 + secondValue;
            duelTimeId.setValue(time.toString());
        }
        accountOpponent = proBonusService.reloadAccountsByPayroll(employee.getPayrollNumber());
        if (accountOpponent != null) {
            userNameId.setValue(accountOpponent.getProfileId().getFirstname());
        }
        accoutContester = proBonusService.reloadAccountById(account);
        if (accoutContester != null) {
            userName.setValue(accoutContester.getProfileId().getFirstname());

        }

        if (duel != null && duel.getQuestions() != null && duel.getQuestions().size() > 0) {
            questionOrder.setValue(questionIndex + 1);
            questionId.setValue(duel.getQuestions().get(questionIndex).getQuestionTitle());
            if (duel.getQuestions().get(questionIndex).getAnswers().size() > 0) {
                answer1.setCaption(duel.getQuestions().get(questionIndex).getAnswers().get(0).getAnswerTitle());
                btn1.setVisible(true);
            }
            if (duel.getQuestions().get(questionIndex).getAnswers().size() > 1) {
                answer2.setCaption(duel.getQuestions().get(questionIndex).getAnswers().get(1).getAnswerTitle());
                btn2.setVisible(true);
            }
            if (duel.getQuestions().get(questionIndex).getAnswers().size() > 2) {
                answer3.setCaption(duel.getQuestions().get(questionIndex).getAnswers().get(2).getAnswerTitle());
                btn3.setVisible(true);
            }
            if (duel.getQuestions().get(questionIndex).getAnswers().size() > 3) {
                answer4.setCaption(duel.getQuestions().get(questionIndex).getAnswers().get(3).getAnswerTitle());
                btn4.setVisible(true);
            }
        }
    }

    @Autowired
    private Label timerId;

    @Subscribe("timer")
    protected void onTimerTick(Timer.TimerActionEvent event) {
        seconds += event.getSource().getDelay() / 1000;
        System.out.println("time");
        System.out.println(time);
        if (seconds == time) {
            questionAnswerShow.setVisible(false);
            questionTitleShowId.setVisible(false);
            resultShowId.setVisible(true);
            timerId.setVisible(false);

        }
        timerId.setValue(seconds + " секунд");
    }

    @Subscribe("answer1")
    public void btnQst1(Button.ClickEvent event) {
        if (duel.getQuestions().get(questionIndex).getAnswers().size() > 0
                && duel.getQuestions().get(questionIndex).getAnswers().get(0).getIsCorrect()) {
            contest.setPointOpponent(contest.getPointOpponent() + 1);
            pointOpponent.setValue(contest.getPointOpponent());
        }
        isFinished();
    }

    @Subscribe("answer2")
    public void btnQst2(Button.ClickEvent event) {

        if (duel.getQuestions().get(questionIndex).getAnswers().size() > 1 &&
                duel.getQuestions().get(questionIndex).getAnswers().get(1).getIsCorrect()) {
            contest.setPointOpponent(contest.getPointOpponent() + 1);
            pointOpponent.setValue(contest.getPointOpponent());
        }
        isFinished();
    }

    @Subscribe("answer3")
    public void btnQst3(Button.ClickEvent event) {
        if (duel.getQuestions().get(questionIndex).getAnswers().size() > 2 &&
                duel.getQuestions().get(questionIndex).getAnswers().get(2).getIsCorrect()) {
            contest.setPointOpponent(contest.getPointOpponent() + 1);
            pointOpponent.setValue(contest.getPointOpponent());
        }
        isFinished();

    }


    @Subscribe("answer4")
    public void btnQst4(Button.ClickEvent event) {
        if (duel.getQuestions().get(questionIndex).getAnswers().size() > 3
                && duel.getQuestions().get(questionIndex).getAnswers().get(3).getIsCorrect()) {
            contest.setPointOpponent(contest.getPointOpponent() + 1);
            pointOpponent.setValue(contest.getPointOpponent());
        }
        isFinished();
    }

    private void loadCurrentEmployee() {
        UserDetails user = currentUserSubstitution.getEffectiveUser();
        employee = dataManager.load(Employee.class)
                .query("select c from kpi_Employee c " +
                        "where c.username = :username")
                .parameter("username", user.getUsername())
                .optional().orElse(dataManager.create(Employee.class));
        var payroll = employee.getPayrollNumber();
        var emplId = employee.getId();
        loadEmployee(emplId);
    }

    private void loadEmployee(UUID emplId) {
        UserDetails user = currentUserSubstitution.getEffectiveUser();
        employee = dataManager.load(Employee.class)
                .query("select c from kpi_Employee c " +
                        "where c.id = :id")
                .parameter("id", emplId)
                .optional().orElse(dataManager.create(Employee.class));
        var payroll = employee.getPayrollNumber();
        var empslId = employee.getId();
    }


    private boolean isFinished() {
        if (duel.getQuestions().size() > questionIndex + 1) {
            questionIndex++;
            questionOrder.setValue(questionIndex);
            questionId.setValue(duel.getQuestions().get(questionIndex).getQuestionTitle());
            answer1.setCaption(duel.getQuestions().get(questionIndex).getAnswers().get(0).getAnswerTitle());
            if (duel.getQuestions().get(questionIndex).getAnswers().size() > 1) {
                answer2.setCaption(duel.getQuestions().get(questionIndex).getAnswers().get(1).getAnswerTitle());
            }
            if (duel.getQuestions().get(questionIndex).getAnswers().size() > 2) {
                answer3.setCaption(duel.getQuestions().get(questionIndex).getAnswers().get(2).getAnswerTitle());
            }
            if (duel.getQuestions().get(questionIndex).getAnswers().size() > 3) {
                answer4.setCaption(duel.getQuestions().get(questionIndex).getAnswers().get(3).getAnswerTitle());
            }

            return false;
        } else {
            questionAnswerShow.setVisible(false);
            questionTitleShowId.setVisible(false);
            result.setVisible(true);
            resultShowId.setVisible(true);
            if (contest.getPointContester() == null) {
                contest.setPointContester(0);
            }
            BonusAuthority award = dataManager.create(BonusAuthority.class);
            award.setCreatedDate(new Date());
            award.setDescription("Бонус за дуэль");
            award.setBonus(duel.getPoints().doubleValue());

            if (contest.getContester() != null && Integer.parseInt(pointOpponent.getValue().toString()) > contest.getPointContester()) {
                result.setValue("Выиграли");

                Accounts accounts = proBonusService.reloadAccountById(accountOpponent.getId());
                Employee employee = proBonusService.reloadEmployeeByPayroll(accounts.getIdentityProperty());
                award.setEmployee(employee);
                dataManager.save(award);
                contest.setWinner(2);
                contest.setWinnerStaff(accountOpponent);
            } else if (contest.getContester() != null && Integer.parseInt(pointOpponent.getValue().toString()) < contest.getPointContester()) {
                result.setValue("Проиграли");
                Accounts accounts = proBonusService.reloadAccountById(accoutContester.getId());
                Employee employee = proBonusService.reloadEmployeeByPayroll(accounts.getIdentityProperty());
                award.setEmployee(employee);
                dataManager.save(award);
                contest.setWinner(1);
                contest.setWinnerStaff(accoutContester);
            } else if (contest.getContester() != null && Integer.parseInt(pointOpponent.getValue().toString()) == contest.getPointContester()){
                result.setValue("Ничья");
                contest.setWinner(0);
            } else {
                result.setValue("Завершить");
            }
            return true;
        }

    }

    @Subscribe("closeBtn")
    public void onCloseBtnClick(Button.ClickEvent event) {

        contest.setPointOpponent(Integer.parseInt(pointOpponent.getValue().toString()));
        if (contest.getWinner() != null) {
            contest.setFinished_date(new Date());
        }
        if (contest.getWinner() == null) {
            contest.setCreated_date(new Date());
        }
        contest.setOpponent(accountOpponent);
        contest.setDuelId(duel);
        dataManager.save(contest);
        close(StandardOutcome.CLOSE);
    }
}