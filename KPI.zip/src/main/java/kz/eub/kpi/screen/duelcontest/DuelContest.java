package kz.eub.kpi.screen.duelcontest;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.GroupBoxLayout;
import io.jmix.ui.component.Label;
import io.jmix.ui.component.VBoxLayout;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.ScreenOptions;
import io.jmix.ui.screen.StandardOutcome;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.ProBonusService;
import kz.eub.kpi.entity.Accounts;
import kz.eub.kpi.entity.Duel;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.RatingUserOptions;
import liquibase.pro.packaged.D;
import org.springframework.beans.factory.annotation.Autowired;
import io.jmix.ui.component.Timer;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Date;
import java.util.UUID;

@UiController("kpi_DuelContest")
@UiDescriptor("duel-contest.xml")
public class DuelContest extends Screen {


    @Autowired
    private FetchPlans fetchPlans;
    kz.eub.kpi.entity.DuelContest contest;

    @Autowired
    protected Timer timer;

    protected int seconds = 0;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private CurrentUserSubstitution currentUserSubstitution;
    @Autowired
    private Label userName;

    private Duel duel;
    @Autowired
    private ProBonusService proBonusService;
    @Autowired
    private Label questionOrder;

    private Integer questionIndex;
    @Autowired
    private Label questionId;
    @Autowired
    private Button answer1;
    @Autowired
    private Button answer2;
    @Autowired
    private Button answer3;
    @Autowired
    private Button answer4;
    @Autowired
    private Label pointContester;
    @Autowired
    private VBoxLayout questionAnswerShow;
    @Autowired
    private GroupBoxLayout questionTitleShowId;
    @Autowired
    private GroupBoxLayout resultShowId;

    private Accounts accoutContester;
    private Employee employee;
    @Autowired
    private GroupBoxLayout btn1;
    @Autowired
    private GroupBoxLayout btn2;
    @Autowired
    private GroupBoxLayout btn3;
    @Autowired
    private GroupBoxLayout btn4;


    @Subscribe
    private void onInit(InitEvent event) {

        ScreenOptions options = event.getOptions();
        Integer duelId = 0;

        if (options instanceof RatingUserOptions) {
            duelId = ((RatingUserOptions) options).getTypeId();

        }
        pointContester.setValue(0);
        resultShowId.setVisible(false);
        contest = dataManager.create(kz.eub.kpi.entity.DuelContest.class);
        contest.setPointContester(0);
        questionIndex = 0;
        duel = proBonusService.reloadDuel(duelId);
        loadCurrentEmployee();
        accoutContester = proBonusService.reloadAccountsByPayroll(employee.getPayrollNumber());
        if (accoutContester != null) {
            userName.setValue(accoutContester.getProfileId().getFirstname());
        }
        if (duel != null && duel.getQuestions() != null && duel.getQuestions().size() > 0) {
            questionOrder.setValue(questionIndex + 1);
            questionId.setValue(duel.getQuestions().get(questionIndex).getQuestionTitle());
            if (duel.getQuestions().get(questionIndex).getAnswers().size() > 0) {
                answer1.setCaption(duel.getQuestions().get(questionIndex).getAnswers().get(0).getAnswerTitle());
                btn1.setVisible(true);
            }
            if (duel.getQuestions().get(questionIndex).getAnswers().size() > 1) {
                answer2.setCaption(duel.getQuestions().get(questionIndex).getAnswers().get(1).getAnswerTitle());
                btn2.setVisible(true);
            }
            if (duel.getQuestions().get(questionIndex).getAnswers().size() > 2) {
                answer3.setCaption(duel.getQuestions().get(questionIndex).getAnswers().get(2).getAnswerTitle());
                btn3.setVisible(true);
            }
            if (duel.getQuestions().get(questionIndex).getAnswers().size() > 3) {
                answer4.setCaption(duel.getQuestions().get(questionIndex).getAnswers().get(3).getAnswerTitle());
                btn4.setVisible(true);
            }
        }
    }

    @Autowired
    private Label timerId;

    @Subscribe("timer")
    protected void onTimerTick(Timer.TimerActionEvent event) {
        seconds += event.getSource().getDelay() / 1000;
        if (seconds == 120) {
            questionAnswerShow.setVisible(false);
            questionTitleShowId.setVisible(false);
            resultShowId.setVisible(true);
            timerId.setVisible(false);

        }
        timerId.setValue(seconds + " секунд");
    }

    @Subscribe("answer1")
    public void btnQst1(Button.ClickEvent event) {
        if (duel.getQuestions().size() > questionIndex && duel.getQuestions().get(questionIndex).getAnswers().size() > 0
                && duel.getQuestions().get(questionIndex).getAnswers().get(0).getIsCorrect()) {
            contest.setPointContester(contest.getPointContester() + 1);
            pointContester.setValue(contest.getPointContester());
        }
        isFinished();
    }

    @Subscribe("answer2")
    public void btnQst2(Button.ClickEvent event) {
        if (duel.getQuestions().size() > questionIndex && duel.getQuestions().get(questionIndex).getAnswers().size() > 1 &&
                duel.getQuestions().get(questionIndex).getAnswers().get(1).getIsCorrect()) {
            contest.setPointContester(contest.getPointContester() + 1);
            pointContester.setValue(contest.getPointContester());
        }
        isFinished();
    }

    @Subscribe("answer3")
    public void btnQst3(Button.ClickEvent event) {
        if (duel.getQuestions().size() > questionIndex && duel.getQuestions().get(questionIndex).getAnswers().size() > 2 &&
                duel.getQuestions().get(questionIndex).getAnswers().get(2).getIsCorrect()) {
            contest.setPointContester(contest.getPointContester() + 1);
            pointContester.setValue(contest.getPointContester());
        }
        isFinished();

    }


    @Subscribe("answer4")
    public void btnQst4(Button.ClickEvent event) {
        if (duel.getQuestions().size() > questionIndex && duel.getQuestions().get(questionIndex).getAnswers().size() > 3
                && duel.getQuestions().get(questionIndex).getAnswers().get(3).getIsCorrect()) {
            contest.setPointContester(contest.getPointContester() + 1);
            pointContester.setValue(contest.getPointContester());
        }
        isFinished();
    }

    private void loadCurrentEmployee() {
        FetchPlan fetchPlan = geUserFetchPlan();
        UserDetails user = currentUserSubstitution.getEffectiveUser();
        employee = dataManager.load(Employee.class)
                .query("select c from kpi_Employee c " +
                        "where c.username = :username")
                .parameter("username", user.getUsername())
                .fetchPlan(fetchPlan)
                .optional().orElse(dataManager.create(Employee.class));
        var payroll = employee.getPayrollNumber();
        var emplId = employee.getId();
        loadEmployee(emplId);

    }

    private void loadEmployee(UUID emplId) {
        FetchPlan fetchPlan = geUserFetchPlan();
        UserDetails user = currentUserSubstitution.getEffectiveUser();
        employee = dataManager.load(Employee.class)
                .query("select c from kpi_Employee c " +
                        "where c.id = :id")
                .parameter("id", emplId)
                .fetchPlan(fetchPlan)
                .optional().orElse(dataManager.create(Employee.class));
        var payroll = employee.getPayrollNumber();
        var empslId = employee.getId();
    }

    private FetchPlan geUserFetchPlan() {
        return fetchPlans.builder(Employee.class)
                .addFetchPlan(FetchPlan.INSTANCE_NAME)
                .add("payrollNumber", FetchPlan.BASE)
                .add("gender", FetchPlan.BASE)
                .add("iin", FetchPlan.BASE)
                .build();
    }


    private boolean isFinished() {
        if (duel.getQuestions().size() > questionIndex + 1) {
            questionIndex++;
            questionOrder.setValue(questionIndex + 1);
            questionId.setValue(duel.getQuestions().get(questionIndex).getQuestionTitle());
            answer1.setCaption(duel.getQuestions().get(questionIndex).getAnswers().get(0).getAnswerTitle());
            if (duel.getQuestions().get(questionIndex).getAnswers().size() > 1) {
                answer2.setCaption(duel.getQuestions().get(questionIndex).getAnswers().get(1).getAnswerTitle());
            }
            if (duel.getQuestions().get(questionIndex).getAnswers().size() > 2) {
                answer3.setCaption(duel.getQuestions().get(questionIndex).getAnswers().get(2).getAnswerTitle());
            }
            if (duel.getQuestions().get(questionIndex).getAnswers().size() > 3) {
                answer4.setCaption(duel.getQuestions().get(questionIndex).getAnswers().get(3).getAnswerTitle());
            }

            return false;
        } else {
            questionAnswerShow.setVisible(false);
            questionTitleShowId.setVisible(false);
            resultShowId.setVisible(true);
            return true;
        }

    }

    @Subscribe("closeBtn")
    public void onCloseBtnClick(Button.ClickEvent event) {
        contest.setDuelId(duel);
        contest.setPointContester(Integer.parseInt(pointContester.getValue().toString()));
        contest.setCreated_date(new Date());
        contest.setContester(accoutContester);
        dataManager.save(contest);
        close(StandardOutcome.CLOSE);
    }
}