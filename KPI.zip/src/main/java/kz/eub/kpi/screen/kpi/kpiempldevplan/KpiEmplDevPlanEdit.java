package kz.eub.kpi.screen.kpi.kpiempldevplan;

import io.jmix.ui.component.CurrencyField;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.KpiEmplDevPlan;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

@UiController("kpi_KpiEmplDevPlan.edit")
@UiDescriptor("kpi-empl-dev-plan-edit.xml")
@EditedEntityContainer("kpiEmplDevPlanDc")
public class KpiEmplDevPlanEdit extends StandardEditor<KpiEmplDevPlan> {

    @Autowired
    private CurrencyField<BigDecimal> efficiencyField;

    @Subscribe("performanceField")
    public void onPerformanceFieldValueChange(HasValue.ValueChangeEvent<BigDecimal> event) {
        updateEfficiency();
    }

    @Subscribe("weightField")
    public void onWeightFieldValueChange(HasValue.ValueChangeEvent<BigDecimal> event) {
        updateEfficiency();
    }

    private void updateEfficiency() {
        efficiencyField.setValue(getEditedEntity().getEfficiency());
    }

}