package kz.eub.kpi.screen.bonusauthority;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.BonusAuthority;

@UiController("kpi_BonusAuthority.edit")
@UiDescriptor("bonus-authority-edit.xml")
@EditedEntityContainer("bonusAuthorityDc")
public class BonusAuthorityEdit extends StandardEditor<BonusAuthority> {
}