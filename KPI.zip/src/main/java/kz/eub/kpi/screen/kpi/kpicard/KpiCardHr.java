package kz.eub.kpi.screen.kpi.kpicard;

import io.jmix.bpm.util.FlowableEntitiesConverter;
import io.jmix.bpmui.processform.ProcessFormContext;
import io.jmix.bpmui.processform.annotation.ProcessForm;
import io.jmix.bpmui.processform.annotation.ProcessVariable;
import io.jmix.ui.Notifications;
import io.jmix.ui.component.Button;
import io.jmix.ui.screen.EditedEntityContainer;
import io.jmix.ui.screen.StandardEditor;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.KpiCardService;
import kz.eub.kpi.app.service.KpiGoalService;
import kz.eub.kpi.entity.kpi.KpiCard;
import org.flowable.engine.RuntimeService;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("kpi_KpiCard.hr")
@UiDescriptor("kpi-card-hr.xml")
@EditedEntityContainer("kpiCardDc")
@ProcessForm
public class KpiCardHr extends StandardEditor<KpiCard> {

    @ProcessVariable
    private KpiCard application;

    @Autowired
    private ProcessFormContext processFormContext;
    @Autowired
    private RuntimeService runtimeService;
    @Autowired
    private FlowableEntitiesConverter flowableEntitiesConverter;


    @Autowired
    private KpiCardService kpiCardService;
    @Autowired
    private KpiGoalService kpiGoalService;
    @Autowired
    private Notifications notifications;

    @Subscribe
    public void onInit(InitEvent event) {
        if (application != null) {
            setEntityToEdit(application);
        }
    }

    @Subscribe
    public void onBeforeCommitChanges(BeforeCommitChangesEvent event) {
        try {
            kpiCardService.validateKpiCard(getEditedEntity());
        } catch (Exception e) {
            event.preventCommit();
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption(e.getMessage())
                    .show();
        }
    }

    private void sendToApprovalTask() {
        commitChanges();
        processFormContext.taskCompletion()
//                .withOutcome(outcome)
                .saveInjectedProcessVariables()
                .complete();
        notifications.create(Notifications.NotificationType.TRAY)
                .withCaption("Цель КПЭ отправлена на согласование...")
                .show();
        closeWithDiscard();
    }

    @Subscribe("sendBtn")
    public void onSendBtnClick(Button.ClickEvent event) {
        sendToApprovalTask();
    }

}