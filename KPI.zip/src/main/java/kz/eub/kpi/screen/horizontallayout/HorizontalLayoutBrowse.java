package kz.eub.kpi.screen.horizontallayout;

import io.jmix.core.LoadContext;
import io.jmix.ui.screen.*;
import io.jmix.dashboards.model.visualmodel.HorizontalLayout;

import java.util.Collections;
import java.util.List;

@UiController("dshbrd_HorizontalLayout.browse")
@UiDescriptor("horizontal-layout-browse.xml")
@LookupComponent("horizontalLayoutsTable")
public class HorizontalLayoutBrowse extends StandardLookup<HorizontalLayout> {

    @Install(to = "horizontalLayoutsDl", target = Target.DATA_LOADER)
    private List<HorizontalLayout> horizontalLayoutsDlLoadDelegate(LoadContext<HorizontalLayout> loadContext) {
        // Here you can load entities from an external store
        return Collections.emptyList();
    }
}