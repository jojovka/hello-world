package kz.eub.kpi.screen.bonusauthority;

import io.jmix.ui.action.list.EditAction;
import io.jmix.ui.action.list.ViewAction;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.BonusAuthority;
import kz.eub.kpi.screen.bonusprofile.BonusProfileScreen;
import kz.eub.kpi.screen.profile.ProfileScreen;
import org.springframework.beans.factory.annotation.Autowired;

import javax.inject.Named;

@UiController("kpi_BonusAuthority.browse")
@UiDescriptor("bonus-authority-browse.xml")
@LookupComponent("bonusAuthoritiesTable")
public class BonusAuthorityBrowse extends StandardLookup<BonusAuthority> {

}