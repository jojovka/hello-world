package kz.eub.kpi.screen.authorityview;

import io.jmix.core.DataManager;
import io.jmix.core.Metadata;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.EntityComboBox;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.TextField;
import io.jmix.ui.component.TextInputField;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.app.service.ProBonusService;
import kz.eub.kpi.entity.AccountProfiles;
import kz.eub.kpi.entity.Accounts;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.DictPosition;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.RatingUser;
import kz.eub.kpi.entity.RatingUserOptions;
import kz.eub.kpi.screen.authority.Authorityscreen;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

@UiController("kpi_Authorityview")
@UiDescriptor("AuthorityView.xml")
public class Authorityview extends StandardLookup<RatingUser> {

    @Autowired
    private GroupTable<Accounts> ratingUserTable;
    @Autowired
    private ScreenBuilders screenBuilders;

    @Autowired
    protected CollectionContainer<DictDepartment> depDc;
    private DictDepartment selectedDepartment;

    private String selectedPosition;
    @Autowired
    protected Metadata metadata;

    @Autowired
    private DataManager dataManager;
    @Autowired
    private CollectionContainer<Accounts> kpiRatingDc;
    @Autowired
    private ProBonusService proBonusService;


    private List<DictDepartment> departmentList;
    int index = 0;
    @Autowired
    private EntityComboBox<DictDepartment> depComboBox;
    @Autowired
    private TextField searchField;
    @Autowired
    private CollectionContainer<DictPosition> posDc;
    @Autowired
    private ComboBox podComboBox;
    @Autowired
    private EmployeeService employeeService;

    @Subscribe
    private void onInit(InitEvent event) {

        addItemClickActions();
        getDepartments();
    }

    @Subscribe
    protected void onBeforeShow(BeforeShowEvent event) {
        getDepartments();
    }


    private void addItemClickActions() {
        ratingUserTable.setItemClickAction(new BaseAction("itemClickAction")
                .withHandler(actionPerformedEvent -> {
                    if (ratingUserTable.getSingleSelected() != null) {
                        showAuthorityscreenDlg(ratingUserTable.getSingleSelected());
                    }
                }));
        ratingUserTable.setEnterPressAction(new BaseAction("enterPressAction")
                .withHandler(actionPerformedEvent -> {
                    if (ratingUserTable.getSingleSelected() != null) {
                        showAuthorityscreenDlg(ratingUserTable.getSingleSelected());
                    }
                }));
    }

    private void showAuthorityscreenDlg(Accounts value) {
        screenBuilders.screen(this)
                .withScreenClass(Authorityscreen.class)
                .withOptions(new RatingUserOptions(
                        value.getId(),
                        (ratingUserTable.getSingleSelected().getProfileId().getFirstname()
                                + " " + ratingUserTable.getSingleSelected().getProfileId().getLastname()),
                        null, null, null, null))
                .build()
                .show();
    }



    @Subscribe("depComboBox")
    public void onDepComboBoxValueChange(HasValue.ValueChangeEvent<DictDepartment> event) {
        selectedDepartment = event.getValue();
        loadPositions(event.getValue());
    }

    private void loadPositions(DictDepartment dep) {
        List<String> posList = proBonusService.loadPositionsByDep(dep.getName());
        podComboBox.setOptionsList(posList);
        podComboBox.setEnterPressHandler(enterPressEvent -> {
            selectedPosition = enterPressEvent.getText();
        });
    }

    private void getDepartments() {
        List<DictDepartment> customDep = new ArrayList<>();
        List<DictDepartment> departments = depDc.getItems();
        departments.forEach(dictDepartment -> {
            if (dictDepartment.getRubillix() == true) {
                customDep.add(dictDepartment);
            }
        });
        depDc.getMutableItems().clear();
        depDc.getMutableItems().addAll(customDep);

    }


    @Subscribe("searchField")
    public void onSearchFieldEnterPress(TextInputField.EnterPressEvent event) {
        List<Accounts> accountUsers = new ArrayList<>();
        List<AccountProfiles> accountsList = proBonusService.searchAccountByFio(searchField.getRawValue());

        List<Employee> employee = employeeService.searchEmployee(searchField.getRawValue());
        employee.forEach(empl -> {
            Accounts account = proBonusService.reloadAccountsByPayroll(empl.getPayrollNumber());
            if (account != null ) {
                accountUsers.add(account);
            }
        });



        kpiRatingDc.getMutableItems().clear();
        kpiRatingDc.getMutableItems().addAll(accountUsers);
    }

    @Subscribe("podComboBox")
    public void onPodComboBoxValueChange(HasValue.ValueChangeEvent event) {
        selectedPosition = event.getValue().toString();
        List<Employee> employeeList = proBonusService.loadDepPositions(selectedDepartment.getName(), selectedPosition);
        System.out.println(employeeList.size());
        List<Accounts> ratingUsers = new ArrayList<>();
        employeeList.forEach(empl -> {
            Accounts accounts = proBonusService.reloadAccountsByPayroll(empl.getPayrollNumber());
            if (accounts != null)
            {
                ratingUsers.add(accounts);
            }
        });
        kpiRatingDc.getMutableItems().clear();
        kpiRatingDc.getMutableItems().addAll(ratingUsers);

    }


}