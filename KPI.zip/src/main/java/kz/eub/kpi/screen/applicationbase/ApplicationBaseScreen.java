package kz.eub.kpi.screen.applicationbase;

import io.jmix.bpm.entity.ProcessInstanceData;
import io.jmix.bpmui.screen.processinstance.diagramfragment.BpmnDiagramViewerFragment;
import io.jmix.core.Messages;
import io.jmix.ui.Dialogs;
import io.jmix.ui.Notifications;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.Action;
import io.jmix.ui.action.DialogAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.Label;
import io.jmix.ui.component.TabSheet;
import io.jmix.ui.component.Table;
import io.jmix.ui.icon.JmixIcon;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.EditedEntityContainer;
import io.jmix.ui.screen.StandardEditor;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.HasRefreshableContent;
import kz.eub.kpi.app.service.ApplicationService;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.entity.Application;
import kz.eub.kpi.entity.ApplicationComment;
import kz.eub.kpi.entity.EApplicationStatus;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.screen.applicationcomment.ApplicationCommentEdit;
import kz.eub.kpi.screen.bpm.bpmtaskhistoryfragment.BpmTaskHistoryFragment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@UiController("kpi_ApplicationBaseScreen")
@UiDescriptor("application-base-screen.xml")
@EditedEntityContainer("applicationDc")
public abstract class ApplicationBaseScreen<T extends Application> extends StandardEditor<T> implements HasRefreshableContent {

    public static final Logger log = LoggerFactory.getLogger(ApplicationBaseScreen.class);

    private final Class<T> type;
    @Autowired
    private Label title;
    @Autowired
    private Button sendBtn;
    @Autowired
    private ApplicationService applicationService;
    @Autowired
    private Notifications notifications;
    @Autowired
    private Button revokeBtn;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private Dialogs dialogs;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private Button commentsTableEditBtn;
    @Autowired
    private Button commentsTableRemoveBtn;
    @Autowired
    private TabSheet tabSheet;
    @Autowired
    private Messages messages;
    @Autowired
    private Table<ApplicationComment> commentsTable;

    public ApplicationBaseScreen(Class<T> type) {
        this.type = type;
    }

    @Autowired
    private BpmTaskHistoryFragment taskHistoryFragment;
    @Autowired
    private InstanceContainer<ProcessInstanceData> processInstanceDataDc;
    @Autowired
    private BpmnDiagramViewerFragment bpmFragment;


    public abstract void reloadApplication();

    protected abstract void startNewApplicationProcess();

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        setReadOnly(true);
        setTitle();
        resetBpmFragmentProcessInstance();
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        toggleStartBtn();
        toggleRevokeBtn();
        markCommentsCount();
    }

    private void toggleRevokeBtn() {
        revokeBtn.setVisible(false);
        T application = getEditedEntity();
        Set<EApplicationStatus> statuses = new HashSet<>(
                Arrays.asList(EApplicationStatus.NEW,
                        EApplicationStatus.AGREED,
                        EApplicationStatus.COMPLETED,
                        EApplicationStatus.REVOKED,
                        EApplicationStatus.REJECTED));
        if (!statuses.contains(application.getStatus())) {
            Employee currentEmployee = employeeService.getCurrentEmployee();
            if (application.getAuthor() != null
                    && currentEmployee != null
                    && Objects.equals(application.getAuthor().getId(), currentEmployee.getId())) {
                revokeBtn.setVisible(true);
            }
        }
    }

    protected void toggleStartBtn() {
        Application application = getEditedEntity();
        Set<EApplicationStatus> statuses = new HashSet<>(
                Arrays.asList(EApplicationStatus.NEW,
                        EApplicationStatus.REVOKED));
        sendBtn.setVisible(statuses.contains(application.getStatus()));
    }

    private void setTitle() {
        T application = getEditedEntity();
        title.setValue(application.getName() + " №" + application.getSn());
    }

    @Override
    public void refreshContent() {
        taskHistoryFragment.refreshContent();
        resetBpmFragmentProcessInstance();
        reloadApplication();
    }

    protected void resetBpmFragmentProcessInstance() {
        Application application = getEditedEntity();
        ProcessInstanceData processInstanceData = applicationService.loadApplicationProcessInstanceData(application);
        processInstanceDataDc.setItem(processInstanceData);
        if (processInstanceData == null) return;
        bpmFragment.setProcessInstanceData(processInstanceData);
    }

    @Subscribe("sendBtn")
    public void onSendBtnClick(Button.ClickEvent event) {
        startNewApplicationProcess();
    }

    @Subscribe("revokeBtn")
    public void onRevokeBtnClick(Button.ClickEvent event) {
        dialogs.createOptionDialog()
                .withCaption("Вы подтверждаете?")
                .withMessage("Вы действительно хотите отозвать заявку?")
                .withActions(
                        new DialogAction(DialogAction.Type.YES, Action.Status.PRIMARY)
                                .withHandler(e -> revokeApplication()),
                        new DialogAction(DialogAction.Type.NO)
                )
                .show();
    }

    private void revokeApplication() {
        try {
            if (applicationService.cancelApplicationProcess(getEditedEntity(), "Отозвана инициатором.")) {
                notifications.create()
                        .withCaption("Заявка успешно отозвана...")
                        .show();
                closeWithDiscard();
            }
        } catch (Exception e) {
            log.error("Ошибка при отзыве заявки: ", e);
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Не удалось отозвать заявку...")
                    .withDescription(e.getMessage())
                    .show();
        }
    }

    @Subscribe("commentsTableCreateBtn")
    public void onCommentsTableCreateBtnClick(Button.ClickEvent event) {
        ApplicationCommentEdit commentEditScreen = screenBuilders.editor(ApplicationComment.class, this)
                .withScreenClass(ApplicationCommentEdit.class)
                .withInitializer(c -> {
                    c.setApplication(getEditedEntity());
                    c.setAuthor(employeeService.getCurrentEmployee());
                })
                .build();
        commentEditScreen.setReadOnly(false);
        commentEditScreen.setEditable();
        commentEditScreen.addAfterCloseListener(e -> reloadApplication());
        commentEditScreen.show();
    }

    @Subscribe("commentsTable")
    public void onCommentsTableSelection(Table.SelectionEvent<ApplicationComment> event) {
        commentsTableEditBtn.setEnabled(false);
        commentsTableRemoveBtn.setEnabled(false);
        Employee employee = employeeService.getCurrentEmployee();
        ApplicationComment comment = commentsTable.getSingleSelected();
        if (comment != null && comment.getAuthor() != null
                && comment.getAuthor().getId().equals(employee.getId())) {
            commentsTableEditBtn.setEnabled(true);
            commentsTableRemoveBtn.setEnabled(true);
        }
    }

    private void markCommentsCount() {
        Application application = getEditedEntity();
        String message = messages.getMessage("kz.eub.kpi.screen.applicationbase/comments");
        int size = 0;
        if (application.getComments() != null)
            size = application.getComments().size();
        String color = "blue";
        JmixIcon icon = JmixIcon.COMMENT_O;
        if (size > 0) {
            color = "red";
        }
        message = message + " <span style='color: " + color + "'><b>(" + size + ")</b></span>";
        tabSheet.setTabCaptionsAsHtml(true);
        TabSheet.Tab attachmentsTab = tabSheet.getTab("commentsTab");
        attachmentsTab.setIconFromSet(icon);
        attachmentsTab.setCaption(message);
    }

}