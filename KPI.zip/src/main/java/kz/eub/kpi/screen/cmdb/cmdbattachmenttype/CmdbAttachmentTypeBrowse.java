package kz.eub.kpi.screen.cmdb.cmdbattachmenttype;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.cmdb.CmdbAttachmentType;

@UiController("kpi_CmdbAttachmentType.browse")
@UiDescriptor("cmdb-attachment-type-browse.xml")
@LookupComponent("cmdbAttachmentTypesTable")
public class CmdbAttachmentTypeBrowse extends StandardLookup<CmdbAttachmentType> {
}