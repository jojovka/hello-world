package kz.eub.kpi.screen.kpi.intermediateassessmentmeeting;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.IntermediateAssessmentMeeting;

@UiController("kpi_IntermediateAssessmentMeeting.edit")
@UiDescriptor("intermediate-assessment-meeting-edit.xml")
@EditedEntityContainer("intermediateAssessmentMeetingDc")
public class IntermediateAssessmentMeetingEdit extends StandardEditor<IntermediateAssessmentMeeting> {
}