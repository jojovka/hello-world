package kz.eub.kpi.screen.user;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.User;

@UiController("bonus_Administration.browse")
@UiDescriptor("administration-browse.xml")
@LookupComponent("table")
public class AdministrationBrowse extends MasterDetailScreen<User> {
}