package kz.eub.kpi.screen.competitioncreate;

import io.jmix.core.DataManager;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.DateField;
import io.jmix.ui.component.EntityComboBox;
import io.jmix.ui.component.HBoxLayout;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.Table;
import io.jmix.ui.component.TextArea;
import io.jmix.ui.component.TextField;
import io.jmix.ui.component.TextInputField;
import io.jmix.ui.icon.Icons;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.app.service.ProBonusService;
import kz.eub.kpi.entity.AccountProfiles;
import kz.eub.kpi.entity.Accounts;
import kz.eub.kpi.entity.AwardUser;
import kz.eub.kpi.entity.Competition;
import kz.eub.kpi.entity.CompetitionCategory;
import kz.eub.kpi.entity.CompetitionUser;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.DictPosition;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.RatingUserOptions;
import kz.eub.kpi.entity.analyze.DictBranch;
import kz.eub.kpi.screen.authority.Authorityscreen;
import kz.eub.kpi.screen.competitionview.CompetitionView;
import liquibase.pro.packaged.D;
import org.springframework.beans.factory.annotation.Autowired;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@UiController("kpi_CompetitionCreate")
@UiDescriptor("competition-create.xml")
public class CompetitionCreate extends Screen {

    @Autowired
    protected CollectionContainer<DictPosition> posDc;

    @Autowired
    protected CollectionContainer<DictDepartment> brDc;

    @Autowired
    private DataManager dataManager;
    @Autowired
    private EntityComboBox posComboBox;

    private List<DictBranch> branches;

    private DictPosition selectedPosition;

    private DictDepartment selectedBranch;
    //    @Autowired
    private TextField cardCountId;
    @Autowired
    private TextField competitionTitleId;
    @Autowired
    private TextArea descriptionId;
    @Autowired
    private TextArea conditionId;
    @Autowired
    private TextField sloganId;
    @Autowired
    private Button saveBtn;
    @Autowired
    private DateField dateStart;
    @Autowired
    private DateField dateEnd;

    private String selectedType;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private EntityComboBox<DictBranch> depComboBox;

    private CompetitionCategory competitionCategory;

    private Competition competition;
    @Autowired
    private TextField<Integer> categoryActivCardCountId;
    @Autowired
    private TextField<Integer> categoryCreditCountId;
    @Autowired
    private TextField<Integer> categoryPosCountId;
    @Autowired
    private TextField<Integer> categoryAvtoCreditCountId;
    @Autowired
    private TextField<Integer> categoryActivSmartbankCountId;
    @Autowired
    private TextField<Integer> categoryClientSmartbankCountId;
    @Autowired
    private TextField<Integer> categoryDepositCountId;
    @Autowired
    private Button categoryActivCardCountBtn;
    @Autowired
    private Button categoryActivCardSumBtn;
    @Autowired
    private Button categoryCreditCountBtn;
    @Autowired
    private Button categoryCreditSumBtn;
    @Autowired
    private Button categoryPosCountBtn;
    @Autowired
    private Button categoryPosSumBtn;
    @Autowired
    private Button categoryAvtoCreditCountBtn;
    @Autowired
    private Button categoryAvtoCreditSumBtn;
    @Autowired
    private Button categoryDepositCountBtn;
    @Autowired
    private Button categoryDepositSumBtn;
    @Autowired
    private HBoxLayout userListWidget;
    @Autowired
    private HBoxLayout userFieldWidget;
    @Autowired
    private CollectionContainer<Accounts> accountDc;
    @Autowired
    private ProBonusService proBonusService;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private TextField fioField;

    private boolean notInList = false;
    @Autowired
    private CollectionContainer<Accounts> userDc;

    @Subscribe
    private void onInit(InitEvent event) {
        dateStart.setValue(new Date());
        dateEnd.setValue(new Date());
        competition = dataManager.create(Competition.class);
        competition.setType("Individual");
        competitionCategory = dataManager.create(CompetitionCategory.class);
        competitionCategory.setActiveCardType("count");
        competitionCategory.setCreditType("count");
        competitionCategory.setPosType("count");
        competitionCategory.setAvtoCreditType("count");
        competitionCategory.setDepositType("count");
        loadPositions();
        loadBranches();
    }



    private void loadPositions() {
        List<DictPosition> positions = dataManager.load(DictPosition.class)
                .query("from kpi_DictPosition c ")
                .list();
        posDc.getMutableItems().clear();
        posDc.getMutableItems().addAll(positions);
    }

    private void loadBranches() {
        List<DictDepartment> branchList = dataManager.load(DictDepartment.class)
                .query("from kpi_DictDepartment c where c.level = 2")
                .list();
        brDc.getMutableItems().clear();
        brDc.getMutableItems().addAll(branchList);
    }

    @Subscribe("posComboBox")
    public void onPosComboBoxValueChange(HasValue.ValueChangeEvent<DictPosition> event) {
        selectedPosition = event.getValue();
    }

    @Subscribe("depComboBox")
    public void onDepComboBoxValueChange(HasValue.ValueChangeEvent<DictDepartment> event) {
        selectedBranch = event.getValue();
    }

    @Subscribe("saveBtn")
    public void onSaveBtnClick(Button.ClickEvent event) {


        if (selectedBranch != null && selectedBranch.getBranch() != null) {
            competition.setBranch(selectedBranch.getBranch());
        }
        if (selectedPosition != null && selectedPosition.getName() != null) {
            competition.setPosition(selectedPosition.getName());
        }
        competition.setDescription(descriptionId.getRawValue());
//        competition.setCompetitionCategory(competitionCategory);

        competition.setDateStart(new Date());
        Date date = new Date();
        date.setMonth(3);
        date.setDate(3);
        competition.setDateEnd(date);
        competition.setSlogan(sloganId.getRawValue());
        competition.setType(selectedType);
        competition.setStatus(true);
        competition.setTitle(competitionTitleId.getRawValue());
        dataManager.save(competition);

        fillCompetitionCategory();
        competitionCategory.setCompetitionId(competition.getId());
        dataManager.save(competitionCategory);
        userDc.getMutableItems().forEach(
                element -> {
                    CompetitionUser aUser = dataManager.create(CompetitionUser.class);
                    Employee employee = employeeService.loadEmployeeByPayrollNumber(element.getIdentityProperty());
                    Accounts accounts = proBonusService.reloadAccountsByPayroll(element.getIdentityProperty());
                    if (employee != null) {
                        aUser.setEmployee(employee.getId());
                        aUser.setCompetitionId(competition.getId());
                        aUser.setAccountId(accounts.getId());
                        dataManager.save(aUser);
                    }
                }
        );
        screenBuilders.screen(this)
                .withScreenClass(CompetitionView.class)
                .build()
                .show();
    }

    private void fillCompetitionCategory() {
        competitionCategory.setActiveCardCount(categoryActivCardCountId.getValue() != null ? categoryActivCardCountId.getValue() : 0);
        competitionCategory.setCreditCount(categoryCreditCountId.getValue() != null ? categoryCreditCountId.getValue() : 0);
        competitionCategory.setPosCount(categoryPosCountId.getValue() != null ? categoryPosCountId.getValue() : 0);
        competitionCategory.setAvtoCreditCount(categoryAvtoCreditCountId.getValue() != null ? categoryAvtoCreditCountId.getValue() : 0);
        competitionCategory.setActiveSmartbankCount(categoryActivSmartbankCountId.getValue() != null ? categoryActivSmartbankCountId.getValue() : 0);
        competitionCategory.setClientSmartbankCount(categoryClientSmartbankCountId.getValue() != null ? categoryClientSmartbankCountId.getValue() : 0);
        competitionCategory.setDepositCount(categoryDepositCountId.getValue() != null ? categoryDepositCountId.getValue() : 0);
    }

    @Subscribe("paramRatingId")
    public void onParamRatingIdValueChange(HasValue.ValueChangeEvent<Boolean> event) {
        competition.setParameterRating(event.getValue());
    }

    @Subscribe("paramCreditId")
    public void onParamCreditIdValueChange(HasValue.ValueChangeEvent<Boolean> event) {
        competition.setParameterCredit(event.getValue());
    }

    @Subscribe("categoryActivCardStatusId")
    public void onCategoryActivCardStatusIdValueChange(HasValue.ValueChangeEvent<Boolean> event) {
        competitionCategory.setActiveCardStatus(event.getValue());
    }

    @Subscribe("categoryCreditStatusId")
    public void onCategoryCreditStatusIdValueChange(HasValue.ValueChangeEvent<Boolean> event) {
        competitionCategory.setCreditStatus(event.getValue());
    }

    @Subscribe("categoryPosStatusId")
    public void onCategoryPosStatusIdValueChange(HasValue.ValueChangeEvent<Boolean> event) {
        competitionCategory.setPosStatus(event.getValue());
    }

    @Subscribe("categoryAvtoCreditStatusId")
    public void onCategoryAvtoCreditStatusIdValueChange(HasValue.ValueChangeEvent<Boolean> event) {
        competitionCategory.setAvtoCreditStatus(event.getValue());
    }

    @Subscribe("categoryActivSmartbankStatusId")
    public void onCategoryActivSmartbankStatusIdValueChange(HasValue.ValueChangeEvent<Boolean> event) {
        competitionCategory.setActivSmartbankStatus(event.getValue());
    }

    @Subscribe("categoryClientSmartbankStatusId")
    public void onCategoryClientSmartbankStatusIdValueChange(HasValue.ValueChangeEvent<Boolean> event) {
        competitionCategory.setClientSmartbankStatus(event.getValue());
    }

    @Subscribe("categoryDepositStatusId")
    public void onCategoryDepositStatusIdValueChange(HasValue.ValueChangeEvent<Boolean> event) {
        competitionCategory.setDepositStatus(event.getValue());
    }

    @Subscribe("dateStart")
    public void onDateStartValueChange(HasValue.ValueChangeEvent event) {

    }

    @Subscribe("categoryActivCardCountBtn")
    public void onCategoryActivCardCountBtnClick(Button.ClickEvent event) {
        competitionCategory.setActiveCardType("count");
        categoryActivCardCountBtn.setIcon("font-icon:CHECK");
        categoryActivCardSumBtn.setIcon("font-icon:WINDOW_CLOSE");
    }

    @Subscribe("categoryActivCardSumBtn")
    public void onCategoryActivCardSumBtnClick(Button.ClickEvent event) {
        competitionCategory.setActiveCardType("sum");
        categoryActivCardCountBtn.setIcon("font-icon:WINDOW_CLOSE");
        categoryActivCardSumBtn.setIcon("font-icon:CHECK");
    }

    @Subscribe("categoryCreditCountBtn")
    public void onCategoryCreditCountBtnClick(Button.ClickEvent event) {
        competitionCategory.setCreditType("count");
        categoryCreditCountBtn.setIcon("font-icon:CHECK");
        categoryCreditSumBtn.setIcon("font-icon:WINDOW_CLOSE");
    }

    @Subscribe("categoryCreditSumBtn")
    public void onCategoryCreditSumBtnClick(Button.ClickEvent event) {
        competitionCategory.setCreditType("sum");
        categoryCreditCountBtn.setIcon("font-icon:WINDOW_CLOSE");
        categoryCreditSumBtn.setIcon("font-icon:CHECK");
    }

    @Subscribe("categoryPosCountBtn")
    public void onCategoryPosCountBtnClick(Button.ClickEvent event) {
        competitionCategory.setPosType("count");
        categoryPosCountBtn.setIcon("font-icon:CHECK");
        categoryPosSumBtn.setIcon("font-icon:WINDOW_CLOSE");
    }

    @Subscribe("categoryPosSumBtn")
    public void onCategoryPosSumBtnClick(Button.ClickEvent event) {
        competitionCategory.setPosType("sum");
        categoryPosCountBtn.setIcon("font-icon:WINDOW_CLOSE");
        categoryPosSumBtn.setIcon("font-icon:CHECK");
    }

    @Subscribe("categoryAvtoCreditCountBtn")
    public void onCategoryAvtoCreditCountBtnClick(Button.ClickEvent event) {
        competitionCategory.setAvtoCreditType("count");
        categoryAvtoCreditCountBtn.setIcon("font-icon:CHECK");
        categoryAvtoCreditSumBtn.setIcon("font-icon:WINDOW_CLOSE");
    }

    @Subscribe("categoryAvtoCreditSumBtn")
    public void onCategoryAvtoCreditSumBtnClick(Button.ClickEvent event) {
        competitionCategory.setAvtoCreditType("sum");
        categoryAvtoCreditCountBtn.setIcon("font-icon:WINDOW_CLOSE");
        categoryAvtoCreditSumBtn.setIcon("font-icon:CHECK");

    }

    @Subscribe("categoryDepositCountBtn")
    public void onCategoryDepositCountBtnClick(Button.ClickEvent event) {
        competitionCategory.setDepositType("count");
        categoryDepositCountBtn.setIcon("font-icon:CHECK");
        categoryDepositSumBtn.setIcon("font-icon:WINDOW_CLOSE");
    }

    @Subscribe("categoryDepositSumBtn")
    public void onCategoryDepositSumBtnClick(Button.ClickEvent event) {
        competitionCategory.setDepositType("sum");
        categoryDepositCountBtn.setIcon("font-icon:WINDOW_CLOSE");
        categoryDepositSumBtn.setIcon("font-icon:CHECK");
    }

    @Subscribe("userBox")
    public void onUserBoxValueChange(HasValue.ValueChangeEvent<Boolean> event) {
        if (event.getValue()) {
            userFieldWidget.setVisible(true);
            userListWidget.setVisible(true);
        } else {
            accountDc.getMutableItems().clear();
            userFieldWidget.setVisible(false);
            userListWidget.setVisible(false);
        }
    }

    @Subscribe("fioField")
    public void onFioFieldEnterPress(TextInputField.EnterPressEvent event) {
        List<Accounts> accountUsers = new ArrayList<>();
        List<AccountProfiles> accountsList = proBonusService.searchAccountByFio(fioField.getRawValue());

        List<Employee> employee = employeeService.searchEmployee(fioField.getRawValue());
        employee.forEach(empl -> {
            Accounts account = proBonusService.reloadAccountsByPayroll(empl.getPayrollNumber());
            if (account != null) {
                accountUsers.add(account);
            }
        });

        accountDc.getMutableItems().clear();
        accountDc.getMutableItems().addAll(accountUsers);

    }

    @Subscribe("ratingUserTable")
    public void onRatingUserTableSelection(Table.SelectionEvent<Accounts> event) {
        if (event != null && event.getSource() != null && event.getSource().getSingleSelected() != null) {
            notInList = false;
            userDc.getMutableItems().forEach(signed -> {
                if (event.getSource().getSingleSelected().getId().equals(signed.getId()))
                    notInList = true;
            });
            if (!notInList) {
                userDc.getMutableItems().add(event.getSource().getSingleSelected());
            }
        }
    }

    @Subscribe("individualBtn")
    public void onIndividualBtnClick(Button.ClickEvent event) {
        competition.setType("Individual");
    }

    @Subscribe("teamBtn")
    public void onTeamBtnClick(Button.ClickEvent event) {
        competition.setType("Team");
    }


}