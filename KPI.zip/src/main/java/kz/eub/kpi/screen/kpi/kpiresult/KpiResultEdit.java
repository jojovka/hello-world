package kz.eub.kpi.screen.kpi.kpiresult;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.KpiResult;

@UiController("kpi_KpiResult.edit")
@UiDescriptor("kpi-result-edit.xml")
@EditedEntityContainer("kpiResultDc")
public class KpiResultEdit extends StandardEditor<KpiResult> {
}