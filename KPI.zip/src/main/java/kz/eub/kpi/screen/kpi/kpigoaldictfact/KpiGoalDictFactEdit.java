package kz.eub.kpi.screen.kpi.kpigoaldictfact;

import io.jmix.ui.component.CurrencyField;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.KpiGoalDict;
import kz.eub.kpi.entity.kpi.KpiGoalDictFact;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

@UiController("kpi_KpiGoalDictFact.edit")
@UiDescriptor("kpi-goal-dict-fact-edit.xml")
@EditedEntityContainer("kpiGoalDictFactDc")
public class KpiGoalDictFactEdit extends StandardEditor<KpiGoalDictFact> {

    @Autowired
    private CurrencyField<BigDecimal> factField;

    @Subscribe
    public void onInitEntity(InitEntityEvent<KpiGoalDictFact> event) {
        KpiGoalDictFact fact = event.getEntity();
        fact.setPeriod(fact.getGoalImportDoc().getPeriod());
    }



    @Subscribe("goalDictField")
    public void onGoalDictFieldValueChange(HasValue.ValueChangeEvent<KpiGoalDict> event) {
        KpiGoalDict goalDict = event.getValue();
        if (goalDict == null) return;
        factField.setCurrency(goalDict.getUnit().getCode());
    }

}