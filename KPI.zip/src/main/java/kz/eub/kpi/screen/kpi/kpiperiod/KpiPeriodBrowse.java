package kz.eub.kpi.screen.kpi.kpiperiod;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.KpiPeriod;

@UiController("kpi_KpiPeriod.browse")
@UiDescriptor("kpi-period-browse.xml")
@LookupComponent("kpiPeriodsTable")
public class KpiPeriodBrowse extends StandardLookup<KpiPeriod> {
}