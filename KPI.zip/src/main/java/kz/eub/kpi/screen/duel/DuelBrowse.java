package kz.eub.kpi.screen.duel;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.AccountProfiles;
import kz.eub.kpi.entity.Duel;
import kz.eub.kpi.entity.RatingUser;
import kz.eub.kpi.entity.RatingUserOptions;
import kz.eub.kpi.screen.authority.Authorityscreen;
import kz.eub.kpi.screen.duelcreate.DuelCreate;
import kz.eub.kpi.screen.dueledit.DuelEdit;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

@UiController("kpi_Duel.browse")
@UiDescriptor("duel-browse.xml")
@LookupComponent("duelsTable")
public class DuelBrowse extends StandardLookup<Duel> {

    @Autowired
    private GroupTable<Duel> duelsTable;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private FetchPlans fetchPlans;
    @Autowired
    private CollectionContainer<Duel> duelsDc;

    @Subscribe
    private void onInit(InitEvent event) {
        List<Duel> duelList = new ArrayList<>();
        duelList = getDuelList();
        duelsDc.getMutableItems().clear();
        duelsDc.getMutableItems().addAll(duelList);
        addItemClickActions();
    }

    private void addItemClickActions() {
        duelsTable.setItemClickAction(new BaseAction("itemClickAction")
                .withHandler(actionPerformedEvent -> {
                    if (duelsTable.getSingleSelected() != null) {
                        showAuthorityscreenDlg(duelsTable.getSingleSelected());
                    }
                }));
    }

    private void showAuthorityscreenDlg(Duel duel) {
        screenBuilders.screen(this)
                .withScreenClass(DuelEdit.class)
                .withOptions(new RatingUserOptions(duel.getId(), null, null, null, null, null) )
                .build()
                .show();
    }

    @Subscribe("createDuelBtn")
    public void onCreateDuelBtnClick(Button.ClickEvent event) {
        screenBuilders.screen(this)
                .withScreenClass(DuelCreate.class)
                .build()
                .show().addAfterCloseListener(afterCloseEvent -> {
                    List<Duel> duelList = new ArrayList<>();
                    duelList = getDuelList();
                    duelsDc.getMutableItems().clear();
                    duelsDc.getMutableItems().addAll(duelList);
                });
    }


    public List<Duel> getDuelList() {
        FetchPlan fetchPlan = getDuelPlan();
        return dataManager.load(Duel.class)
                .query("select c from kpi_Duel c ")
                .fetchPlan(fetchPlan).list();
    }

    private FetchPlan getDuelPlan() {
        return fetchPlans.builder(Duel.class)
                .addFetchPlan(FetchPlan.BASE)
                .build();
    }
}