package kz.eub.kpi.screen.dictdepartment;

import com.google.common.base.Strings;
import io.jmix.ui.Notifications;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.TextField;
import io.jmix.ui.component.TextInputField;
import io.jmix.ui.component.Tree;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.LookupComponent;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.entity.DictDepartment;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@UiController("kpi_DictDepartment.lookup")
@UiDescriptor("dict-department-lookup.xml")
@LookupComponent("dictDepartmentsTree")
public class DictDepartmentLookup extends StandardLookup<DictDepartment> {

    @Autowired
    private Tree<DictDepartment> dictDepartmentsTree;
    @Autowired
    private CollectionContainer<DictDepartment> dictDepartmentsDc;
    @Autowired
    private TextField<String> nameFld;
    @Autowired
    private Notifications notifications;

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        excludeRootCompanyDepFromDepartmentsList();
    }

    private void excludeRootCompanyDepFromDepartmentsList() {
        List<DictDepartment> depsList = dictDepartmentsDc.getMutableItems();
        DictDepartment hq = depsList.stream()
                .filter(d -> d.getSapId().equals(DictDepartment.COMPANY_SAP_ID))
                .findFirst().orElse(null);
        dictDepartmentsDc.getMutableItems().remove(hq);
        dictDepartmentsDc.getMutableItems().sort(Comparator.comparing(DictDepartment::getName));
    }

    @Subscribe("expendBtn")
    public void onExpendBtnClick(Button.ClickEvent event) {
        dictDepartmentsTree.expandTree();
    }

    @Subscribe("collapseBtn")
    public void onCollapseBtnClick(Button.ClickEvent event) {
        dictDepartmentsTree.collapseTree();
    }

    @Subscribe("nameFld")
    public void onNameFldEnterPress(TextInputField.EnterPressEvent event) {
        searchDepartmentByName();
    }

    @Subscribe("searchBtn")
    public void onSearchBtnClick(Button.ClickEvent event) {
        searchDepartmentByName();
    }

    private void searchDepartmentByName() {
        String value = nameFld.getValue();
        if (Strings.isNullOrEmpty(value))
            return;
        List<DictDepartment> foundDepartments = dictDepartmentsDc.getMutableItems().stream()
                .filter(d -> d.getName().toLowerCase().contains(value.toLowerCase()))
                .collect(Collectors.toList());
        dictDepartmentsTree.collapseTree();
        List<DictDepartment> selectedCollection = new ArrayList<>();
        for (DictDepartment dep : foundDepartments) {
            dictDepartmentsTree.expand(dep);
            selectedCollection.add(dep);
        }
        dictDepartmentsTree.setSelected(selectedCollection);
        notifications.create(Notifications.NotificationType.TRAY)
                .withCaption(String.format("Найдено %d подразделения(й)", selectedCollection.size()))
                .show();
    }

}