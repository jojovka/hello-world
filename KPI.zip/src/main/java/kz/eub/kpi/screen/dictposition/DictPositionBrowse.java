package kz.eub.kpi.screen.dictposition;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.DictPosition;

@UiController("kpi_DictPosition.browse")
@UiDescriptor("dict-position-browse.xml")
@LookupComponent("dictPositionsTable")
public class DictPositionBrowse extends StandardLookup<DictPosition> {
}