package kz.eub.kpi.screen.competition;

import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.CheckBox;
import io.jmix.ui.component.Component;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.HBoxLayout;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.Label;
import io.jmix.ui.component.LayoutClickNotifier;
import io.jmix.ui.component.Table;
import io.jmix.ui.component.VBoxLayout;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.ScreenOptions;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.ProBonusService;
import kz.eub.kpi.entity.Accounts;
import kz.eub.kpi.entity.Award;
import kz.eub.kpi.entity.Competition;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.Duel;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.RatingUserOptions;
import kz.eub.kpi.screen.award.AwardCreate;
import kz.eub.kpi.screen.bonusprofile.BonusProfileScreen;
import kz.eub.kpi.screen.competitioncreate.CompetitionCreate;
import kz.eub.kpi.screen.competitionview.CompetitionView;
import org.apache.batik.bridge.ViewBox;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

@UiController("kpi_CompetitionScreen")
@UiDescriptor("competition-screen.xml")
public class CompetitionScreen extends Screen {

    @Autowired
    protected CollectionContainer<Accounts> emplDc;

    private Competition competition;
    @Autowired
    private ProBonusService proBonusService;
    @Autowired
    private DataManager dataManager;

    List<Accounts> accounts = new ArrayList<>();
    @Autowired
    private FetchPlans fetchPlans;
    @Autowired
    private Button createBtn;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private CollectionContainer<Competition> competitionDc;
    @Autowired
    private HBoxLayout listId;
    @Autowired
    private CheckBox statusId;

    @Subscribe
    private void onInit(InitEvent event) {
        competitionDc.getMutableItems().clear();
        ScreenOptions options = event.getOptions();
        Integer competitionId = 0;
        FetchPlan fetchPlan = geCompetitionFetchPlan();
        if (options instanceof RatingUserOptions) {
            competitionId = ((RatingUserOptions) options).getAccountId();
            if (competitionId > 0) {
                competition = dataManager.load(Competition.class)
                        .query("select c from kpi_Competition c " +
                                "where c.id = :competitionId")
                        .parameter("competitionId", competitionId)
                        .fetchPlan(fetchPlan)
                        .optional().orElse(dataManager.create(Competition.class));
                if (competition.getId() > 0) {
                    setCompetitionData();
                    loadEmployeesbyCompetitionId();
                }
            }
        } else {
            List<Competition> competitions = dataManager.load(Competition.class)
                    .query("select e from kpi_Competition e")
                    .list();
            competitionDc.getMutableItems().addAll(competitions);
        }
    }

    private void loadEmployeesbyCompetitionId() {
        accounts = proBonusService.loadAccountsByCompetition(competition);
        emplDc.getMutableItems().clear();
        emplDc.getMutableItems().addAll(accounts);
    }

    private void setCompetitionData() {

    }

    private FetchPlan geCompetitionFetchPlan() {
        return fetchPlans.builder(Competition.class)
                .addFetchPlan(FetchPlan.BASE)
                .build();
    }

    @Subscribe("createBtn")
    public void onCreateBtnClick(Button.ClickEvent event) {
        screenBuilders.screen(this)
                .withScreenClass(CompetitionCreate.class)
                .build()
                .show().addAfterCloseListener(afterCloseEvent -> {
                    competitionDc.getMutableItems().clear();
                    competitionDc.getMutableItems().addAll(dataManager.load(Competition.class)
                            .query("select e from kpi_Competition e")
                            .list());
                });
    }

    @Subscribe("statusId")
    public void onStatusIdValueChange(HasValue.ValueChangeEvent<Boolean> event) {
        
    }

    @Subscribe("listId")
    public void onListIdLayoutClick(LayoutClickNotifier.LayoutClickEvent event) {

    }

    @Subscribe("ratingUserTable")
    public void onRatingUserTableSelection(Table.SelectionEvent<Competition> event) {
        screenBuilders.screen(this)
                .withScreenClass(CompetitionView.class)
                .withOptions(new RatingUserOptions(
                        event.getSelected().iterator().next().getId(),
                        null,
                        null, null, null, null))
                .build()
                .show();
    }
}