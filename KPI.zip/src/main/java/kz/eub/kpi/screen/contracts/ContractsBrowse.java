package kz.eub.kpi.screen.contracts;

import io.jmix.core.DataManager;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.*;
import kz.eub.kpi.app.service.ProBonusService;
import kz.eub.kpi.entity.Accounts;
import kz.eub.kpi.entity.Contracts;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.DictPosition;
import kz.eub.kpi.entity.RatingUserOptions;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@UiController("kpi_Contracts.browse")
@UiDescriptor("contracts-browse.xml")
@LookupComponent("contractsesTable")
public class ContractsBrowse extends StandardLookup<Contracts> {
    @Autowired
    private CollectionContainer<Contracts> contractsesDc;

    private Date selectedDate;
    private Date selectedCurrentMonthDate;

    List<Contracts> contracts = new ArrayList<>();

    private Integer accountId;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private ProBonusService proBonusService;

    @Subscribe
    private void onInit(InitEvent event) {
        ScreenOptions options = event.getOptions();

        if (options instanceof RatingUserOptions) {
            accountId = ((RatingUserOptions) options).getAccountId();
            selectedDate = ((RatingUserOptions) options).getDateStart();
            selectedCurrentMonthDate = ((RatingUserOptions) options).getDateEnd();
        }

        if (accountId != null && selectedDate != null) {
            loadContracts();
        }
    }

    private void loadContracts() {
        Calendar c1 = Calendar.getInstance();   // this takes current date
        c1.set(Calendar.MONTH, c1.get(Calendar.MONTH));
        c1.set(Calendar.DAY_OF_MONTH, 1);
        Date theDateMinDayCurrentMonth = c1.getTime();
        if (selectedCurrentMonthDate == null) {
         contracts =  proBonusService.zaimPdfCount(accountId, selectedDate);
        } else {
            contracts = proBonusService.zaimPdfCountOld(accountId, selectedCurrentMonthDate, theDateMinDayCurrentMonth);
        }
        if (contracts.size() > 0) {
            contracts.forEach(contract -> {
                Accounts account = proBonusService.reloadAccountById(contract.getUserId());
                if (account != null) {
                    contract.setUserId(Integer.parseInt(account.getIdentityProperty()));
                }
            });
        }
        contractsesDc.getMutableItems().clear();
        contractsesDc.getMutableItems().addAll(contracts);
    }
}