package kz.eub.kpi.screen.awardassign;

import io.jmix.core.DataManager;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.Label;
import io.jmix.ui.component.Table;
import io.jmix.ui.component.TextField;
import io.jmix.ui.component.TextInputField;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.ScreenOptions;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.StandardOutcome;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.app.service.ProBonusService;
import kz.eub.kpi.entity.AccountProfiles;
import kz.eub.kpi.entity.Accounts;
import kz.eub.kpi.entity.Award;
import kz.eub.kpi.entity.AwardUser;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.RatingUserOptions;
import liquibase.pro.packaged.D;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@UiController("kpi_AwardAssignScreen")
@UiDescriptor("award-assign-screen.xml")
public class AwardAssignScreen extends Screen {

    UUID awardId;

    Award selectedAward;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private TextField titleField;
    @Autowired
    private TextField descriptionField;
    @Autowired
    private CollectionContainer<Accounts> accountDc;
    @Autowired
    private ProBonusService proBonusService;
    @Autowired
    private TextField fioField;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private CollectionContainer<Accounts> signedDc;

    private boolean notInList = false;
    @Autowired
    private TextField countId;

    @Subscribe
    private void onInit(InitEvent event) {
        signedDc.getMutableItems().clear();
        accountDc.getMutableItems().clear();
        countId.setValue("0");
        ScreenOptions options = event.getOptions();

        if (options instanceof RatingUserOptions) {
            awardId = ((RatingUserOptions) options).getUuid();
        }
        if (awardId != null) {
            selectedAward = dataManager.load(Award.class)
                    .query("select c from kpi_Award c" +
                            " where c.id = :awardId")
                    .parameter("awardId", awardId)
                    .optional().orElse(null);
        }
        if (selectedAward != null) {
            titleField.setValue(selectedAward.getTitle());
            descriptionField.setValue(selectedAward.getDescription());
        }
    }

    @Subscribe
    protected void afterShow(AfterShowEvent event) {
        loadSignedAccounts();
    }

    private void loadSignedAccounts() {
        List<AwardUser> users = dataManager.load(AwardUser.class)
                .query("select c from kpi_AwardUser c where " +
                        "c.awardId = :id ")
                .parameter("id", awardId)
                .list();

        signedDc.getMutableItems().clear();
        users.forEach(user -> {
            Accounts accounts = proBonusService.reloadAccountById(user.getAccountId());
            Employee employee = employeeService.reloadEmployeeById(user.getEmployee());
            accounts.setEmployee(employee);
            signedDc.getMutableItems().add(accounts);
        });
        countId.setValue((signedDc.getMutableItems().size()) + "");

    }

    @Subscribe("fioField")
    public void onSearchFieldEnterPress(TextInputField.EnterPressEvent event) {
        List<Accounts> accountUsers = new ArrayList<>();
        List<AccountProfiles> accountsList = proBonusService.searchAccountByFio(fioField.getRawValue());

        List<Employee> employee = employeeService.searchEmployee(fioField.getRawValue());
        employee.forEach(empl -> {
            Accounts account = proBonusService.reloadAccountsByPayroll(empl.getPayrollNumber());
            if (account != null) {
                accountUsers.add(account);
            }
        });

        accountDc.getMutableItems().clear();
        accountDc.getMutableItems().addAll(accountUsers);
    }

    @Subscribe("ratingUserTable")
    public void onRatingUserTableSelection(Table.SelectionEvent<Accounts> event) {
        if (event != null && event.getSource() != null && event.getSource().getSingleSelected() != null) {
            notInList = false;
            signedDc.getMutableItems().forEach(signed -> {
                if (event.getSource().getSingleSelected().getId().equals(signed.getId()))
                    notInList = true;
            });
            if (!notInList) {
                signedDc.getMutableItems().add(event.getSource().getSingleSelected());
                countId.setValue((signedDc.getMutableItems().size()) + "");
            }
        }
    }

    @Subscribe("saveBtn")
    public void onSaveBtnClick(Button.ClickEvent event) {
        signedDc.getMutableItems().forEach(
                element -> {
                    AwardUser aUser = dataManager.create(AwardUser.class);
                    Employee employee = employeeService.loadEmployeeByPayrollNumber(element.getIdentityProperty());
                    Accounts accounts = proBonusService.reloadAccountsByPayroll(element.getIdentityProperty());
                    if (employee != null) {
                        aUser.setEmployee(employee.getId());
                        aUser.setAwardId(awardId);
                        aUser.setAccountId(accounts.getId());
                        aUser.setCreatedDate(new Date());
                        dataManager.save(aUser);
                    }
                }
        );
        close(StandardOutcome.CLOSE);
    }
}