package kz.eub.kpi.screen.bonusreportdashboard;

import io.jmix.ui.Actions;
import io.jmix.ui.action.Action;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.ScreenOptions;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import io.jmix.uiexport.action.ExcelExportAction;
import io.jmix.uiexport.exporter.excel.ExcelExporter;
import kz.eub.kpi.app.service.ProBonusService;
import kz.eub.kpi.entity.AccountVisits;
import kz.eub.kpi.entity.Accounts;
import kz.eub.kpi.entity.BonusAuthority;
import kz.eub.kpi.entity.DuelContest;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.PointUser;
import kz.eub.kpi.entity.RatingUserOptions;
import liquibase.pro.packaged.A;
import liquibase.pro.packaged.D;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import javax.inject.Named;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

@UiController("kpi_BonusReportDashboard")
@UiDescriptor("bonus-report-dashboard.xml")
public class BonusReportDashboard extends StandardLookup<BonusReportDashboard> {

    @Autowired
    private CollectionContainer<DuelContest> kpiRatingDc;

    @Autowired
    private CollectionContainer<AccountVisits> kpiBonusVisitDc;
    @Autowired
    private ProBonusService proBonusService;

    private Date dateStart;
    private Date dateEnd;

    private Integer typeId;

    @Autowired
    private GroupTable<PointUser> duelTable;
    @Autowired
    private GroupTable<DuelContest> ratingUserTable;

    @Autowired
    private GroupTable<AccountVisits> userVisitTable;

    int checker = 0;

    Date date = new Date();

    @Subscribe
    private void onInit(InitEvent event) {
        userVisitTable.setVisible(false);
        duelTable.setVisible(false);
        ratingUserTable.setVisible(false);

        ScreenOptions options = event.getOptions();
        if (options instanceof RatingUserOptions) {
            dateStart = ((RatingUserOptions) options).getDateStart();
            dateEnd = ((RatingUserOptions) options).getDateEnd();
            typeId = ((RatingUserOptions) options).getTypeId();
            loadPointUserByAuthority();
            loadVisits();
            if (typeId == 3) {
                duelTable.setVisible(true);
            } else if (typeId == 4){
                ratingUserTable.setVisible(true);
            } else {
                userVisitTable.setVisible(true);
            }
        }

    }
    private void loadPointUserByAuthority() {
        List<DuelContest> duelContests = proBonusService.reloadAllContestsByDate(dateStart, dateEnd);
            kpiRatingDc.getMutableItems().clear();
            duelContests.forEach(duelContest -> {
                if (duelContest.getWinnerStaff() != null && duelContest.getWinnerStaff().getId() != null) {
                    Accounts account = proBonusService.reloadAccountById(duelContest.getWinnerStaff().getId());
                    Employee employee = proBonusService.reloadEmployeeByPayroll(account.getIdentityProperty());
                    account.setEmployee(employee);
                    duelContest.setWinnerStaff(account);
                }
                if (duelContest.getContester() != null && duelContest.getContester().getId() != null) {
                    Accounts account = proBonusService.reloadAccountById(duelContest.getContester().getId());
                    Employee employee = proBonusService.reloadEmployeeByPayroll(account.getIdentityProperty());
                    account.setEmployee(employee);
                    duelContest.setContester(account);
                }
                if (duelContest.getOpponent() != null && duelContest.getOpponent().getId() != null) {
                    Accounts account = proBonusService.reloadAccountById(duelContest.getOpponent().getId());
                    Employee employee = proBonusService.reloadEmployeeByPayroll(account.getIdentityProperty());
                    account.setEmployee(employee);
                    duelContest.setOpponent(account);
                }

            });
            kpiRatingDc.getMutableItems().addAll(duelContests);
    }

    private void loadVisits() {
        List<AccountVisits> visits = proBonusService.reloadVisitsBetweenDateByType(dateStart, dateEnd);
        List<AccountVisits> visits1 = new ArrayList<>();
        checker = 1;
        date = dateStart;
        for (int i=0;i<visits.size();i++) {
            if (i != visits.size()-1) {
                date = visits.get(i+1).getVisited_at();
            }
            if (visits.get(i).getAccountId() != null) {
                Accounts account = proBonusService.reloadAccountById(visits.get(i).getAccountId());
                visits.get(i).setFio( account.getProfileId().getLastname() + " " + account.getProfileId().getFirstname());
            }
            visits1.add(visits.get(i));
            if (!visits.get(i).getVisited_at().equals(date) || i == visits.size()-1) {
                AccountVisits visit2 = new AccountVisits();
                int x = ThreadLocalRandom.current().nextInt(10000,99999);
                visit2.setId(x);
                visit2.setFio("Итого сотрудников");
                visit2.setAccountId(checker);
                visits1.add(visit2);
                checker = 0;
            }
            checker++;
        }
        kpiBonusVisitDc.getMutableItems().clear();
        kpiBonusVisitDc.getMutableItems().addAll(visits1);
    }
}