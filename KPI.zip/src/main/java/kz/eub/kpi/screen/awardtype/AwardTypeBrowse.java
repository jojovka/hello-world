package kz.eub.kpi.screen.awardtype;

import io.jmix.core.DataManager;
import io.jmix.security.role.annotation.RowLevelRole;
import io.jmix.ui.component.Filter;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.model.DataComponents;
import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.AwardType;
import kz.eub.kpi.entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

import static org.eclipse.persistence.expressions.ExpressionOperator.Log;

@RowLevelRole(
        name = "Can see kpi_AwardType with description == null",
        code = "limited-kpi_AwardType")
@UiController("kpi_AwardType.browse")
@UiDescriptor("award-type-browse.xml")
@LookupComponent("awardTypesTable")
public class AwardTypeBrowse extends StandardLookup<AwardType> {

    @Autowired
    private DataManager dataManager;

    @Subscribe
    public void onInit(InitEvent event) {
        createCustomerLoader();
    }

    private void createCustomerLoader() {

//        List<AwardType> employeeList =  dataManager.load(AwardType.class)
//                .query("select e from kpi_AwardType e")
//                .list();
//        System.out.println("//");
//        System.out.println(employeeList);
//
//        System.out.println("//");
    }
}