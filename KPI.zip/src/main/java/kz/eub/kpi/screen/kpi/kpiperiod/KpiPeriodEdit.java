package kz.eub.kpi.screen.kpi.kpiperiod;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.KpiPeriod;

@UiController("kpi_KpiPeriod.edit")
@UiDescriptor("kpi-period-edit.xml")
@EditedEntityContainer("kpiPeriodDc")
public class KpiPeriodEdit extends StandardEditor<KpiPeriod> {
}