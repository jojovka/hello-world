package kz.eub.kpi.screen.kpi.kpicompetence;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.KpiCompetence;

@UiController("kpi_KpiCompetence.browse")
@UiDescriptor("kpi-competence-browse.xml")
@LookupComponent("kpiCompetencesTable")
public class KpiCompetenceBrowse extends StandardLookup<KpiCompetence> {
}