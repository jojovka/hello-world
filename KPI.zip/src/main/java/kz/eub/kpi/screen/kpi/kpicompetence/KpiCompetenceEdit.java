package kz.eub.kpi.screen.kpi.kpicompetence;

import io.jmix.ui.component.CurrencyField;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.KpiCompetence;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

@UiController("kpi_KpiCompetence.edit")
@UiDescriptor("kpi-competence-edit.xml")
@EditedEntityContainer("kpiCompetenceDc")
public class KpiCompetenceEdit extends StandardEditor<KpiCompetence> {

    @Autowired
    private CurrencyField<BigDecimal> efficiencyField;

    @Subscribe("weightField")
    public void onWeightFieldValueChange(HasValue.ValueChangeEvent<BigDecimal> event) {
        updateEfficiency();
    }

    @Subscribe("performanceField")
    public void onPerformanceFieldValueChange(HasValue.ValueChangeEvent<BigDecimal> event) {
        updateEfficiency();
    }

    private void updateEfficiency() {
        efficiencyField.setValue(getEditedEntity().getEfficiency());
    }

}