package kz.eub.kpi.screen.pointuser;

import io.jmix.core.DataManager;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.PointUser;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.TemporalType;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@UiController("kpi_PointUser.browse")
@UiDescriptor("point-user-browse.xml")
@LookupComponent("pointUsersTable")
public class PointUserBrowse extends StandardLookup<PointUser> {

    @Autowired
    private ComboBox<String> comboBoxId;

    @Autowired
    private DataManager dataManager;

    @Subscribe
    private void onInit(InitEvent event) {

        List<String> values = new ArrayList<>();
        values.add("Авторитету");
        values.add("Дуэли");
        values.add("Посещаемости");
        values.add("Конкурсам");
        comboBoxId.setOptionsList(values);


        Calendar myCal1 = Calendar.getInstance();
        Calendar myCal2 = Calendar.getInstance();
        myCal1.set(Calendar.YEAR, 2022);
        myCal1.set(Calendar.MONTH, 9);
        myCal1.set(Calendar.DAY_OF_MONTH, 1);

        myCal2.set(Calendar.YEAR, 2022);
        myCal2.set(Calendar.MONTH, 9);
        myCal2.set(Calendar.DAY_OF_MONTH, 30);
        Date startDate = myCal1.getTime();
        Date endDate = myCal2.getTime();
        List<PointUser> d = findAllEvents(startDate, endDate);
        System.out.println(d.size());
    }

    public List<PointUser> findAllEvents(Date startDate, Date endDate) {
        List<PointUser> allEvents = dataManager.load(PointUser.class)
                .query("SELECT e FROM kpi_PointUser e WHERE e.created_at BETWEEN :startDate AND :endDate " +
                        "AND e.type_id in (1,3,4) ")
                .parameter("startDate", startDate)
                .parameter("endDate", endDate)
                .list();
        return allEvents ;
    }
}