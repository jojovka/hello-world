package kz.eub.kpi.screen.kpi.kpigoal;

import io.jmix.core.DataManager;
import io.jmix.core.EntityStates;
import io.jmix.core.querycondition.LogicalCondition;
import io.jmix.core.querycondition.PropertyCondition;
import io.jmix.ui.Notifications;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.Action;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.CurrencyField;
import io.jmix.ui.component.DateField;
import io.jmix.ui.component.EntityComboBox;
import io.jmix.ui.component.EntityPicker;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.TabSheet;
import io.jmix.ui.component.Table;
import io.jmix.ui.component.TextArea;
import io.jmix.ui.component.ValidationException;
import io.jmix.ui.icon.JmixIcon;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.InstanceLoader;
import io.jmix.ui.screen.EditedEntityContainer;
import io.jmix.ui.screen.Install;
import io.jmix.ui.screen.MessageBundle;
import io.jmix.ui.screen.StandardEditor;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.Target;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.app.service.KpiCardService;
import kz.eub.kpi.app.service.KpiGoalService;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.Unit;
import kz.eub.kpi.entity.kpi.EKpiGoalAssessmentType;
import kz.eub.kpi.entity.kpi.EKpiGoalCategory;
import kz.eub.kpi.entity.kpi.KpiGoal;
import kz.eub.kpi.entity.kpi.KpiGoalAttachment;
import kz.eub.kpi.entity.kpi.KpiGoalComment;
import kz.eub.kpi.entity.kpi.KpiGoalDict;
import kz.eub.kpi.entity.kpi.KpiGoalDictFact;
import kz.eub.kpi.entity.kpi.KpiGoalDictPlan;
import kz.eub.kpi.entity.kpi.KpiGoalSubCategory;
import kz.eub.kpi.entity.kpi.KpiPeriod;
import kz.eub.kpi.screen.kpi.kpigoalcomment.KpiGoalCommentEdit;
import kz.eub.kpi.screen.kpi.kpigoaldict.KpiGoalDictBrowse;
import kz.eub.kpi.screen.kpi.kpigoaldictplan.KpiGoalDictPlanBrowse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@UiController("kpi_KpiGoal.edit")
@UiDescriptor("kpi-goal-edit.xml")
@EditedEntityContainer("kpiGoalDc")
public class KpiGoalEdit extends StandardEditor<KpiGoal> {

    public static final Logger log = LoggerFactory.getLogger(KpiGoalEdit.class);

    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private EntityStates entityStates;
    @Autowired
    private DateField<Date> planDateField;
    @Autowired
    private DateField<Date> factDateField;
    @Autowired
    private CurrencyField<BigDecimal> planField;
    @Autowired
    private CurrencyField<BigDecimal> factField;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private InstanceLoader<KpiGoal> kpiGoalDl;
    @Autowired
    private TabSheet tabSheet;
    @Autowired
    private MessageBundle messageBundle;
    @Autowired
    private Button kpiGoalCommentsTableEditBtn;
    @Autowired
    private Button kpiGoalCommentsTableRemoveBtn;
    @Autowired
    private Table<KpiGoalComment> kpiGoalCommentsTable;
    @Autowired
    private KpiGoalService kpiGoalService;
    @Autowired
    private ComboBox<EKpiGoalAssessmentType> assessmentTypeField;
    @Autowired
    private EntityPicker<KpiGoalDict> goalDictPicker;

    @Autowired
    private EntityPicker<KpiGoalDictPlan> goalDictPlanPicker;
    @Autowired
    private TextArea<String> nameField;
    @Autowired
    private TextArea<String> kpiDescriptionField;
    @Autowired
    private EntityComboBox<Unit> unitField;
    @Autowired
    private CurrencyField<BigDecimal> weightField;
    @Autowired
    private TextArea<String> dataSourceField;
    @Autowired
    private Notifications notifications;
    @Autowired
    private CollectionContainer<KpiGoalSubCategory> kpiGoalSubCategoriesDc;
    @Autowired
    private KpiCardService kpiCardService;
    @Autowired
    private DataManager dataManager;

    @Subscribe
    public void onInitEntity(InitEntityEvent<KpiGoal> event) {
        KpiGoal goal = event.getEntity();
        kpiGoalService.initKpiGoal(goal);
    }

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        markAttachmentsCount();
        markCommentsCount();
        if (!isReadOnly()) {
            planField.setWidth("103%");
            KpiGoal goal = getEditedEntity();
            if (Objects.equals(goal.getCategory(), EKpiGoalCategory.GVK_GOAL))
                toggleFieldsForGvkCategory();
        }
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        goalDictPicker.setEnabled(!isReadOnly());
    }

    private void markAttachmentsCount() {
        KpiGoal goal = getEditedEntity();
        String message = messageBundle.getMessage("attachments");
        int size = 0;
        if (goal.getAttachments() != null)
            size = goal.getAttachments().size();
        String color = "blue";
        JmixIcon icon = JmixIcon.CIRCLE_O;
        if (size > 0) {
            color = "red";
            icon = JmixIcon.CHECK_CIRCLE_O;
        }
        message = message + " <span style='color: " + color + "'><b>(" + size + ")</b></span>";
        tabSheet.setTabCaptionsAsHtml(true);
        TabSheet.Tab attachmentsTab = tabSheet.getTab("attachmentsTab");
        attachmentsTab.setIconFromSet(icon);
        attachmentsTab.setCaption(message);
    }

    private void markCommentsCount() {
        KpiGoal goal = getEditedEntity();
        String message = messageBundle.getMessage("comments");
        int size = 0;
        if (goal.getComments() != null)
            size = goal.getComments().size();
        String color = "blue";
        JmixIcon icon = JmixIcon.COMMENT_O;
        if (size > 0) {
            color = "red";
        }
        message = message + " <span style='color: " + color + "'><b>(" + size + ")</b></span>";
        tabSheet.setTabCaptionsAsHtml(true);
        TabSheet.Tab attachmentsTab = tabSheet.getTab("commentsTab");
        attachmentsTab.setIconFromSet(icon);
        attachmentsTab.setCaption(message);
    }

    @Subscribe("unitField")
    public void onUnitFieldValueChange(HasValue.ValueChangeEvent<Unit> event) {
        togglePlanFactFields(event.getValue());
        if (isReadOnly() || !event.isUserOriginated()) return;
        Unit unit = event.getValue();
        planField.setCurrency("");
        factField.setCurrency("");
        KpiGoal goal = getEditedEntity();
        goal.setAssessmentType(null);
        assessmentTypeField.setEditable(false);
        if (unit != null) {
            planField.setCurrency(unit.getCode());
            factField.setCurrency(unit.getCode());
            if (unit.getId().equals(Unit.UNIT_WDAY))
                goal.setAssessmentType(EKpiGoalAssessmentType.LESS_IS_BETTER);
            else if (!Objects.equals(goal.getCategory(), EKpiGoalCategory.FINANCIAL_GOAL))
                assessmentTypeField.setEditable(true);
        }
    }

    private void togglePlanFactFields(Unit unit) {
        planField.setVisible(true);
        planField.setRequired(true);
        factField.setVisible(true);
        planDateField.setValue(null);
        planDateField.setVisible(false);
        planDateField.setRequired(false);
        factDateField.setValue(null);
        factDateField.setVisible(false);
        if (unit == null) return;
        if (Objects.equals(unit.getId(), Unit.UNIT_WDAY)) {
            planDateField.setVisible(true);
            planDateField.setRequired(true);
            factDateField.setVisible(true);
            planField.setVisible(false);
            planField.setValue(null);
            planField.setRequired(false);
            factField.setVisible(false);
            factField.setValue(null);
        }
    }

    private void reloadKpiGoal() {
        kpiGoalDl.load();
    }

    @Install(to = "weightField", subject = "validator")
    private void weightFieldValidator(BigDecimal weight) {
        validateWeightPercentage(weight);
    }

    private void validateWeightPercentage(BigDecimal value) {
        if (value == null) return;
        if (value.compareTo(new BigDecimal(10)) < 0)
            throw new ValidationException("Минимальное допустимое значение 10");
        if (value.compareTo(new BigDecimal(50)) > 0)
            throw new ValidationException("Максиммально допустимое значение: 50");
    }

    @Install(to = "planField", subject = "validator")
    private void planFieldValidator(BigDecimal plan) {
        validatePlan(plan);
    }

    private void validatePlan(BigDecimal value) {
        if (value == null) return;
        if (value.compareTo(BigDecimal.ZERO) <= 0)
            throw new ValidationException("Отрицательные числа и значение 0 не допустимы");
    }

    @Subscribe(id = "attachmentsDc", target = Target.DATA_CONTAINER)
    public void onAttachmentsDcCollectionChange(CollectionContainer.CollectionChangeEvent<KpiGoalAttachment> event) {
        markAttachmentsCount();
    }

    @Subscribe("kpiGoalCommentsTableCreateBtn")
    public void onKpiGoalCommentsTableCreateBtnClick(Button.ClickEvent event) {
        KpiGoalCommentEdit commentEditScreen = screenBuilders.editor(KpiGoalComment.class, this)
                .withScreenClass(KpiGoalCommentEdit.class)
                .withInitializer(c -> {
                    c.setGoal(getEditedEntity());
                    c.setAuthor(employeeService.getCurrentEmployee());
                })
                .build();
        commentEditScreen.setReadOnly(false);
        commentEditScreen.setEditable();
        commentEditScreen.addAfterCloseListener(e -> reloadKpiGoal());
        commentEditScreen.show();
    }

    @Subscribe("kpiGoalCommentsTable")
    public void onKpiGoalCommentsTableSelection(Table.SelectionEvent<KpiGoalComment> event) {
        kpiGoalCommentsTableEditBtn.setEnabled(false);
        kpiGoalCommentsTableRemoveBtn.setEnabled(false);
        KpiGoalComment comment = kpiGoalCommentsTable.getSingleSelected();
        Employee employee = employeeService.getCurrentEmployee();
        if (comment != null && comment.getAuthor() != null
            && comment.getAuthor().getId().equals(employee.getId())) {
            kpiGoalCommentsTableEditBtn.setEnabled(true);
            kpiGoalCommentsTableRemoveBtn.setEnabled(true);
        }
    }

    @Subscribe("categoryField")
    public void onCategoryFieldValueChange(HasValue.ValueChangeEvent<EKpiGoalCategory> event) {
        if (isReadOnly()) return;
//        if (!event.isUserOriginated()) return;
        if (event.getPrevValue() != null)
            clearKpiGoalVariableFields();
        EKpiGoalCategory category = event.getValue();
        loadGoalSubCategories(category);
        if (category == null) {
            toggleFieldForDefaultCategory();
            return;
        }
        switch (category) {
            case FINANCIAL_GOAL :
                toggleFieldsForFinCategory();
                break;
            case PROJECT_GOAL :
                toggleFieldsForProjectCategory();
                break;
            case GVK_GOAL :
                toggleFieldsForGvkCategory();
                break;
            default :
                toggleFieldForDefaultCategory();
        }
    }

    private void toggleFieldsForGvkCategory() {
        goalDictPlanPicker.setEditable(false);
        goalDictPlanPicker.setRequired(false);
        goalDictPicker.setEditable(false);
        goalDictPicker.setRequired(false);
        nameField.setEditable(false);
        kpiDescriptionField.setEditable(false);
        unitField.setEditable(false);
        assessmentTypeField.setEditable(false);
        planDateField.setEditable(false);
        dataSourceField.setEditable(true);
        weightField.setEditable(false);
        planField.setWidth("100%");
        planField.setCurrency("");
        planField.setEditable(false);
    }

    private void toggleFieldsForFinCategory() {
        goalDictPicker.setVisible(false);
        goalDictPicker.setValue(null);
        goalDictPicker.setRequired(false);

        KpiGoal goal = getEditedEntity();

        goalDictPlanPicker.setVisible(true);
        goalDictPlanPicker.setEditable(true);
        goalDictPlanPicker.setRequired(goal.getGoalDict() == null);
        goalDictPlanPicker.focus();

        nameField.setEditable(false);
        kpiDescriptionField.setEditable(false);
        unitField.setEditable(false);
        assessmentTypeField.setEditable(false);
        planDateField.setEditable(false);
        dataSourceField.setEditable(false);
        planField.setEditable(false);
        planField.setWidth("100%");
        notifications.create(Notifications.NotificationType.TRAY)
                .withCaption("Выберите шаблон цели КПЭ")
                .show();
    }

    private void toggleFieldsForProjectCategory() {
        goalDictPlanPicker.setVisible(false);
        goalDictPlanPicker.setValue(null);
        goalDictPlanPicker.setRequired(false);

        goalDictPicker.setVisible(true);
        goalDictPicker.setEditable(true);
        goalDictPicker.setRequired(true);
        goalDictPicker.focus();

        nameField.setEditable(false);
        kpiDescriptionField.setEditable(true);
        unitField.setEditable(true);
        assessmentTypeField.setEditable(true);
        planDateField.setEditable(true);
        dataSourceField.setEditable(true);
        planField.setEditable(true);
        planField.setWidth("103%");
        notifications.create(Notifications.NotificationType.TRAY)
                .withCaption("Выберите шаблон цели КПЭ")
                .show();
    }

    private void toggleFieldForDefaultCategory() {
        goalDictPlanPicker.setEditable(false);
        goalDictPlanPicker.setRequired(false);
        goalDictPicker.setEditable(false);
        goalDictPicker.setRequired(false);
        nameField.setEditable(true);
        kpiDescriptionField.setEditable(true);
        unitField.setEditable(true);
        assessmentTypeField.setEditable(true);
        planDateField.setEditable(true);
        dataSourceField.setEditable(true);
        planField.setEditable(true);
        planField.setWidth("103%");
    }

    private void loadGoalSubCategories(EKpiGoalCategory category) {
        kpiGoalSubCategoriesDc.getMutableItems().clear();
        List<KpiGoalSubCategory> subCategories = kpiGoalService.loadGoalSubCategories(category);
        kpiGoalSubCategoriesDc.getMutableItems().addAll(subCategories);
    }

    private void clearKpiGoalVariableFields() {
        if (isReadOnly()) return;
        goalDictPicker.setValue(null);
        goalDictPlanPicker.setValue(null);
        KpiGoal goal = getEditedEntity();
        if (!entityStates.isNew(goal)) return;
        goal.setSubCategory(null);
        goal.setName(null);
        goal.setKpiDescription(null);
        goal.setUnit(null);
        goal.setAssessmentType(null);
        goal.setPlan(null);
        goal.setPlanDate(null);
        goal.setDataSource(null);
        goal.setGoalDict(null);
    }


    private void fillGoalFieldsFromDictPlan(KpiGoalDictPlan goalPlan) {
        if (goalPlan == null) {
            clearKpiGoalVariableFields();
            return;
        }
        goalDictPlanPicker.setValue(goalPlan);
        KpiGoal goal = getEditedEntity();
        goal.setGoalDict(goalPlan.getGoalDict());
        goal.setCategory(goalPlan.getGoalDict().getCategory());
        goal.setSubCategory(goalPlan.getGoalDict().getSubCategory());
        goal.setPlan(goalPlan.getPlan());
        goal.setUnit(goalPlan.getGoalDict().getUnit());
        goal.setName(goalPlan.getGoalDict().getName());
        goal.setKpiDescription(goalPlan.getGoalDict().getGoalDescription());
        goal.setAssessmentType(goalPlan.getGoalDict().getAssessmentMethod());
        goal.setInfo(goalPlan.getGoalDict().getInfo());
        goal.setDataSource(goalPlan.getGoalDict().getDataSource());
        BigDecimal fact = loadDiсtFact(goalPlan);
        goal.setFact(fact);
    }

    private BigDecimal loadDiсtFact(KpiGoalDictPlan goalDictPlan) {
        KpiGoalDictFact goalDictFact = dataManager.load(KpiGoalDictFact.class)
                .condition(LogicalCondition.and(
                        PropertyCondition.equal("goalDictPlan", goalDictPlan),
                        PropertyCondition.equal("period", goalDictPlan.getPeriod()),
                        PropertyCondition.equal("goalDict", goalDictPlan.getGoalDict())
                ))
                .optional().orElse(null);
        return (goalDictFact != null) ? goalDictFact.getFact() : null;
    }

    @Subscribe("goalDictPlanPicker.entity_lookup")
    public void onGoalDictPlanPickerEntity_lookup(Action.ActionPerformedEvent event) {
        KpiGoalDictPlanBrowse planBrowser = screenBuilders.lookup(KpiGoalDictPlan.class, this)
                .withScreenClass(KpiGoalDictPlanBrowse.class)
                .withSelectHandler(plans -> {
                    KpiGoalDictPlan plan = plans.iterator().next();
                    fillGoalFieldsFromDictPlan(plan);
                })
                .build();
        KpiPeriod period = getEditedEntity().getPeriod();
        planBrowser.setFilterPeriod(period);
        planBrowser.show();
    }

    private void fillGoalFieldsFromDict(KpiGoalDict dict) {
        clearKpiGoalVariableFields();
        if (dict == null) return;
        goalDictPicker.setValue(dict);
        KpiGoal goal = getEditedEntity();
        goal.setGoalDict(dict);
        goal.setCategory(dict.getCategory());
        goal.setSubCategory(dict.getSubCategory());
        goal.setName(dict.getName());
        goal.setKpiDescription(dict.getGoalDescription());
        goal.setInfo(dict.getInfo());
        goal.setDataSource(dict.getDataSource());
    }

    @Subscribe("goalDictPicker.entity_lookup")
    public void onGoalDictPickerEntity_lookup(Action.ActionPerformedEvent event) {
        KpiGoalDictBrowse goalDictBrowser = screenBuilders.lookup(KpiGoalDict.class, this)
                .withScreenClass(KpiGoalDictBrowse.class)
                .withSelectHandler(dicts -> {
                    KpiGoalDict dict = dicts.iterator().next();
                    fillGoalFieldsFromDict(dict);
                })
                .build();
        goalDictBrowser.show();
        goalDictBrowser.setFilterCategory(EKpiGoalCategory.PROJECT_GOAL);
    }

    @Subscribe
    public void onBeforeCommitChanges(BeforeCommitChangesEvent event) {
        try {
            kpiCardService.validateGoal(getEditedEntity());
        } catch (Exception e) {
            log.warn("Неправильное заполнение цели", e);
            notifications.create(Notifications.NotificationType.TRAY)
                    .withDescription(e.getMessage())
                    .show();
            event.preventCommit();
        }
    }

}