package kz.eub.kpi.screen.kpi.kpigoalattachment;

import io.jmix.data.Sequence;
import io.jmix.data.Sequences;
import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.KpiGoalAttachment;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("kpi_KpiGoalAttachment.edit")
@UiDescriptor("kpi-goal-attachment-edit.xml")
@EditedEntityContainer("kpiGoalAttachmentDc")
public class KpiGoalAttachmentEdit extends StandardEditor<KpiGoalAttachment> {

    @Autowired
    private Sequences sequences;

    @Subscribe
    public void onInitEntity(InitEntityEvent<KpiGoalAttachment> event) {
        long sn = sequences.createNextValue(Sequence.withName(KpiGoalAttachment.SEQUENCE_NAME));
        event.getEntity().setSn(String.format("%06d", sn));
    }

}