package kz.eub.kpi.screen.kpi.intermediateassessmentmeeting;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.IntermediateAssessmentMeeting;

@UiController("kpi_IntermediateAssessmentMeeting.browse")
@UiDescriptor("intermediate-assessment-meeting-browse.xml")
@LookupComponent("intermediateAssessmentMeetingsTable")
public class IntermediateAssessmentMeetingBrowse extends StandardLookup<IntermediateAssessmentMeeting> {
}