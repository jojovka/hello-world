package kz.eub.kpi.screen.kpi.kpicard;

import io.jmix.bpmui.processform.ProcessFormContext;
import io.jmix.bpmui.processform.annotation.ProcessForm;
import io.jmix.bpmui.processform.annotation.ProcessVariable;
import io.jmix.core.DataManager;
import io.jmix.ui.Notifications;
import io.jmix.ui.RemoveOperation;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.Action;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.Table;
import io.jmix.ui.model.CollectionPropertyContainer;
import io.jmix.ui.screen.EditedEntityContainer;
import io.jmix.ui.screen.Install;
import io.jmix.ui.screen.StandardEditor;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.DepartmentService;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.app.service.KpiCardService;
import kz.eub.kpi.app.service.KpiGoalService;
import kz.eub.kpi.entity.DictPosition;
import kz.eub.kpi.entity.EApplicationStatus;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.kpi.EKpiCardStage;
import kz.eub.kpi.entity.kpi.EKpiGoalCategory;
import kz.eub.kpi.entity.kpi.KpiCard;
import kz.eub.kpi.entity.kpi.KpiGoal;
import kz.eub.kpi.entity.kpi.KpiPeriod;
import kz.eub.kpi.screen.kpi.kpigoal.KpiGoalFactEdit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@UiController("kpi_KpiCard.edit")
@UiDescriptor("kpi-card-edit.xml")
@EditedEntityContainer("kpiCardDc")
@ProcessForm
public class KpiCardEdit extends StandardEditor<KpiCard> {

    public static final Logger log = LoggerFactory.getLogger(KpiCardEdit.class);

    @ProcessVariable
    private KpiCard application;

    @Autowired
    private ProcessFormContext processFormContext;

    @Autowired
    private KpiCardService kpiCardService;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private KpiGoalService kpiGoalService;
    @Autowired
    private Notifications notifications;
    @Autowired
    private Table<KpiGoal> kpiGoalsTable;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private DepartmentService departmentService;
    @Autowired
    private CollectionPropertyContainer<KpiGoal> kpiGoalsDc;
    @Autowired
    private Button sendBtn;

    @Subscribe
    public void onInit(InitEvent event) {
        if (application != null) {
            setEntityToEdit(application);
        }
    }


    @Subscribe
    public void onInitEntity(InitEntityEvent<KpiCard> event) {
        KpiPeriod period = kpiGoalService.getCurrentKpiPeriod();
        KpiCard card = event.getEntity();
        card.setDate(new Date());
        card.setPeriod(period);
        card.setStage(EKpiCardStage.FIRST_STAGE);
        card.setStatus(EApplicationStatus.NEW);
        Employee employee = employeeService.getCurrentEmployee();
        card.setAuthor(employee);
        if (employee != null) {
            card.setDepartment(employee.getDepartment());
            card.setPosition(employee.getPosition());
            card.setLeader(employee.getLeader());
            card.setSupervisor(employee.getSupervisor());
        }
        card.setSn(kpiCardService.getApplicationSN());
        assert employee != null;
        checkDepartmentAndAddGvkGoal(card, employee);
    }

    private void checkDepartmentAndAddGvkGoal(KpiCard card, Employee employee) {
        boolean isGvkStaff = departmentService.isEqualOrChildOfGvkDepartment(employee.getDepartment());
        if (isGvkStaff) {
            addGvkGoal(card, true);
        }
    }

    private void addGvkGoal(KpiCard card, boolean isOnInit) {
        KpiGoal gvkGoal = kpiGoalService.createDefaultGvkGoal(card);
        if (isOnInit) {
            card.setKpiGoals(new ArrayList<>());
            card.getKpiGoals().add(gvkGoal);
        } else {
            if (kpiGoalsDc.getMutableItems() == null)
                kpiGoalsDc.setItems(new ArrayList<>());
            kpiGoalsDc.getMutableItems().add(gvkGoal);
        }
    }

    private boolean hasExistsGvkGoal() {
        KpiCard card = getEditedEntity();
        if (card.getKpiGoals() == null)
            return false;
        for (KpiGoal goal : card.getKpiGoals()) {
            if (Objects.equals(goal.getCategory(), EKpiGoalCategory.GVK_GOAL))
                return true;
        }
        return false;
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        toggleStartBtn();
        calcTotalKpi();
    }

    protected void toggleStartBtn() {
        sendBtn.setVisible(startButtonEnableRule());
    }

    private boolean startButtonEnableRule() {
        KpiCard application = getEditedEntity();
        if (Objects.equals(application.getStatus(), EApplicationStatus.NEW)) {
            return kpiCardService.checkEnableCreationDeadline()
                    || kpiCardService.isTransferDuringPeriod(application.getAuthor().getHireDate(), application.getPeriod());
        }
        Set<EApplicationStatus> statuses = new HashSet<>(
                Arrays.asList(EApplicationStatus.REVOKED,
                        EApplicationStatus.ADJUSTMENT));
        return statuses.contains(application.getStatus());
    }

    private void refreshApplicationEmployeeData() {
        KpiCard card = getEditedEntity();
        if (Objects.equals(card.getStatus(), EApplicationStatus.NEW)
                || Objects.equals(card.getStatus(), EApplicationStatus.REVOKED)
                || Objects.equals(card.getStatus(), EApplicationStatus.AGREED)) {
            kpiCardService.updateApplicationEmployeeData(card);
            getEditedEntityLoader().load();
        }
    }

    @Subscribe
    public void onBeforeCommitChanges(BeforeCommitChangesEvent event) {
        try {
            kpiCardService.validateKpiCard(getEditedEntity());
        } catch (Exception e) {
            event.preventCommit();
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption(e.getMessage())
                    .show();
        }
    }

    @Install(to = "kpiGoalsTable.edit", subject = "afterCommitHandler")
    private void kpiGoalsTableEditAfterCommitHandler(KpiGoal kpiGoal) {
        calcTotalKpi();
    }


    private void sendToApprovalTask() {
        commitChanges();
        processFormContext.taskCompletion()
                .saveInjectedProcessVariables()
                .complete();
        notifications.create(Notifications.NotificationType.TRAY)
                .withCaption("Цель КПЭ отправлена на согласование...")
                .show();
        closeWithDiscard();
    }

    private void startNewApplicationProcess() {
        try {
            KpiCard application = getEditedEntity();
            for (KpiGoal goal : application.getKpiGoals()) {
                goal.setStatus(null);
            }
            commitChanges();
            application = getEditedEntity();
            HashMap<String, Object> variables = new HashMap<>();
            variables.put("businessModer", null);
            String processDefKeyApproval = KpiCard.PROCESS_DEF_KEY_APPROVAL;
            if (Objects.equals(application.getStage(), EKpiCardStage.SECOND_STAGE))
                processDefKeyApproval = KpiCard.PROCESS_DEF_KEY_ASSESSMENT;
            kpiCardService.startNewApplicationProcess(application, processDefKeyApproval, variables);
            notifications.create(Notifications.NotificationType.TRAY)
                    .withCaption("Карта КПЭ отправлена на согласование...")
                    .show();
            closeWithDiscard();
        } catch (Exception e) {
            log.error("Ошибка при запуске согласования", e);
            notifications.create(Notifications.NotificationType.ERROR)
                    .withDescription(e.getMessage())
                    .show();
        }
    }

    @Subscribe("sendBtn")
    public void onSendBtnClick(Button.ClickEvent event) {
        try {
            KpiCard card = getEditedEntity();
            kpiCardService.validateKpiCard(card);
            for (KpiGoal goal : card.getKpiGoals()) {
                goal.setStatus(null);
            }
            dataManager.save(card);
            getEditedEntityLoader().load();
            card = getEditedEntity();
            if (card.getStatus() == null
                    || card.getStatus().equals(EApplicationStatus.NEW)
                    || card.getStatus().equals(EApplicationStatus.REVOKED)) {
                startNewApplicationProcess();
            } else {
                sendToApprovalTask();
            }
        } catch (Exception e) {
            log.error("Error while trying to send: ", e);
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption(e.getMessage())
                    .show();
        }
    }

    @Subscribe("authorField")
    public void onAuthorFieldValueChange(HasValue.ValueChangeEvent<Employee> event) {
        if (event.getValue() == null) return;
        getEditedEntity().setDepartment(event.getValue().getDepartment());
    }

    @Install(to = "kpiGoalsTable.create", subject = "enabledRule")
    private boolean kpiGoalsTableCreateEnabledRule() {
        return Objects.equals(getEditedEntity().getStage(), EKpiCardStage.FIRST_STAGE);
    }

    @Install(to = "kpiGoalsTable.remove", subject = "enabledRule")
    private boolean kpiGoalsTableRemoveEnabledRule() {
        return Objects.equals(getEditedEntity().getStage(), EKpiCardStage.FIRST_STAGE);
    }

    @Install(to = "kpiGoalsTable.edit", subject = "enabledRule")
    private boolean kpiGoalsTableEditEnabledRule() {
        KpiGoal goal = kpiGoalsTable.getSingleSelected();
        if (goal == null) return false;
        return Objects.equals(getEditedEntity().getStage(), EKpiCardStage.FIRST_STAGE)
                 && !Objects.equals(goal.getCategory(), EKpiGoalCategory.GVK_GOAL);
    }

    @Install(to = "kpiGoalsTable.fact", subject = "enabledRule")
    private boolean kpiGoalsTableFactEnabledRule() {
        return Objects.equals(getEditedEntity().getStage(), EKpiCardStage.SECOND_STAGE)
                && kpiGoalsTable.getSingleSelected() != null;
    }

    @Subscribe("kpiGoalsTable.fact")
    public void onKpiGoalsTableFact(Action.ActionPerformedEvent event) {
        screenBuilders.editor(kpiGoalsTable)
                .withScreenClass(KpiGoalFactEdit.class)
                .withAfterCloseListener(e -> calcTotalKpi())
                .show();
    }

    private void calcTotalKpi() {
        kpiCardService.calcTotalKpi(getEditedEntity());
    }

    @Install(to = "kpiGoalsTable.remove", subject = "afterActionPerformedHandler")
    private void kpiGoalsTableRemoveAfterActionPerformedHandler(RemoveOperation.AfterActionPerformedEvent<KpiGoal> afterActionPerformedEvent) {
        calcTotalKpi();
    }

    @Subscribe("positionField")
    public void onPositionFieldValueChange(HasValue.ValueChangeEvent<DictPosition> event) {
        DictPosition position = event.getValue();
        if (position == null) return;
        getEditedEntity().setDepartment(position.getDepartment());
    }

    @Subscribe("kpiGoalsTable.addGvkGoal")
    public void onKpiGoalsTableAddGvkGoal(Action.ActionPerformedEvent event) {
        KpiCard card = getEditedEntity();
        addGvkGoal(card, false);
    }

    @Install(to = "kpiGoalsTable.addGvkGoal", subject = "enabledRule")
    private boolean kpiGoalsTableAddGvkGoalEnabledRule() {
        return !hasExistsGvkGoal();
    }
}