package kz.eub.kpi.screen.accountprofiles;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.AccountProfiles;

@UiController("kpi_AccountProfiles.browse")
@UiDescriptor("account-profiles-browse.xml")
@LookupComponent("accountProfilesesTable")
public class AccountProfilesBrowse extends StandardLookup<AccountProfiles> {
}