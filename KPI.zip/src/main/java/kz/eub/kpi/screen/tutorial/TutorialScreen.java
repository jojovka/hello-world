package kz.eub.kpi.screen.tutorial;

import io.jmix.core.DataManager;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.EntityComboBox;
import io.jmix.ui.component.HasEnterPressHandler;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.Install;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.ProBonusService;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.Duel;
import kz.eub.kpi.entity.DuelContest;
import kz.eub.kpi.entity.RatingUserOptions;
import kz.eub.kpi.screen.authority.Authorityscreen;
import kz.eub.kpi.screen.duelcontestwithopponent.DuelContestWithOpponent;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

@UiController("bonus_TutorialScreen")
@UiDescriptor("tutorial-screen.xml")
public class TutorialScreen extends Screen {
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private ProBonusService proBonusService;

    private List<Duel> duels;

    private List<DuelContest> duelContests;

    private Duel selectedDuel;

    @Autowired
    protected CollectionContainer<Duel> depDc;
    @Autowired
    private EntityComboBox<Duel> depComboBox;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private CollectionContainer<kz.eub.kpi.entity.DuelContest> awardsDc;

    @Subscribe
    private void onInit(InitEvent event) {
        duels = proBonusService.reloadAllDuel();
        depDc.getMutableItems().clear();
        depDc.getMutableItems().addAll(duels);

        duelContests = proBonusService.reloadAllContests();
        awardsDc.getMutableItems().clear();
        awardsDc.getMutableItems().addAll(duelContests);
    }

    @Subscribe("newDuelBtn")
    public void onNewDuelBtnClick(Button.ClickEvent event) {
        DuelContest duel = dataManager.create(DuelContest.class);
        if (selectedDuel != null) {
            duel = proBonusService.reloadOpenDuelContestByType(selectedDuel.getId());
        }

        if (duel != null && duel.getCreated_date() != null) {
            screenBuilders.screen(this)
                    .withScreenClass(DuelContestWithOpponent.class)
                    .withOptions(new RatingUserOptions(duel.getContester().getId(),
                            null,duel.getPointContester() + 0.0,null,
                            null, duel.getDuelId().getId()))
                    .build()
                    .show().addAfterCloseListener(afterCloseEvent -> {
                        duelContests = proBonusService.reloadAllContests();
                        awardsDc.getMutableItems().clear();
                        awardsDc.getMutableItems().addAll(duelContests);
                    });
        } else {
            screenBuilders.screen(this)
                    .withScreenClass(kz.eub.kpi.screen.duelcontest.DuelContest.class)
                    .withOptions(new RatingUserOptions(null, null,null,null,null, selectedDuel.getId()))
                    .build()
                    .show().addAfterCloseListener(afterCloseEvent -> {
                        duelContests = proBonusService.reloadAllContests();
                        awardsDc.getMutableItems().clear();
                        awardsDc.getMutableItems().addAll(duelContests);
                    });
        }

    }

    @Subscribe("depComboBox")
    public void selectedType(HasValue.ValueChangeEvent<Duel> event) {
        selectedDuel = event.getValue();
    }

}