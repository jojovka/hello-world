package kz.eub.kpi.screen.gvkdepartment;

import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.*;
import kz.eub.kpi.app.service.DepartmentService;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.GvkDepartment;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@UiController("kpi_GvkDepartment.browse")
@UiDescriptor("gvk-department-browse.xml")
@LookupComponent("gvkDepartmentsTable")
public class GvkDepartmentBrowse extends StandardLookup<GvkDepartment> {

    @Autowired
    private CollectionContainer<GvkDepartment> gvkDepartmentsDc;
    @Autowired
    private DepartmentService departmentService;

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        List<GvkDepartment> gvkDepList = gvkDepartmentsDc.getMutableItems();
        for (GvkDepartment gvkDepartment : gvkDepList) {
            getDepartment(gvkDepartment);
        }
    }

    private void getDepartment(GvkDepartment gvkDep) {
        DictDepartment department = departmentService.getDepartmentBySapId(gvkDep.getSapId());
        gvkDep.setDepartment(department);
    }

}