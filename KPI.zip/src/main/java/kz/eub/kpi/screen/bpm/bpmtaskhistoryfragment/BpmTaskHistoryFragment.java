package kz.eub.kpi.screen.bpm.bpmtaskhistoryfragment;

import com.google.common.base.Strings;
import io.jmix.bpm.data.outcome.Outcome;
import io.jmix.bpm.data.outcome.OutcomesContainer;
import io.jmix.bpm.entity.ProcessInstanceData;
import io.jmix.bpm.entity.TaskData;
import io.jmix.ui.UiComponents;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.Component;
import io.jmix.ui.component.GridLayout;
import io.jmix.ui.component.GroupBoxLayout;
import io.jmix.ui.component.HBoxLayout;
import io.jmix.ui.component.Label;
import io.jmix.ui.component.PopupView;
import io.jmix.ui.component.VBoxLayout;
import io.jmix.ui.icon.JmixIcon;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.MessageBundle;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.ScreenFragment;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.Target;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.HasRefreshableContent;
import kz.eub.kpi.app.service.BpmUserTaskService;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.app.service.EmployeeService;
import org.flowable.variable.api.history.HistoricVariableInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

@UiController("kpi_BpmTaskHistoryFragment")
@UiDescriptor("bpm-task-history-fragment.xml")
public class BpmTaskHistoryFragment extends ScreenFragment implements HasRefreshableContent {

    private static final SimpleDateFormat dataTimeFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
    public static final Logger log = LoggerFactory.getLogger(BpmTaskHistoryFragment.class);

    @Autowired
    private CollectionContainer<TaskData> allTasksDc;
    @Autowired
    private VBoxLayout container;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private MessageBundle messageBundle;
    @Autowired
    private BpmUserTaskService bpmUserTaskService;
    @Autowired
    private InstanceContainer<ProcessInstanceData> processInstanceDataDc;



    @Subscribe(target = Target.PARENT_CONTROLLER)
    public void onBeforeShow(Screen.BeforeShowEvent event) {
        refreshContent();
    }

    @Override
    public void refreshContent() {
        loadProcessTasks();
        List<TaskData> tasks = allTasksDc.getItems();
        if (tasks.size() > 0) {
            createTaskHistoryInfo();
        }
    }

    private void loadProcessTasks() {
        allTasksDc.getMutableItems().clear();
        if (processInstanceDataDc.getItemOrNull() == null) return;
        List<TaskData> tasks = bpmUserTaskService.getHistoricTaskDataListByProcId(processInstanceDataDc.getItem().getId());
        allTasksDc.getMutableItems().addAll(tasks);
    }

    private void createTaskHistoryInfo() {
        List<TaskData> allTasks = allTasksDc.getItems();
        if (allTasks.size() > 0) {
            container.removeAll();

            int i = allTasks.size();
            for (TaskData taskData : allTasks) {
                String headCaption = "<b>" + (i--) + " - " + taskData.getName() + "</b>";

                GroupBoxLayout taskInfo = uiComponents.create(GroupBoxLayout.class);
                container.add(taskInfo);
                taskInfo.setShowAsPanel(true);
                taskInfo.setStyleName("well");
                taskInfo.setCaptionAsHtml(true);
                //taskInfo.setWidthFull();
                taskInfo.setCaption(headCaption);

                GridLayout gridLayout = uiComponents.create(GridLayout.class);
                taskInfo.add(gridLayout);
                gridLayout.setRows(4);
                gridLayout.setColumns(3);
                gridLayout.setSpacing(true);

                HBoxLayout firstRow = uiComponents.create(HBoxLayout.class);
                firstRow.setAlignment(Component.Alignment.MIDDLE_LEFT);
                gridLayout.add(firstRow, 0, 0, 2, 0);

                Button taskStatusIcon = uiComponents.create(Button.class);
                firstRow.add(taskStatusIcon);
                taskStatusIcon.setStyleName("borderless icon-only");
                //gridLayout.add(taskStatusIcon,0,0);

                Label<String> assignedToLabel = uiComponents.create(Label.TYPE_STRING);
                assignedToLabel.setAlignment(Component.Alignment.MIDDLE_LEFT);
                firstRow.add(assignedToLabel);

                Employee assignedUser = employeeService.reloadEmployeeByUsername(taskData.getAssignee());
                if (assignedUser != null) {
                    assignedToLabel.setValue(assignedUser.getFullName());
                    if (assignedUser.getPosition() != null
                            && !Strings.isNullOrEmpty(assignedUser.getPosition().getName())) {
                        assignedToLabel.setValue(assignedToLabel.getValue() + "\n" + assignedUser.getPosition().getName());
                    }
                } else {
                    assignedToLabel.setValue(messageBundle.getMessage("notAssigned.caption"));
                }

                Label<String> createTimeLabel = uiComponents.create(Label.TYPE_STRING);
                createTimeLabel.setHtmlEnabled(true);
                createTimeLabel.setValue(messageBundle.getMessage("task.received.caption") + ": &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
                        + dataTimeFormat.format(taskData.getCreateTime()) + "<br/>");

                if (taskData.getEndTime() == null) {
                    taskStatusIcon.setIcon("font-icon:CLOCK_O");
                    createTimeLabel.setValue(createTimeLabel.getValue() + "\n"
                            + messageBundle.getMessage("taskStatus.inWork.caption"));
                } else {
                    HistoricVariableInstance outcomeResult = bpmUserTaskService.getHistoricVariableInstance(
                            taskData.getProcessInstanceId(),
                            taskData.getTaskDefinitionKey() + "_result");

                    List<Outcome> taskOutcomes = null;
                    if (outcomeResult != null && outcomeResult.getValue() != null) {

                        try {
                            OutcomesContainer outcomesContainer = (OutcomesContainer) outcomeResult.getValue();
                            taskOutcomes = outcomesContainer.getOutcomes();
                        } catch (ClassCastException e) {
                            log.error("Couldn't cast to OutcomesContainer class", e);
                        }
                    }

                    VBoxLayout vbox = uiComponents.create(VBoxLayout.class);
                    HBoxLayout secondRow = uiComponents.create(HBoxLayout.class);
                    secondRow.setAlignment(Component.Alignment.MIDDLE_LEFT);

                    vbox.setAlignment(Component.Alignment.MIDDLE_LEFT);
                    if (taskOutcomes != null && taskOutcomes.size() > 0) {
                        String outcomeText = getOutcomeCaption(taskOutcomes.get(0).getOutcomeId());
                        if (!Strings.isNullOrEmpty(outcomeText)
                                && !outcomeText.contains(".caption")) {
                            Button taskOutcomeIcon = uiComponents.create(Button.class);
                            taskOutcomeIcon.setIconFromSet(JmixIcon.DOT_CIRCLE_O);
                            taskOutcomeIcon.setStyleName("borderless icon-only");
                            secondRow.add(taskOutcomeIcon);

                            Label<String> oucomeLabel = uiComponents.create(Label.TYPE_STRING);
                            oucomeLabel.setValue(outcomeText.toUpperCase(Locale.ROOT));
                            vbox.add(oucomeLabel);
                        }
                    }

                    taskStatusIcon.setIcon("font-icon:CHECK");
                    taskStatusIcon.setStyleName("borderless icon-only");
                    createTimeLabel.setHtmlEnabled(true);
                    createTimeLabel.setValue(createTimeLabel.getValue() + "\n"
                            + messageBundle.getMessage("task.completed.caption") + ": &nbsp;&nbsp;"
                            + dataTimeFormat.format(taskData.getEndTime()) + "<br/>");

                    String commentFull = getTaskComment(taskData);
                    if (commentFull != null && commentFull.trim().length() > 0) {
                        String commentShort = commentFull;
                        if (commentFull.length() > 25)
                            commentShort = commentFull.substring(0, 25) + "...";
                        Component outcomeComment = createPopupViewForUserComment(assignedUser, taskData.getName(), commentShort, commentFull);
                        outcomeComment.setStyleName("h4 colored");
                        vbox.add(outcomeComment);
                    }

                    secondRow.add(vbox);
                    gridLayout.add(secondRow, 0, 2);
                }

                gridLayout.add(createTimeLabel, 0, 3);
            }
        }
    }

    private Component createPopupViewForUserComment(Employee employee, String taskName, String popupLabel, String commentText) {
        PopupView result = uiComponents.create(PopupView.class);
        result.setResponsive(true);
        result.setWidth("300px");
        result.setHeightAuto();
        result.setMinimizedValue(popupLabel);

        VBoxLayout userInfoVBox = uiComponents.create(VBoxLayout.class);
        result.setPopupContent(userInfoVBox);
        userInfoVBox.setSpacing(true);
        userInfoVBox.setMargin(true);

        Label<String> taskInfoLabel = uiComponents.create(Label.NAME);
        taskInfoLabel.setHtmlEnabled(true);
        userInfoVBox.add(taskInfoLabel);

        String taskInfo = (employee != null) ? employee.getFullName() : "";
        taskInfo += "<h3><strong>" + taskName + "</strong></h3>";

        taskInfoLabel.setValue(taskInfo);

        Label<String> comment = uiComponents.create(Label.TYPE_STRING);
        comment.setHtmlEnabled(true);
        commentText = "<p>" + commentText + "</p>";
        comment.setValue(commentText);
        comment.setStyleName("j-label");
        comment.setWidth("400px");
        userInfoVBox.add(comment);

        return result;
    }

    private String getTaskComment(TaskData taskData) {

        // todo: Load all Task Comments by TaskID ... Redesign comments popup ...

        HistoricVariableInstance commenData =
                bpmUserTaskService.getHistoricVariableInstance(taskData.getProcessInstanceId(),
                        taskData.getTaskDefinitionKey() + "_" + taskData.getExecutionId() + "_comment");

        if (commenData == null)
            commenData =
                    bpmUserTaskService.getHistoricVariableInstance(
                            taskData.getProcessInstanceId(),
                            taskData.getTaskDefinitionKey() + "_comment");

        return commenData != null ? (String) commenData.getValue() : "";
    }

    private String getOutcomeCaption(String outcomeId) {
        return messageBundle.getMessage("outcomes." + outcomeId + ".caption");
    }

}