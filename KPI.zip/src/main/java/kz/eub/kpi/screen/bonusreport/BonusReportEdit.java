package kz.eub.kpi.screen.bonusreport;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.BonusReport;

@UiController("kpi_bonus_report.edit")
@UiDescriptor("bonus-report-edit.xml")
@EditedEntityContainer("bonusReportDc")
public class BonusReportEdit extends StandardEditor<BonusReport> {
}