package kz.eub.kpi.screen.awardtype;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.AwardType;

@UiController("kpi_AwardType.edit")
@UiDescriptor("award-type-edit.xml")
@EditedEntityContainer("awardTypeDc")
public class AwardTypeEdit extends StandardEditor<AwardType> {
}