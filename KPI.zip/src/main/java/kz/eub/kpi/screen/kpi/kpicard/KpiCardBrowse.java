package kz.eub.kpi.screen.kpi.kpicard;

import io.jmix.ui.Dialogs;
import io.jmix.ui.Notifications;
import io.jmix.ui.action.Action;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.action.DialogAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.EntityPicker;
import io.jmix.ui.component.Filter;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.PropertyFilter;
import io.jmix.ui.component.SimplePagination;
import io.jmix.ui.component.ValuesPicker;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.Install;
import io.jmix.ui.screen.LookupComponent;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.ApplicationService;
import kz.eub.kpi.app.service.EmployeeSecService;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.app.service.KpiCardService;
import kz.eub.kpi.app.service.KpiGoalExportService;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.EApplicationStatus;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.kpi.EKpiCardStage;
import kz.eub.kpi.entity.kpi.KpiCard;
import kz.eub.kpi.entity.kpi.KpiPeriod;
import kz.eub.kpi.security.HrModeratorRole;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@UiController("kpi_KpiCard.browse")
@UiDescriptor("kpi-card-browse.xml")
@LookupComponent("kpiCardsTable")
public class KpiCardBrowse extends StandardLookup<KpiCard> {

    public static final Logger log = LoggerFactory.getLogger(KpiCardBrowse.class);

    @Autowired
    private GroupTable<KpiCard> kpiCardsTable;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private PropertyFilter<Employee> authorProp;
    @Autowired
    private Filter filter;
    @Autowired
    private CollectionContainer<KpiCard> kpiCardsDc;
    @Autowired
    private Notifications notifications;
    @Autowired
    private KpiCardService kpiCardService;
    @Autowired
    private EntityPicker<KpiPeriod> periodFld;
    @Autowired
    private ValuesPicker<DictDepartment> departmentsFld;
    @Autowired
    private ComboBox<EApplicationStatus> statusFld;
    @Autowired
    private SimplePagination simplePagination;
    @Autowired
    private Button calcGoalsBtn;

    @Autowired
    private KpiGoalExportService kpiGoalExportService;
    @Autowired
    private CollectionContainer<KpiCard> orgStructureCardsDc;
    @Autowired
    private CollectionLoader<KpiCard> kpiCardsDl;
    @Autowired
    private Dialogs dialogs;
    @Autowired
    private ApplicationService applicationService;
    @Autowired
    private EmployeeSecService employeeSecService;
    @Autowired
    private Button revokeBtn;
    @Autowired
    private Button rollBackBtn;

    @Subscribe
    public void onInit(InitEvent event) {
        initEnterPressHandler();
        initDoubleClickHandler();
    }

    public void setAuthorFilterProperty() {
        Filter.Configuration authorConf = filter.getConfiguration("authorConf");
        List<Filter.Configuration> confList = filter.getConfigurations()
                .stream().filter(f -> !f.getId().equals(authorConf.getId()))
                .collect(Collectors.toList());
        for (Filter.Configuration conf : confList) {
            filter.removeConfiguration(conf);
        }
        kpiCardsDc.getMutableItems().clear();
        Employee currentEmployee = employeeService.getCurrentEmployee();
        if (currentEmployee != null) {
            authorProp.setValue(currentEmployee);
            filter.setCurrentConfiguration(authorConf);
            filter.apply();
        }
        filter.setVisible(false);
        departmentsFld.setValue(Arrays.asList(currentEmployee.getDepartment()));
        departmentsFld.setEditable(false);
        calcGoalsBtn.setVisible(false);
    }

    private void initEnterPressHandler() {
        kpiCardsTable.setEnterPressAction(new BaseAction("enterPressAction")
                .withHandler(event -> openKpiCard()));
    }

    private void initDoubleClickHandler() {
        kpiCardsTable.setItemClickAction(new BaseAction("itemClickAction")
                .withHandler(event -> openKpiCard()));
    }

    private void openKpiCard() {
        KpiCard card = kpiCardsTable.getSingleSelected();
        if (card == null) return;
        Objects.requireNonNull(kpiCardsTable.getAction("view")).actionPerform(kpiCardsTable);
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        toggleRevokeAndRollBackBtns();
    }

    @Subscribe("exportGoalsBtn")
    public void onExportGoalsBtnClick(Button.ClickEvent event) {
        try {
            List<KpiCard> kpiCards = kpiCardsDc.getMutableItems();
            kpiGoalExportService.exportKpiGoals(kpiCards);
        } catch (Exception e) {
            log.error("Ошибка при попытке выгрузки целей", e);
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Ошибка при попытке выгрузки целей")
                    .withDescription(e.getMessage())
                    .show();
        }
    }

    private void loadCardsByDepartment(List<DictDepartment> departmentsList, KpiPeriod period, EApplicationStatus status) {
        try {
            if (departmentsList == null || departmentsList.size() == 0)
                throw new IllegalArgumentException("Передан пустой аргумент: Подразделение");
            if (period == null)
                throw new IllegalArgumentException("Передан пустой аргумент: Период");

            List<KpiCard> kpiCards = new ArrayList<>();
            for (DictDepartment department : departmentsList) {
                List<KpiCard> cardList = kpiCardService.loadAllDepartmentKpiCards(period, department);
                kpiCards.addAll(cardList);
            }
            kpiCards = kpiCards.stream().distinct().collect(Collectors.toList());
            if (status != null) {
                kpiCards = kpiCards.stream()
                        .filter(c -> c.getStatus().equals(status))
                        .collect(Collectors.toList());
            }
            orgStructureCardsDc.getMutableItems().clear();
            orgStructureCardsDc.getMutableItems().addAll(kpiCards);
            notifications.create(Notifications.NotificationType.TRAY)
                    .withCaption(String.format("Найдены %d карт КПЭ сотрудников структурных подразделений.", kpiCards.size()))
                    .show();
        } catch (IllegalArgumentException e) {
            notifications.create(Notifications.NotificationType.TRAY)
                    .withDescription(e.getMessage())
                    .show();
        }
    }


    @Subscribe("departmentsFld")
    public void onDepartmentsFldValueChange(HasValue.ValueChangeEvent<DictDepartment> event) {
        searchDepartmentKpiCards();
    }

    @Subscribe("searchBtn")
    public void onSearchBtnClick(Button.ClickEvent event) {
        searchDepartmentKpiCards();
    }

    private void searchDepartmentKpiCards() {
        KpiPeriod period = periodFld.getValue();
        List<DictDepartment> departments = (List) departmentsFld.getValue();
        EApplicationStatus status = statusFld.getValue();
        loadCardsByDepartment(departments, period, status);
    }

    @Subscribe("periodFld")
    public void onPeriodFldValueChange(HasValue.ValueChangeEvent<KpiPeriod> event) {
        searchDepartmentKpiCards();
    }

    @Subscribe("statusFld")
    public void onStatusFldValueChange(HasValue.ValueChangeEvent<EApplicationStatus> event) {
        searchDepartmentKpiCards();
    }

    @Subscribe("calcGoalsBtn")
    public void onCalcGoalsBtnClick(Button.ClickEvent event) {
        List<KpiCard> kpiCards = kpiCardsDc.getMutableItems();
        KpiCard card = kpiCards.stream().findFirst().orElse(null);
        if (card == null) return;
        KpiPeriod period = card.getPeriod();
        try {
            int count = kpiCardService.calcAllCardsGoalsPerformances(period);
            notifications.create()
                    .withCaption(String.format("Пересчитаны %d Карт КПЭ...", count))
                    .show();
        } catch (Exception e) {
            log.error("Ошибка", e);
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Произошла ошибка при попытке расчета КПЭ... ")
                    .withDescription(e.getMessage())
                    .show();
        }
    }

    @Subscribe("osExportGoalsBtn")
    public void onOsExportGoalsBtnClick(Button.ClickEvent event) {
        try {
            List<KpiCard> kpiCards = orgStructureCardsDc.getMutableItems();
            kpiGoalExportService.exportKpiGoals(kpiCards);
        } catch (Exception e) {
            log.error("Ошибка при попытке выгрузки целей", e);
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Ошибка при попытке выгрузки целей")
                    .withDescription(e.getMessage())
                    .show();
        }
    }

    @Subscribe("kpiCardsTable.revoke")
    public void onKpiCardsTableRevoke(Action.ActionPerformedEvent event) {
        KpiCard selected = kpiCardsTable.getSingleSelected();
        if (selected == null) return;
        dialogs.createOptionDialog()
                .withCaption("Вы подтверждаете?")
                .withMessage("Вы действительно хотите отозвать заявку?")
                .withActions(
                        new DialogAction(DialogAction.Type.YES, Action.Status.PRIMARY)
                                .withHandler(e -> revokeApplication(selected)),
                        new DialogAction(DialogAction.Type.NO)
                )
                .show();
    }

    private void toggleRevokeAndRollBackBtns() {
        boolean isModerator = employeeSecService.currentUserHasRole(HrModeratorRole.CODE);
        revokeBtn.setVisible(isModerator);
        rollBackBtn.setVisible(isModerator);
    }

    private void revokeApplication(KpiCard card) {
        try {
            if (applicationService.cancelApplicationProcess(card, "Отозвана модератором.")) {
                notifications.create()
                        .withCaption("Заявка успешно отозвана...")
                        .show();
            } else {
                notifications.create()
                        .withCaption("Заявка переведена в статус \"Отозвано\".")
                        .show();
            }
        } catch (Exception e) {
            log.error("Ошибка при отзыве заявки: ", e);
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Не удалось отозвать заявку...")
                    .withDescription(e.getMessage())
                    .show();
        }
        kpiCardsDl.load();
    }

    @Subscribe("kpiCardsTable.rollBack")
    public void onKpiCardsTableRollBack(Action.ActionPerformedEvent event) {
        KpiCard selected = kpiCardsTable.getSingleSelected();
        if (selected == null) return;
        dialogs.createOptionDialog()
                .withCaption("Вы подтверждаете?")
                .withMessage("Вы действительно хотите откатить заявку на I этап?")
                .withActions(
                        new DialogAction(DialogAction.Type.YES, Action.Status.PRIMARY)
                                .withHandler(e -> rollBackApplication(selected)),
                        new DialogAction(DialogAction.Type.NO)
                )
                .show();
    }

    private void rollBackApplication(KpiCard card) {
        try {
            kpiCardService.rollBackCardToFirstStage(card);
                notifications.create()
                        .withCaption("Заявка успешно откачена на I этап...")
                        .show();
            kpiCardsDl.load();
        } catch (Exception e) {
            log.error("Ошибка при откате заявки: ", e);
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Не удалось откатить заявку...")
                    .withDescription(e.getMessage())
                    .show();
        }
    }

    @Install(to = "kpiCardsTable.revoke", subject = "enabledRule")
    private boolean kpiCardsTableRevokeEnabledRule() {
        KpiCard selected = kpiCardsTable.getSingleSelected();
        if (selected == null) return false;
        if (!employeeSecService.currentUserHasRole(HrModeratorRole.CODE))
            return false;
        return (Objects.equals(selected.getStatus(), EApplicationStatus.AGREED)
                || Objects.equals(selected.getStatus(), EApplicationStatus.COMPLETED));
    }

    @Install(to = "kpiCardsTable.rollBack", subject = "enabledRule")
    private boolean kpiCardsTableRollBackEnabledRule() {
        KpiCard selected = kpiCardsTable.getSingleSelected();
        if (selected == null) return false;
        if (!employeeSecService.currentUserHasRole(HrModeratorRole.CODE))
            return false;
        return (Objects.equals(selected.getStatus(), EApplicationStatus.REVOKED)
            && Objects.equals(selected.getStage(), EKpiCardStage.SECOND_STAGE));
    }
}