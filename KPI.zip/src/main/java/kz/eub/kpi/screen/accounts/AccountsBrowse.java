package kz.eub.kpi.screen.accounts;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.Accounts;

@UiController("kpi_Accounts.browse")
@UiDescriptor("accounts-browse.xml")
@LookupComponent("accountsesTable")
public class AccountsBrowse extends StandardLookup<Accounts> {
}