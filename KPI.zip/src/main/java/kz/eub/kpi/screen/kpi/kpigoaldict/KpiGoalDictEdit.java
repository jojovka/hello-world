package kz.eub.kpi.screen.kpi.kpigoaldict;

import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.EntityComboBox;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.TextArea;
import io.jmix.ui.component.TextField;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.EditedEntityContainer;
import io.jmix.ui.screen.StandardEditor;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.KpiGoalService;
import kz.eub.kpi.entity.Unit;
import kz.eub.kpi.entity.kpi.EKpiGoalAssessmentType;
import kz.eub.kpi.entity.kpi.EKpiGoalCategory;
import kz.eub.kpi.entity.kpi.KpiGoalDict;
import kz.eub.kpi.entity.kpi.KpiGoalSubCategory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@UiController("kpi_KpiGoalDict.edit")
@UiDescriptor("kpi-goal-dict-edit.xml")
@EditedEntityContainer("kpiGoalDictDc")
public class KpiGoalDictEdit extends StandardEditor<KpiGoalDict> {

    @Autowired
    private CollectionContainer<KpiGoalSubCategory> kpiGoalSubCategoriesDc;
    @Autowired
    private KpiGoalService kpiGoalService;
    @Autowired
    private EntityComboBox<KpiGoalSubCategory> subCategoryField;
    @Autowired
    private TextArea<String> goalDescriptionField;
    @Autowired
    private EntityComboBox<Unit> unitField;
    @Autowired
    private TextArea<String> dataSourceField;
    @Autowired
    private ComboBox<EKpiGoalAssessmentType> assessmentMethodField;
    @Autowired
    private TextField<String> nameField;

    @Subscribe("categoryField")
    public void onCategoryFieldValueChange(HasValue.ValueChangeEvent<EKpiGoalCategory> event) {
        loadGoalSubCategories(event.getValue());
        toggleFieldsByCategory();
    }

    private void toggleFieldsByCategory() {
        EKpiGoalCategory category = getEditedEntity().getCategory();
        switch (category) {
            case FINANCIAL_GOAL :
                toggleFieldsForFinCategory();
                break;
            default:
                toggleFieldsToDefault();
        }
    }

    private void toggleFieldsForFinCategory() {
        subCategoryField.setRequired(true);
        goalDescriptionField.setRequired(true);
        unitField.setRequired(true);
        dataSourceField.setRequired(true);
        assessmentMethodField.setRequired(true);
    }

    private void toggleFieldsToDefault() {
        subCategoryField.setRequired(false);
        goalDescriptionField.setRequired(false);
        unitField.setRequired(false);
        dataSourceField.setRequired(false);
        assessmentMethodField.setRequired(false);
    }

    private void loadGoalSubCategories(EKpiGoalCategory category) {
        kpiGoalSubCategoriesDc.getMutableItems().clear();
        List<KpiGoalSubCategory> subCategories = kpiGoalService.loadGoalSubCategories(category);
        kpiGoalSubCategoriesDc.getMutableItems().addAll(subCategories);
    }

}