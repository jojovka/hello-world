package kz.eub.kpi.screen.bonusbonusdescription;

import io.jmix.ui.component.Table;
import io.jmix.ui.component.data.table.ContainerTableItems;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("kpi_BonusBonusDescription")
@UiDescriptor("bonus_Bonus_Description.xml")
public class BonusBonusDescription extends Screen {

    @Subscribe
    private void onInit(InitEvent event) {

    }
}