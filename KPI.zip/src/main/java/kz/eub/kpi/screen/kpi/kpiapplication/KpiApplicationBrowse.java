package kz.eub.kpi.screen.kpi.kpiapplication;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.KpiApplication;

@UiController("kpi_KpiApplication.browse")
@UiDescriptor("kpi-application-browse.xml")
@LookupComponent("kpiApplicationsTable")
public class KpiApplicationBrowse extends StandardLookup<KpiApplication> {
}