package kz.eub.kpi.screen.unit;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.Unit;

@UiController("kpi_Unit.edit")
@UiDescriptor("unit-edit.xml")
@EditedEntityContainer("unitDc")
public class UnitEdit extends StandardEditor<Unit> {
}