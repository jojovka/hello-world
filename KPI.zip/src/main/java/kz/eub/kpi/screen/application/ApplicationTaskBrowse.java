package kz.eub.kpi.screen.application;

import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import io.jmix.ui.Screens;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.TextField;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.*;
import kz.eub.kpi.app.service.BpmUserTaskService;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.entity.Application;
import kz.eub.kpi.screen.main.MainScreen;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

@UiController("kpi_ApplicationTask.browse")
@UiDescriptor("application-task-browse.xml")
@LookupComponent("activeTasksTable")
public class ApplicationTaskBrowse extends StandardLookup<Application> {

    @Autowired
    private CollectionContainer<Application> activeTasksApplicationsDc;
    @Autowired
    private CollectionContainer<Application> historicTasksApplicationsDc;

    @Autowired
    private BpmUserTaskService bpmUserTaskService;
    @Autowired
    private CurrentUserSubstitution currentUserSubstitution;

    List<Application> appList;
    @Autowired
    private TextField snFld;
    @Autowired
    private TextField fioFld;
    @Autowired
    private Screens screens;
    @Autowired
    private EmployeeService employeeService;

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        loadApplicationTasks();
        loadApplicationHistoricTasks();
        ((MainScreen)screens.getOpenedScreens().getRootScreen()).updateMyTasksBadge();
    }

    private void loadApplicationTasks() {
        activeTasksApplicationsDc.getMutableItems().clear();
        appList = bpmUserTaskService.getUserTaskApplications(currentUserSubstitution.getEffectiveUser().getUsername());
        activeTasksApplicationsDc.getMutableItems().addAll(appList);
    }

    @Subscribe("snFld")
    public void onSnFldValueChange(HasValue.ValueChangeEvent event) {
        if (event.getValue() == null) {
            if (fioFld.getValue() == null)
                activeTasksApplicationsDc.getMutableItems().addAll(appList);
            else filterByFio(fioFld.getRawValue(), appList);
            return;
        }
        String sn = (String) event.getValue();
        filterBySn(sn, activeTasksApplicationsDc.getMutableItems());
    }

    private void filterBySn(String sn, List<Application> appL) {
        if (sn == null) {
            activeTasksApplicationsDc.getMutableItems().clear();
            activeTasksApplicationsDc.getMutableItems().addAll(appL);
            return;
        }
        List<Application> applicationList = appL.stream()
                .filter(app -> app.getSn().contains(sn))
                .collect(Collectors.toList());
        activeTasksApplicationsDc.getMutableItems().clear();
        activeTasksApplicationsDc.getMutableItems().addAll(applicationList);
    }

    @Subscribe("fioFld")
    public void onFioFldValueChange(HasValue.ValueChangeEvent event) {
        if (event.getValue() == null) {
            if (snFld.getValue() == null)
                activeTasksApplicationsDc.getMutableItems().addAll(appList);
            else filterBySn(snFld.getRawValue(), appList);
            return;
        }
        String fio = (String) event.getValue();
        filterByFio(fio, activeTasksApplicationsDc.getMutableItems());
    }

    private void filterByFio(String fio, List<Application> appL) {
        if (fio == null) {
            activeTasksApplicationsDc.getMutableItems().clear();
            activeTasksApplicationsDc.getMutableItems().addAll(appL);
            return;
        }
        List<Application> applicationList = appL.stream()
                .filter(app -> app.getAuthor().getFullName().toLowerCase(Locale.ROOT).contains(fio.toLowerCase()))
                .collect(Collectors.toList());
        activeTasksApplicationsDc.getMutableItems().clear();
        activeTasksApplicationsDc.getMutableItems().addAll(applicationList);
    }

    private void loadApplicationHistoricTasks() {
        historicTasksApplicationsDc.getMutableItems().clear();
        appList = bpmUserTaskService.getUserApplicationHistoricTasks(currentUserSubstitution.getEffectiveUser().getUsername());
        historicTasksApplicationsDc.getMutableItems().addAll(appList);
    }
}