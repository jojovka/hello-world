package kz.eub.kpi.screen.employee;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.Employee;

@UiController("kpi_Employee.browse")
@UiDescriptor("employee-browse.xml")
@LookupComponent("employeesTable")
public class EmployeeBrowse extends StandardLookup<Employee> {
}