package kz.eub.kpi.screen.announce;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.Announce;

@UiController("kpi_Announce.browse")
@UiDescriptor("announce-browse.xml")
@LookupComponent("announcesTable")
public class AnnounceBrowse extends StandardLookup<Announce> {
}