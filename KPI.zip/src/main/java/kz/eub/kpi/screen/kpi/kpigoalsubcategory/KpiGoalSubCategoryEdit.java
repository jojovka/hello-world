package kz.eub.kpi.screen.kpi.kpigoalsubcategory;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.KpiGoalSubCategory;

@UiController("kpi_KpiGoalSubCategory.edit")
@UiDescriptor("kpi-goal-sub-category-edit.xml")
@EditedEntityContainer("kpiGoalSubCategoryDc")
public class KpiGoalSubCategoryEdit extends StandardEditor<KpiGoalSubCategory> {
}