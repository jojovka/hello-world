package kz.eub.kpi.screen.kpi.kpigoalplanimportdoc;

import io.jmix.reportsui.runner.ParametersDialogShowMode;
import io.jmix.reportsui.runner.UiReportRunner;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.Table;
import io.jmix.ui.screen.Install;
import io.jmix.ui.screen.LookupComponent;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.entity.EApplicationStatus;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.kpi.KpiGoalPlanImportDoc;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Objects;

@UiController("kpi_KpiGoalPlanImportDoc.browse")
@UiDescriptor("kpi-goal-plan-import-doc-browse.xml")
@LookupComponent("kpiGoalPlanImportDocsTable")
public class KpiGoalPlanImportDocBrowse extends StandardLookup<KpiGoalPlanImportDoc> {

    @Autowired
    private GroupTable<KpiGoalPlanImportDoc> kpiGoalPlanImportDocsTable;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private UiReportRunner uiReportRunner;

    @Install(to = "kpiGoalPlanImportDocsTable.remove", subject = "enabledRule")
    private boolean kpiGoalPlanImportDocsTableRemoveEnabledRule() {
        KpiGoalPlanImportDoc doc = kpiGoalPlanImportDocsTable.getSingleSelected();
        Employee currentEmployee = employeeService.getCurrentEmployee();
        return doc != null
                && doc.getAuthor() != null
                && Objects.equals(doc.getAuthor().getId(), currentEmployee.getId())
                && Objects.equals(doc.getStatus(), EApplicationStatus.NEW);
    }

    @Subscribe("kpiGoalPlanImportDocsTable")
    public void onKpiGoalPlanImportDocsTableSelection(Table.SelectionEvent<KpiGoalPlanImportDoc> event) {
        Objects.requireNonNull(kpiGoalPlanImportDocsTable.getAction("remove"))
                .setEnabled(kpiGoalPlanImportDocsTableRemoveEnabledRule());
    }

    @Subscribe("finGoalsPivotBtn")
    public void onFinGoalsPivotBtnClick(Button.ClickEvent event) {
        uiReportRunner.byReportCode("fin-goals-pivot")
                .withParametersDialogShowMode(ParametersDialogShowMode.NO)
                .runAndShow();
    }
}