package kz.eub.kpi.screen.kpi.kpicard;

import io.jmix.appsettings.AppSettings;
import io.jmix.core.DataManager;
import io.jmix.core.EntityAccessException;
import io.jmix.core.MetadataTools;
import io.jmix.reports.entity.ReportOutputType;
import io.jmix.reportsui.runner.ParametersDialogShowMode;
import io.jmix.reportsui.runner.UiReportRunner;
import io.jmix.ui.Dialogs;
import io.jmix.ui.Notifications;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.Action;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.action.DialogAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.Table;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.navigation.Route;
import io.jmix.ui.navigation.UrlIdSerializer;
import io.jmix.ui.navigation.UrlParamsChangedEvent;
import io.jmix.ui.screen.Install;
import io.jmix.ui.screen.PrimaryEditorScreen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.Target;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.EmployeeSecService;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.app.service.KpiCardService;
import kz.eub.kpi.app.service.KpiGoalService;
import kz.eub.kpi.app.service.KpiGoalSummaryService;
import kz.eub.kpi.entity.EApplicationStatus;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.kpi.EKpiCardStage;
import kz.eub.kpi.entity.kpi.EKpiGoalAssessmentType;
import kz.eub.kpi.entity.kpi.EKpiGoalCategory;
import kz.eub.kpi.entity.kpi.EKpiGoalStatus;
import kz.eub.kpi.entity.kpi.KpiCard;
import kz.eub.kpi.entity.kpi.KpiCardSettings;
import kz.eub.kpi.entity.kpi.KpiGoal;
import kz.eub.kpi.entity.kpi.KpiGoalAttachment;
import kz.eub.kpi.entity.kpi.KpiPeriod;
import kz.eub.kpi.screen.applicationbase.ApplicationBaseScreen;
import kz.eub.kpi.screen.kpi.kpigoal.KpiGoalEdit;
import kz.eub.kpi.security.HrModeratorRole;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

@UiController("kpi_KpiCard.view")
@UiDescriptor("kpi-card-view.xml")
@PrimaryEditorScreen(KpiCard.class)
@Route(value = KpiCard.ROUTE)
public class KpiCardView extends ApplicationBaseScreen<KpiCard> {

    @Autowired
    private UiReportRunner uiReportRunner;
    @Autowired
    private Dialogs dialogs;
    @Autowired
    private Button rejectBtn;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private MetadataTools metadataTools;
    @Autowired
    private Button cloneBtn;
    @Autowired
    private EmployeeSecService employeeSecService;
    @Autowired
    private Button editFactBtn;
    @Autowired
    private Button startSummaryBtn;
    @Autowired
    private Table<KpiGoal> kpiGoalsTable;
    @Autowired
    private KpiGoalService kpiGoalService;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private AppSettings appSettings;
    @Autowired
    private KpiGoalSummaryService kpiGoalSummaryService;
    @Autowired
    private Button restorePosAndDepBtn;
    @Autowired
    private Button updateCoordinatorsBtn;
    @Autowired
    private Button restoreLeaderBtn;
    @Autowired
    private Button restoreSupervisorBtn;
    @Autowired
    private Button sendBtn;
    public KpiCardView() {
        super(KpiCard.class);
    }

    @Autowired
    private InstanceContainer<KpiCard> applicationDc;
    @Autowired
    private KpiCardService kpiCardService;
    @Autowired
    private Notifications notifications;

    @Subscribe
    public void onInit(InitEvent event) {
        initKpiGoalTableItemClickAction();
    }

    private void initKpiGoalTableItemClickAction() {
        kpiGoalsTable.setItemClickAction(new BaseAction("itemClickAction")
                .withHandler(actionPerformedEvent -> openSelectedGoal()));
        kpiGoalsTable.setItemClickAction(new BaseAction("enterPressAction")
                .withHandler(actionPerformedEvent -> openSelectedGoal()));
    }

    private void openSelectedGoal() {
        KpiGoal goal = kpiGoalsTable.getSingleSelected();
        if (goal == null) return;
        KpiGoalEdit kpiGoalEditScreen = screenBuilders.editor(KpiGoal.class, this)
                .withScreenClass(KpiGoalEdit.class)
                .editEntity(goal)
                .build();
        kpiGoalEditScreen.setReadOnly(true);
        kpiGoalEditScreen.show();
    }

    @Override
    public void reloadApplication() {
        reloadKpiCard();
    }

    @Subscribe
    public void onAfterShow1(AfterShowEvent event) {
        toggleRejectBtn();
        toggleCloneBtn();
        toggleEditFactBtn();
        toggleSummaryBtn();
        toggleRestorePosAndDepBtn();
//        refreshApplicationEmployeeData();
        checkAndUpdateTotalKpi();
        calcGoalPerformances();
    }

    @Override
    protected void toggleStartBtn() {
        sendBtn.setVisible(startButtonEnableRule());        
    }

    private boolean startButtonEnableRule() {
        KpiCard application = getEditedEntity();
        if (Objects.equals(application.getStatus(), EApplicationStatus.NEW)) {
            return kpiCardService.checkEnableCreationDeadline()
                    || kpiCardService.isTransferDuringPeriod(application.getAuthor().getHireDate(), application.getPeriod());
        }
        Set<EApplicationStatus> statuses = new HashSet<>(
                Arrays.asList(EApplicationStatus.REVOKED));
        return statuses.contains(application.getStatus());
    }

    private void toggleRestorePosAndDepBtn() {
        updateCoordinatorsBtn.setVisible(false);
        restoreSupervisorBtn.setEnabled(false);
        restorePosAndDepBtn.setEnabled(false);
        restoreLeaderBtn.setEnabled(false);
        Employee currentEmployee = employeeService.getCurrentEmployee();
        KpiCard card = getEditedEntity();
        if (card.getStatus() != null
                && (Objects.equals(card.getStatus(), EApplicationStatus.AGREED)
                || Objects.equals(card.getStatus(), EApplicationStatus.NEW)
                || Objects.equals(card.getStatus(), EApplicationStatus.REVOKED)
                || Objects.equals(card.getStatus(), EApplicationStatus.ADJUSTMENT))
                && currentEmployee != null
                && Objects.equals(card.getAuthor().getId(), currentEmployee.getId())) {
            updateCoordinatorsBtn.setVisible(true);
            restorePosAndDepBtn.setEnabled(true);
            restoreSupervisorBtn.setEnabled(true);
            restoreLeaderBtn.setEnabled(true);
        }
    }

    private void checkAndUpdateTotalKpi() {
        KpiCard card = getEditedEntity();
        BigDecimal totalKpi = kpiCardService.calcAndGetTotalKpi(card);
        if (!Objects.equals(card.getTotalKpi(), totalKpi))
            updateTotalKpi();
    }

    private void updateCoordinators() {
        KpiCard card = getEditedEntity();
        if (Objects.equals(card.getStatus(), EApplicationStatus.NEW)
                || Objects.equals(card.getStatus(), EApplicationStatus.REVOKED)
                || Objects.equals(card.getStatus(), EApplicationStatus.AGREED)) {
            kpiCardService.updateApplicationEmployeeData(card);
            reloadKpiCard();
        }
    }

    @Subscribe
    protected void onUrlParamsChanged(UrlParamsChangedEvent event) {
        try {
            String id = event.getParams().get("id");
            UUID eventId = (UUID) UrlIdSerializer.deserializeId(UUID.class, id);
            KpiCard card = kpiCardService.reloadApplication(eventId);
            setEntityToEdit(card);
        } catch (EntityAccessException e) {
            notifications.create(Notifications.NotificationType.HUMANIZED)
                    .withCaption("Заявка была уже отозвана и удалена инициатором...")
                    .show();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при загрузке переданной заявки:", e);
        }
    }

    private void toggleSummaryBtn() {
        startSummaryBtn.setVisible(false);
        Employee currentEmployee = employeeService.getCurrentEmployee();
        KpiCard card = getEditedEntity();
        if (card.getStatus() != null
                && card.getStatus().equals(EApplicationStatus.AGREED)
                && currentEmployee != null
                && card.getAuthor().getId().equals(currentEmployee.getId())) {
            for (KpiGoal goal : card.getKpiGoals()) {
                if (goal.getFact() == null
                        && goal.getFactDate() == null) {
                    return;
                }
            }
            KpiPeriod nextPeriod = kpiGoalService.getNextPeriod(card.getPeriod());
            long daysFromNextPeriod = kpiGoalService.getDaysPassedFromQuarterStart(nextPeriod);
            KpiCardSettings cardSettings = appSettings.load(KpiCardSettings.class);
            if (daysFromNextPeriod <= cardSettings.getEnableSummaryDaysAfterNextQuarter()
                    && daysFromNextPeriod > -cardSettings.getEnableSummaryDaysBeforeNextQuarter())
                startSummaryBtn.setVisible(true);
        }
    }

    private void toggleEditFactBtn() {
        editFactBtn.setVisible(false);
        Employee currentEmployee = employeeService.getCurrentEmployee();
        KpiCard card = getEditedEntity();
        if (card.getStatus() != null
                && card.getStatus().equals(EApplicationStatus.AGREED)
                && currentEmployee != null
                && card.getAuthor().getId().equals(currentEmployee.getId())) {
            editFactBtn.setVisible(true);
        }
    }

    private void toggleCloneBtn() {
        KpiCard card = getEditedEntity();
        Employee currentEmployee = employeeService.getCurrentEmployee();
        if (card.getStatus() != null
                && card.getStatus().equals(EApplicationStatus.REJECTED)
                && card.getAuthor() != null && currentEmployee != null
                && card.getAuthor().getId().equals(currentEmployee.getId())) {
            cloneBtn.setVisible(true);
        }
    }

    private void toggleRejectBtn() {
        if (getEditedEntity().getStatus() != null
                && getEditedEntity().getStatus().equals(EApplicationStatus.AGREED)) {
            rejectBtn.setVisible(employeeSecService.currentUserHasRole(HrModeratorRole.CODE));
        }
    }

    private void reloadKpiCard() {
        getEditedEntityLoader().load();
    }

    @Override
    protected void startNewApplicationProcess() {
        try {
            commitChanges();
            KpiCard application = getEditedEntity();
            HashMap<String, Object> variables = new HashMap<>();
            variables.put("businessModer", null);
            if (application.getStage() == null
                    || Objects.equals(application.getStage(), EKpiCardStage.FIRST_STAGE)) {
                kpiCardService.startNewApplicationProcess(application, KpiCard.PROCESS_DEF_KEY_APPROVAL, variables);
            } else if (Objects.equals(application.getStage(), EKpiCardStage.SECOND_STAGE)) {
                kpiCardService.startNewApplicationProcess(application, KpiCard.PROCESS_DEF_KEY_ASSESSMENT, variables);
            }
            notifications.create(Notifications.NotificationType.TRAY)
                    .withCaption("Карта КПЭ отправлена на согласование...")
                    .show();
            closeWithDiscard();
        } catch (Exception e) {
            log.error("Ошибка при запуске согласования", e);
            notifications.create(Notifications.NotificationType.ERROR)
                    .withDescription(e.getMessage())
                    .show();
        }
    }

    @Subscribe("excelExportBtn")
    public void onExcelExportBtnClick(Button.ClickEvent event) {
        uiReportRunner.byReportCode(KpiCard.REP_ENTITY_REPORT_CODE)
                .withOutputType(ReportOutputType.XLSX)
//                .withTemplateCode(KpiCard.REP_ENTITY_DEFAULT_TEMPLATE_CODE)
                .withParametersDialogShowMode(ParametersDialogShowMode.NO)
                .addParam("entity", getEditedEntity())
                .runAndShow();
    }

    @Subscribe("rejectBtn")
    public void onRejectBtnClick(Button.ClickEvent event) {
        dialogs.createOptionDialog()
                .withCaption("Подтвердите действие")
                .withMessage("Вы уверены что хотите отказать данной заявке?")
                .withActions(
                        new DialogAction(DialogAction.Type.YES, Action.Status.PRIMARY)
                                .withHandler(e -> rejectApplication()),
                        new DialogAction(DialogAction.Type.NO)
                )
                .show();
    }

    @Subscribe("cloneBtn")
    public void onCloneBtnClick(Button.ClickEvent event) {
        KpiCard copy = metadataTools.copy(getEditedEntity());
        copy.setId(UUID.randomUUID());
        copy.setProcId(null);
        copy.setStatus(EApplicationStatus.NEW);
        copy = kpiCardService.updateApplicationCoordinators(copy);
        copy.setKpiGoals(new ArrayList<>());
        for (KpiGoal goal : getEditedEntity().getKpiGoals()) {
            KpiGoal goalCopy = metadataTools.copy(goal);
            goalCopy.setId(UUID.randomUUID());
            // goalCopy.setSn(kpiGoalService.getGoalNextSn());
            goalCopy.setGoalDict(goal.getGoalDict());
            goalCopy.setSubCategory(goal.getSubCategory());
            goalCopy.setKpiCard(copy);
            goalCopy.setStatus(null);
            copy.getKpiGoals().add(goalCopy);
            goalCopy.setReviewResults(new ArrayList<>());
            if (goal.getAttachments() == null) continue;
            goalCopy.setAttachments(new ArrayList<>());
            for (KpiGoalAttachment attachment : goal.getAttachments()) {
                KpiGoalAttachment attachmentCopy = metadataTools.copy(attachment);
                attachmentCopy.setId(UUID.randomUUID());
                attachmentCopy.setKpiGoal(goal);
                goalCopy.getAttachments().add(attachmentCopy);
            }
        }

        screenBuilders.editor(KpiCard.class, this)
                .editEntity(copy)
                .withScreenClass(KpiCardEdit.class)
                .build().show();
    }

    private void rejectApplication() {
        KpiCard card = getEditedEntity();
        for (KpiGoal kpiGoal : card.getKpiGoals()) {
            kpiGoal.setStatus(EKpiGoalStatus.REJECTED);
        }
        commitChanges();
        kpiCardService.updateStatus(card, EApplicationStatus.REJECTED);
        reloadKpiCard();
    }

    @Subscribe("kpiGoalsTable")
    public void onKpiGoalsTableSelection(Table.SelectionEvent<KpiGoal> event) {
        Objects.requireNonNull(kpiGoalsTable.getAction("edit")).setEnabled(false);
        KpiGoal goal = event.getSource().getSingleSelected();
        KpiCard card = getEditedEntity();
        if (card.getStatus().equals(EApplicationStatus.AGREED)
                && goal != null
                && !Objects.equals(goal.getCategory(), EKpiGoalCategory.FINANCIAL_GOAL)) {
            Objects.requireNonNull(kpiGoalsTable.getAction("edit")).setEnabled(true);
        }
    }

    @Subscribe("startSummaryBtn")
    public void onStartSummaryBtnClick(Button.ClickEvent event) {
        KpiCard card = getEditedEntity();
        card.setStage(EKpiCardStage.SECOND_STAGE);
        for (KpiGoal goal : card.getKpiGoals()) {
            goal.setStatus(null);
        }
        dataManager.save(card);
        reloadKpiCard();
        startNewApplicationProcess();
    }

    @Subscribe(id = "kpiGoalsDc", target = Target.DATA_CONTAINER)
    public void onKpiGoalsDcCollectionChange(CollectionContainer.CollectionChangeEvent<KpiGoal> event) {
        toggleSummaryBtn();
    }

    @Install(to = "kpiGoalsTable.edit", subject = "afterCloseHandler")
    private void kpiGoalsTableEditAfterCloseHandler(AfterCloseEvent afterCloseEvent) {
        toggleSummaryBtn();
    }

    @Install(to = "kpiGoalsTable.edit", subject = "afterCommitHandler")
    private void kpiGoalsTableEditAfterCommitHandler(KpiGoal kpiGoal) {
        updateTotalKpi();
    }

    private void updateTotalKpi() {
        commitChanges();
        kpiCardService.updateTotalKpi(getEditedEntity());
        reloadKpiCard();
    }

    private void calcGoalPerformances() {
        KpiCard card = getEditedEntity();
        boolean existsEqualsAssessmentType = false;
        for (KpiGoal goal : card.getKpiGoals()) {
            if (Objects.equals(goal.getAssessmentType(), EKpiGoalAssessmentType.EQUALS)
                    && goal.getPlan() != null && goal.getFact() != null
                    && goal.getPlan().compareTo(goal.getFact()) == 0
                    && goal.getProgress() != null
                    && goal.getProgress().compareTo(BigDecimal.ZERO) == 0) {
                existsEqualsAssessmentType = true;
                calcGoalPerformance(goal);
            }
        }
        if (existsEqualsAssessmentType)
            updateTotalKpi();
    }

    private void calcGoalPerformance(KpiGoal goal) {
        try {
            if ((goal.getPlan() == null && goal.getPlanDate() == null)
                    || (goal.getFact() == null && goal.getFactDate() == null))
                return;
            kpiGoalSummaryService.calcPerformanceAndEfficiency(goal);
        } catch (Exception e) {
            log.error("Error", e);
            notifications.create()
                    .withCaption(e.getMessage())
                    .withDescription("Произошла ошибка при попытке расчета КПЭ...")
                    .show();
        }
    }

    @Subscribe("calcBtn")
    public void onCalcBtnClick(Button.ClickEvent event) {
        KpiCard card = getEditedEntity();
        if (kpiCardService.calcGoalsPerformances(card)) {
            notifications.create()
                    .withCaption("Итоговые показатели целей пересчитаны...")
                    .show();
            getEditedEntityLoader().load();
        }
    }

    @Subscribe("restorePosAndDepBtn")
    public void onRestorePosAndDepBtnClick(Button.ClickEvent event) {
        boolean success = kpiCardService.doRestoreDepAndPosCards(getEditedEntity());
        if (success) getEditedEntityLoader().load();
    }

    @Subscribe("updateCoordinatorsBtn")
    public void onUpdateCoordinatorsBtnClick(Button.ClickEvent event) {
        updateCoordinators();
    }

    @Subscribe("restoreSupervisorBtn")
    public void onRestoreSupervisorBtnClick(Button.ClickEvent event) {
        boolean success = kpiCardService.doRestoreSupervisor(getEditedEntity());
        if (success) getEditedEntityLoader().load();
    }

    @Subscribe("restoreLeaderBtn")
    public void onRestoreLeaderBtnClick(Button.ClickEvent event) {
        boolean success = kpiCardService.doRestoreLeader(getEditedEntity());
        if (success) getEditedEntityLoader().load();
    }

}