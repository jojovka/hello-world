package kz.eub.kpi.screen.employee;

import io.jmix.core.DataManager;
import io.jmix.core.EntityStates;
import io.jmix.core.FileRef;
import io.jmix.core.MetadataTools;
import io.jmix.core.querycondition.PropertyCondition;
import io.jmix.ui.Notifications;
import io.jmix.ui.action.Action;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.GroupBoxLayout;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.Image;
import io.jmix.ui.component.MaskedField;
import io.jmix.ui.screen.EditedEntityContainer;
import io.jmix.ui.screen.StandardEditor;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.EmployeeSecService;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Objects;

@UiController("kpi_Employee.create")
@UiDescriptor("employee-create.xml")
@EditedEntityContainer("employeeDc")
public class EmployeeCreate extends StandardEditor<Employee> {

    public static final Logger log = LoggerFactory.getLogger(EmployeeCreate.class);

    @Autowired
    private Notifications notifications;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private Image<FileRef> photo;
    @Autowired
    private MaskedField<String> pnFld;
    @Autowired
    private MetadataTools metadataTools;
    @Autowired
    private EntityStates entityStates;
    @Autowired
    private EmployeeSecService employeeSecService;
    @Autowired
    private GroupBoxLayout searchBox;

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        togglePhoto();
        toggleSearchBox();
    }

    private void toggleSearchBox() {
        searchBox.setVisible(!isReadOnly());
    }

    private void togglePhoto() {
        Employee employee = getEditedEntity();
        photo.setVisible(employee.getPhoto() != null);
        photo.setHeightFull();
    }

    @Subscribe("photoField")
    public void onPhotoFieldValueChange(HasValue.ValueChangeEvent<FileRef> event) {
        togglePhoto();
    }

    private User user;

    @Subscribe("searchBtn")
    public void onSearchBtnClick(Button.ClickEvent event) {
        String pn = pnFld.getValue();
        if (pn == null || pn.isEmpty()) return;
        user = dataManager.load(User.class)
                .condition(PropertyCondition.equal("pn", pn))
                .optional().orElse(null);
        if (user == null) {
            notifications.create()
                    .withCaption(String.format("Пользователь с табельным номером %s не найден.", pn))
                    .show();
        } else if (user instanceof  Employee) {
            notifications.create()
                    .withCaption("Такой сотрудник уже существует")
                    .show();
        } else {
            updateEmployeeDetailsFromUser(user);
        }
    }

    private void updateEmployeeDetailsFromUser(User user) {
        Employee employee = getEditedEntity();
        metadataTools.copy(user, employee);
        entityStates.makeDetached(employee);
        employee.setVersion(user.getVersion());
        employee.setPayrollNumber(user.getPn());
    }

    @Subscribe("windowCommitAndClose")
    public void onWindowCommitAndClose(Action.ActionPerformedEvent event) {
        try {
            if (user != null
                    && Objects.equals(user.getPn(), getEditedEntity().getPayrollNumber())) {
                employeeSecService.createEmployeeFromUser(user);
            }
            commitChanges();
        } catch (Exception e) {
            log.error("error", e);
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Ошибка при попытке создать сотрудника")
                    .withDescription(e.getMessage())
                    .show();
        }
    }

}