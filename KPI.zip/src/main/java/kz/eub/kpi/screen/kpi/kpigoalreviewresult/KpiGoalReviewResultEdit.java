package kz.eub.kpi.screen.kpi.kpigoalreviewresult;

import io.jmix.core.TimeSource;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.TextArea;
import io.jmix.ui.screen.*;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.entity.kpi.KpiGoalReviewResult;
import kz.eub.kpi.entity.kpi.EKpiGoalStatus;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("kpi_KpiGoalReviewResult.edit")
@UiDescriptor("kpi-goal-review-result-edit.xml")
@EditedEntityContainer("kpiGoalReviewResultDc")
public class KpiGoalReviewResultEdit extends StandardEditor<KpiGoalReviewResult> {

    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private TimeSource timeSource;
    @Autowired
    private ComboBox<EKpiGoalStatus> statusField;
    @Autowired
    private TextArea<String> infoField;

    @Subscribe
    public void onInitEntity(InitEntityEvent<KpiGoalReviewResult> event) {
        event.getEntity().setReviewer(employeeService.getCurrentEmployee());
        event.getEntity().setDate(timeSource.currentTimestamp());
        event.getEntity().setTitle("Комментарий");
        setEditable();
    }

    public void setEditable() {
        setReadOnly(false);
        statusField.setEditable(true);
        infoField.setEditable(true);
    }

    @Subscribe("commitAndCloseBtn")
    public void onCommitAndCloseBtnClick(Button.ClickEvent event) {
        commitChanges();
    }

}