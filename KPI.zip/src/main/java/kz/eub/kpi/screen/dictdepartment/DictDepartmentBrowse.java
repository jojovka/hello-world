package kz.eub.kpi.screen.dictdepartment;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.DictDepartment;

@UiController("kpi_DictDepartment.browse")
@UiDescriptor("dict-department-browse.xml")
@LookupComponent("dictDepartmentsTable")
public class DictDepartmentBrowse extends StandardLookup<DictDepartment> {
}