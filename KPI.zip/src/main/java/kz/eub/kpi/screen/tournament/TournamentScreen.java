package kz.eub.kpi.screen.tournament;

import io.jmix.charts.component.SerialChart;
import io.jmix.core.Metadata;
import io.jmix.ui.data.DataItem;
import io.jmix.ui.data.impl.ListDataProvider;
import io.jmix.ui.data.impl.MapDataItem;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.PointUser;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

@UiController("bonus_TournamentScreen")
@UiDescriptor("tournament-screen.xml")
public class TournamentScreen extends Screen {
    @Autowired
    protected InstanceContainer<DictDepartment> customerDc;
    @Autowired
    protected Metadata metadata;

    @Subscribe
    protected void onInit(InitEvent event) {
        DictDepartment customer = metadata.create(DictDepartment.class);
        customerDc.setItem(customer);
    }
}