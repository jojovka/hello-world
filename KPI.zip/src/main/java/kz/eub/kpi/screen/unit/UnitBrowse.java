package kz.eub.kpi.screen.unit;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.Unit;

@UiController("kpi_Unit.browse")
@UiDescriptor("unit-browse.xml")
@LookupComponent("unitsTable")
public class UnitBrowse extends StandardLookup<Unit> {
}