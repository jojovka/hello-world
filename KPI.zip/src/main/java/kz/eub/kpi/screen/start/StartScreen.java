package kz.eub.kpi.screen.start;

import io.jmix.reportsui.screen.report.browse.ReportBrowser;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.component.LayoutClickNotifier;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.screen.kpi.kpigoal.KpiGoalBrowse;
import kz.eub.kpi.screen.profile.ProfileScreen;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("kpi_StartScreen")
@UiDescriptor("start-screen.xml")
public class StartScreen extends Screen {
    @Autowired
    private ScreenBuilders screenBuilders;

    @Subscribe("profileBox")
    public void onProfileBoxLayoutClick(LayoutClickNotifier.LayoutClickEvent event) {
        screenBuilders.screen(this)
                .withScreenClass(ProfileScreen.class)
                .build()
                .show();
    }

    @Subscribe("kpiBox")
    public void onKpiBoxLayoutClick(LayoutClickNotifier.LayoutClickEvent event) {
        screenBuilders.screen(this)
                .withScreenClass(KpiGoalBrowse.class)
                .build()
                .show();
    }

    @Subscribe("reportsBox")
    public void onReportsBoxLayoutClick(LayoutClickNotifier.LayoutClickEvent event) {
        screenBuilders.screen(this)
                .withScreenClass(ReportBrowser.class)
                .build()
                .show();
    }

}