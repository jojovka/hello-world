package kz.eub.kpi.screen.application;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.Application;

@UiController("kpi_Application.browse")
@UiDescriptor("application-browse.xml")
@LookupComponent("applicationsTable")
public class ApplicationBrowse extends StandardLookup<Application> {
}