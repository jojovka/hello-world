package kz.eub.kpi.screen.kpi.kpigoalplanimportdoc;

import io.jmix.core.AccessManager;
import io.jmix.core.EntityStates;
import io.jmix.core.accesscontext.SpecificOperationAccessContext;
import io.jmix.emailtemplates.EmailTemplates;
import io.jmix.emailtemplates.exception.TemplateNotFoundException;
import io.jmix.reports.entity.ReportOutputType;
import io.jmix.reportsui.runner.ParametersDialogShowMode;
import io.jmix.reportsui.runner.UiReportRunner;
import io.jmix.ui.Dialogs;
import io.jmix.ui.Notifications;
import io.jmix.ui.action.Action;
import io.jmix.ui.action.DialogAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.FileUploadField;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.model.CollectionPropertyContainer;
import io.jmix.ui.navigation.Route;
import io.jmix.ui.navigation.UrlRouting;
import io.jmix.ui.screen.EditedEntityContainer;
import io.jmix.ui.screen.Install;
import io.jmix.ui.screen.StandardEditor;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.EmployeeSecService;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.app.service.FinGoalService;
import kz.eub.kpi.app.service.KpiCardService;
import kz.eub.kpi.app.service.KpiGoalPlanImportService;
import kz.eub.kpi.app.service.KpiGoalService;
import kz.eub.kpi.entity.EApplicationStatus;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.kpi.EKpiGoalCategory;
import kz.eub.kpi.entity.kpi.KpiGoalDictPlan;
import kz.eub.kpi.entity.kpi.KpiGoalPlanImportDoc;
import kz.eub.kpi.entity.kpi.KpiPeriod;
import kz.eub.kpi.security.specific.FdFactImport;
import org.eclipse.persistence.exceptions.DatabaseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.List;
import java.util.Objects;

@UiController("kpi_KpiGoalPlanImportDoc.edit")
@UiDescriptor("kpi-goal-plan-import-doc-edit.xml")
@EditedEntityContainer("kpiGoalPlanImportDocDc")
@Route(value = KpiGoalPlanImportDoc.ROUTE)
public class KpiGoalPlanImportDocEdit extends StandardEditor<KpiGoalPlanImportDoc> {

    public static final Logger log = LoggerFactory.getLogger(KpiGoalPlanImportDocEdit.class);

    @Autowired
    private KpiGoalService kpiGoalService;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private KpiCardService kpiCardService;
    @Autowired
    private FileUploadField uploadField;
    @Autowired
    private Button approveBtn;
    @Autowired
    private CollectionPropertyContainer<KpiGoalDictPlan> goalDictPlansDc;
    @Autowired
    private AccessManager accessManager;
    @Autowired
    private UiReportRunner uiReportRunner;
    @Autowired
    private KpiGoalPlanImportService kpiGoalPlanImportService;
    @Autowired
    private Notifications notifications;
    @Autowired
    private Dialogs dialogs;
    @Autowired
    private EmailTemplates emailTemplates;
    @Autowired
    private EmployeeSecService employeeSecService;
    @Autowired
    private EntityStates entityStates;
    @Autowired
    private UrlRouting urlRouting;
    @Autowired
    private FinGoalService finGoalService;

    @Subscribe
    public void onInitEntity(InitEntityEvent<KpiGoalPlanImportDoc> event) {
        KpiGoalPlanImportDoc doc = event.getEntity();
        KpiPeriod period = kpiGoalService.getCurrentKpiPeriod();
        long days = kpiGoalService.getDaysToNextQuarter(period);
        if (days < 45) {
            period = kpiGoalService.getNextPeriod(period);
        }
        doc.setDate(new Date());
        doc.setPeriod(period);
        doc.setCategory(EKpiGoalCategory.FINANCIAL_GOAL);
        doc.setStatus(EApplicationStatus.NEW);
        Employee employee = employeeService.getCurrentEmployee();
        doc.setAuthor(employee);
        if (employee != null) {
            doc.setDepartment(employee.getDepartment());
            doc.setPosition(employee.getPosition());
            doc.setLeader(employee.getLeader());
            doc.setSupervisor(employee.getSupervisor());
        }
        doc.setSn(kpiCardService.getApplicationSN());
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        toggleApproveBtn();
        toggleUploadBtn();
        toggleEditMode();
    }

    private void toggleEditMode() {
        KpiGoalPlanImportDoc doc = getEditedEntity();
        if (Objects.equals(doc.getStatus(), EApplicationStatus.APPROVED)
                && doc.getPeriod() != null && doc.getCreatedBy() != null) {
            setReadOnly(true);
        }
    }

    private void toggleUploadBtn() {
        uploadField.setVisible(!isImportPermitted());
        uploadField.setEnabled(false);
        if (Objects.equals(getEditedEntity().getStatus(), EApplicationStatus.NEW)
                && getEditedEntity().getPeriod() != null) {
            uploadField.setEnabled(true);
        }
    }

    private void toggleApproveBtn() {
        boolean permitted = isImportPermitted();
        approveBtn.setVisible(permitted);
        if (!permitted) return;
        approveBtn.setEnabled(false);
        if (Objects.equals(getEditedEntity().getStatus(), EApplicationStatus.NEW)
                && getEditedEntity().getPeriod() != null
                && goalDictPlansDc.getMutableItems().size() > 0) {
            approveBtn.setEnabled(true);
        }
    }

    private boolean isImportPermitted() {
        SpecificOperationAccessContext accessContext =
                new SpecificOperationAccessContext(FdFactImport.NAME);
        accessManager.applyRegisteredConstraints(accessContext);
        return accessContext.isPermitted();
    }

    @Subscribe("goalDictPlansTable.downloadTemplate")
    public void onGoalDictPlansTableDownloadTemplate(Action.ActionPerformedEvent event) {
        uiReportRunner.byReportCode("kpi-goal-plan-import-template")
                .withOutputType(ReportOutputType.XLSX)
                .withTemplateCode("DEFAULT")
                .withParametersDialogShowMode(ParametersDialogShowMode.NO)
                .addParam("category", getEditedEntity().getCategory())
                .runAndShow();
    }

    @Subscribe("uploadField")
    public void onUploadFieldValueChange(HasValue.ValueChangeEvent<byte[]> event) {
        byte[] file = event.getValue();
        goalDictPlansDc.getMutableItems().clear();
        try {
            List<KpiGoalDictPlan> goalFacts = kpiGoalPlanImportService.importGoalPans(file, getEditedEntity());
            goalDictPlansDc.getMutableItems().addAll(goalFacts);
        } catch (Exception e) {
            log.error("Ошибка при импорте...", e);
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Ошибка при импорте...")
                    .withDescription(e.getMessage())
                    .show();
        } finally {
            if (goalDictPlansDc.getMutableItems().size() > 0)
                approveBtn.setEnabled(true);
        }
    }

    @Subscribe("approveBtn")
    public void onApproveBtnClick(Button.ClickEvent event) {
        dialogs.createOptionDialog().withWidth("721")
                .withCaption("Вы подтверждаете импорт текущих фактических показателей?")
                .withMessage("Данное действие не имеет возможности возврата...")
                .withActions(
                        new DialogAction(DialogAction.Type.OK)
                                .withHandler(e ->
                                        approveGoalPlans()
                                ),
                        new DialogAction(DialogAction.Type.CANCEL))
                .show();
    }

    private void approveGoalPlans() {
        List<KpiGoalDictPlan> planList = goalDictPlansDc.getMutableItems();
        for (KpiGoalDictPlan plan : planList) {
            plan.setStatus(EApplicationStatus.APPROVED);
        }
        getEditedEntity().setStatus(EApplicationStatus.APPROVED);
        commitChanges();
        notifications.create()
                .withCaption("Импорт выполнен.")
                .withDescription("Успешно согласованы плановые показатели " +
                        goalDictPlansDc.getMutableItems().size() + " целей.")
                .show();
        toggleApproveBtn();
        toggleUploadBtn();
    }

    @Install(to = "goalDictPlansTable.downloadTemplate", subject = "enabledRule")
    private boolean goalDictPlansTableDownloadTemplateEnabledRule() {
        return !isImportPermitted();
    }

    @Subscribe("commitAndCloseBtn")
    public void onCommitAndCloseBtnClick(Button.ClickEvent event) {
        try {
            closeWithCommit();
        } catch (Exception e) {
            String description = e.getMessage();
            if (e.getCause().getClass().equals(DatabaseException.class))
                description = "Ошибка дублирования... Такая цель за указанный период уже существует.";
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Ошибка при сохранении")
                    .withDescription(description)
                    .show();
            log.error("Error while trying to save: ", e);
        }
    }

    @Subscribe
    public void onAfterCommitChanges(AfterCommitChangesEvent event) {
        sendApproversNotification(getEditedEntity());
    }

    private void sendApproversNotification(KpiGoalPlanImportDoc doc) {
        try {
            String link = urlRouting.getRouteGenerator().getEditorRoute(doc);
            finGoalService.sendApproversNotification(doc, link);
        } catch (TemplateNotFoundException e) {
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Ошибка при попытке отправить уведомление")
                    .withDescription(e.getMessage())
                    .show();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при попытке отправить уведомление", e);
        }
    }
}