package kz.eub.kpi.screen.bonusdescriptionopzp;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("kpi_BonusDescriptionOpzp")
@UiDescriptor("bonus-description-OPZP.xml")
public class BonusDescriptionOpzp extends Screen {
}