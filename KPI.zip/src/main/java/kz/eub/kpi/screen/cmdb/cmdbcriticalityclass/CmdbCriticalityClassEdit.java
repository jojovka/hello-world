package kz.eub.kpi.screen.cmdb.cmdbcriticalityclass;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.cmdb.CmdbCriticalityClass;

@UiController("kpi_CmdbCriticalityClass.edit")
@UiDescriptor("cmdb-criticality-class-edit.xml")
@EditedEntityContainer("cmdbCriticalityClassDc")
public class CmdbCriticalityClassEdit extends StandardEditor<CmdbCriticalityClass> {
}