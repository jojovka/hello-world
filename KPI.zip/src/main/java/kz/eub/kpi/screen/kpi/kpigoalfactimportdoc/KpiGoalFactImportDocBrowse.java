package kz.eub.kpi.screen.kpi.kpigoalfactimportdoc;

import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.Table;
import io.jmix.ui.screen.Install;
import io.jmix.ui.screen.LookupComponent;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.entity.EApplicationStatus;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.kpi.KpiGoalFactImportDoc;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Objects;

@UiController("kpi_KpiGoalFactImport.browse")
@UiDescriptor("kpi-goal-fact-import-doc-browse.xml")
@LookupComponent("kpiGoalFactImportDocsTable")
public class KpiGoalFactImportDocBrowse extends StandardLookup<KpiGoalFactImportDoc> {

    @Autowired
    private GroupTable<KpiGoalFactImportDoc> kpiGoalFactImportDocsTable;
    @Autowired
    private EmployeeService employeeService;

    @Install(to = "kpiGoalFactImportDocsTable.remove", subject = "enabledRule")
    private boolean kpiGoalFactImportDocsTableRemoveEnabledRule() {
        KpiGoalFactImportDoc doc = kpiGoalFactImportDocsTable.getSingleSelected();
        Employee currentEmployee = employeeService.getCurrentEmployee();
        return doc != null
                && doc.getAuthor() != null
                && Objects.equals(doc.getAuthor().getId(), currentEmployee.getId())
                && Objects.equals(doc.getStatus(), EApplicationStatus.NEW);
    }

    @Subscribe("kpiGoalFactImportDocsTable")
    public void onKpiGoalFactImportDocsTableSelection(Table.SelectionEvent<KpiGoalFactImportDoc> event) {
        Objects.requireNonNull(kpiGoalFactImportDocsTable.getAction("remove"))
                .setEnabled(kpiGoalFactImportDocsTableRemoveEnabledRule());
    }

}