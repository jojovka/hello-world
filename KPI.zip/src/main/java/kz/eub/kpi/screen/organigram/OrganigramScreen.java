package kz.eub.kpi.screen.organigram;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import freemarker.cache.FileTemplateLoader;
import freemarker.cache.MultiTemplateLoader;
import freemarker.cache.TemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;
import io.jmix.core.DataManager;
import io.jmix.core.MetadataTools;
import io.jmix.ui.UiComponents;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.BrowserFrame;
import io.jmix.ui.component.HBoxLayout;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.SuggestionField;
import io.jmix.ui.component.Tree;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.app.service.OrgChartService;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.overtime.OrgChart;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.File;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Used js libraries from:
 * https://www.npmjs.com/package/d3-org-chart
 */
@UiController("kpi_OrganigramScreen")
@UiDescriptor("organigram-screen.xml")
public class OrganigramScreen extends Screen {

    @Autowired
    private DataManager dataManager;
    @Autowired
    private Tree<DictDepartment> departmentTree;
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private HBoxLayout frameContainer;
    @Autowired
    private OrgChartService orgChartService;
    @Autowired
    private MetadataTools metadataTools;
    @Autowired
    private SuggestionField<DictDepartment> departmentSuggestionField;
    @Autowired
    private CollectionContainer<DictDepartment> departmentDc;
    @Autowired
    private SuggestionField<Employee> employeeSuggestionField;
    @Autowired
    private EmployeeService employeeService;

    @Subscribe
    public void onInit(InitEvent event) {
        setDepartmentSearchExecutor();
        setEmployeeSearchExecutor();
        setDepartmentTreeActions();
    }

    private void setDepartmentTreeActions() {
        departmentTree.setItemClickAction(new BaseAction("itemClickAction")
                .withHandler(actionPerformedEvent -> {
                    drawOrgChartDiagram(null, null, false);
                }));
        departmentTree.setEnterPressAction(new BaseAction("enterPressAction")
                .withHandler(actionPerformedEvent -> {
                    drawOrgChartDiagram(null, null, false);
                }));
    }

    private void setEmployeeSearchExecutor() {
        employeeSuggestionField.setSearchExecutor((searchString, searchParams) ->
                employeeService.searchEmployee(searchString));
    }

    private void setDepartmentSearchExecutor() {
        List<DictDepartment> departments = departmentDc.getMutableItems();
        departmentSuggestionField.setSearchExecutor((searchString, searchParams) ->
                departments
                        .stream()
                        .filter(department ->
                                StringUtils.containsIgnoreCase(metadataTools.getInstanceName(department), searchString))
                        .collect(Collectors.toList()));
    }

    @Subscribe("employeeSuggestionField")
    public void onEmployeeSuggestionFieldValueChange(HasValue.ValueChangeEvent<Employee> event) {
        DictDepartment parentDepartment = orgChartService.searchByFio(event.getValue());
        drawOrgChartDiagram(parentDepartment, event.getValue(), true);
    }

    @Subscribe("departmentSuggestionField")
    public void onStringSuggestionFieldValueChange(HasValue.ValueChangeEvent<DictDepartment> event) {
        DictDepartment department = event.getValue();
        assert department != null;
        departmentTree.collapseTree();
        departmentTree.expand(department);
        departmentTree.setSelected(department);
        drawOrgChartDiagram(null, null, false);

    }

    private void drawOrgChartDiagram(DictDepartment department, Employee employee, boolean isFilter) {
        DictDepartment selectedDepartment = departmentTree.getSingleSelected();
        if (department != null) {
            selectedDepartment = department;
        }
        if (selectedDepartment != null) {
            List<Employee> employeeList = orgChartService.getOrgChartEmployeeList(selectedDepartment);
            String htmlDoc;
            if (isFilter) {
                htmlDoc = generateHtmlDoc(employeeList, employee, true);
            } else {
                htmlDoc = generateHtmlDoc(employeeList, null, false);
            }
            refreshChartFrameContainer(htmlDoc);
        }
    }

    private void refreshChartFrameContainer(String htmlDoc) {
        frameContainer.removeAll();
        frameContainer.setHeightFull();
        BrowserFrame browserFrame = uiComponents.create(BrowserFrame.class);
        browserFrame.setSrcdoc(htmlDoc);
        browserFrame.setId("orgFrame");
        browserFrame.setHeightFull();
        browserFrame.setWidthFull();
        browserFrame.setHtmlSanitizerEnabled(false);
        browserFrame.setReferrerPolicy(BrowserFrame.ReferrerPolicy.NO_REFERRER);
        frameContainer.add(browserFrame);
        frameContainer.expand(browserFrame);
    }

    private String generateHtmlDoc(List<Employee> employeeList, Employee employee, boolean isFilter) {
        try {
            Configuration cfg = new Configuration(Configuration.VERSION_2_3_29);
            FileTemplateLoader repFolder = new FileTemplateLoader(new File("./rep/ftl"));
            MultiTemplateLoader mtl = new MultiTemplateLoader(new TemplateLoader[]{repFolder});
            cfg.setTemplateLoader(mtl);

            cfg.setDefaultEncoding("UTF-8");
            cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
            cfg.setWrapUncheckedExceptions(true);
            cfg.setFallbackOnNullLoopVariable(false);

            Template temp = cfg.getTemplate("orgChart.ftlh");

            Map<String, Object> input = new HashMap<>();
            if (isFilter) {
                input.put("employeeExpandId", employee.getId());
            } else {
                input.put("employeeExpandId", "");
            }
            input.put("orgJson", getPrettyJson(employeeList, employee, isFilter));
            StringWriter out = new StringWriter();
            temp.process(input, out);

            return out.toString();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при генерации HTML документа: ", e);
        }
    }

    private String getPrettyJson(List<Employee> employeeList, Employee employee, boolean isFilter) throws JsonProcessingException {
        List<String> orgCharts = new ArrayList<>();
        ObjectMapper om = new ObjectMapper();
        boolean isSelectedColorChange;
        for (Employee el : employeeList) {
            isSelectedColorChange = false;
            if (isFilter) {
                if (el.getId().equals(employee.getId())) {
                    isSelectedColorChange = true;
                }
            }
            orgCharts.add(om.writeValueAsString(getOrgChartFromEmployee(el, isSelectedColorChange, isFilter)));
        }
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        JsonElement jsonElement = JsonParser.parseString(orgCharts.toString());
        return gson.toJson(jsonElement);
    }

    public OrgChart getOrgChartFromEmployee(Employee employee, boolean isSelectedColorChange, boolean isEmployeeFilter) {
        OrgChart orgChart = dataManager.create(OrgChart.class);
        orgChart.setName(employee.getFullName());
        orgChart.setImageUrl(orgChartService.getImageUrl(employee));
        orgChart.setArea("");

        if (orgChartService.isDepartment(employee)) {
            orgChart.setProfileUrl("#");
            orgChart.setDepartment("");
        } else {
            orgChart.setProfileUrl("#main/employee?id=" + employee.getId());
            orgChart.setDepartment(employee.getDepartment().getName());
        }

        orgChart.setTags("");
        orgChart.setIsLoggedUser(String.valueOf(false));
        orgChart.setPositionName(employee.getPosition() != null
                ? employee.getPosition().getName()
                : "");
        orgChart.setId(employee.getId().toString());
        orgChart.setParentId(employee.getSupervisor() != null
                ? employee.getSupervisor().getId().toString()
                : "");
        orgChart.setSize("");

        orgChart.setEmail(employee.getEmail());
        orgChart.setMobile(employee.getMobile());
        orgChart.setPhone(employee.getPhone());
        orgChart.setColor("#f7f7fc");
        orgChart.setCircleColor("#adf");
        if (isSelectedColorChange) {
            orgChart.setColor("#f7d4e4");
            orgChart.setCircleColor("#f477b2");
        }

        orgChart.setPayrollNumber(employee.getPayrollNumber() != null ? employee.getPayrollNumber() : "");
        SimpleDateFormat sm = new SimpleDateFormat("dd.MM.yyyy");
        if (employee.getStartDate() != null) {
            orgChart.setStartDate(sm.format(employee.getStartDate()));
        }
        if (employee.getBirthDate() != null) {
            orgChart.setBirthDate(sm.format(employee.getBirthDate()));
        }
        return orgChart;
    }

}