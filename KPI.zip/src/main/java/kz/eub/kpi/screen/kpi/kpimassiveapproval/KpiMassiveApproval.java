package kz.eub.kpi.screen.kpi.kpimassiveapproval;

import io.jmix.bpm.entity.TaskData;
import io.jmix.bpm.service.BpmTaskService;
import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import io.jmix.ui.Notifications;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.DataGrid;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.BpmUserTaskService;
import kz.eub.kpi.entity.Application;
import kz.eub.kpi.entity.ApplicationTask;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@UiController("kpi_KpiMassiveApproval")
@UiDescriptor("kpi-massive-approval.xml")
public class KpiMassiveApproval extends Screen {

    public static final String TASK_ID_KEY_MASS_APPROVAL = "massapproval";

    @Autowired
    private BpmUserTaskService bpmUserTaskService;
    @Autowired
    private BpmTaskService bpmTaskService;


    private String currentUserName;
    @Autowired
    private CurrentUserSubstitution currentUserSubstitution;
    @Autowired
    private CollectionContainer<ApplicationTask> kpiApplicationTasksDc;
    @Autowired
    private DataGrid<ApplicationTask> kpiApplicationTasksTable;
    @Autowired
    private Notifications notifications;
    @Autowired
    private ScreenBuilders screenBuilders;

    @Subscribe
    public void onInit(InitEvent event) {
        currentUserName = currentUserSubstitution.getEffectiveUser().getUsername();
    }

    private void openSelectedApplication(ApplicationTask applicationTask) {
        if (applicationTask == null
                || applicationTask.getApplication() == null) return;
        Screen screen = screenBuilders.editor(Application.class, this)
                .editEntity(applicationTask.getApplication())
                .build();
        screen.addAfterCloseListener(event -> loadKpiApplications());
        screen.show();
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        loadKpiApplications();
    }

    private void loadKpiApplications() {
        kpiApplicationTasksDc.getMutableItems().clear();
        List<ApplicationTask> appTasks = bpmUserTaskService.getUserApplicationTasks(currentUserName);
        appTasks = appTasks.stream()
                .filter(appTask -> appTask.getTaskData()
                        .getTaskDefinitionKey().toLowerCase().contains(TASK_ID_KEY_MASS_APPROVAL))
                .collect(Collectors.toList());
        kpiApplicationTasksDc.getMutableItems().addAll(appTasks);
    }

    @Subscribe("massiveApproveBtn")
    public void onMassiveApproveBtnClick(Button.ClickEvent event) {
        Set<ApplicationTask> appTasks = kpiApplicationTasksTable.getSelected();

        for (ApplicationTask appTask : appTasks) {
            TaskData taskData = appTask.getTaskData();
            HashMap<String, Object> variables = new HashMap<>();
            bpmTaskService.completeTaskWithOutcome(
                    taskData.getId(),
                    ApplicationTask.OUTCOME_APPROVE,
                    variables);
        }
        if (appTasks.size() > 0) {
            notifications.create()
                    .withCaption("Выбранные заявки успешно согласованы.")
                    .show();
        }
        loadKpiApplications();
    }

    @Subscribe("kpiApplicationTasksTable")
    public void onKpiApplicationTasksTableItemClick(DataGrid.ItemClickEvent<ApplicationTask> event) {
        if (!event.isDoubleClick()) return;
        openSelectedApplication(event.getItem());
    }

    @Subscribe("closeBtn")
    public void onCloseBtnClick(Button.ClickEvent event) {
        closeWithDefaultAction();
    }

}