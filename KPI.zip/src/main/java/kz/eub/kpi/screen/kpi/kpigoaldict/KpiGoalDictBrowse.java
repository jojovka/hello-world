package kz.eub.kpi.screen.kpi.kpigoaldict;

import io.jmix.core.DataManager;
import io.jmix.core.MetadataTools;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.Action;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.Filter;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.PropertyFilter;
import io.jmix.ui.screen.Install;
import io.jmix.ui.screen.LookupComponent;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.entity.kpi.EKpiGoalCategory;
import kz.eub.kpi.entity.kpi.KpiGoalDict;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.UUID;

@UiController("kpi_KpiGoalDict.browse")
@UiDescriptor("kpi-goal-dict-browse.xml")
@LookupComponent("kpiGoalDictsTable")
public class KpiGoalDictBrowse extends StandardLookup<KpiGoalDict> {


    @Autowired
    private GroupTable<KpiGoalDict> kpiGoalDictsTable;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private MetadataTools metadataTools;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private Filter filter;
    @Autowired
    private PropertyFilter<EKpiGoalCategory> categoryProperty;
    @Autowired
    private ButtonsPanel buttonsPanel;

    public void setFilterCategory(EKpiGoalCategory category) {
        Filter.Configuration categoryFilterConf = filter.getConfiguration("categoryFilterConf");
        assert categoryFilterConf != null;
        categoryProperty.setValue(category);
        filter.setCurrentConfiguration(categoryFilterConf);
        filter.apply();
        filter.setVisible(false);
        buttonsPanel.setVisible(false);
    }

    @Subscribe("kpiGoalDictsTable.copy")
    public void onKpiGoalDictsTableCopy(Action.ActionPerformedEvent event) {
        KpiGoalDict fdGoalDict = kpiGoalDictsTable.getSingleSelected();
        if (fdGoalDict == null) return;
        KpiGoalDict newFdGoalDict = dataManager.create(KpiGoalDict.class);
        metadataTools.copy(fdGoalDict, newFdGoalDict);
        newFdGoalDict.setId(UUID.randomUUID());
        screenBuilders.editor(kpiGoalDictsTable)
                .editEntity(newFdGoalDict)
                .build().show();
    }

    @Install(to = "kpiGoalDictsTable.copy", subject = "enabledRule")
    private boolean kpiGoalDictsTableCopyEnabledRule() {
        return kpiGoalDictsTable.getSingleSelected() != null;
    }

}