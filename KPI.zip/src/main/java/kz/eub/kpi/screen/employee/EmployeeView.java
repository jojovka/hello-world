package kz.eub.kpi.screen.employee;

import io.jmix.core.DataManager;
import io.jmix.core.FileRef;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.Image;
import io.jmix.ui.component.Table;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.navigation.Route;
import io.jmix.ui.navigation.UrlParamsChangedEvent;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.kpi.KpiCard;
import kz.eub.kpi.entity.kpi.KpiResult;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.UUID;

@UiController("kpi_Employee.view")
@UiDescriptor("employee-view.xml")
@Route(value = "employee")
public class EmployeeView extends Screen {

    @Autowired
    private DataManager dataManager;
    @Autowired
    private CollectionContainer<Employee> employeesDc;
    @Autowired
    private Image<FileRef> photo;
    @Autowired
    private CollectionContainer<KpiResult> kpiResultsDc;
    @Autowired
    private CollectionContainer<KpiCard> kpiCardsDc;
    @Autowired
    private InstanceContainer<Employee> employeeDc;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private Table<Employee> accountablesTable;
    @Autowired
    private ScreenBuilders screenBuilders;

    @Subscribe
    public void onInit(InitEvent event) {
        employeeDc.setItem(dataManager.create(Employee.class));
        addItemClickAction();
        enterPressAction();
    }

    private void enterPressAction() {
        accountablesTable.setEnterPressAction(new BaseAction("enterPressAction")
                .withHandler(actionPerformedEvent -> {
                    showEmployeeView();
                }));
    }

    private void addItemClickAction() {
        accountablesTable.setItemClickAction(new BaseAction("itemClickAction")
                .withHandler(actionPerformedEvent -> {
                    showEmployeeView();
                }));
    }

    @Subscribe
    protected void onUrlParamsChanged(UrlParamsChangedEvent event) {
        String id = event.getParams().get("id");
        UUID eventId = UUID.fromString(id);
        Employee employee = employeeService.reloadEmployeeById(eventId);
        employeeDc.setItem(employee);
    }

    public void setEmployee(Employee employee) {
        employeeDc.setItem(employee);
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        loadKpiCards();
        loadAccountableEmployees();
        loadKpiResults();
        togglePhoto();
    }

    private void loadKpiCards() {
        kpiCardsDc.getMutableItems().clear();
        List<KpiCard> kpiCards = dataManager.load(KpiCard.class)
                .query("select c from kpi_KpiCard c " +
                        "where c.author = :employee")
                .parameter("employee", employeeDc.getItem())
                .list();
        kpiCardsDc.getMutableItems().addAll(kpiCards);
    }

    private void togglePhoto() {
        Employee employee = employeeDc.getItem();
        photo.setVisible(employee.getPhoto() != null);
        photo.setHeightFull();
    }

    private void loadAccountableEmployees() {
        employeesDc.getMutableItems().clear();
        List<Employee> employees = dataManager.load(Employee.class)
                .query("select c from kpi_Employee c " +
                        "where c.supervisor = :employee")
                .parameter("employee", employeeDc.getItem())
                .list();
        employeesDc.getMutableItems().addAll(employees);
    }

    private void loadKpiResults() {
        kpiResultsDc.getMutableItems().clear();
        List<KpiResult> kpiGoals = dataManager.load(KpiResult.class)
                .query("select c from kpi_KpiResult c " +
                        "where c.employee = :employee")
                .parameter("employee", employeeDc.getItem())
                .list();
        kpiResultsDc.getMutableItems().addAll(kpiGoals);
    }

    @Subscribe("closeBtn")
    public void onCloseBtnClick(Button.ClickEvent event) {
        closeWithDefaultAction();
    }

    @Subscribe("employeeViewBtn")
    public void onEmployeeViewBtnClick(Button.ClickEvent event) {
        showEmployeeView();
    }

    private void showEmployeeView() {
        Employee employee = accountablesTable.getSingleSelected();
        EmployeeView employeeView = screenBuilders.screen(this)
                .withScreenClass(EmployeeView.class)
                .build();
        employeeView.setEmployee(employee);
        employeeView.show();
    }

}