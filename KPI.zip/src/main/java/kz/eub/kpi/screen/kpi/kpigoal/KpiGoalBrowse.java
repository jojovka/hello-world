package kz.eub.kpi.screen.kpi.kpigoal;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.KpiGoal;

@UiController("kpi_KpiGoal.browse")
@UiDescriptor("kpi-goal-browse.xml")
@LookupComponent("kpiGoalsTable")
public class KpiGoalBrowse extends StandardLookup<KpiGoal> {
}