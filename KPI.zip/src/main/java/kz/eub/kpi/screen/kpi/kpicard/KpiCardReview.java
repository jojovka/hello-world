package kz.eub.kpi.screen.kpi.kpicard;

import com.google.common.base.Strings;
import io.jmix.bpmui.processform.ProcessFormContext;
import io.jmix.bpmui.processform.annotation.Outcome;
import io.jmix.bpmui.processform.annotation.Param;
import io.jmix.bpmui.processform.annotation.ProcessForm;
import io.jmix.bpmui.processform.annotation.ProcessFormParam;
import io.jmix.bpmui.processform.annotation.ProcessVariable;
import io.jmix.core.DataManager;
import io.jmix.core.MetadataTools;
import io.jmix.core.SaveContext;
import io.jmix.ui.Notifications;
import io.jmix.ui.UiComponents;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.Component;
import io.jmix.ui.component.Label;
import io.jmix.ui.component.Table;
import io.jmix.ui.component.TextArea;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.EditedEntityContainer;
import io.jmix.ui.screen.Install;
import io.jmix.ui.screen.StandardEditor;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.app.service.KpiCardService;
import kz.eub.kpi.entity.ApplicationTask;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.kpi.KpiGoalReviewResult;
import kz.eub.kpi.entity.kpi.EKpiGoalStatus;
import kz.eub.kpi.entity.kpi.KpiCard;
import kz.eub.kpi.entity.kpi.KpiGoal;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@UiController("kpi_KpiCard.review")
@UiDescriptor("kpi-card-review.xml")
@EditedEntityContainer("kpiCardDc")
@ProcessForm(
        params = {
                @Param(name = "title"),
                @Param(name = "goalCategoryId")
        },
        outcomes = {
                @Outcome(id = ApplicationTask.OUTCOME_APPROVE),
                @Outcome(id = ApplicationTask.OUTCOME_REJECT)
        })
public class KpiCardReview extends StandardEditor<KpiCard> {

    @ProcessVariable
    private KpiCard application;

    @ProcessFormParam
    private String title;
    @ProcessFormParam
    private String goalCategoryId;

    @Autowired
    private ProcessFormContext processFormContext;

    @Autowired
    private KpiCardService kpiCardService;
    @Autowired
    private Notifications notifications;
    @Autowired
    private CollectionContainer<KpiGoal> kpiGoalsDc;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private Label titleFld;
    @Autowired
    private Table<KpiGoal> kpiGoalsTable;
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private MetadataTools metadataTools;

    @Subscribe
    public void onInit(InitEvent event) {
        if (application != null) {
            setEntityToEdit(application);
        }
        this.getWindow().setCaption(title);
        titleFld.setValue(title);
        setReadOnly(true);
    }

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        filterGoalsByCategory();
    }

    private void filterGoalsByCategory() {
        kpiGoalsDc.getMutableItems().clear();
        KpiCard card = getEditedEntity();
        List<KpiGoal> kpiGoals = card.getKpiGoals();
        if (goalCategoryId != null && !goalCategoryId.isEmpty()) {
            kpiGoals = card.getKpiGoals().stream()
                    .filter(g -> g.getCategory().getId().equals(goalCategoryId))
                    .collect(Collectors.toList());
        }
        kpiGoalsDc.getMutableItems().addAll(kpiGoals);
    }

    @Subscribe
    public void onBeforeCommitChanges(BeforeCommitChangesEvent event) {
        try {
            kpiCardService.validateKpiCard(getEditedEntity());
        } catch (Exception e) {
            event.preventCommit();
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption(e.getMessage())
                    .show();
        }
    }


    private void sendToApprovalTask() {
        try {
            List<KpiGoal> kpiGoals = kpiGoalsDc.getMutableItems();
            saveGoalReviewResults(kpiGoals);                                    // todo deprecated, gotta replace to the next line
//            kpiGoalReviewService.saveReviewResults(kpiGoals, title);          // todo uncomment
            String outcome = getCardOutcomeFromGoals(kpiGoals);
            processFormContext.taskCompletion()
                    .saveInjectedProcessVariables()
                    .withOutcome(outcome)
                    .complete();
            notifications.create(Notifications.NotificationType.TRAY)
                    .withCaption("Цель КПЭ отправлена на согласование...")
                    .show();
            closeWithDiscard();
        } catch (Exception e) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption(e.getMessage())
                    .show();
            throw new RuntimeException("Ошибка при согласовании КПЭ: ", e);
        }
    }

    private String getCardOutcomeFromGoals(List<KpiGoal> kpiGoals) {
        for (KpiGoal goal : kpiGoals) {
            if (goal.getStatus() == null)
                throw new IllegalStateException("Статус цели не указан.");
            if (goal.getStatus().equals(EKpiGoalStatus.REJECTED))
                return ApplicationTask.OUTCOME_REJECT;
        }
        return ApplicationTask.OUTCOME_APPROVE;
    }

    @Deprecated
    private void saveGoalReviewResults(List<KpiGoal> kpiGoals) {
        validateKpiGoalReviewResults();
        SaveContext saveContext = new SaveContext().setDiscardSaved(true);
        Employee employee = employeeService.getCurrentEmployee();
        for (KpiGoal goal : kpiGoals) {
            KpiGoalReviewResult res = createKpiGoalReviewResult(employee, goal);
            saveContext.saving(res);
            saveContext.saving(goal);
        }
        dataManager.save(saveContext);
    }

    private KpiGoalReviewResult createKpiGoalReviewResult(Employee employee, KpiGoal goal) {
        KpiGoalReviewResult res = dataManager.create(KpiGoalReviewResult.class);
        res.setKpiGoal(goal);
        res.setDate(new Date());
        res.setTitle(title);
        res.setReviewer(employee);
        res.setStatus(goal.getStatus());
        res.setInfo(goal.getComment());
        return res;
    }

    private boolean validateKpiGoalReviewResults() {
        for (KpiGoal goal : kpiGoalsDc.getMutableItems()) {
            if (goal.getStatus() == null)
                throw new IllegalStateException(String.format("Укажите статус цели №%s.", goal.getSn()));
            if (Objects.equals(goal.getStatus(), EKpiGoalStatus.REJECTED)
                    && Strings.isNullOrEmpty(goal.getComment()))
                throw new IllegalStateException(String.format("Укажите причину отказа цели №%s в поле \"Примечание\".", goal.getSn()));
        }
        return true;
    }

    @Subscribe("sendBtn")
    public void onSendBtnClick(Button.ClickEvent event) {
        sendToApprovalTask();
    }

    @Install(to = "kpiGoalsTable.comment", subject = "columnGenerator")
    private Component kpiGoalsTableInfoColumnGenerator(KpiGoal kpiGoal) {
        TextArea<String> textArea = uiComponents.create(TextArea.TYPE_STRING);
        textArea.setValue(kpiGoal.getComment());
        textArea.setWidth("100%");
        textArea.addValueChangeListener(e -> kpiGoal.setComment(e.getValue()));
        return textArea;
    }

}