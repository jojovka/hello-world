package kz.eub.kpi.screen.authority;

import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.Screens;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.Label;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.*;
import kz.eub.kpi.app.service.ProBonusService;
import kz.eub.kpi.entity.Accounts;
import kz.eub.kpi.entity.BonusAuthority;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.RatingUserOptions;
import kz.eub.kpi.screen.bonusprofile.BonusProfileScreen;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

@UiController("authorityAuthorityscreen")
@UiDescriptor("authorityscreen.xml")
public class Authorityscreen extends Screen {
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private Screens screens;
    @Autowired
    private Label pointLabel;

    @Autowired
    private Button titleBtnEvent;

    List<BonusAuthority> authorityList = new ArrayList<>();
    @Autowired
    private ProBonusService proBonusService;
    @Autowired
    private CollectionContainer<BonusAuthority> bonusAuthoritiesDc;

    Employee employee;


    @Subscribe("titleBtnEvent")
    public void onTitleBtnEventClick(Button.ClickEvent event) {
        showAuthorityscreenDlg();
    }

    private Integer accountId;
    private String fio;
    private Double points;

    @Subscribe
    private void onInit(InitEvent event) {
        ScreenOptions options = event.getOptions();
        bonusAuthoritiesDc.getMutableItems().clear();

        if (options instanceof RatingUserOptions) {
            accountId = ((RatingUserOptions) options).getAccountId();
            Accounts accounts = proBonusService.reloadAccountById(accountId);
            employee = proBonusService.reloadEmployeeByPayroll(accounts.getIdentityProperty());
            if (accountId != null) {
                authorityList = proBonusService.reloadBonusAuthority();
            }
//            bonusAuthoritiesDc.getMutableItems().clear();
            authorityList.forEach(bonusAuthority -> {
                if (bonusAuthority.getEmployee().getId().equals(employee.getId())) {
//                    bonusAuthoritiesDc.getMutableItems().add(bonusAuthority);
                }
            });

            fio = ((RatingUserOptions) options).getFio();
            points = ((RatingUserOptions) options).getPoints();
            if (fio != null) {
                titleBtnEvent.setCaption(fio);
            }
            if (points != null) {
                pointLabel.setValue("Баллов: " + points.intValue());
            }
        }
    }

    private void showAuthorityscreenDlg() {
        screens.remove(this);
        screenBuilders.screen(this)
                .withScreenClass(BonusProfileScreen.class)
                .withOptions(new RatingUserOptions(
                        this.accountId,
                        this.fio,
                        this.points, null, null, null))
                .build()
                .show();
    }
}