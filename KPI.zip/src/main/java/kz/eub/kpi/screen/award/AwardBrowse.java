package kz.eub.kpi.screen.award;

import io.jmix.core.DataManager;
import io.jmix.security.role.annotation.RowLevelRole;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.CheckBox;
import io.jmix.ui.component.Component;
import io.jmix.ui.component.DataGrid;
import io.jmix.ui.component.DateField;
import io.jmix.ui.component.FlowBoxLayout;
import io.jmix.ui.component.Form;
import io.jmix.ui.component.GridLayout;
import io.jmix.ui.component.GroupBoxLayout;
import io.jmix.ui.component.HBoxLayout;
import io.jmix.ui.component.Label;
import io.jmix.ui.component.VBoxLayout;
import io.jmix.ui.component.impl.VBoxLayoutImpl;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.*;
import io.jmix.ui.widget.JmixResponsiveGridLayout;
import kz.eub.kpi.entity.Award;
import kz.eub.kpi.entity.RatingUserOptions;
import kz.eub.kpi.screen.awardassign.AwardAssignScreen;
import org.springframework.beans.factory.annotation.Autowired;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;


@UiController("kpi_Award.browse")
@UiDescriptor("award-browse.xml")
@LookupComponent("awardsTable")
public class AwardBrowse extends StandardLookup<Award> {

    private UUID selectedUuid;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private CollectionContainer<Award> awardsDc;
    @Autowired
    private DataManager dataManager;
    private VBoxLayout vBox;
    private VBoxLayout hBox;

    private Label label;

    private CheckBox checkBox;

    @Autowired
    private Button newAwardBtn;

    @Autowired
    protected UiComponents uiComponents;

    private GroupBoxLayout groupBoxId;
    @Autowired
    private FlowBoxLayout formId;
    @Autowired
    private Label awardCount;


    @Subscribe
    private void onInit(InitEvent event) {
        newAwardBtn.addClickListener(btn -> {
            screenBuilders.screen(this)
                    .withScreenClass(AwardCreate.class)
                    .build()
                    .show().addAfterCloseListener(afterCloseEvent -> {
                        initValues();
                    });
        });

        initValues();

    }

    private void initValues() {
        vBox = uiComponents.create(VBoxLayout.class);
        hBox = uiComponents.create(VBoxLayout.class);
        byte[] array = new byte[7];
        new Random().nextBytes(array);
        String generatedString = new String(array, Charset.forName("UTF-8"));
        vBox.setId(generatedString);
        awardsDc.getMutableItems().clear();
        awardsDc.getMutableItems().addAll(dataManager.load(Award.class)
                .query("select e from kpi_Award e")
                .list());
        awardCount.setValue(awardsDc.getMutableItems().size());


        groupBoxId = uiComponents.create(GroupBoxLayout.class);
        awardsDc.getMutableItems().forEach(award -> {
            vBox = uiComponents.create(VBoxLayout.class);
            hBox = uiComponents.create(VBoxLayout.class);
            VBoxLayout textBox = uiComponents.create(VBoxLayout.class);
            VBoxLayout checkBoxLayout = uiComponents.create(VBoxLayout.class);
            label = uiComponents.create(Label.class);
            Label description = uiComponents.create(Label.class);
            Label date = uiComponents.create(Label.class);
            checkBox = uiComponents.create(CheckBox.class);
            Button btnGive = uiComponents.create(Button.class);
            vBox.setSpacing(false);

            btnGive.setId(award.getId().toString());

            checkBox.setValue(award.getStatus());
            if (!award.getStatus()) {
                btnGive.setVisible(false);
            }


            btnGive.setAlignment(Component.Alignment.MIDDLE_RIGHT);
            btnGive.setCaption("Выдать");
            btnGive.addClickListener(btn -> {
                screenBuilders.screen(this)
                        .withScreenClass(AwardAssignScreen.class)
                        .withOptions(new RatingUserOptions(UUID.fromString(btn.getSource().getId())))
                        .build()
                        .show();
            });

            vBox.setId("d" + award.getId());
            vBox.setStyleName("well");
            vBox.setHeight("150px");
            vBox.setWidth("100%");
            vBox.setSpacing(true);
//            HBox
            hBox.setStyleName("v-panel-caption");
            hBox.setWidth("100%");
            hBox.setId(" f" + award.getId());
//            Label
            label.setValue(award.getTitle());
            label.setId(" label" + award.getId());
//            description
            description.setValue(award.getDescription());
            description.setId(" desc" + award.getId());

            date.setValue(award.getCreatedDate());
            date.setId(" date" + award.getId());
//            Button
            checkBox.setAlignment(Component.Alignment.MIDDLE_RIGHT);
            checkBox.setId(" f" + award.getId());

            checkBox.setValue(true);

            checkBoxLayout.add(checkBox);
//            checkBoxLayout.add(btnGive);
            hBox.add(checkBoxLayout);
            HBoxLayout vertical = uiComponents.create(HBoxLayout.class);
            vertical.setId("ver " + award.getId());
            vertical.setWidth("100%");
            vertical.setSpacing(true);
            vertical.add(description);
            vertical.add(btnGive);
            textBox.add(label);
            textBox.add(vertical);

            textBox.add(date);
            hBox.add(textBox);

            vBox.add(hBox);

            formId.add(vBox);
        });

    }

    @Subscribe("newAwardBtn")
    public void onNewAwardBtnClick(Button.ClickEvent event) {

    }
}