package kz.eub.kpi.screen.dictbusiness;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.DictBusiness;

@UiController("kpi_DictBusiness.browse")
@UiDescriptor("dict-business-browse.xml")
@LookupComponent("dictBusinessesTable")
public class DictBusinessBrowse extends StandardLookup<DictBusiness> {
}