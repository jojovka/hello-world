package kz.eub.kpi.screen.cmdb.cmdbattachmenttype;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.cmdb.CmdbAttachmentType;

@UiController("kpi_CmdbAttachmentType.edit")
@UiDescriptor("cmdb-attachment-type-edit.xml")
@EditedEntityContainer("cmdbAttachmentTypeDc")
public class CmdbAttachmentTypeEdit extends StandardEditor<CmdbAttachmentType> {
}