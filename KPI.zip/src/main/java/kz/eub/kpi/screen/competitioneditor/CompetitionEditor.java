package kz.eub.kpi.screen.competitioneditor;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("kpi_CompetitionEditor")
@UiDescriptor("competition-editor.xml")
public class CompetitionEditor extends Screen {
}