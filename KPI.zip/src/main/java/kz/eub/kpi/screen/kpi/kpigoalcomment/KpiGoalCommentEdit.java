package kz.eub.kpi.screen.kpi.kpigoalcomment;

import io.jmix.ui.component.TextArea;
import io.jmix.ui.component.TextField;
import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.kpi.KpiGoalComment;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("kpi_KpiGoalComment.edit")
@UiDescriptor("kpi-goal-comment-edit.xml")
@EditedEntityContainer("kpiGoalCommentDc")
public class KpiGoalCommentEdit extends StandardEditor<KpiGoalComment> {


    @Autowired
    private TextField<String> subjectField;
    @Autowired
    private TextArea<String> commentField;

    public void setEditable() {
        setReadOnly(false);
        subjectField.setEditable(true);
        commentField.setEditable(true);
    }

}