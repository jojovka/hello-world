package kz.eub.kpi.screen.main;

import io.jmix.core.FileStorageLocator;
import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import io.jmix.reportsui.screen.report.run.ReportRun;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.ScreenTools;
import io.jmix.ui.UiComponents;
import io.jmix.ui.component.AppWorkArea;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.GroupBoxLayout;
import io.jmix.ui.component.HBoxLayout;
import io.jmix.ui.component.LayoutClickNotifier;
import io.jmix.ui.component.ScrollBoxLayout;
import io.jmix.ui.component.SizeUnit;
import io.jmix.ui.component.SplitPanel;
import io.jmix.ui.component.Window;
import io.jmix.ui.component.mainwindow.Drawer;
import io.jmix.ui.component.mainwindow.SideMenu;
import io.jmix.ui.icon.JmixIcon;
import io.jmix.ui.navigation.Route;
import io.jmix.ui.screen.OpenMode;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiControllerUtils;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.event.UserTaskAssignedUiEvent;
import kz.eub.kpi.app.service.AnnounceService;
import kz.eub.kpi.app.service.BpmUserTaskService;
import kz.eub.kpi.entity.Announce;
import kz.eub.kpi.screen.kpi.kpicard.KpiCardBrowse;
import kz.eub.kpi.screen.profile.ProfileScreen;
import org.flowable.task.service.impl.persistence.entity.TaskEntityImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.transaction.event.TransactionalEventListener;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

@UiController("kpi_MainScreen")
@UiDescriptor("main-screen.xml")
@Route(path = "main", root = true)
public class MainScreen extends Screen implements Window.HasWorkArea {

    public static final Logger log = LoggerFactory.getLogger(MainScreen.class);

    @Autowired
    private ScreenTools screenTools;

    @Autowired
    private AppWorkArea workArea;
    @Autowired
    private Drawer drawer;
    @Autowired
    private Button collapseDrawerButton;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private SideMenu sideMenu;
    @Autowired
    private BpmUserTaskService bpmUserTaskService;
    @Autowired
    private CurrentUserSubstitution currentUserSubstitution;

    private String currentUserName;
    @Autowired
    private AnnounceService announceService;
    @Autowired
    private ScrollBoxLayout announcesContainer;
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private FileStorageLocator fileStorageLocator;
    @Autowired
    private SplitPanel splitter;
    @Autowired
    private HBoxLayout workAreaHbox;

    @Subscribe
    public void onInit(InitEvent event) {
        currentUserName = currentUserSubstitution.getEffectiveUser().getUsername();
    }


    @Override
    public AppWorkArea getWorkArea() {
        return workArea;
    }

    @Subscribe("collapseDrawerButton")
    private void onCollapseDrawerButtonClick(Button.ClickEvent event) throws InterruptedException {
        drawer.toggle();
        if (drawer.isCollapsed()) {
//            Thread.sleep(500);
            workAreaHbox.setWidth("100%");
            splitter.setDockable(true);
            splitter.setSplitPosition(75, SizeUnit.PERCENTAGE);
            collapseDrawerButton.setIconFromSet(JmixIcon.CHEVRON_RIGHT);
        } else {
            workAreaHbox.setWidth("87.3%");
            splitter.setSplitPosition(100, SizeUnit.PERCENTAGE);
            splitter.setDockable(false);
            collapseDrawerButton.setIconFromSet(JmixIcon.CHEVRON_LEFT);
        }
    }

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        drawer.collapse();
        updateMyTasksBadge();
    }

    public void updateMyTasksBadge() {
        SideMenu.MenuItem myTasks = sideMenu.getMenuItem("myTasks");
        if (myTasks == null) return;
        myTasks.setBadgeText(getCurrentUserTotalTasks());
    }

    private String getCurrentUserTotalTasks() {
//        long count = bpmUserTaskService.getUserActiveTasksCount(currentUserSubstitution.getEffectiveUser().getUsername());
        long count = bpmUserTaskService.getUserTaskApplications(currentUserName).size();
        return String.valueOf(count);
    }

    @Async
    @TransactionalEventListener
    public void onTaskAssigned(UserTaskAssignedUiEvent event) {
        if (Objects.equals(currentUserName, event.getSource().getUsername())
                || Objects.equals(((TaskEntityImpl) event.getSource().getTask()).getOriginalAssignee(), currentUserName)
        ) {
            updateMyTasksBadge();
        }
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        screenTools.openDefaultScreen(
                UiControllerUtils.getScreenContext(this).getScreens());

        screenTools.handleRedirect();
        loadAnnounces();
    }

    private void loadAnnounces() {
        try {
            List<Announce> announces = announceService.loadAnnounces();
            for (Announce announce : announces) {
                GroupBoxLayout groupBox = announceService.getAnnounceCard(announce);
                announcesContainer.add(groupBox);
            }
        } catch (IOException e) {
            log.error("Файл не найден", e);
        }
    }

    @Subscribe("profileBtn")
    public void onProfileBtnClick(Button.ClickEvent event) {
        screenBuilders.screen(this)
                .withScreenClass(ProfileScreen.class)
                .withOpenMode(OpenMode.NEW_TAB)
                .build()
                .show();
    }

    @Subscribe("profileBox")
    public void onProfileBoxLayoutClick(LayoutClickNotifier.LayoutClickEvent event) {
        screenBuilders.screen(this)
                .withScreenClass(ProfileScreen.class)
                .withOpenMode(OpenMode.NEW_TAB)
                .build()
                .show();
    }

    @Subscribe("kpiBox")
    public void onKpiBoxLayoutClick(LayoutClickNotifier.LayoutClickEvent event) {
        try {
            KpiCardBrowse cardsBrowser = screenBuilders.screen(this)
                    .withScreenClass(KpiCardBrowse.class)
                    .withOpenMode(OpenMode.NEW_TAB)
                    .build();
            cardsBrowser.show();
            Thread.sleep(1000);
            cardsBrowser.setAuthorFilterProperty();
        } catch (InterruptedException e) {
            String caption = "Ошибка";
            log.error(caption, e);
            throw new RuntimeException(caption, e);
        }
    }

    @Subscribe("reportsBox")
    public void onReportsBoxLayoutClick(LayoutClickNotifier.LayoutClickEvent event) {
        screenBuilders.screen(this)
                .withScreenClass(ReportRun.class)
                .withOpenMode(OpenMode.NEW_TAB)
                .build()
                .show();
    }

}
