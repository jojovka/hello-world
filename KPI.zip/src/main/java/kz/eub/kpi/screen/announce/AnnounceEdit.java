package kz.eub.kpi.screen.announce;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.Announce;

@UiController("kpi_Announce.edit")
@UiDescriptor("announce-edit.xml")
@EditedEntityContainer("announceDc")
public class AnnounceEdit extends StandardEditor<Announce> {
}