package kz.eub.kpi.screen.bonusprofile;

import io.jmix.charts.component.AngularGaugeChart;
import io.jmix.charts.model.Color;
import io.jmix.charts.model.GaugeArrow;
import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.FetchPlans;
import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.Screens;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.GroupBoxLayout;
import io.jmix.ui.component.Label;
import io.jmix.ui.component.ProgressBar;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.*;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.app.service.ProBonusService;
import kz.eub.kpi.entity.AccountProfiles;
import kz.eub.kpi.entity.AccountVisits;
import kz.eub.kpi.entity.Accounts;
import kz.eub.kpi.entity.Award;
import kz.eub.kpi.entity.AwardUser;
import kz.eub.kpi.entity.Contracts;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.PointUser;
import kz.eub.kpi.entity.RatingUser;
import kz.eub.kpi.entity.RatingUserOptions;
import kz.eub.kpi.screen.bonusbonusdescription.BonusBonusDescription;
import kz.eub.kpi.screen.bonusdescriptionopzp.BonusDescriptionOpzp;
import kz.eub.kpi.screen.contracts.ContractsBrowse;
//import kz.eub.kpi.screen.fancymessage.FancyMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.*;
import java.util.List;


@UiController("bonus_administration_BonusProfileScreen")
@UiDescriptor("bonus-profile-screen.xml")
public class BonusProfileScreen extends Screen {

    @Autowired
    private FetchPlans fetchPlans;

    private boolean isAuto = false;

    private static final String COLOR_GREEN = "#47b194";
    private static final String COLOR_BLUE = "#314082";
    private static final String COLOR_RED = "#dd1668";

    int dep = 0;

    private static final int POINT_TOTAL_PREMI = 5;
    private static final int POINT_PREMI_FOR_SHOW = 129;
    private static final int POINT_DEBET_COUNT = 98;

    private static final int POINT_PREMIAL_CARD_TOTAL = 295;

    private static final int POINT_PREMIAL_CARD = 296;

    private static final int POINT_PREMIAL_CARD_PREMI = 297;

    private static final int POINT_PRONIKNOVENIE = 99;
    private static final int POINT_NEW_AUTO_DEBET = 127;
    private static final int POINT_OLD_AUTO_DEBET = 125;
    private static final int POINT_NEW_AUTO = 126;
    private static final int POINT_OLD_AUTO = 124;
    private static final int POINT_SMARTBANK = 301;

    private static final int POINT_SMARTBANK_ONLAIN = 312;

    private static final int POINT_SMARTBANKTOTAL = 302;

    private static final int SMS_AUTO = 0;
    private static final int SMS_DS = 280;
    private static final int SMS_DS_COUNT = 279;

    private static final int SMS_AUTO_COUNT = 277;

    private static final int SMS_AUTO_SUM = 278;

    private static final int SMS_POS_COUNT = 281;

    private static final int SMS_POS_SUM = 282;

    private static final int POS_CHANEL_TOP_SUM = 108;

    private static final int POS_CHANEL_MID_SUM = 106;

    private static final int POS_CHANEL_LOW_SUM = 104;

    private static final int DEBET_COUNT_BONUS_SUM = 109;

    private static final int POS_CHANEL_TOP_BONUS = 107;

    private static final int POS_CHANEL_MID_BONUS = 105;

    private static final int POS_CHANEL_LOW_BONUS = 103;

    private static final int POS_CHANEL_TOTAl = 231;

    private static final int DEBET_PREMI = 97;
    private static final int DEBET_PREMI_TYPE_1 = 92;
    private static final int DEBET_PREMI_TYPE_2 = 90;
    private static final int DEBET_PREMI_TYPE_3 = 88;
    private static final int DEBET_PREMI_TYPE_4 = 86;
    private static final int DEBET_PREMI_BONUS_1 = 91;
    private static final int DEBET_PREMI_BONUS_2 = 89;
    private static final int DEBET_PREMI_BONUS_3 = 87;
    private static final int DEBET_PREMI_BONUS_4 = 85;

    public static final int NEW_DEBET_COUNT = 94;
    private static final int NEW_DEBET_PREMI = 93;

    private static final int SALARY_ACTIVATION_COUNT = 101;

    private static final int SALARY_ACTIVATION_PLAN = 130;

    private static final int POINT_ACTIVE_CARD_COUNT = 298;
    private static final int RATING_USER = 96;

    private static final int POINT_USER_POINT = 1;

    private static final int POINT_SHTRAFT = 96;

    private static final int POINT_VALUE_GIVEN_CREDIT_NEW_AUTO = 75;

    private static final int POINT_VALUE_GIVEN_CREDIT_OLD_AUTO = 73;

    private static final int POINT_VALUE_GIVEN_CREDIT_NEW_AUTO_PLAN = 151;

    private static final int POINT_VALUE_GIVEN_CREDIT_OLD_AUTO_PLAN = 153;

    private static final int POINT_VALUE_PLAN_ZAIM_TOTAL = 268;

    private static final int POINT_VALUE_PLAN_ZAIM_SUM_PRL = 138;

    private static final int POINT_VALUE_PLAN_ZAIM_COUNT_PRL = 139;

    private static final int POINT_VALUE_PLAN_ZAIM_SUM_UnsCL = 266;

    private static final int POINT_VALUE_PLAN_ZAIM_COUNT_UnsCL = 267;

    private static final int POINT_VALUE_PLAN_ZAIM_SUM_UCLREF = 136;

    private static final int POINT_VALUE_PLAN_ZAIM_COUNT_UCLREF = 137;

    private static final int POINT_VALUE_PLAN_ZAIM_SUM_Loyalty = 140;

    private static final int POINT_VALUE_PLAN_ZAIM_COUNT_Loyalty = 141;
    private Integer accountId;

    private Date selectedDate;
    private Date selectedCurrentMonthDate;

    private String fio;
    private Double points;


    @Autowired
    private ProBonusService proBonusService;
    @Autowired
    protected ProgressBar pointUserPREMIOLDAUTODEBETBar;
    @Autowired
    protected ProgressBar pointUserPREMINEWAUTODEBETBar;

    @Autowired
    private ProgressBar pointUserPREMINEWAUTOBar;
    @Autowired
    private ProgressBar pointUserPREMIOLDAUTOBar;
    @Autowired
    private ProgressBar debetPremiType1Bar;
    @Autowired
    private ProgressBar debetPremiType2Bar;
    @Autowired
    private ProgressBar debetPremiType3Bar;
    @Autowired
    private ProgressBar debetPremiType4Bar;
    @Autowired
    private ProgressBar debetPremiBonus1Bar;
    @Autowired
    private ProgressBar debetPremiBonus2Bar;
    @Autowired
    private ProgressBar debetPremiBonus3Bar;
    @Autowired
    private ProgressBar debetPremiBonus4Bar;
    @Autowired
    private ProgressBar planPrirostBarId;
    @Autowired
    private ProgressBar debetPremiProgressId;
    @Autowired
    private ProgressBar proniknovenieBarId;

    private Double fact;
    private Double plan;
    private Double totalPremiBonus;

    @Autowired
    private AngularGaugeChart gaugeId;

    @Autowired
    private AngularGaugeChart gaugeOnlainId;


    PointUser pointValuePlanZaimTotal;

    PointUser pointValuePlanZaimSumPRL;

    PointUser pointValuePlanZaimCountPRL;

    PointUser pointValuePlanZaimSumUnsCL;

    PointUser pointValuePlanZaimCountUnsCL;

    PointUser pointValuePlanZaimSumUCLREF;

    PointUser pointValuePlanZaimCountUCLREF;

    PointUser pointValuePlanZaimSumLoyalty;

    PointUser pointValuePlanZaimCountLoyalty;
    PointUser pointProniknovenie;
    PointUser pointUserTotalBonus;
    PointUser pointUserSmartbank;

    PointUser pointUserSmartbankOnlain;
    PointUser pointUserSmartbankTotal;
    PointUser pointUserPREMISHOW;
    PointUser pointUserPREMIDEBETCOUNT;
    PointUser pointUserPREMINEWAUTODEBET;
    PointUser pointUserPREMIOLDAUTODEBET;
    PointUser pointUserPREMINEWAUTO;
    PointUser pointUserPREMIOLDAUTO;
    PointUser pointUserSMSDSCOUNT;
    PointUser pointUserSMSPOSCOUNT;

    PointUser pointUserPosChanelTopSum;

    PointUser pointUserPosChanelMidSum;

    PointUser pointUserPosChanelLowSum;

    PointUser pointUserPosChanelTopBonus;

    PointUser pointUserPosChanelMidBonus;

    PointUser pointUserPosChanelLowBonus;
    PointUser pointUserPosChanelTotal;

    PointUser pointUserSMSAUTOCOUNT;
    PointUser pointUserSMSDS;
    PointUser pointUserSMSAUTO;
    PointUser pointUserSMSPOS;

    PointUser pointUserDebetPremi;
    PointUser pointUserDebetPremiType1;
    PointUser pointUserDebetPremiType2;
    PointUser pointUserDebetPremiType3;
    PointUser pointUserDebetPremiType4;
    PointUser pointUserDebetPremiBonus1;
    PointUser pointUserDebetPremiBonus2;
    PointUser pointUserDebetPremiBonus3;
    PointUser pointUserDebetPremiBonus4;

    PointUser pointUserNewDebetCount;

    PointUser pointUserNewDebetPremi;

    PointUser activeCardCount;

    PointUser pointUserSalaryActivationCount;

    PointUser pointUserSalaryActivationPlan;

    PointUser pointPremialCardTotal;

    PointUser pointPenalty;

    PointUser pointUserValueGivenCreditNewAuto;

    PointUser pointUserValueGivenCreditOldAuto;

    PointUser pointUserValueGivenCreditNewAutoPlan;

    PointUser pointUserValueGivenCreditOldAutoPlan;

    PointUser pointPremialCard;
    PointUser pointPremialCardPremi;
    PointUser pointActiveCardCount;

    RatingUser ratingUser;

    RatingUser pointUserPoint;
    @Autowired
    private Button liveDataButton;

    @Autowired
    private GroupBoxLayout carPremiId;
    @Autowired
    private GroupBoxLayout newPremialCardId;
    @Autowired
    private GroupBoxLayout salaryCardActivationId;
    @Autowired
    private GroupBoxLayout newCardId;
    @Autowired
    private GroupBoxLayout cardConvertationId;
    @Autowired
    private GroupBoxLayout cardId;
    @Autowired
    private GroupBoxLayout debetPosId;
    @Autowired
    private GroupBoxLayout debetStrahovkaId;
    @Autowired
    private GroupBoxLayout smsId;
    @Autowired
    private GroupBoxLayout smartbankId;
    @Autowired
    private GroupBoxLayout orbId;

    @Autowired
    private CurrentUserSubstitution currentUserSubstitution;
    private String currentUserName;

    @Autowired
    private DataManager dataManager;

    private Employee employee;
    @Autowired
    private ScreenBuilders screenBuilders;


    @Autowired
    private GroupBoxLayout planPrirostId;
    @Autowired
    private GroupBoxLayout planObiemId;
    @Autowired
    private GroupBoxLayout planVydachaId;
    @Autowired
    private GroupBoxLayout planVypushennyxCartId;
    @Autowired
    private GroupBoxLayout proniknovenieId;
    @Autowired
    private GroupBoxLayout pokazatelNPSId;
    @Autowired
    private GroupBoxLayout zaimFDP;
    @Autowired
    private GroupBoxLayout planPRL;
    @Autowired
    private GroupBoxLayout obiemCreditNewCarId;
    @Autowired
    private GroupBoxLayout obiemCreditOldCarId;

    @Autowired
    private GroupBoxLayout creditId;
    @Autowired
    private Button oldDataButton;

    @Autowired
    private Label pointValuePlanZaimTotalId;

    @Autowired
    private Label pointValuePlanZaimSumPRLId;

    @Autowired
    private Label pointValuePlanZaimCountPRLId;

    @Autowired
    private Label pointValuePlanZaimSumUnsCLId;

    @Autowired
    private Label pointValuePlanZaimCountUnsCLId;

    @Autowired
    private Label pointValuePlanZaimSumUCLREFId;

    @Autowired
    private Label pointValuePlanZaimCountUCLREFId;

    @Autowired
    private Label pointValuePlanZaimSumLoyaltyId;

    @Autowired
    private Label pointValuePlanZaimCountLoyaltyId;
    @Autowired
    private Label usernameId;
    @Autowired
    private Label positionId;
    @Autowired
    private Label branchId;
    @Autowired
    private Label pointId;
    @Autowired
    private Label planId;
    @Autowired
    private Label planOnlainId;

    @Autowired
    private Label factOnlainId;
    @Autowired
    private Label factId;
    @Autowired
    private Label smartbankTotalPremiId;
    @Autowired
    private Label pointUserShowId;
    @Autowired
    private Label pointUserPREMINEWAUTODEBETId;
    @Autowired
    private Label pointUserPREMIOLDAUTODEBETId;
    @Autowired
    private Label pointUserPREMIDEBETCOUNTId;
    @Autowired
    private Label pointUserPREMINEWAUTOId;
    @Autowired
    private Label pointUserPREMIOLDAUTOId;
    @Autowired
    private Label totalPremiValueId;
    @Autowired
    private Label totalPremiORBId;

    @Autowired
    private Label lastModifyDate;
    @Autowired
    private Label smsDsCount;
    @Autowired
    private Label smsAutoCount;
    @Autowired
    private Label smsPosCount;
    @Autowired
    private Label smsDs;

    @Autowired
    private Label smsAuto;

    @Autowired
    private Label smsPos;
    @Autowired
    private Label debetPremiId;
    @Autowired
    private Label debetPremiType1;
    @Autowired
    private Label debetPremiType2;
    @Autowired
    private Label debetPremiType3;
    @Autowired
    private Label debetPremiType4;
    @Autowired
    private Label debetPremiBonus1;
    @Autowired
    private Label debetPremiBonus2;
    @Autowired
    private Label debetPremiBonus3;
    @Autowired
    private Label debetPremiBonus4;
    @Autowired
    private Label newDebetCountId;
    @Autowired
    private Label newDebetPremiId;
    @Autowired
    private Label salaryActivationCountId;
    @Autowired
    private Label salaryActivationPlanId;
    @Autowired
    private Label salaryActivationPremiId;
    @Autowired
    private Label creditPremiId;

    @Autowired
    private Label creditTotalSumId;
    @Autowired
    private Label proniknoviePlanId;
    @Autowired
    private Label proniknoveineFactId;

    @Autowired
    private Label zaimPdfId;

    @Autowired
    private Label ratingId;
    @Autowired
    private Label departmentId;
    @Autowired
    private Label premialCardTotalId;
    @Autowired
    private Label premialCardId;
    @Autowired
    private Label premialCardDate;
    @Autowired
    private Label pointPenaltyId;
    @Autowired
    private Label premialCardActiveId;
    @Autowired
    private Label pointPremialCardPremiId;
    @Autowired
    private Label channelPOSTopBarId;
    @Autowired
    private Label channelPOSMidBarId;
    @Autowired
    private Label channelPOSLowBarId;
    @Autowired
    private Label channelPOSBonusTopBarId;
    @Autowired
    private Label channelPOSBonusMidBarId;
    @Autowired
    private Label channelPOSBonusLowBarId;
    @Autowired
    private Label posChanelTotalId;
    @Autowired
    private Label valueOfGivenCreditId;
    @Autowired
    private Label valueOfGivenCreditPlanId;
    @Autowired
    private Label valueOfGivenCreditNewAutoFactId;
    @Autowired
    private Label valueOfGivenCreditNewAutoPlanId;
    @Autowired
    private Label valueOfGivenCreditPlanOldId;
    @Autowired
    private Label valueOfGivenCreditOldAutoFactId;
    @Autowired
    private Label valueOfGivenCreditOldAutoPlanId;
    @Autowired
    private Label valueOfGivenCreditFactOldId;
    @Autowired
    private Screens screens;

    @Autowired
    private GroupBoxLayout onlainSmartbankId;

    List<Contracts> zaimPdfCount = new ArrayList<Contracts>();
    @Autowired
    private ProgressBar channelPOSTopBar;
    @Autowired
    private ProgressBar channelPOSMidBar;
    @Autowired
    private ProgressBar channelPOSLowBar;

    @Autowired
    private ProgressBar channelPOSBonusTopBar;
    @Autowired
    private ProgressBar channelPOSBonusMidBar;
    @Autowired
    private ProgressBar channelPOSBonusLowBar;

    @Autowired
    private ProgressBar valueOfGivenCreditBar;

    @Autowired
    private ProgressBar valueOfGivenCreditOldBar;
    @Autowired
    private ProgressBar pointValuePlanZaimCountLoyaltyBar;
    @Autowired
    private ProgressBar pointValuePlanZaimCountUCLREFBar;
    @Autowired
    private ProgressBar pointValuePlanZaimCountUnsCLBar;
    @Autowired
    private ProgressBar pointValuePlanZaimCountPRLBar;
    @Autowired
    private ProgressBar pointValuePlanZaimSumLoyaltyBar;
    @Autowired
    private ProgressBar pointValuePlanZaimSumUCLREFBar;
    @Autowired
    private ProgressBar pointValuePlanZaimSumUnsCLBar;
    @Autowired
    private ProgressBar pointValuePlanZaimSumPRLBar;
    List<PointUser> pointUserList = new ArrayList<>();
    @Autowired
    private ProgressBar creditLowBar;
    @Autowired
    private Label creditLowBarId;
    @Autowired
    private Label creditTopBarId;
    @Autowired
    private ProgressBar creditTopBar;
    @Autowired
    private ProgressBar creditMidBar;
    @Autowired
    private Label creditMidBarId;
    @Autowired
    private Label creditBonusLowBarId;
    @Autowired
    private ProgressBar creditBonusLowBar;
    @Autowired
    private Label creditBonusMidBarId;
    @Autowired
    private ProgressBar creditBonusMidBar;
    @Autowired
    private Label creditBonusTopBarId;
    @Autowired
    private ProgressBar creditBonusTopBar;

    @Autowired
    private Label zaimPdfCountId;
    @Autowired
    private CollectionContainer<AwardUser> kpiAwardUserDc;
    @Autowired
    private EmployeeService employeeService;


    @Subscribe
    private void onInit(InitEvent event) {

        String[] monthNames = {"январь", "февраль",
                "март", "апрель", "май", "июнь", "июль",
                "август", "сентябрь", "октябрь", "ноябрь",
                "декабрь"};

        Calendar c = Calendar.getInstance();
        c.set(Calendar.DAY_OF_MONTH, 1);
        Date theDate1 = c.getTime();
        Calendar oldMonth = Calendar.getInstance();
        oldMonth.set(Calendar.MONTH, oldMonth.get(Calendar.MONTH) - 1);
        oldDataButton.setCaption(monthNames[oldMonth.get(Calendar.MONTH)]);
        selectedDate = theDate1;
        Calendar c1 = Calendar.getInstance();
        c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) - 1);
        c1.set(Calendar.DAY_OF_MONTH, 1);
        Date theDateMinDayCurrentMonth = c1.getTime();
        liveDataButton.addClickListener(clickEvent -> {
            zaimPdfCount = proBonusService.zaimPdfCount(accountId, theDate1);
            zaimPdfCountId.setValue(zaimPdfCount.size());
            zaimPdfId.setValue(zaimPdfCount.size());
            selectedDate = theDate1;
            selectedCurrentMonthDate = null;

            premialCardDate.setValue("За период: " + monthNames[c.get(Calendar.MONTH)]);
            clearBonuses();
            clearLabelsBar();
            pointUserList = proBonusService.reloadPointUserByPN(accountId, theDate1);
            setDataFromList();
            setData();
        });
        premialCardDate.setValue("За период: " + monthNames[c.get(Calendar.MONTH)]);
        oldDataButton.addClickListener(clickEvent -> {

            Calendar myCal = Calendar.getInstance();
            myCal.set(Calendar.MONTH, myCal.get(Calendar.MONTH) - 1);
            premialCardDate.setValue("За период: " + monthNames[myCal.get(Calendar.MONTH)]);
            myCal.set(Calendar.DAY_OF_MONTH, myCal.getActualMaximum(Calendar.DAY_OF_MONTH));

            zaimPdfCount = proBonusService.zaimPdfCountOld(accountId, theDateMinDayCurrentMonth, theDate1);
            zaimPdfCountId.setValue(zaimPdfCount.size());
            zaimPdfId.setValue(zaimPdfCount.size());
            Date theDate = c1.getTime();
            selectedDate = theDate;
            selectedCurrentMonthDate = theDateMinDayCurrentMonth;
            pointUserList = proBonusService.reloadPointUserOldDate(accountId, theDate1, theDate);
            clearBonuses();
            clearLabelsBar();
            setDataFromList();
            setData();
        });
        ScreenOptions options = event.getOptions();

        if (options instanceof RatingUserOptions) {
            accountId = ((RatingUserOptions) options).getAccountId();
            loadAward();
            fio = ((RatingUserOptions) options).getFio();
            if (fio != null) {
                usernameId.setValue(fio);
            }
            if (accountId != null) {
                Accounts accountIdByPayroll = proBonusService.reloadAccountById(accountId);
                pointUserList = proBonusService.reloadPointUserByPN(accountId, theDate1);
                if (accountIdByPayroll.getProfileId() != null) {
                    departmentId.setValue(accountIdByPayroll.getProfileId().getDepName());
                }
                clearBonuses();
                clearLabelsBar();
                pointUserPoint = proBonusService.reloadRatingUserAuthority(accountId, POINT_USER_POINT);
                setDataFromList();
                zaimPdfCount = proBonusService.zaimPdfCount(accountId, theDate1);
                zaimPdfCountId.setValue(zaimPdfCount.size());
                zaimPdfId.setValue(zaimPdfCount.size());

                setData();
            }
        } else {
            currentUserName = currentUserSubstitution.getEffectiveUser().getUsername();
            loadCurrentEmployee();
            Accounts accountIdByPayroll = proBonusService.reloadAccountsByPayroll(employee.getPayrollNumber());


            if (accountIdByPayroll != null && accountIdByPayroll.getId() != null) {
                accountId = accountIdByPayroll.getId();
                loadAward();
                fio = employee.getFullName();
                pointUserList = proBonusService.reloadPointUserByPN(accountId, theDate1);

                AccountVisits visitor = proBonusService.searchVisitByAccount(accountId);
                if (visitor == null) {
                    AccountVisits visits = dataManager.create(AccountVisits.class);
                    visits.setAccountId(accountId);
                    visits.setFio(fio);
                    visits.setVisited_at(new Date());
                    visits.setBranch((accountIdByPayroll.getProfileId().getBranchName() != null ? accountIdByPayroll.getProfileId().getBranchName() : ""));
                    visits.setPosition((accountIdByPayroll.getProfileId().getPosition() != null ? accountIdByPayroll.getProfileId().getPosition() : ""));
                    visits.setDepartment((accountIdByPayroll.getProfileId().getDepName() != null ? accountIdByPayroll.getProfileId().getDepName() : ""));
                    dataManager.save(visits);
                }

                clearBonuses();
                clearLabelsBar();

                setDataFromList();

                if (accountIdByPayroll.getProfileId() != null) {
                    departmentId.setValue(accountIdByPayroll.getProfileId().getDepName());
                }
                if (fio != null) {
                    usernameId.setValue(fio);
                }
                zaimPdfCount = proBonusService.zaimPdfCount(accountId, theDate1);
                zaimPdfCountId.setValue(zaimPdfCount.size());
                zaimPdfId.setValue(zaimPdfCount.size());
                pointUserPoint = proBonusService.reloadRatingUserAuthority(accountId, POINT_USER_POINT);
                setData();
            }
        }


    }

    private void loadAward() {
        List<AwardUser> awardUserList = new ArrayList<>();
        try {
            awardUserList = dataManager.load(AwardUser.class)
                    .query("select c from kpi_AwardUser c where c.accountId = :accountId")
                    .parameter("accountId", accountId)
                    .list();
        } catch (Exception e) {
            System.out.println(e);
        }
        if (awardUserList.size() > 0) {
            awardUserList.forEach(awardUser -> {
                Employee employee1 = employeeService.reloadEmployeeById(awardUser.getEmployee());
                Award award = proBonusService.reloadAwardById(awardUser.getAwardId());
                if (award != null) {
                    awardUser.setCreatedBy(award.getTitle());
                    awardUser.setVersion(award.getPoints() != null ? award.getPoints().intValue() : 0);
                }
                awardUser.setEntityClass(employee1.getFullName());
            });
            kpiAwardUserDc.getMutableItems().clear();
            kpiAwardUserDc.getMutableItems().addAll(awardUserList);

        }

    }

    private void clearLabelsBar() {
        pointUserPREMIOLDAUTODEBETBar.clear();
        pointUserPREMINEWAUTODEBETBar.clear();
        pointUserPREMINEWAUTOBar.clear();
        pointUserPREMIOLDAUTOBar.clear();
        debetPremiType1Bar.clear();
        debetPremiType2Bar.clear();
        debetPremiType3Bar.clear();
        debetPremiType4Bar.clear();
        debetPremiBonus1Bar.clear();
        debetPremiBonus2Bar.clear();
        debetPremiBonus3Bar.clear();
        debetPremiBonus4Bar.clear();
        planPrirostBarId.clear();
        debetPremiProgressId.clear();
        proniknovenieBarId.clear();
        planId.setValue("0");
        planOnlainId.setValue("0");
        factOnlainId.setValue("0");
        factId.setValue("0");
        smartbankTotalPremiId.setValue("0");
        pointUserShowId.setValue("0");
        pointUserPREMINEWAUTODEBETId.setValue("0");
        pointUserPREMIOLDAUTODEBETId.setValue("0");
        pointUserPREMIDEBETCOUNTId.setValue("0");
        pointUserPREMINEWAUTOId.setValue("0");
        pointUserPREMIOLDAUTOId.setValue("0");
        totalPremiValueId.setValue("");
        totalPremiORBId.setValue("0");
        lastModifyDate.setValue(selectedDate);
        smsDsCount.setValue("0");
        smsAutoCount.setValue("0");
        smsPosCount.setValue("0");
        smsDs.setValue("");
        smsAuto.setValue("");
        smsPos.setValue("");
        debetPremiId.setValue("0");
        debetPremiType1.setValue("0");
        debetPremiType2.setValue("0");
        debetPremiType3.setValue("0");
        debetPremiType4.setValue("0");
        debetPremiBonus1.setValue("0");
        debetPremiBonus2.setValue("0");
        debetPremiBonus3.setValue("0");
        debetPremiBonus4.setValue("0");
        newDebetCountId.setValue("0");
        newDebetPremiId.setValue("0");
        salaryActivationCountId.setValue("0");
        salaryActivationPlanId.setValue("0");
        salaryActivationPremiId.setValue("0");
        creditPremiId.setValue("0");
        creditTotalSumId.setValue("0");
        proniknoviePlanId.setValue("0");
        proniknoveineFactId.setValue("0");

        premialCardTotalId.setValue("0");
        premialCardId.setValue("0");
        pointPenaltyId.setValue("0");
        premialCardActiveId.setValue("0");
        pointPremialCardPremiId.setValue("0");
        channelPOSTopBarId.setValue("0");
        channelPOSMidBarId.setValue("0");
        channelPOSLowBarId.setValue("0");
        channelPOSBonusTopBarId.setValue("0");
        channelPOSBonusMidBarId.setValue("0");
        channelPOSBonusLowBarId.setValue("0");
        posChanelTotalId.setValue("0");
        valueOfGivenCreditId.setValue("0");
        valueOfGivenCreditPlanId.setValue("0");
        valueOfGivenCreditNewAutoFactId.setValue("0");
        valueOfGivenCreditNewAutoPlanId.setValue("0");
        valueOfGivenCreditPlanOldId.setValue("0");
        valueOfGivenCreditOldAutoFactId.setValue("0");
        valueOfGivenCreditOldAutoPlanId.setValue("0");
        valueOfGivenCreditFactOldId.setValue("0");
    }

    private void clearBonuses() {
        pointUserTotalBonus = new PointUser();
        pointProniknovenie = new PointUser();
        pointUserSmartbank = new PointUser();
        pointUserSmartbankOnlain = new PointUser();
        pointUserSmartbankTotal = new PointUser();
        pointUserPREMISHOW = new PointUser();
        pointUserPREMIDEBETCOUNT = new PointUser();
        pointUserPREMISHOW = new PointUser();
        pointUserPREMIOLDAUTODEBET = new PointUser();
        pointUserPREMINEWAUTO = new PointUser();
        pointUserPREMIOLDAUTO = new PointUser();
        pointUserSMSDS = new PointUser();
        pointUserSMSAUTO = new PointUser();
        pointUserSMSPOS = new PointUser();
        pointUserSMSDSCOUNT = new PointUser();
        pointUserSMSAUTOCOUNT = new PointUser();
        pointUserSMSPOSCOUNT = new PointUser();
        pointUserPosChanelTopSum = new PointUser();
        pointUserPosChanelMidSum = new PointUser();
        pointUserPosChanelLowSum = new PointUser();
        pointUserPosChanelTopBonus = new PointUser();
        pointUserPosChanelMidBonus = new PointUser();
        pointUserPosChanelLowBonus = new PointUser();
        ;
        pointUserPosChanelTotal = new PointUser();
        pointUserDebetPremi = new PointUser();
        pointUserDebetPremiType1 = new PointUser();
        pointUserDebetPremiType2 = new PointUser();
        pointUserDebetPremiType3 = new PointUser();
        pointUserDebetPremiType4 = new PointUser();
        pointUserDebetPremiBonus1 = new PointUser();
        pointUserDebetPremiBonus2 = new PointUser();
        pointUserDebetPremiBonus3 = new PointUser();
        pointUserDebetPremiBonus4 = new PointUser();
        pointValuePlanZaimSumPRL = new PointUser();
        pointValuePlanZaimSumLoyalty = new PointUser();
        pointValuePlanZaimSumUnsCL = new PointUser();
        pointValuePlanZaimSumUCLREF = new PointUser();
        pointValuePlanZaimCountPRL = new PointUser();
        pointValuePlanZaimCountLoyalty = new PointUser();
        pointValuePlanZaimCountUnsCL = new PointUser();
        pointValuePlanZaimCountUCLREF = new PointUser();
        pointValuePlanZaimTotal = new PointUser();
        pointUserNewDebetCount = new PointUser();
        pointUserNewDebetPremi = new PointUser();
        pointUserSalaryActivationCount = new PointUser();
        pointUserSalaryActivationPlan = new PointUser();
        pointPremialCardTotal = new PointUser();
        pointPremialCard = new PointUser();
        pointPremialCardPremi = new PointUser();
        pointActiveCardCount = new PointUser();
        pointPenalty = new PointUser();
        pointUserValueGivenCreditNewAuto = new PointUser();
        pointUserValueGivenCreditOldAuto = new PointUser();
        pointUserValueGivenCreditNewAutoPlan = new PointUser();
        pointUserValueGivenCreditOldAutoPlan = new PointUser();
    }

    private void setDataFromList() {
        if (pointUserList.size() > 0) {
            pointUserList.forEach(pointUser -> {
                switch (pointUser.getTypeId()) {
                    case POINT_TOTAL_PREMI: {
                        pointUserTotalBonus = pointUser;
                    }
                    break;
                    case POINT_PRONIKNOVENIE: {
                        pointProniknovenie = pointUser;
                    }
                    break;
                    case POINT_SMARTBANK: {
                        pointUserSmartbank = pointUser;
                    }
                    break;
                    case POINT_SMARTBANK_ONLAIN: {
                        pointUserSmartbankOnlain = pointUser;
                    }
                    break;
                    case POINT_SMARTBANKTOTAL: {
                        pointUserSmartbankTotal = pointUser;
                    }
                    break;
                    case POINT_PREMI_FOR_SHOW: {
                        pointUserPREMISHOW = pointUser;
                    }
                    break;
                    case POINT_DEBET_COUNT: {
                        pointUserPREMIDEBETCOUNT = pointUser;
                    }
                    break;
                    case POINT_NEW_AUTO_DEBET: {
                        pointUserPREMINEWAUTODEBET = pointUser;
                    }
                    break;
                    case POINT_OLD_AUTO_DEBET: {
                        pointUserPREMIOLDAUTODEBET = pointUser;
                    }
                    break;
//                    ---
                    case POINT_NEW_AUTO: {
                        pointUserPREMINEWAUTO = pointUser;
                    }
                    break;
                    case POINT_OLD_AUTO: {
                        pointUserPREMIOLDAUTO = pointUser;
                    }
                    break;
                    case SMS_DS: {
                        pointUserSMSDS = pointUser;
                    }
                    break;
                    case SMS_AUTO_SUM: {
                        pointUserSMSAUTO = pointUser;
                    }
                    break;
                    case SMS_POS_SUM: {
                        pointUserSMSPOS = pointUser;
                    }
                    break;
                    case DEBET_COUNT_BONUS_SUM: {
                        creditTotalSumId.setValue(pointUser.getValue());
                    }
                    break;
                    case SMS_DS_COUNT: {
                        pointUserSMSDSCOUNT = pointUser;
                    }
                    break;
                    //                    ---
                    case SMS_AUTO_COUNT: {
                        pointUserSMSAUTOCOUNT = pointUser;
                    }
                    break;
                    case SMS_POS_COUNT: {
                        pointUserSMSPOSCOUNT = pointUser;
                    }
                    break;
                    case POS_CHANEL_TOP_SUM: {
                        pointUserPosChanelTopSum = pointUser;
                    }
                    break;
                    case POS_CHANEL_MID_SUM: {
                        pointUserPosChanelMidSum = pointUser;
                    }
                    break;
                    //                    ---
                    case POS_CHANEL_LOW_SUM: {
                        pointUserPosChanelLowSum = pointUser;
                    }
                    break;
                    case POS_CHANEL_TOP_BONUS: {
                        pointUserPosChanelTopBonus = pointUser;
                    }
                    break;
                    case POS_CHANEL_MID_BONUS: {
                        pointUserPosChanelMidBonus = pointUser;
                    }
                    break;
                    case POS_CHANEL_LOW_BONUS: {
                        pointUserPosChanelLowBonus = pointUser;
                    }
                    break;
                    //                    ---
                    case POS_CHANEL_TOTAl: {
                        pointUserPosChanelTotal = pointUser;
                    }
                    break;
                    case DEBET_PREMI: {
                        pointUserDebetPremi = pointUser;
                    }
                    break;
                    case DEBET_PREMI_TYPE_1: {
                        pointUserDebetPremiType1 = pointUser;
                    }
                    break;
                    case DEBET_PREMI_TYPE_2: {
                        pointUserDebetPremiType2 = pointUser;
                    }
                    break;
                    //                    ---
                    case DEBET_PREMI_TYPE_3: {
                        pointUserDebetPremiType3 = pointUser;
                    }
                    break;
                    case DEBET_PREMI_TYPE_4: {
                        pointUserDebetPremiType4 = pointUser;
                    }
                    break;
                    case DEBET_PREMI_BONUS_1: {
                        pointUserDebetPremiBonus1 = pointUser;
                    }
                    break;
                    case POINT_VALUE_PLAN_ZAIM_TOTAL: {
                        pointValuePlanZaimTotal = pointUser;
                    }
                    break;
                    case POINT_VALUE_PLAN_ZAIM_SUM_PRL: {
                        pointValuePlanZaimSumPRL = pointUser;
                    }
                    break;
                    case POINT_VALUE_PLAN_ZAIM_SUM_Loyalty: {
                        pointValuePlanZaimSumLoyalty = pointUser;
                    }
                    break;
                    case POINT_VALUE_PLAN_ZAIM_SUM_UCLREF: {
                        pointValuePlanZaimSumUCLREF = pointUser;
                    }
                    break;
                    case POINT_VALUE_PLAN_ZAIM_SUM_UnsCL: {
                        pointValuePlanZaimSumUnsCL = pointUser;
                    }
                    break;
                    case POINT_VALUE_PLAN_ZAIM_COUNT_PRL: {
                        pointValuePlanZaimCountPRL = pointUser;
                    }
                    break;
                    case POINT_VALUE_PLAN_ZAIM_COUNT_Loyalty: {
                        pointValuePlanZaimCountLoyalty = pointUser;
                    }
                    break;
                    case POINT_VALUE_PLAN_ZAIM_COUNT_UCLREF: {
                        pointValuePlanZaimCountUCLREF = pointUser;
                    }
                    break;
                    case POINT_VALUE_PLAN_ZAIM_COUNT_UnsCL: {
                        pointValuePlanZaimCountUnsCL = pointUser;
                    }
                    break;
                    case DEBET_PREMI_BONUS_2: {
                        pointUserDebetPremiBonus2 = pointUser;
                    }
                    break;
                    //                    ---
                    case DEBET_PREMI_BONUS_3: {
                        pointUserDebetPremiBonus3 = pointUser;
                    }
                    break;
                    case DEBET_PREMI_BONUS_4: {
                        pointUserDebetPremiBonus4 = pointUser;
                    }
                    break;
                    case NEW_DEBET_COUNT: {
                        pointUserNewDebetCount = pointUser;
                    }
                    break;
                    case NEW_DEBET_PREMI: {
                        pointUserNewDebetPremi = pointUser;
                    }
                    break;
                    //                    ---
                    case SALARY_ACTIVATION_COUNT: {
                        pointUserSalaryActivationCount = pointUser;
                    }
                    break;
                    case SALARY_ACTIVATION_PLAN: {
                        pointUserSalaryActivationPlan = pointUser;
                    }
                    break;
                    case POINT_PREMIAL_CARD_TOTAL: {
                        pointPremialCardTotal = pointUser;
                    }
                    break;
                    case POINT_PREMIAL_CARD: {
                        pointPremialCard = pointUser;
                    }
                    break;
                    //                    ---
                    case POINT_PREMIAL_CARD_PREMI: {
                        pointPremialCardPremi = pointUser;
                    }
                    break;
                    case POINT_ACTIVE_CARD_COUNT: {
                        pointActiveCardCount = pointUser;
                    }
                    break;
                    case POINT_SHTRAFT: {
                        pointPenalty = pointUser;
                    }
                    break;
                    case POINT_VALUE_GIVEN_CREDIT_NEW_AUTO: {
                        pointUserValueGivenCreditNewAuto = pointUser;
                    }
                    break;
                    case POINT_VALUE_GIVEN_CREDIT_OLD_AUTO: {
                        pointUserValueGivenCreditOldAuto = pointUser;
                    }
                    break;
                    case POINT_VALUE_GIVEN_CREDIT_NEW_AUTO_PLAN: {
                        pointUserValueGivenCreditNewAutoPlan = pointUser;
                    }
                    break;
                    case POINT_VALUE_GIVEN_CREDIT_OLD_AUTO_PLAN: {
                        pointUserValueGivenCreditOldAutoPlan = pointUser;
                    }
                    break;
                }
            });
        }
    }

    private void loadCurrentEmployee() {
        FetchPlan fetchPlan = geUserFetchPlan();
        UserDetails user = currentUserSubstitution.getEffectiveUser();
        employee = dataManager.load(Employee.class)
                .query("select c from kpi_Employee c " +
                        "where c.username = :username")
                .parameter("username", user.getUsername())
                .fetchPlan(fetchPlan)
                .optional().orElse(dataManager.create(Employee.class));
        var emplId = employee.getId();
        loadEmployee(emplId);
    }

    private void loadEmployee(UUID emplId) {
        FetchPlan fetchPlan = geUserFetchPlan();
        UserDetails user = currentUserSubstitution.getEffectiveUser();
        employee = dataManager.load(Employee.class)
                .query("select c from kpi_Employee c " +
                        "where c.id = :id")
                .parameter("id", emplId)
                .fetchPlan(fetchPlan)
                .optional().orElse(dataManager.create(Employee.class));
    }

    private FetchPlan geUserFetchPlan() {
        return fetchPlans.builder(Employee.class)
                .addFetchPlan(FetchPlan.BASE)
                .add("payrollNumber", FetchPlan.BASE)
                .build();
    }

    void setData() {
        Accounts accounts = proBonusService.reloadAccountById(accountId);
        Employee employee = proBonusService.reloadEmployeeByPayroll(accounts.getIdentityProperty());

        if (pointUserPoint != null && pointUserPoint.getId() > 0 && pointUserPoint.getValue() != null) {
            if (pointUserPoint.getCreatedAt() != null) lastModifyDate.setValue(pointUserPoint.getCreatedAt());
            pointId.setValue(pointUserPoint.getValue());
        } else {
            pointId.setValue(0);
        }
        if (pointUserTotalBonus != null) {
            if (pointUserTotalBonus.getCreatedAt() != null) lastModifyDate.setValue(pointUserTotalBonus.getCreatedAt());
            totalPremiBonus = pointUserTotalBonus.getValue();
            totalPremiValueId.setValue(totalPremiBonus);
            totalPremiORBId.setValue(totalPremiBonus);
            salaryActivationPremiId.setValue(totalPremiBonus);
        }

        if (employee != null && employee.getPosition().getName() != null) {
            AccountProfiles profiles = proBonusService.reloadAccountProfileById(accountId);
            positionId.setValue(profiles.getPosition());
            setFalseAllWidgets();

            if (accounts.getProfileId().getDepName().equals("Отдел потребительского кредитования")) {
                dep = 1;
            } else if (accounts.getProfileId().getDepName().equals("Отдел продаж зарплатных проектов")) {
                dep = 2;
            } else if (accounts.getProfileId().getDepName().equals("Отдел автокредитования")) {
                dep = 3;
            }
            if (dep == 0) {
                dep = 4;
            }

            if (dep == 3) {
                if (positionId.getValue().equals("Ведущий финансовый консультант") ||
                        positionId.getValue().equals("Финансовый консультант")) {
                    isAuto = true;
                    carPremiId.setVisible(true);
                    smartbankId.setVisible(true);
                    smsId.setVisible(true);
                    debetPosId.setVisible(true);
                    cardId.setVisible(true);
                    debetStrahovkaId.setVisible(true);
                    onlainSmartbankId.setVisible(false);
                    cardId.setVisible(true);
                } else if (positionId.getValue().equals("Начальник отдела")) {
                    pokazatelNPSId.setVisible(true);
                    debetStrahovkaId.setVisible(true);
                    obiemCreditOldCarId.setVisible(true);
                    obiemCreditNewCarId.setVisible(true);
                    debetPosId.setVisible(true);
                    smsId.setVisible(true);
                } else if (positionId.getValue().equals("Менеджер по развитию бизнеса")) {
                    pokazatelNPSId.setVisible(true);
                    debetStrahovkaId.setVisible(true);
                    obiemCreditOldCarId.setVisible(true);
                    obiemCreditNewCarId.setVisible(true);
                    debetPosId.setVisible(true);
                    smsId.setVisible(true);
                } else {
                    cardId.setVisible(true);
                    smartbankId.setVisible(true);
                    smsId.setVisible(true);
                    debetPosId.setVisible(true);
                    debetStrahovkaId.setVisible(true);

                }
            } else if (dep == 2) {
                pointUserPREMIDEBETCOUNTId.setValue(0);
                if (profiles.getPosition().equals("Менеджер по развитию бизнеса")) {
                    salaryCardActivationId.setVisible(true);
                    smartbankId.setVisible(true);
                } else if (positionId.getValue().equals("Главный специалист")) {
                    planPrirostId.setVisible(true);
                    planObiemId.setVisible(true);
                } else if (positionId.getValue().equals("Начальник отдела")) {
                    planPrirostId.setVisible(true);
                    planObiemId.setVisible(true);
                    planVydachaId.setVisible(true);
                    proniknovenieId.setVisible(true);
                    smsId.setVisible(true);
                } else if (positionId.getValue().equals("Финансовый консультант")) {
                    orbId.setVisible(true);
                    cardId.setVisible(true);
                    carPremiId.setVisible(true);
                    proniknovenieId.setVisible(true);
                    smsId.setVisible(true);
                    onlainSmartbankId.setVisible(false);
                } else {
                    planPrirostId.setVisible(true);
                    planObiemId.setVisible(true);
                    planVydachaId.setVisible(true);
                    proniknovenieId.setVisible(true);
                    smsId.setVisible(true);
                }
            } else if (dep == 1) {
                pointUserPREMIDEBETCOUNTId.setValue(0);
                if (profiles.getPosition().equals("Менеджер по развитию бизнеса")) {

                } else if (profiles.getPosition().equals("Начальник отдела")) {

                } else if (profiles.getPosition().equals("Заведующий сектором")) {

                } else if (profiles.getPosition().equals("Финансовый консультант")) {
                    debetPosId.setVisible(true);
                    smartbankId.setVisible(true);
                    smsId.setVisible(true);
                    zaimFDP.setVisible(true);
                    cardId.setVisible(true);
                    onlainSmartbankId.setVisible(false);
                } else if (profiles.getPosition().equals("Старший финансовый консультант")) {
                    creditId.setVisible(true);
                    smartbankId.setVisible(true);
                    smsId.setVisible(true);
//                    carPremiId.setVisible(true);
                    cardId.setVisible(true);
                    zaimFDP.setVisible(true);
                    proniknovenieId.setVisible(true);
                } else if (profiles.getPosition().equals("Ведущий финансовый консультант")) {
                    smartbankId.setVisible(true);
                    creditId.setVisible(true);
                    smsId.setVisible(true);
                    proniknovenieId.setVisible(true);
                    zaimFDP.setVisible(true);
                }
            } else {
                pointUserPREMIDEBETCOUNTId.setValue(0);
                if (positionId.getValue().equals("Ведущий финансовый консультант")) {

                    orbId.setVisible(true);
                    smartbankId.setVisible(true);
                    smsId.setVisible(true);
                    proniknovenieId.setVisible(true);
                    debetPosId.setVisible(true);
                    newPremialCardId.setVisible(true);
                    cardId.setVisible(true);
                    newPremialCardId.setVisible(true);
                    cardConvertationId.setVisible(true);
                } else if (positionId.getValue().equals("Начальник мини-офиса")) {
                    pokazatelNPSId.setVisible(true);
                    planPRL.setVisible(true);
                    smsId.setVisible(true);
                    proniknovenieId.setVisible(true);
                } else if (positionId.getValue().equals("Старший финансовый консультант")) {

                    orbId.setVisible(true);
                    smartbankId.setVisible(true);
                    smsId.setVisible(true);
                    newPremialCardId.setVisible(true);
                    proniknovenieId.setVisible(true);
                    cardConvertationId.setVisible(true);
                    onlainSmartbankId.setVisible(false);
                    cardId.setVisible(true);
                } else if (positionId.getValue().equals("Начальник отделения")) {
                    pokazatelNPSId.setVisible(true);
                    zaimFDP.setVisible(true);
                    planPRL.setVisible(true);
                    planVypushennyxCartId.setVisible(true);
                    smsId.setVisible(true);
                    proniknovenieId.setVisible(true);
                } else if (positionId.getValue().equals("Ведущий финансовый консультант мини-офиса")) {
                    cardId.setVisible(true);
                    planPRL.setVisible(true);
                    smartbankId.setVisible(true);
                } else if (positionId.getValue().equals("Офис-менеджер")) {
                    smartbankId.setVisible(true);
                } else {
                    pokazatelNPSId.setVisible(true);
                    zaimFDP.setVisible(true);
                    smsId.setVisible(true);
                    proniknovenieId.setVisible(true);
                    creditId.setVisible(true);
                    smartbankId.setVisible(true);
                    cardId.setVisible(true);
                }
            }
        }

        if (employee != null && employee.getDepName() != null) {
            branchId.setValue(accounts.getProfileId().getDepName());
        }


        if (pointUserDebetPremi != null) {
            if (pointUserDebetPremi.getCreatedAt() != null) lastModifyDate.setValue(pointUserDebetPremi.getCreatedAt());
            debetPremiId.setValue(pointUserDebetPremi.getValue());
        }
        pointValuePlanZaimCountLoyaltyBar.clear();
        pointValuePlanZaimCountUCLREFBar.clear();
        pointValuePlanZaimCountUnsCLBar.clear();
        pointValuePlanZaimCountPRLBar.clear();
        pointValuePlanZaimSumLoyaltyBar.clear();
        pointValuePlanZaimSumUCLREFBar.clear();
        pointValuePlanZaimSumUnsCLBar.clear();
        pointValuePlanZaimSumPRLBar.clear();

        double maxPlanZaimSum = 0;
        double maxPlanZaimCount = 0;
        if (pointValuePlanZaimTotal != null) {
            if (pointValuePlanZaimTotal.getCreatedAt() != null)
                lastModifyDate.setValue(pointValuePlanZaimTotal.getCreatedAt());
            pointValuePlanZaimTotalId.setValue(pointValuePlanZaimTotal.getValue());
        }
        if (pointValuePlanZaimSumPRL != null && pointValuePlanZaimSumPRL.getValue() != null) {
            if (pointValuePlanZaimSumPRL.getCreatedAt() != null)
                lastModifyDate.setValue(pointValuePlanZaimSumPRL.getCreatedAt());
            pointValuePlanZaimSumPRLId.setValue(pointValuePlanZaimSumPRL.getValue());
            if (pointValuePlanZaimSumPRL.getValue() > maxPlanZaimSum)
                maxPlanZaimSum = pointValuePlanZaimSumPRL.getValue();
        }
        if (pointValuePlanZaimSumUnsCL != null && pointValuePlanZaimSumUnsCL.getValue() != null) {
            if (pointValuePlanZaimSumUnsCL.getCreatedAt() != null)
                lastModifyDate.setValue(pointValuePlanZaimSumUnsCL.getCreatedAt());
            pointValuePlanZaimSumUnsCLId.setValue(pointValuePlanZaimSumUnsCL.getValue());
            if (pointValuePlanZaimSumUnsCL.getValue() > maxPlanZaimSum)
                maxPlanZaimSum = pointValuePlanZaimSumUnsCL.getValue();
        }
        if (pointValuePlanZaimSumUCLREF != null && pointValuePlanZaimSumUCLREF.getValue() != null) {
            if (pointValuePlanZaimSumUCLREF.getCreatedAt() != null)
                lastModifyDate.setValue(pointValuePlanZaimSumUCLREF.getCreatedAt());

            pointValuePlanZaimSumUCLREFId.setValue(pointValuePlanZaimSumUCLREF.getValue());
            if (pointValuePlanZaimSumUCLREF.getValue() > maxPlanZaimSum)
                maxPlanZaimSum = pointValuePlanZaimSumUCLREF.getValue();
        }
        if (pointValuePlanZaimSumLoyalty != null && pointValuePlanZaimSumLoyalty.getValue() != null) {
            if (pointValuePlanZaimSumLoyalty.getCreatedAt() != null)
                lastModifyDate.setValue(pointValuePlanZaimSumLoyalty.getCreatedAt());

            pointValuePlanZaimSumLoyaltyId.setValue(pointValuePlanZaimSumLoyalty.getValue());
            if (pointValuePlanZaimSumLoyalty.getValue() > maxPlanZaimSum)
                maxPlanZaimSum = pointValuePlanZaimSumLoyalty.getValue();
        }
        if (pointValuePlanZaimCountPRL != null && pointValuePlanZaimCountPRL.getValue() != null) {
            if (pointValuePlanZaimCountPRL.getCreatedAt() != null)
                lastModifyDate.setValue(pointValuePlanZaimCountPRL.getCreatedAt());

            pointValuePlanZaimCountPRLId.setValue(pointValuePlanZaimCountPRL.getValue());
            if (pointValuePlanZaimCountPRL.getValue() > maxPlanZaimCount)
                maxPlanZaimCount = pointValuePlanZaimCountPRL.getValue();
        }
        if (pointValuePlanZaimCountUnsCL != null && pointValuePlanZaimCountUnsCL.getValue() != null) {
            if (pointValuePlanZaimCountUnsCL.getCreatedAt() != null)
                lastModifyDate.setValue(pointValuePlanZaimCountUnsCL.getCreatedAt());

            pointValuePlanZaimCountUnsCLId.setValue(pointValuePlanZaimCountUnsCL.getValue());
            if (pointValuePlanZaimCountUnsCL.getValue() > maxPlanZaimCount)
                maxPlanZaimCount = pointValuePlanZaimCountUnsCL.getValue();
        }
        if (pointValuePlanZaimCountUCLREF != null && pointValuePlanZaimCountUCLREF.getValue() != null) {
            if (pointValuePlanZaimCountUCLREF.getCreatedAt() != null)
                lastModifyDate.setValue(pointValuePlanZaimCountUCLREF.getCreatedAt());
            pointValuePlanZaimCountUCLREFId.setValue(pointValuePlanZaimCountUCLREF.getValue());
            if (pointValuePlanZaimCountUCLREF.getValue() > maxPlanZaimCount)
                maxPlanZaimCount = pointValuePlanZaimCountUCLREF.getValue();
        }
        if (pointValuePlanZaimCountLoyalty != null && pointValuePlanZaimCountLoyalty.getValue() != null) {
            if (pointValuePlanZaimCountLoyalty.getCreatedAt() != null)
                lastModifyDate.setValue(pointValuePlanZaimCountLoyalty.getCreatedAt());
            pointValuePlanZaimCountLoyaltyId.setValue(pointValuePlanZaimCountLoyalty.getValue());
            if (pointValuePlanZaimCountLoyalty.getValue() > maxPlanZaimCount)
                maxPlanZaimCount = pointValuePlanZaimCountLoyalty.getValue();
        }


        if (maxPlanZaimSum != 0) {
            double percentage1 = (pointValuePlanZaimSumPRL.getValue().intValue() * 100) / maxPlanZaimSum;
            pointValuePlanZaimSumPRLBar.setValue(percentage1 / 100);

            double percentage2 = (pointValuePlanZaimSumLoyalty.getValue().intValue() * 100) / maxPlanZaimSum;
            pointValuePlanZaimSumLoyaltyBar.setValue(percentage2 / 100);
            double percentage3 = (pointValuePlanZaimSumUCLREF.getValue().intValue() * 100) / maxPlanZaimSum;
            pointValuePlanZaimSumUCLREFBar.setValue(percentage3 / 100);
            double percentage4 = (pointValuePlanZaimSumUnsCL.getValue().intValue() * 100) / maxPlanZaimSum;
            pointValuePlanZaimSumUnsCLBar.setValue(percentage4 / 100);

        }

        if (maxPlanZaimCount != 0) {
            double percentage1 = (pointValuePlanZaimCountPRL.getValue().intValue() * 100) / maxPlanZaimCount;
            pointValuePlanZaimCountPRLBar.setValue(percentage1 / 100);

            double percentage2 = (pointValuePlanZaimCountLoyalty.getValue().intValue() * 100) / maxPlanZaimCount;
            pointValuePlanZaimCountLoyaltyBar.setValue(percentage2 / 100);
            double percentage3 = (pointValuePlanZaimCountUCLREF.getValue().intValue() * 100) / maxPlanZaimCount;
            pointValuePlanZaimCountUCLREFBar.setValue(percentage3 / 100);
            double percentage4 = (pointValuePlanZaimCountUnsCL.getValue().intValue() * 100) / maxPlanZaimCount;
            pointValuePlanZaimCountUnsCLBar.setValue(percentage4 / 100);
        }

//        --------------------------------------
        channelPOSTopBar.clear();
        channelPOSMidBar.clear();
        channelPOSLowBar.clear();
        channelPOSBonusTopBar.clear();
        channelPOSBonusMidBar.clear();
        channelPOSBonusLowBar.clear();

        channelPOSTopBar.setValue(0.0);
        channelPOSMidBar.setValue(0.0);
        channelPOSLowBar.setValue(0.0);
        channelPOSTopBarId.setValue(0.0);
        channelPOSMidBarId.setValue(0.0);
        channelPOSLowBarId.setValue(0.0);
        channelPOSBonusTopBar.setValue(0.0);
        channelPOSBonusMidBar.setValue(0.0);
        channelPOSBonusLowBar.setValue(0.0);
        channelPOSBonusTopBarId.setValue(0.0);
        channelPOSBonusMidBarId.setValue(0.0);
        channelPOSBonusLowBarId.setValue(0.0);
        double maxPosPremiTypeBar = 0;
        double maxPosBonusTypeBar = 0;

        double maxCreditPremiTypeBar = 0;
        double maxCreditBonusTypeBar = 0;
        if (pointUserPosChanelTopSum != null && pointUserPosChanelTopSum.getValue() != null) {
            channelPOSTopBarId.setValue(pointUserPosChanelTopSum.getValue());
            if (pointUserPosChanelTopSum.getValue() > maxPosPremiTypeBar)
                maxPosPremiTypeBar = pointUserPosChanelTopSum.getValue();

            creditTopBarId.setValue(pointUserPosChanelTopSum.getValue());
            if (pointUserPosChanelTopSum.getValue() > maxCreditPremiTypeBar)
                maxCreditPremiTypeBar = pointUserPosChanelTopSum.getValue();
        }

        if (pointUserPosChanelMidSum != null && pointUserPosChanelMidSum.getValue() != null) {
            channelPOSMidBarId.setValue(pointUserPosChanelMidSum.getValue());
            if (pointUserPosChanelMidSum.getValue() > maxPosPremiTypeBar)
                maxPosPremiTypeBar = pointUserPosChanelMidSum.getValue();

            creditMidBarId.setValue(pointUserPosChanelMidSum.getValue());
            if (pointUserPosChanelMidSum.getValue() > maxCreditPremiTypeBar)
                maxCreditPremiTypeBar = pointUserPosChanelMidSum.getValue();
        }

        if (pointUserPosChanelLowSum != null && pointUserPosChanelLowSum.getValue() != null) {
            channelPOSLowBarId.setValue(pointUserPosChanelLowSum.getValue());
            if (pointUserPosChanelTopSum.getValue() > maxPosPremiTypeBar)
                maxPosPremiTypeBar = pointUserPosChanelLowSum.getValue();

            creditLowBarId.setValue(pointUserPosChanelLowSum.getValue());
            if (pointUserPosChanelTopSum.getValue() > maxCreditPremiTypeBar)
                maxCreditPremiTypeBar = pointUserPosChanelLowSum.getValue();
        }

        if (pointUserPosChanelTopBonus != null && pointUserPosChanelTopBonus.getValue() != null) {
            channelPOSBonusTopBarId.setValue(pointUserPosChanelTopBonus.getValue());
            if (pointUserPosChanelTopBonus.getValue() > maxPosBonusTypeBar)
                maxPosBonusTypeBar = pointUserPosChanelTopBonus.getValue();

            creditBonusTopBarId.setValue(pointUserPosChanelTopBonus.getValue());
            if (pointUserPosChanelTopBonus.getValue() > maxCreditBonusTypeBar)
                maxCreditBonusTypeBar = pointUserPosChanelTopBonus.getValue();
        }

        if (pointUserPosChanelMidBonus != null && pointUserPosChanelMidBonus.getValue() != null) {
            channelPOSBonusMidBarId.setValue(pointUserPosChanelMidBonus.getValue());
            if (pointUserPosChanelMidBonus.getValue() > maxPosBonusTypeBar)
                maxPosBonusTypeBar = pointUserPosChanelMidBonus.getValue();

            creditBonusMidBarId.setValue(pointUserPosChanelMidBonus.getValue());
            if (pointUserPosChanelMidBonus.getValue() > maxCreditBonusTypeBar)
                maxCreditBonusTypeBar = pointUserPosChanelMidBonus.getValue();
        }

        if (pointUserPosChanelLowBonus != null && pointUserPosChanelLowBonus.getValue() != null) {
            channelPOSBonusLowBarId.setValue(pointUserPosChanelLowBonus.getValue());
            if (pointUserPosChanelMidBonus.getValue() > maxPosBonusTypeBar)
                maxPosBonusTypeBar = pointUserPosChanelLowBonus.getValue();

            creditBonusLowBarId.setValue(pointUserPosChanelLowBonus.getValue());
            if (pointUserPosChanelMidBonus.getValue() > maxCreditBonusTypeBar)
                maxCreditBonusTypeBar = pointUserPosChanelLowBonus.getValue();
        }

        if (pointUserPosChanelTotal != null) {
            posChanelTotalId.setValue(pointUserPosChanelTotal.getValue());
        }

        if (maxPosBonusTypeBar != 0) {
            double percentagePremiType1 = (pointUserPosChanelTopBonus.getValue().intValue() * 100) / maxPosBonusTypeBar;
            channelPOSBonusTopBar.setValue(percentagePremiType1 / 100);

            double percentagePremiType2 = (pointUserPosChanelMidBonus.getValue().intValue() * 100) / maxPosBonusTypeBar;
            channelPOSBonusMidBar.setValue(percentagePremiType2 / 100);

            double percentagePremiType3 = (pointUserPosChanelLowBonus.getValue().intValue() * 100) / maxPosBonusTypeBar;
            channelPOSBonusLowBar.setValue(percentagePremiType3 / 100);
        }

        if (maxPosPremiTypeBar != 0) {
            double percentagePremiType1 = (pointUserPosChanelTopSum.getValue().intValue() * 100) / maxPosPremiTypeBar;
            channelPOSTopBar.setValue(percentagePremiType1 / 100);

            double percentagePremiType2 = (pointUserPosChanelMidSum.getValue().intValue() * 100) / maxPosPremiTypeBar;
            channelPOSMidBar.setValue(percentagePremiType2 / 100);

            double percentagePremiType3 = (pointUserPosChanelLowSum.getValue().intValue() * 100) / maxPosPremiTypeBar;
            channelPOSLowBar.setValue(percentagePremiType3 / 100);
        }

        if (maxCreditBonusTypeBar != 0) {
            double percentagePremiType1 = (pointUserPosChanelTopBonus.getValue().intValue() * 100) / maxCreditBonusTypeBar;
            creditBonusTopBar.setValue(percentagePremiType1 / 100);

            double percentagePremiType2 = (pointUserPosChanelMidBonus.getValue().intValue() * 100) / maxCreditBonusTypeBar;
            creditBonusMidBar.setValue(percentagePremiType2 / 100);

            double percentagePremiType3 = (pointUserPosChanelLowBonus.getValue().intValue() * 100) / maxCreditBonusTypeBar;
            creditBonusLowBar.setValue(percentagePremiType3 / 100);
        }

        if (maxCreditPremiTypeBar != 0) {
            double percentagePremiType1 = (pointUserPosChanelTopSum.getValue().intValue() * 100) / maxCreditPremiTypeBar;
            creditTopBar.setValue(percentagePremiType1 / 100);

            double percentagePremiType2 = (pointUserPosChanelMidSum.getValue().intValue() * 100) / maxCreditPremiTypeBar;
            creditMidBar.setValue(percentagePremiType2 / 100);

            double percentagePremiType3 = (pointUserPosChanelLowSum.getValue().intValue() * 100) / maxCreditPremiTypeBar;
            creditLowBar.setValue(percentagePremiType3 / 100);
        }
//        --------------------------------------------

        double maxPremiTypeBar = 0;
        double maxBonusTypeBar = 0;
        if (pointUserDebetPremiType1 != null && pointUserDebetPremiType1.getValue() != null) {
            debetPremiType1.setValue(pointUserDebetPremiType1.getValue());
            if (pointUserDebetPremiType1.getValue() > maxPremiTypeBar)
                maxPremiTypeBar = pointUserDebetPremiType1.getValue();
        }

        if (pointUserDebetPremiType2 != null && pointUserDebetPremiType2.getValue() != null) {
            debetPremiType2.setValue(pointUserDebetPremiType2.getValue());
            if (pointUserDebetPremiType2.getValue() > maxPremiTypeBar)
                maxPremiTypeBar = pointUserDebetPremiType2.getValue();
        }
        if (pointUserDebetPremiType3 != null && pointUserDebetPremiType3.getValue() != null) {
            debetPremiType3.setValue(pointUserDebetPremiType3.getValue());
            if (pointUserDebetPremiType3.getValue() > maxPremiTypeBar)
                maxPremiTypeBar = pointUserDebetPremiType3.getValue();
        }

        if (pointUserDebetPremiType4 != null && pointUserDebetPremiType4.getValue() != null) {
            debetPremiType4.setValue(pointUserDebetPremiType4.getValue());
            if (pointUserDebetPremiType4.getValue() > maxPremiTypeBar)
                maxPremiTypeBar = pointUserDebetPremiType4.getValue();
        }


        debetPremiType1Bar.clear();
        debetPremiType2Bar.clear();
        debetPremiType3Bar.clear();
        debetPremiType4Bar.clear();
        debetPremiType1Bar.setValue(0.0);
        debetPremiType2Bar.setValue(0.0);
        debetPremiType3Bar.setValue(0.0);
        debetPremiType4Bar.setValue(0.0);

        if (maxPremiTypeBar != 0) {
            double percentagePremiType1 = (pointUserDebetPremiType1.getValue().intValue() * 100) / maxPremiTypeBar;
            debetPremiType1Bar.setValue(percentagePremiType1 / 100);

            double percentagePremiType2 = (pointUserDebetPremiType2.getValue().intValue() * 100) / maxPremiTypeBar;
            debetPremiType2Bar.setValue(percentagePremiType2 / 100);

            double percentagePremiType3 = (pointUserDebetPremiType3.getValue().intValue() * 100) / maxPremiTypeBar;
            debetPremiType3Bar.setValue(percentagePremiType3 / 100);

            double percentagePremiType4 = (pointUserDebetPremiType4.getValue().intValue() * 100) / maxPremiTypeBar;
            debetPremiType4Bar.setValue(percentagePremiType4 / 100);
        }

//        ----------------

        if (pointUserDebetPremiBonus1 != null && pointUserDebetPremiBonus1.getValue() != null) {
            debetPremiBonus1.setValue(pointUserDebetPremiBonus1.getValue());
            if (pointUserDebetPremiBonus1.getValue() > maxBonusTypeBar)
                maxBonusTypeBar = pointUserDebetPremiBonus1.getValue();
        }

        if (pointUserDebetPremiBonus2 != null && pointUserDebetPremiBonus2.getValue() != null) {
            debetPremiBonus2.setValue(pointUserDebetPremiBonus2.getValue());
            if (pointUserDebetPremiBonus2.getValue() > maxBonusTypeBar)
                maxBonusTypeBar = pointUserDebetPremiBonus2.getValue();
        }
        if (pointUserDebetPremiBonus3 != null && pointUserDebetPremiBonus3.getValue() != null) {
            debetPremiBonus3.setValue(pointUserDebetPremiBonus3.getValue());
            if (pointUserDebetPremiBonus3.getValue() > maxBonusTypeBar)
                maxBonusTypeBar = pointUserDebetPremiBonus3.getValue();
        }

        if (pointUserDebetPremiBonus4 != null && pointUserDebetPremiBonus4.getValue() != null) {
            debetPremiBonus4.setValue(pointUserDebetPremiBonus4.getValue());
            if (pointUserDebetPremiBonus4.getValue() > maxBonusTypeBar)
                maxBonusTypeBar = pointUserDebetPremiBonus4.getValue();
        }

        if (maxPremiTypeBar != 0) {
            double percentagePremiBonus1 = (pointUserDebetPremiBonus1.getValue().intValue() * 100) / maxBonusTypeBar;
            debetPremiBonus1Bar.setValue(percentagePremiBonus1 / 100);

            double percentagePremiBonus2 = (pointUserDebetPremiBonus2.getValue().intValue() * 100) / maxBonusTypeBar;
            debetPremiBonus2Bar.setValue(percentagePremiBonus2 / 100);

            double percentagePremiBonus3 = (pointUserDebetPremiBonus3.getValue().intValue() * 100) / maxBonusTypeBar;
            debetPremiBonus3Bar.setValue(percentagePremiBonus3 / 100);

            double percentagePremiBonus4 = (pointUserDebetPremiBonus4.getValue().intValue() * 100) / maxBonusTypeBar;
            debetPremiBonus4Bar.setValue(percentagePremiBonus4 / 100);
        }

        if (pointUserDebetPremiBonus1 != null) {
            debetPremiBonus1.setValue(pointUserDebetPremiBonus1.getValue());
        }
        if (pointUserDebetPremiBonus2 != null) {
            debetPremiBonus2.setValue(pointUserDebetPremiBonus2.getValue());
        }
        if (pointUserDebetPremiBonus3 != null) {
            debetPremiBonus3.setValue(pointUserDebetPremiBonus3.getValue());
        }
        if (pointUserDebetPremiBonus4 != null) {
            debetPremiBonus4.setValue(pointUserDebetPremiBonus4.getValue());
        }
        if (pointUserSMSDSCOUNT != null) {
            smsDsCount.setValue(pointUserSMSDSCOUNT.getValue());
        }
        if (pointUserSMSAUTOCOUNT != null) {
            smsAutoCount.setValue(pointUserSMSAUTOCOUNT.getValue());
        }
        if (pointUserSMSPOSCOUNT != null) {
            smsPosCount.setValue(pointUserSMSPOSCOUNT.getValue());
        }
        if (pointUserSMSDS != null) {
            smsDs.setValue(pointUserSMSDS.getValue());
        }
        if (pointUserSMSAUTO != null) {
            smsAuto.setValue(pointUserSMSAUTO.getValue());
        }
        if (pointUserSMSPOS != null) {
            smsPos.setValue(pointUserSMSPOS.getValue());
        }

        pointUserPREMINEWAUTOBar.clear();
        pointUserPREMIOLDAUTOBar.clear();
        pointUserPREMINEWAUTOBar.setValue(0.0);
        pointUserPREMIOLDAUTOBar.setValue(0.0);
        pointUserPREMINEWAUTOId.setValue(0);
        pointUserPREMIOLDAUTOId.setValue(0);

        if (pointUserPREMINEWAUTO != null && pointUserPREMINEWAUTO.getValue() != null &&
                pointUserPREMIOLDAUTO != null && pointUserPREMIOLDAUTO.getValue() != null) {
            pointUserPREMINEWAUTOId.setValue(pointUserPREMINEWAUTO.getValue());
            pointUserPREMIOLDAUTOId.setValue(pointUserPREMIOLDAUTO.getValue());
            if (pointUserPREMIOLDAUTO.getValue() != null && pointUserPREMINEWAUTO.getValue() != null &&
                    pointUserPREMINEWAUTO.getValue().compareTo(pointUserPREMIOLDAUTO.getValue()) > 0) {
                pointUserPREMINEWAUTOBar.setValue(1.0);
                if (pointUserPREMIOLDAUTO.getValue() == 0.0) {
                    pointUserPREMIOLDAUTOBar.setValue(0.0);
                } else {
                    double percentage = (pointUserPREMIOLDAUTO.getValue().intValue() * 100) / pointUserPREMINEWAUTO.getValue().intValue();
                    pointUserPREMIOLDAUTOBar.setValue((percentage / 100));
                }

            } else if (pointUserPREMIOLDAUTO.getValue() != null && pointUserPREMINEWAUTO.getValue() != null) {
                pointUserPREMIOLDAUTOBar.setValue(1.0);
                if (pointUserPREMINEWAUTO.getValue() == 0.0) {
                    pointUserPREMINEWAUTOBar.setValue(0.0);
                } else {
                    double percentage = (pointUserPREMINEWAUTO.getValue().intValue() * 100) / pointUserPREMIOLDAUTO.getValue().intValue();
                    pointUserPREMINEWAUTOBar.setValue((percentage / 100));
                }

            }
        }
        pointUserPREMINEWAUTODEBETBar.clear();
        pointUserPREMINEWAUTODEBETBar.setValue(0.0);
        pointUserPREMIOLDAUTODEBETBar.clear();
        pointUserPREMIOLDAUTODEBETBar.setValue(0.0);
        pointUserPREMINEWAUTODEBETId.setValue(0);
        pointUserPREMIOLDAUTODEBETId.setValue(0);
        if (pointUserPREMINEWAUTODEBET != null) {
            pointUserPREMINEWAUTODEBETId.setValue(pointUserPREMINEWAUTODEBET.getValue());
            pointUserPREMIOLDAUTODEBETId.setValue(pointUserPREMIOLDAUTODEBET.getValue());

            if (pointUserPREMINEWAUTODEBET.getValue() != null && pointUserPREMIOLDAUTODEBET.getValue() != null &&
                    pointUserPREMINEWAUTODEBET.getValue().compareTo(pointUserPREMIOLDAUTODEBET.getValue()) > 0) {
                pointUserPREMINEWAUTODEBETBar.setValue(1.0);
                if (pointUserPREMIOLDAUTODEBET.getValue() == 0.0) {
                    pointUserPREMIOLDAUTODEBETBar.setValue(0.0);
                } else {
                    double percentage = (pointUserPREMIOLDAUTODEBET.getValue().intValue() * 100) / pointUserPREMINEWAUTODEBET.getValue().intValue();
                    pointUserPREMIOLDAUTODEBETBar.setValue((percentage / 100));
                }
            } else if (pointUserPREMINEWAUTODEBET.getValue() != null
                    && pointUserPREMIOLDAUTODEBET.getValue() != null) {
                pointUserPREMIOLDAUTODEBETBar.setValue(1.0);
                if (pointUserPREMINEWAUTODEBET.getValue() == 0.0) {
                    pointUserPREMINEWAUTODEBETBar.setValue(0.0);
                } else {
                    double percentage = (pointUserPREMIOLDAUTODEBET.getValue().intValue() * 100) / pointUserPREMINEWAUTODEBET.getValue().intValue();
                    pointUserPREMINEWAUTODEBETBar.setValue((percentage / 100));
                }
            }
        }
        if (pointUserPREMIDEBETCOUNT != null && pointUserPREMIDEBETCOUNT.getPlan() != null
                && pointUserPREMIDEBETCOUNT.getValue() != null) {
            debetPremiProgressId.setValue(pointUserPREMIDEBETCOUNT.getPlan() - pointUserPREMIDEBETCOUNT.getValue() / 100);
            creditPremiId.setValue(pointUserPREMIDEBETCOUNT.getPlan() - pointUserPREMIDEBETCOUNT.getValue());
        }
        if (pointUserPREMIDEBETCOUNT != null) {
            pointUserPREMIDEBETCOUNTId.setValue(pointUserPREMIDEBETCOUNT.getValue());
        }
        if (pointUserNewDebetCount != null) {
            newDebetCountId.setValue(pointUserNewDebetCount.getValue());
        }
        if (pointUserNewDebetPremi != null) {
            newDebetPremiId.setValue(pointUserNewDebetPremi.getValue());
        }
        if (pointUserSalaryActivationCount != null) {
            salaryActivationCountId.setValue(pointUserSalaryActivationCount.getValue());
        }
        if (pointUserSalaryActivationPlan != null) {
            salaryActivationPlanId.setValue(pointUserSalaryActivationPlan.getValue());
        }
        if (pointPremialCardTotal != null) {
            premialCardTotalId.setValue(pointPremialCardTotal.getValue());
        }
        if (pointPremialCard != null) {
            premialCardId.setValue(pointPremialCard.getValue());
        }
        if (pointPremialCardPremi != null) {
            pointPremialCardPremiId.setValue(pointPremialCardPremi.getValue());
        }
        if (pointActiveCardCount != null) {
            premialCardActiveId.setValue(pointActiveCardCount.getValue());
        }
        if (pointPenalty != null && pointPenalty.getValue() != null) {
            pointPenaltyId.setValue(pointPenalty.getValue() + " ₸");
        } else {
            pointPenaltyId.setValue("0 ₸");
        }
        valueOfGivenCreditBar.clear();
        valueOfGivenCreditBar.setValue(0.0);

        valueOfGivenCreditOldBar.clear();
        valueOfGivenCreditOldBar.setValue(0.0);

        if (pointUserValueGivenCreditOldAutoPlan != null && pointUserValueGivenCreditOldAutoPlan.getValue() != null
                && pointUserValueGivenCreditOldAutoPlan.getRatio() != null) {
            valueOfGivenCreditOldAutoFactId.setValue(pointUserValueGivenCreditOldAutoPlan.getValue());
            valueOfGivenCreditOldAutoPlanId.setValue(pointUserValueGivenCreditOldAutoPlan.getRatio());
            if (pointUserValueGivenCreditOldAutoPlan.getValue() > pointUserValueGivenCreditOldAutoPlan.getRatio()) {
                valueOfGivenCreditBar.setValue(1.0);
            } else {
                valueOfGivenCreditBar.setValue(pointUserValueGivenCreditOldAutoPlan.getRatio() / 100);
            }
        }

        if (pointUserValueGivenCreditNewAutoPlan != null && pointUserValueGivenCreditNewAutoPlan.getValue() != null
                && pointUserValueGivenCreditNewAutoPlan.getRatio() != null) {
            valueOfGivenCreditNewAutoFactId.setValue(pointUserValueGivenCreditNewAutoPlan.getValue());
            valueOfGivenCreditNewAutoPlanId.setValue(pointUserValueGivenCreditNewAutoPlan.getRatio());

        }

        if (pointUserValueGivenCreditOldAuto != null) {
            if (pointUserValueGivenCreditOldAuto.getValue() != null) {
                valueOfGivenCreditFactOldId.setValue(pointUserValueGivenCreditOldAuto.getValue());
            }
            if (pointUserValueGivenCreditOldAuto.getPlan() != null) {
                valueOfGivenCreditPlanOldId.setValue(pointUserValueGivenCreditOldAuto.getPlan());
            }
        }

        if (pointUserValueGivenCreditNewAuto != null) {
            if (pointUserValueGivenCreditNewAuto.getValue() != null) {
                valueOfGivenCreditId.setValue(pointUserValueGivenCreditNewAuto.getValue());
            }
            if (pointUserValueGivenCreditNewAuto.getPlan() != null) {
                valueOfGivenCreditPlanId.setValue(pointUserValueGivenCreditNewAuto.getPlan());
            }

            if (pointUserValueGivenCreditNewAuto.getRatio() != null)
                valueOfGivenCreditBar.setValue(pointUserValueGivenCreditNewAutoPlan.getRatio() / 100);

        }

        if (pointProniknovenie != null) {
            proniknoviePlanId.setValue(pointProniknovenie.getPlan());
            proniknoveineFactId.setValue(pointProniknovenie.getRatio());
            if (pointProniknovenie.getValue() != null && pointProniknovenie.getPlan() != null) {
                proniknovenieBarId.setValue(((pointProniknovenie.getRatio() * 100) / pointProniknovenie.getPlan()) / 100);

            }
        }

        if (pointUserSmartbank != null && pointUserSmartbank.getPlan() != null) {
            if (pointUserSmartbank.getCreatedAt() != null) lastModifyDate.setValue(pointUserSmartbank.getCreatedAt());
            planId.setValue(pointUserSmartbank.getPlan().intValue() + " %");
            factId.setValue(pointUserSmartbank.getValue().intValue() + " %");
            plan = pointUserSmartbank.getValue();
            List<GaugeArrow> gaugeArrows = new ArrayList<>();
            GaugeArrow gaugeArrow = new GaugeArrow();
            gaugeArrow.setValue(plan);
            gaugeArrow.setInnerRadius("0%");
            gaugeArrow.setInnerRadius("6").setStartWidth(10).setRadius("85%");
            gaugeArrow.setColor(Color.valueOf("#314082"));
            gaugeArrow.setBorderAlpha(0.0)
                    .setBorderAlpha(0.0)
                    .setValue(plan);
            gaugeArrows.add(gaugeArrow);
            gaugeId.setArrows(gaugeArrows);
        }

        if (pointUserSmartbankOnlain != null && pointUserSmartbankOnlain.getPlan() != null) {
            if (pointUserSmartbankOnlain.getCreatedAt() != null)
                lastModifyDate.setValue(pointUserSmartbankOnlain.getCreatedAt());
            planOnlainId.setValue(pointUserSmartbankOnlain.getPlan().intValue() + " %");
            factOnlainId.setValue(pointUserSmartbankOnlain.getValue().intValue() + " %");
            plan = pointUserSmartbankOnlain.getValue();
            List<GaugeArrow> gaugeArrows = new ArrayList<>();
            GaugeArrow gaugeArrow = new GaugeArrow();
            gaugeArrow.setValue(plan);
            gaugeArrow.setInnerRadius("0%");
            gaugeArrow.setInnerRadius("6").setStartWidth(10).setRadius("85%");
            gaugeArrow.setColor(Color.valueOf("#314082"));
            gaugeArrow.setBorderAlpha(0.0)
                    .setBorderAlpha(0.0)
                    .setValue(plan);
            gaugeArrows.add(gaugeArrow);
            gaugeOnlainId.setArrows(gaugeArrows);
        }
        if (pointUserPREMISHOW != null) {
            pointUserShowId.setValue(pointUserPREMISHOW.getValue());
        }
        if (pointUserSmartbankTotal != null) {
            smartbankTotalPremiId.setValue(pointUserSmartbankTotal.getValue());
        }


    }

    void setFalseAllWidgets() {
        obiemCreditOldCarId.setVisible(false);
        obiemCreditNewCarId.setVisible(false);
        planPrirostBarId.setVisible(false);
        planPrirostId.setVisible(false);
        onlainSmartbankId.setVisible(false);
        creditId.setVisible(false);
        planObiemId.setVisible(false);
        planVydachaId.setVisible(false);
        planVypushennyxCartId.setVisible(false);
        proniknovenieId.setVisible(false);
        pokazatelNPSId.setVisible(false);
        zaimFDP.setVisible(false);
        planPRL.setVisible(false);
        isAuto = false;
        orbId.setVisible(false);
        newCardId.setVisible(false);
        newPremialCardId.setVisible(false);
        carPremiId.setVisible(false);
        smartbankId.setVisible(false);
        smsId.setVisible(false);
        debetPosId.setVisible(false);
        debetStrahovkaId.setVisible(false);
        cardId.setVisible(false);
        cardConvertationId.setVisible(false);
        salaryCardActivationId.setVisible(false);
    }

    @Subscribe("motivationButtonId")
    public void onMotivationButtonIdClick(Button.ClickEvent event) {
        showAuthorityMotivation();
    }

    private void showAuthorityMotivation() {
        if (isAuto) {
            screenBuilders.screen(this)
                    .withScreenClass(BonusBonusDescription.class)
                    .build()
                    .show();
        } else {
            screenBuilders.screen(this)
                    .withScreenClass(BonusDescriptionOpzp.class)
                    .build()
                    .show();
        }

    }

    @Subscribe("contractListBtnId")
    public void onContractListBtnIdClick(Button.ClickEvent event) {
//        screenBuilders.screen(this)
//                .withScreenClass(ContractsBrowse.class)
//                .withOptions(new RatingUserOptions(accountId, null, null, selectedDate, selectedCurrentMonthDate, null))
//                .build()
//                .show();
    }

}