package kz.eub.kpi.screen.bonusdescriptionvfk;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("kpi_BonusDescriptionVfk")
@UiDescriptor("bonus-description-vfk.xml")
public class BonusDescriptionVfk extends Screen {
}