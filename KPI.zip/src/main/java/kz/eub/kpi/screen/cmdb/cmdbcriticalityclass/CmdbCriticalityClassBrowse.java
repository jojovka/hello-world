package kz.eub.kpi.screen.cmdb.cmdbcriticalityclass;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.cmdb.CmdbCriticalityClass;

@UiController("kpi_CmdbCriticalityClass.browse")
@UiDescriptor("cmdb-criticality-class-browse.xml")
@LookupComponent("cmdbCriticalityClassesTable")
public class CmdbCriticalityClassBrowse extends StandardLookup<CmdbCriticalityClass> {
}