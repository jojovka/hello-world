package kz.eub.kpi.screen.cmdb.cmdbispassport;

import io.jmix.ui.screen.*;
import kz.eub.kpi.entity.cmdb.CmdbIsPassport;

@UiController("kpi_CmdbIsPassport.edit")
@UiDescriptor("cmdb-is-passport-edit.xml")
@EditedEntityContainer("cmdbIsPassportDc")
public class CmdbIsPassportEdit extends StandardEditor<CmdbIsPassport> {
}