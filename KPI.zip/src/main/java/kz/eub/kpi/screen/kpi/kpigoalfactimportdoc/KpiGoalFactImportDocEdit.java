package kz.eub.kpi.screen.kpi.kpigoalfactimportdoc;

import io.jmix.core.AccessManager;
import io.jmix.core.accesscontext.SpecificOperationAccessContext;
import io.jmix.emailtemplates.exception.TemplateNotFoundException;
import io.jmix.reports.entity.ReportOutputType;
import io.jmix.reportsui.runner.ParametersDialogShowMode;
import io.jmix.reportsui.runner.UiReportRunner;
import io.jmix.ui.Dialogs;
import io.jmix.ui.Notifications;
import io.jmix.ui.action.Action;
import io.jmix.ui.action.DialogAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.FileUploadField;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.model.CollectionPropertyContainer;
import io.jmix.ui.navigation.Route;
import io.jmix.ui.navigation.UrlRouting;
import io.jmix.ui.screen.EditedEntityContainer;
import io.jmix.ui.screen.Install;
import io.jmix.ui.screen.StandardEditor;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.service.EmployeeService;
import kz.eub.kpi.app.service.FinGoalService;
import kz.eub.kpi.app.service.KpiCardService;
import kz.eub.kpi.app.service.KpiGoalFactImportService;
import kz.eub.kpi.app.service.KpiGoalService;
import kz.eub.kpi.entity.EApplicationStatus;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.kpi.EKpiGoalCategory;
import kz.eub.kpi.entity.kpi.KpiGoalDictFact;
import kz.eub.kpi.entity.kpi.KpiGoalFactImportDoc;
import kz.eub.kpi.entity.kpi.KpiPeriod;
import kz.eub.kpi.security.specific.FdFactImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.List;
import java.util.Objects;

@UiController("kpi_KpiGoalFactImport.edit")
@UiDescriptor("kpi-goal-fact-import-doc-edit.xml")
@EditedEntityContainer("kpiGoalFactImportDocDc")
@Route(value = KpiGoalFactImportDoc.ROUTE)
public class KpiGoalFactImportDocEdit extends StandardEditor<KpiGoalFactImportDoc> {

    public static final Logger log = LoggerFactory.getLogger(KpiGoalFactImportDocEdit.class);

    @Autowired
    private KpiGoalService kpiGoalService;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private KpiCardService kpiCardService;
    @Autowired
    private UiReportRunner uiReportRunner;
    @Autowired
    private CollectionPropertyContainer<KpiGoalDictFact> goalDictFactsDc;
    @Autowired
    private Notifications notifications;
    @Autowired
    private Button importBtn;
    @Autowired
    private KpiGoalFactImportService kpiGoalFactImportService;
    @Autowired
    private FileUploadField uploadField;

    @Autowired
    private AccessManager accessManager;
    @Autowired
    private Dialogs dialogs;
    @Autowired
    private FinGoalService finGoalService;
    @Autowired
    private UrlRouting urlRouting;

    @Subscribe
    public void onInitEntity(InitEntityEvent<KpiGoalFactImportDoc> event) {
        KpiGoalFactImportDoc doc = event.getEntity();
        KpiPeriod period = kpiGoalService.getCurrentKpiPeriod();
        long days = kpiGoalService.getDaysToNextQuarter(period);
        if (days > 45) {
            period = kpiGoalService.getPreviousPeriod(period);
        }
        doc.setDate(new Date());
        doc.setPeriod(period);
        doc.setCategory(EKpiGoalCategory.FINANCIAL_GOAL);
        doc.setStatus(EApplicationStatus.NEW);
        Employee employee = employeeService.getCurrentEmployee();
        doc.setAuthor(employee);
        if (employee != null) {
            doc.setDepartment(employee.getDepartment());
            doc.setPosition(employee.getPosition());
            doc.setLeader(employee.getLeader());
            doc.setSupervisor(employee.getSupervisor());
        }
        doc.setSn(kpiCardService.getApplicationSN());
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        toggleImportBtn();
        toggleUploadBtn();
        toggleEditMode();
    }

    private void toggleEditMode() {
        KpiGoalFactImportDoc doc = getEditedEntity();
        if (Objects.equals(doc.getStatus(), EApplicationStatus.APPROVED)
                && doc.getPeriod() != null && doc.getCreatedBy() != null) {
            setReadOnly(true);
        }
    }

    private void toggleUploadBtn() {
        uploadField.setVisible(!isImportPermitted());
        uploadField.setEnabled(false);
        if (Objects.equals(getEditedEntity().getStatus(), EApplicationStatus.NEW)
            && getEditedEntity().getPeriod() != null) {
            uploadField.setEnabled(true);
        }
    }

    private void toggleImportBtn() {
        boolean permitted = isImportPermitted();
        importBtn.setVisible(permitted);
        if (!permitted) return;
        importBtn.setEnabled(false);
        if (Objects.equals(getEditedEntity().getStatus(), EApplicationStatus.NEW)
            && getEditedEntity().getPeriod() != null
            && goalDictFactsDc.getMutableItems().size() > 0) {
            importBtn.setEnabled(true);
        }
    }

    private boolean isImportPermitted() {
        SpecificOperationAccessContext accessContext =
                new SpecificOperationAccessContext(FdFactImport.NAME);
        accessManager.applyRegisteredConstraints(accessContext);
        return accessContext.isPermitted();
    }

    @Subscribe("goalDictFactsTable.downloadTemplate")
    public void onGoalDictFactsTableDownloadTemplate(Action.ActionPerformedEvent event) {
        uiReportRunner.byReportCode("kpi-goal-fact-import-template")
                .withOutputType(ReportOutputType.XLSX)
                .withTemplateCode("DEFAULT")
                .withParametersDialogShowMode(ParametersDialogShowMode.NO)
                .addParam("category", getEditedEntity().getCategory())
                .addParam("period", getEditedEntity().getPeriod())
                .runAndShow();
    }

    @Subscribe("uploadField")
    public void onUploadFieldValueChange(HasValue.ValueChangeEvent<byte[]> event) {
        byte[] file = event.getValue();
        goalDictFactsDc.getMutableItems().clear();
        try {
            List<KpiGoalDictFact> goalFacts = kpiGoalFactImportService.importGoalFacts(file, getEditedEntity());
            goalDictFactsDc.getMutableItems().addAll(goalFacts);
        } catch (Exception e) {
            String errCaption = "Ошибка при импорте...";
            log.error(errCaption, e);
            notifyError(errCaption, e);
        } finally {
            if (goalDictFactsDc.getMutableItems().size() > 0)
                importBtn.setEnabled(true);
        }
    }

    @Subscribe("importBtn")
    public void onImportBtnClick(Button.ClickEvent event) {
        dialogs.createOptionDialog().withWidth("721")
                .withCaption("Вы подтверждаете импорт текущих фактических показателей?")
                .withMessage("Данное действие не имеет возможности возврата...")
                .withActions(
                        new DialogAction(DialogAction.Type.OK)
                                .withHandler(e ->
                                    importGoalFacts()
                                ),
                        new DialogAction(DialogAction.Type.CANCEL))
                .show();
    }

    private void importGoalFacts() {
        try {
            int count = kpiGoalFactImportService.distributeGoalFacts(getEditedEntity().getCategory(),
                    getEditedEntity().getPeriod(), goalDictFactsDc.getMutableItems());
            getEditedEntity().setStatus(EApplicationStatus.APPROVED);
            commitChanges();
            notifications.create()
                    .withCaption("Импорт выполнен.")
                    .withDescription("Успешно обновлены фактические показатели " + count + " целей.")
                    .show();
            toggleImportBtn();
            toggleUploadBtn();
        } catch (Exception e) {
            String errCaption = "Ошибка при попытке импортировать и обновить фактические показатели целей.";
            log.error(errCaption, e);
            notifyError(errCaption, e);
        }
    }

    @Install(to = "goalDictFactsTable.downloadTemplate", subject = "enabledRule")
    private boolean goalDictFactsTableDownloadTemplateEnabledRule() {
        return !isImportPermitted();
    }

    @Subscribe("commitAndCloseBtn")
    public void onCommitAndCloseBtnClick(Button.ClickEvent event) {
        try {
            closeWithCommit();
        } catch (Exception e) {
            String errCaption = "Ошибка при попытке сохранить";
            log.error(errCaption, e);
            notifyError(errCaption, e);
        }
    }

    private void notifyError(String errCaption, Exception e) {
        notifications.create(Notifications.NotificationType.ERROR)
                .withCaption(errCaption)
                .withDescription(e.getMessage())
                .show();
    }

    @Subscribe
    public void onAfterCommitChanges(AfterCommitChangesEvent event) {
        sendApproversNotification(getEditedEntity());
    }

    private void sendApproversNotification(KpiGoalFactImportDoc doc) {
        try {
            String link = urlRouting.getRouteGenerator().getEditorRoute(doc);
            finGoalService.sendApproversNotification(doc, link);
        } catch (TemplateNotFoundException e) {
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Ошибка при попытке отправить уведомление")
                    .withDescription(e.getMessage())
                    .show();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при попытке отправить уведомление", e);
        }
    }
}