package kz.eub.kpi.screen.profile;

import io.jmix.appsettings.AppSettings;
import io.jmix.bpm.engine.events.UserTaskAssignedEvent;
import io.jmix.core.DataManager;
import io.jmix.core.EntityStates;
import io.jmix.core.FetchPlan;
import io.jmix.core.FileRef;
import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import io.jmix.reports.entity.ReportOutputType;
import io.jmix.reportsui.runner.ParametersDialogShowMode;
import io.jmix.reportsui.runner.UiReportRunner;
import io.jmix.ui.Notifications;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.BaseAction;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.component.Image;
import io.jmix.ui.component.Table;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.Install;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.kpi.app.bean.KpiGeneralUtils;
import kz.eub.kpi.app.event.UserTaskAssignedUiEvent;
import kz.eub.kpi.app.service.BpmUserTaskService;
import kz.eub.kpi.app.service.KpiCardService;
import kz.eub.kpi.app.service.KpiGoalService;
import kz.eub.kpi.entity.Application;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.EApplicationStatus;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.kpi.EKpiCardStage;
import kz.eub.kpi.entity.kpi.KpiApplication;
import kz.eub.kpi.entity.kpi.KpiCard;
import kz.eub.kpi.entity.kpi.KpiCardSettings;
import kz.eub.kpi.entity.kpi.KpiPeriod;
import kz.eub.kpi.entity.kpi.KpiResult;
import kz.eub.kpi.screen.kpi.kpimassiveapproval.KpiMassiveApproval;
import org.flowable.task.service.impl.persistence.entity.TaskEntityImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.transaction.event.TransactionalEventListener;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

@UiController("kpi_ProfileScreen")
@UiDescriptor("profile-screen.xml")
public class ProfileScreen extends Screen {

    private static final Logger log = LoggerFactory.getLogger(ProfileScreen.class);

    private List<KpiCard> kpiCardsList;

    @Autowired
    private Notifications notifications;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private InstanceContainer<Employee> employeeDc;
    @Autowired
    private CollectionContainer<Employee> employeesDc;
    @Autowired
    private CurrentUserSubstitution currentUserSubstitution;
    @Autowired
    private EntityStates entityStates;
    @Autowired
    private Image<FileRef> photo;

    @Autowired
    private CollectionContainer<KpiResult> kpiResultsDc;
    @Autowired
    private CollectionContainer<KpiCard> kpiCardsDc;
    @Autowired
    private Table<KpiCard> kpiCardsTable;
    @Autowired
    private BpmUserTaskService bpmUserTaskService;
    @Autowired
    private CollectionContainer<KpiCard> kpiApplicationsDc;

    private String currentUserName;
    @Autowired
    private Button kpiCardsTableEditBtn;
    @Autowired
    private Button kpiCardsTableRemoveBtn;
    @Autowired
    private KpiGoalService kpiGoalService;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private KpiCardService kpiCardService;
    @Autowired
    private UiReportRunner uiReportRunner;
    @Autowired
    private Button kpiCardsTableCreateBtn;
    @Autowired
    private AppSettings appSettings;
    @Autowired
    private KpiGeneralUtils kpiGeneralUtils;

    @Subscribe
    public void onInit(InitEvent event) {
        initDblClickAndEnterPressHandler();
        currentUserName = currentUserSubstitution.getEffectiveUser().getUsername();
    }

    private void initDblClickAndEnterPressHandler() {
        kpiCardsTable.setEnterPressAction(new BaseAction("enterPressAction")
                .withHandler(event -> openKpiCard()));
        kpiCardsTable.setItemClickAction(new BaseAction("itemClickAction")
                .withHandler(event -> openKpiCard()));
    }

    private void openKpiCard() {
        KpiCard card = kpiCardsTable.getSingleSelected();
        if (card == null) return;
        Objects.requireNonNull(kpiCardsTable.getAction("view")).actionPerform(kpiCardsTable);
    }

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        loadCurrentEmployee();
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        Employee employee = employeeDc.getItemOrNull();
        if (employee == null)
            closeWithDefaultAction();
        togglePhoto();
    }

    private void loadCurrentEmployee() {
        UserDetails user = currentUserSubstitution.getEffectiveUser();
        Employee employee = dataManager.load(Employee.class)
                .query("select c from kpi_Employee c " +
                        "where c.username = :username")
                .parameter("username", user.getUsername())
                .fetchPlan(fp -> fp.addFetchPlan(FetchPlan.BASE)
                        .add("position", FetchPlan.BASE)
                        .add("department", FetchPlan.BASE))
                .optional().orElse(null);
        employeeDc.setItem(employee);
        if (employee == null) {
            return;
        }
        loadKpiCards();
        loadAccountableEmployees();
        loadKpiResults();
        loadKpiApplications();
        togglePhoto();
        toggleKpiCardCreateBtn();
    }

    private void toggleKpiCardCreateBtn() {
        kpiCardsTableCreateBtn.setEnabled(kpiCardsTableCreateEnabledRule());
    }

    private void loadKpiApplications() {
        kpiApplicationsDc.getMutableItems().clear();
        List<Application> userApplicationTasks = bpmUserTaskService.getUserTaskApplications(currentUserName);
        List<KpiCard> applicationList = userApplicationTasks.stream()
                .filter(a -> a instanceof KpiCard)
                .map(a -> (KpiCard) a)
                .collect(Collectors.toList());
        List<UUID> uuidList = applicationList.stream().map(KpiApplication::getId).collect(Collectors.toList());
        applicationList = kpiCardService.loadAllKpiCardsById(uuidList);
        kpiApplicationsDc.getMutableItems().addAll(applicationList);
    }

    private void togglePhoto() {
        Employee employee = employeeDc.getItemOrNull();
        if (employee == null) return;
        photo.setVisible(employee.getPhoto() != null);
        photo.setHeightFull();
    }

    private void loadAccountableEmployees() {
        employeesDc.getMutableItems().clear();
        List<Employee> employees = dataManager.load(Employee.class)
                .query("select c from kpi_Employee c " +
                        "where c.active = true " +
                        "and c.supervisor = :employee")
                .parameter("employee", employeeDc.getItem())
                .list();
        employeesDc.getMutableItems().addAll(employees);
    }

    private void loadKpiCards() {
        kpiCardsDc.getMutableItems().clear();
        kpiCardsList = dataManager.load(KpiCard.class)
                .query("select c from kpi_KpiCard c " +
                        "where c.author = :employee")
                .parameter("employee", employeeDc.getItem())
                .list();
        kpiCardsDc.getMutableItems().addAll(kpiCardsList);
    }

    private void loadKpiResults() {
        kpiResultsDc.getMutableItems().clear();
        List<KpiResult> kpiGoals = dataManager.load(KpiResult.class)
                .query("select c from kpi_KpiResult c " +
                        "where c.employee = :employee")
                .parameter("employee", employeeDc.getItem())
                .list();
        kpiResultsDc.getMutableItems().addAll(kpiGoals);
    }

    @Subscribe("closeBtn")
    public void onCloseBtnClick(Button.ClickEvent event) {
        closeWithDefaultAction();
    }

    @Subscribe("submitBtn")
    public void onSubmitBtnClick(Button.ClickEvent event) {
        if (!entityStates.isNew(employeeDc.getItem())) {
            Employee employee = dataManager.save(employeeDc.getItem());
            employeeDc.setItem(employee);
            notifications.create(Notifications.NotificationType.TRAY)
                    .withCaption("Профайл успешно обновлен.")
                    .show();
        }
    }

    @Subscribe("photoField")
    public void onPhotoFieldValueChange(HasValue.ValueChangeEvent<FileRef> event) {
        togglePhoto();
    }

    @Install(to = "kpiCardsTable.create", subject = "afterCloseHandler")
    private void kpiCardsTableCreateAfterCloseHandler(AfterCloseEvent afterCloseEvent) {
        loadKpiCards();
    }

    @Async
    @TransactionalEventListener
    public void onTaskAssigned(UserTaskAssignedUiEvent customEvent) {
        UserTaskAssignedEvent event = customEvent.getSource();
        if (Objects.equals(currentUserName, event.getUsername())) {
            notifications.create(Notifications.NotificationType.TRAY)
                    .withCaption("Вам назначена новая задача")
                    .withDescription(event.getTask().getName())
                    .show();
            loadKpiApplications();
        } else if (Objects.equals(((TaskEntityImpl)event.getTask()).getOriginalAssignee(), currentUserName)) {
            loadKpiApplications();
        }
    }

    @Subscribe("kpiCardsTable")
    public void onKpiCardsTableSelection(Table.SelectionEvent<KpiCard> event) {
        kpiCardsTableEditBtn.setEnabled(false);
        kpiCardsTableRemoveBtn.setEnabled(false);
        KpiCard card = kpiCardsTable.getSingleSelected();
        if (card != null &&
            card.getStatus() != null && (
                    card.getStatus().equals(EApplicationStatus.NEW)
                    || card.getStatus().equals(EApplicationStatus.REVOKED)
        )) {
            kpiCardsTableEditBtn.setEnabled(true);
            kpiCardsTableRemoveBtn.setEnabled(true);
        }
    }

    @Install(to = "kpiApplicationsTable.view", subject = "afterCloseHandler")
    private void kpiApplicationsTableViewAfterCloseHandler(AfterCloseEvent afterCloseEvent) {
        loadKpiApplications();
    }

    @Install(to = "kpiCardsTable.view", subject = "afterCloseHandler")
    private void kpiCardsTableViewAfterCloseHandler(AfterCloseEvent afterCloseEvent) {
        loadKpiCards();
    }

    @Install(to = "kpiCardsTable.edit", subject = "afterCloseHandler")
    private void kpiCardsTableEditAfterCloseHandler(AfterCloseEvent afterCloseEvent) {
        loadKpiCards();
    }

    @Install(to = "kpiCardsTable.create", subject = "enabledRule")
    private boolean kpiCardsTableCreateEnabledRule() {
        Employee employee = employeeDc.getItem();
        boolean isBcbStaff = (employee.getDepartment() != null
                && employee.getDepartment().isEqualOrChildOfParentSapId(DictDepartment.BCB_SAP_ID));  // Check if employee is "БЦБ" staff
        if (!isBcbStaff && !kpiCardService.employeeHasWorkedMinRequiredDaysInCompany(employee))
            return false;
        KpiPeriod period = kpiGoalService.getCurrentKpiPeriod();
        if (isTransferInCurrentPeriod(employee.getHireDate(), period)) return true;

        if (kpiCardService.checkEnableCreationDeadline()) {
            return checkForPeriodActiveCards(period);
        }
        return false;
    }

    private boolean isTransferInCurrentPeriod(Date hireDate, KpiPeriod period) {
        if (!kpiCardService.isTransferDuringPeriod(hireDate, period))
            return false;

        List<KpiCard> kpiCards = kpiCardsDc.getMutableItems();
        for (KpiCard card : kpiCards) {
            if (card.getDate().after(hireDate))
                return false;
        }
        return true;
    }

    private boolean checkForPeriodActiveCards(KpiPeriod period) {
        List<KpiCard> kpiCards = kpiCardsDc.getMutableItems();
        for (KpiCard card : kpiCards) {
            if (isCurrentPeriodCard(period, card)) {
                if (card.getStage().equals(EKpiCardStage.FIRST_STAGE)
                        && !card.getStatus().equals(EApplicationStatus.AGREED)
                        && !card.getStatus().equals(EApplicationStatus.REJECTED))
                    return false;
            }
        }
        return true;
    }

    private boolean isCurrentPeriodCard(KpiPeriod period, KpiCard card) {
        return card.getPeriod().getYear().equals(period.getYear())
                && card.getPeriod().getQuarter().equals(period.getQuarter());
    }

    @Subscribe("massiveApprovalBtn")
    public void onMassiveApprovalBtnClick(Button.ClickEvent event) {
        screenBuilders.screen(this)
                .withScreenClass(KpiMassiveApproval.class)
                .build().show();
    }


    @Subscribe("currentQuarterCardsCheckBox")
    public void onCurrentQuarterCardsCheckBoxValueChange(HasValue.ValueChangeEvent<Boolean> event) {
        kpiCardsDc.getMutableItems().clear();
        if (Boolean.TRUE.equals(event.getValue())) {
            KpiPeriod currentPeriod = kpiGoalService.getCurrentKpiPeriod();
            List<KpiCard> kpiCards = kpiCardsList.stream()
                    .filter(card -> card.getPeriod().getId().equals(currentPeriod.getId()))
                    .collect(Collectors.toList());
            kpiCardsDc.getMutableItems().addAll(kpiCards);
        } else {
            kpiCardsDc.getMutableItems().addAll(kpiCardsList);
        }
    }



    @Subscribe("exportGoalsBtn")
    public void onExportGoalsBtnClick(Button.ClickEvent event) {
        try {
            List<KpiCard> kpiCards = kpiApplicationsDc.getMutableItems();
            KpiCard card = kpiCards.stream().findFirst().orElse(null);
            if (card == null) return;
            KpiPeriod period = card.getPeriod();
            uiReportRunner.byReportCode(KpiCard.REP_EXPORT_KPI_CARDS_LIST_CODE)
                    .withOutputType(ReportOutputType.XLSX)
                    .withParametersDialogShowMode(ParametersDialogShowMode.NO)
                    .addParam("year", period.getYear())
                    .addParam("quarter", period.getQuarter())
                    .addParam("kpiCards", kpiCards)
                    .runAndShow();
        } catch (Exception e) {
            log.error("Ошибка при попытке выгрузки целей", e);
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("Ошибка при попытке выгрузки целей")
                    .withDescription(e.getMessage())
                    .show();
        }
    }

}