package kz.eub.kpi.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;

@JmixEntity
@Table(name = "KPI_DUEL_CONTEST", schema = "probonus", indexes = {
        @Index(name = "IDX_KPI_DUEL_CONTEST_DUEL", columnList = "DUEL_ID"),
        @Index(name = "IDX_KPI_DUEL_CONTEST_CONTESTER", columnList = "CONTESTER_ID"),
        @Index(name = "IDX_KPI_DUEL_CONTEST_OPPONENT", columnList = "OPPONENT_ID"),
        @Index(name = "IDX_KPIDUELCONTEST_WINNERSTAFF", columnList = "WINNER_STAFF_ID")
})
@Entity(name = "kpi_DuelContest")
public class DuelContest {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private Integer id;

    @JoinColumn(name = "WINNER_STAFF_ID")
    @Composition
    @OneToOne(fetch = FetchType.LAZY)
    private Accounts winnerStaff;

    @Column(name = "QUESTION_LIMIT")
    private Integer questionLimit;

    @JoinColumn(name = "DUEL_ID")
    @Composition
    @OneToOne(fetch = FetchType.LAZY)
    private Duel duelId;

    @JoinColumn(name = "CONTESTER_ID")
    @Composition
    @OneToOne(fetch = FetchType.LAZY)
    private Accounts contester;

    @JoinColumn(name = "OPPONENT_ID")
    @Composition
    @OneToOne(fetch = FetchType.LAZY)
    private Accounts opponent;

    @Column(name = "POINT_CONTESTER")
    private Integer pointContester;

    @Column(name = "POINT_OPPONENT")
    private Integer pointOpponent;

    @Column(name = "WINNER")
    private Integer winner;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE")
    private Date created_date;

    @Column(name = "FINISHED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date finished_date;

    public Accounts getWinnerStaff() {
        return winnerStaff;
    }

    public void setWinnerStaff(Accounts winnerStaff) {
        this.winnerStaff = winnerStaff;
    }

    public Integer getQuestionLimit() {
        return questionLimit;
    }

    public void setQuestionLimit(Integer questionLimit) {
        this.questionLimit = questionLimit;
    }

    public void setCreated_date(Date created_date) {
        this.created_date = created_date;
    }

    public Date getCreated_date() {
        return created_date;
    }

    public Date getFinished_date() {
        return finished_date;
    }

    public void setFinished_date(Date finished_date) {
        this.finished_date = finished_date;
    }

    public Integer getWinner() {
        return winner;
    }

    public void setWinner(Integer winner) {
        this.winner = winner;
    }

    public Integer getPointOpponent() {
        return pointOpponent;
    }

    public void setPointOpponent(Integer pointOpponent) {
        this.pointOpponent = pointOpponent;
    }

    public Integer getPointContester() {
        return pointContester;
    }

    public void setPointContester(Integer pointContester) {
        this.pointContester = pointContester;
    }

    public Accounts getOpponent() {
        return opponent;
    }

    public void setOpponent(Accounts opponent) {
        this.opponent = opponent;
    }

    public Accounts getContester() {
        return contester;
    }

    public void setContester(Accounts contester) {
        this.contester = contester;
    }

    public Duel getDuelId() {
        return duelId;
    }

    public void setDuelId(Duel duelId) {
        this.duelId = duelId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}