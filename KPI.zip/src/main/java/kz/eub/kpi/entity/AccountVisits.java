package kz.eub.kpi.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;

@JmixEntity
@Table(name = "ACCOUNT_VISITS", schema = "probonus")
@Entity(name = "accountVisits")
public class AccountVisits {
    @JmixGeneratedValue
    @Column(name = "id", nullable = false)
    @Id
    private Integer id;

    @Column(name = "POSITION_")
    private String position;

    @Column(name = "DEPARTMENT")
    private String department;

    @Column(name = "BRANCH")
    private String branch;

    @Column(name = "FIO")
    private String fio;

    @Column(name = "ACCOUNT_ID")
    private Integer accountId;

    @Temporal(TemporalType.DATE)
    @Column(name = "visited_at")
    private Date visited_at;

    public void setVisited_at(Date visited_at) {
        this.visited_at = visited_at;
    }

    public Date getVisited_at() {
        return visited_at;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getFio() {
        return fio;
    }

    public void setFio(String fio) {
        this.fio = fio;
    }


    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    public Integer getAccountId() {
        return accountId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

}