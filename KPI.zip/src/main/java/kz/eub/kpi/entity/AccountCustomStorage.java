package kz.eub.kpi.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;

@JmixEntity
@Table(name = "KPI_ACCOUNT_CUSTOM_STORAGE", schema = "probonus", indexes = {
        @Index(name = "IDX_KPIACCOUNTCUSTOM_ACCOUNTID", columnList = "ACCOUNT_ID")
})
@Entity(name = "kpi_AccountCustomStorage")
public class AccountCustomStorage {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private Integer id;

    @Column(name = "ACCOUNT_ID")
    private Integer accountId;

    @Column(name = "KEY")
    private String key;

    @Column(name = "VALUE", length = 1045)
    private String value;

    @Column(name = "IS_READ_ONLY")
    private Boolean isReadOnly;

    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    public Integer getAccountId() {
        return accountId;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    public Boolean getIsReadOnly() {
        return isReadOnly;
    }

    public void setIsReadOnly(Boolean isReadOnly) {
        this.isReadOnly = isReadOnly;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}