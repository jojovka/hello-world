package kz.eub.kpi.entity.kpi;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "KPI_KPI_GOAL_DICT_FACT", indexes = {
        @Index(name = "IDX_KPIKPIGOALDICTFAC_GOALDICT", columnList = "GOAL_DICT_ID"),
        @Index(name = "IDX_KPIKPIGOALDICTFACT_PERIOD", columnList = "PERIOD_ID"),
        @Index(name = "IDX_KPIKPIGOALDI_GOALIMPORTDO", columnList = "GOAL_IMPORT_DOC_ID"),
        @Index(name = "IDX_KPIKPIGOALDIC_GOALDICTPLAN", columnList = "GOAL_DICT_PLAN_ID")
})
@Entity(name = "kpi_KpiGoalDictFact")
public class KpiGoalDictFact {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @NotNull
    @JoinColumn(name = "GOAL_IMPORT_DOC_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private KpiGoalFactImportDoc goalImportDoc;

    @NotNull
    @JoinColumn(name = "GOAL_DICT_PLAN_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private KpiGoalDictPlan goalDictPlan;

    @NotNull
    @JoinColumn(name = "GOAL_DICT_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private KpiGoalDict goalDict;

    @NotNull
    @JoinColumn(name = "PERIOD_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private KpiPeriod period;

    @NotNull
    @Column(name = "FACT", nullable = false, precision = 19, scale = 2)
    private BigDecimal fact;

    public KpiGoalDictPlan getGoalDictPlan() {
        return goalDictPlan;
    }

    public void setGoalDictPlan(KpiGoalDictPlan goalDictPlan) {
        this.goalDictPlan = goalDictPlan;
    }

    public KpiGoalFactImportDoc getGoalImportDoc() {
        return goalImportDoc;
    }

    public void setGoalImportDoc(KpiGoalFactImportDoc goalImportDoc) {
        this.goalImportDoc = goalImportDoc;
    }

    public BigDecimal getFact() {
        return fact;
    }

    public void setFact(BigDecimal fact) {
        this.fact = fact;
    }

    public KpiPeriod getPeriod() {
        return period;
    }

    public void setPeriod(KpiPeriod period) {
        this.period = period;
    }

    public KpiGoalDict getGoalDict() {
        return goalDict;
    }

    public void setGoalDict(KpiGoalDict goalDict) {
        this.goalDict = goalDict;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}