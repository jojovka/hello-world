package kz.eub.kpi.entity.kpi;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum EKpiCardStage implements EnumClass<String> {

    FIRST_STAGE("FIRST_STAGE"),
    SECOND_STAGE("SECOND_STAGE");

    private String id;

    EKpiCardStage(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static EKpiCardStage fromId(String id) {
        for (EKpiCardStage at : EKpiCardStage.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}