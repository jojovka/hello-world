package kz.eub.kpi.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@JmixEntity
@Table(name = "KPI_COMPETITION_USER", schema = "probonus")
@Entity(name = "kpi_CompetitionUser")
public class CompetitionUser {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "EMPLOYEE")
    private UUID employee;

    @Column(name = "COMPETITION_ID")
    private Integer competitionId;

    @Column(name = "ACCOUNT_ID")
    private Integer accountId;

    public void setCompetitionId(Integer competitionId) {
        this.competitionId = competitionId;
    }

    public Integer getCompetitionId() {
        return competitionId;
    }

    public Integer getAccountId() {
        return accountId;
    }

    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    public UUID getEmployee() {
        return employee;
    }

    public void setEmployee(UUID employee) {
        this.employee = employee;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}