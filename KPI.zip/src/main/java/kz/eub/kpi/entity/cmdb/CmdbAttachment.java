package kz.eub.kpi.entity.cmdb;

import io.jmix.core.FileRef;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.util.UUID;

@JmixEntity
@Table(name = "KPI_CMDB_ATTACHMENT", indexes = {
        @Index(name = "IDX_CMDBATTACHMENT", columnList = "IS_PASSPORT_ID"),
        @Index(name = "IDX_CMDBATTACHMENT", columnList = "ATTACHMENT_TYPE_ID")
})
@Entity(name = "kpi_CmdbAttachment")
public class CmdbAttachment {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "IS_PASSPORT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CmdbIsPassport isPassport;

    @JoinColumn(name = "ATTACHMENT_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CmdbAttachmentType attachmentType;

    @InstanceName
    @Column(name = "DESCRIPTION", length = 1024)
    private String description;

    @Column(name = "ACTUAL")
    private Boolean actual;

    @Column(name = "ATTACHMENT_FILE", length = 1024)
    private FileRef attachmentFile;

    public FileRef getAttachmentFile() {
        return attachmentFile;
    }

    public void setAttachmentFile(FileRef fileRef) {
        this.attachmentFile = fileRef;
    }

    public Boolean getActual() {
        return actual;
    }

    public void setActual(Boolean actual) {
        this.actual = actual;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public CmdbAttachmentType getAttachmentType() {
        return attachmentType;
    }

    public void setAttachmentType(CmdbAttachmentType attachmentType) {
        this.attachmentType = attachmentType;
    }

    public CmdbIsPassport getIsPassport() {
        return isPassport;
    }

    public void setIsPassport(CmdbIsPassport isPassport) {
        this.isPassport = isPassport;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}