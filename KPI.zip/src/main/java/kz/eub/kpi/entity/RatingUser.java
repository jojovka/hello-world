package kz.eub.kpi.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;

@JmixEntity
@Table(name = "rating_user", schema = "probonus", indexes = {
        @Index(name = "IDX_RATING_USER_ACCOUNT", columnList = "account_id")
})
@Entity(name = "kpi_RatingUser")
public class RatingUser {
    @JmixGeneratedValue
    @Column(name = "id", nullable = false)
    @Id
    private Integer id;

    @Column(name = "PAYROLL_NUMBER")
    private String payrollNumber;

    @JoinColumn(name = "account_id")
    @OneToOne(fetch = FetchType.LAZY)
    private Accounts accountId;

    @Column(name = "type_id")
    private Integer typeId;

    @Column(name = "position")
    private Integer position;

    @Column(name = "value")
    private Double value;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "period_id")
    private Integer periodId;

    public String getPayrollNumber() {
        return payrollNumber;
    }

    public void setPayrollNumber(String payrollNumber) {
        this.payrollNumber = payrollNumber;
    }

    public Integer getPeriodId() {
        return periodId;
    }

    public void setPeriodId(Integer periodId) {
        this.periodId = periodId;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    public Accounts getAccountId() {
        return accountId;
    }

    public void setAccountId(Accounts accountId) {
        this.accountId = accountId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}