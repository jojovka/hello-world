package kz.eub.kpi.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@JmixEntity
@Table(name = "KPI_COMPETITION_CATEGORY", schema = "probonus")
@Entity(name = "kpi_CompetitionCategory")
public class CompetitionCategory {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "COMPETITION_ID")
    private Integer competitionId;

    @Column(name = "CREDIT_TYPE")
    private String creditType;

    @Column(name = "ACTIVE_CARD_TYPE")
    private String activeCardType;

    @Column(name = "ACTIVE_CARD_COUNT")
    private Integer activeCardCount;

    @Column(name = "ACTIVE_CARD_STATUS")
    private Boolean activeCardStatus;

    @Column(name = "CREDIT_STATUS")
    private Boolean creditStatus;

    @Column(name = "POS_COUNT")
    private Integer posCount;

    @Column(name = "CREDIT_COUNT")
    private Integer creditCount;

    @Column(name = "POS_TYPE")
    private String posType;

    @Column(name = "POS_STATUS")
    private Boolean posStatus;

    @Column(name = "AVTO_CREDIT_COUNT")
    private Integer avtoCreditCount;

    @Column(name = "AVTO_CREDIT_TYPE")
    private String avtoCreditType;

    @Column(name = "AVTO_CREDIT_STATUS")
    private Boolean avtoCreditStatus;

    @Column(name = "ACTIVE_SMARTBANK_COUNT")
    private Integer activeSmartbankCount;

    @Column(name = "ACTIV_SMARTBANK_TYPE")
    private String activSmartbankType;

    @Column(name = "ACTIV_SMARTBANK_STATUS")
    private Boolean activSmartbankStatus;

    @Column(name = "CLIENT_SMARTBANK_COUNT")
    private Integer clientSmartbankCount;

    @Column(name = "CLIENT_SMARTBANK_TYPE")
    private String clientSmartbankType;

    @Column(name = "CLIENT_SMARTBANK_STATUS")
    private Boolean clientSmartbankStatus;

    @Column(name = "DEPOSIT_COUNT")
    private Integer depositCount;

    @Column(name = "DEPOSIT_TYPE")
    private String depositType;

    @Column(name = "DEPOSIT_STATUS")
    private Boolean depositStatus;

    public void setCompetitionId(Integer competitionId) {
        this.competitionId = competitionId;
    }

    public Integer getCompetitionId() {
        return competitionId;
    }

    public void setCreditStatus(Boolean creditStatus) {
        this.creditStatus = creditStatus;
    }

    public Boolean getCreditStatus() {
        return creditStatus;
    }

    public void setActiveCardStatus(Boolean activeCardStatus) {
        this.activeCardStatus = activeCardStatus;
    }

    public Boolean getActiveCardStatus() {
        return activeCardStatus;
    }

    public void setCreditCount(Integer creditCount) {
        this.creditCount = creditCount;
    }

    public Integer getCreditCount() {
        return creditCount;
    }

    public Boolean getDepositStatus() {
        return depositStatus;
    }

    public void setDepositStatus(Boolean depositStatus) {
        this.depositStatus = depositStatus;
    }

    public String getDepositType() {
        return depositType;
    }

    public void setDepositType(String depositType) {
        this.depositType = depositType;
    }

    public Integer getDepositCount() {
        return depositCount;
    }

    public void setDepositCount(Integer depositCount) {
        this.depositCount = depositCount;
    }

    public Boolean getClientSmartbankStatus() {
        return clientSmartbankStatus;
    }

    public void setClientSmartbankStatus(Boolean clientSmartbankStatus) {
        this.clientSmartbankStatus = clientSmartbankStatus;
    }

    public String getClientSmartbankType() {
        return clientSmartbankType;
    }

    public void setClientSmartbankType(String clientSmartbankType) {
        this.clientSmartbankType = clientSmartbankType;
    }

    public Integer getClientSmartbankCount() {
        return clientSmartbankCount;
    }

    public void setClientSmartbankCount(Integer clientSmartbankCount) {
        this.clientSmartbankCount = clientSmartbankCount;
    }

    public Boolean getActivSmartbankStatus() {
        return activSmartbankStatus;
    }

    public void setActivSmartbankStatus(Boolean activSmartbankStatus) {
        this.activSmartbankStatus = activSmartbankStatus;
    }

    public String getActivSmartbankType() {
        return activSmartbankType;
    }

    public void setActivSmartbankType(String activSmartbankType) {
        this.activSmartbankType = activSmartbankType;
    }

    public Integer getActiveSmartbankCount() {
        return activeSmartbankCount;
    }

    public void setActiveSmartbankCount(Integer activeSmartbankCount) {
        this.activeSmartbankCount = activeSmartbankCount;
    }

    public Boolean getAvtoCreditStatus() {
        return avtoCreditStatus;
    }

    public void setAvtoCreditStatus(Boolean avtoCreditStatus) {
        this.avtoCreditStatus = avtoCreditStatus;
    }

    public String getAvtoCreditType() {
        return avtoCreditType;
    }

    public void setAvtoCreditType(String avtoCreditType) {
        this.avtoCreditType = avtoCreditType;
    }

    public Integer getAvtoCreditCount() {
        return avtoCreditCount;
    }

    public void setAvtoCreditCount(Integer avtoCreditCount) {
        this.avtoCreditCount = avtoCreditCount;
    }

    public Boolean getPosStatus() {
        return posStatus;
    }

    public void setPosStatus(Boolean posStatus) {
        this.posStatus = posStatus;
    }

    public String getPosType() {
        return posType;
    }

    public void setPosType(String posType) {
        this.posType = posType;
    }

    public Integer getPosCount() {
        return posCount;
    }

    public void setPosCount(Integer posCount) {
        this.posCount = posCount;
    }

    public String getCreditType() {
        return creditType;
    }

    public void setCreditType(String creditType) {
        this.creditType = creditType;
    }

    public Integer getActiveCardCount() {
        return activeCardCount;
    }

    public void setActiveCardCount(Integer activeCardCount) {
        this.activeCardCount = activeCardCount;
    }

    public String getActiveCardType() {
        return activeCardType;
    }

    public void setActiveCardType(String activeCardType) {
        this.activeCardType = activeCardType;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}