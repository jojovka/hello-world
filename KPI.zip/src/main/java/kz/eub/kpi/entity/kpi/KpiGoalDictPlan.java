package kz.eub.kpi.entity.kpi;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import kz.eub.kpi.entity.EApplicationStatus;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "KPI_KPI_GOAL_DICT_PLAN", indexes = {
        @Index(name = "IDX_KPIGOALDICT_GOALPLNIMPDOC", columnList = "GOAL_IMPORT_DOC_ID"),
        @Index(name = "IDX_KPIGOALDICTPLAN_PERIOD", columnList = "PERIOD_ID"),
        @Index(name = "IDX_KPIGOALDICTPLA_GOALDICT", columnList = "GOAL_DICT_ID"),
        @Index(name = "IDX_KPI_KPI_GOAL_DICT_PLAN_UNQ", columnList = "GOAL_DICT_ID, PERIOD_ID", unique = true)
})
@Entity(name = "kpi_KpiGoalDictPlan")
public class KpiGoalDictPlan {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @NotNull
    @JoinColumn(name = "GOAL_IMPORT_DOC_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private KpiGoalPlanImportDoc goalImportDoc;

    @NotNull
    @JoinColumn(name = "GOAL_DICT_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private KpiGoalDict goalDict;

    @NotNull
    @JoinColumn(name = "PERIOD_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private KpiPeriod period;

    @NotNull
    @Column(name = "PLAN_", nullable = false, precision = 19, scale = 2)
    private BigDecimal plan;

    @Column(name = "STATUS")
    private String status;

    public EApplicationStatus getStatus() {
        return status == null ? null : EApplicationStatus.fromId(status);
    }

    public void setStatus(EApplicationStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public BigDecimal getPlan() {
        return plan;
    }

    public void setPlan(BigDecimal plan) {
        this.plan = plan;
    }

    public KpiGoalDict getGoalDict() {
        return goalDict;
    }

    public void setGoalDict(KpiGoalDict goalDict) {
        this.goalDict = goalDict;
    }

    public KpiPeriod getPeriod() {
        return period;
    }

    public void setPeriod(KpiPeriod period) {
        this.period = period;
    }

    public KpiGoalPlanImportDoc getGoalImportDoc() {
        return goalImportDoc;
    }

    public void setGoalImportDoc(KpiGoalPlanImportDoc goalImportDoc) {
        this.goalImportDoc = goalImportDoc;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"goalDict"})
    public String getInstanceName() {
        return String.format("%s", goalDict.getInstanceName());
    }
}