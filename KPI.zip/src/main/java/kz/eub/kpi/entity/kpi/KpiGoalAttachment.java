package kz.eub.kpi.entity.kpi;

import io.jmix.core.FileRef;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import kz.eub.kpi.entity.kpi.KpiGoal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.util.UUID;

@JmixEntity
@Table(name = "KPI_KPI_GOAL_ATTACHMENT", indexes = {
        @Index(name = "IDX_KPIKPIGOALATTACHME_KPIGOAL", columnList = "KPI_GOAL_ID")
})
@Entity(name = "kpi_KpiGoalAttachment")
public class KpiGoalAttachment {

    public static final String SEQUENCE_NAME = "kpiGoalAttachment";

    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "SN", length = 24)
    private String sn;

    @JoinColumn(name = "KPI_GOAL_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private KpiGoal kpiGoal;

    @Column(name = "ATTACHMENT_FILE", nullable = false, length = 1024)
    @NotNull
    private FileRef attachmentFile;

    @Column(name = "INFO")
    private String info;

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public FileRef getAttachmentFile() {
        return attachmentFile;
    }

    public void setAttachmentFile(FileRef attachmentFile) {
        this.attachmentFile = attachmentFile;
    }

    public KpiGoal getKpiGoal() {
        return kpiGoal;
    }

    public void setKpiGoal(KpiGoal kpiGoal) {
        this.kpiGoal = kpiGoal;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}