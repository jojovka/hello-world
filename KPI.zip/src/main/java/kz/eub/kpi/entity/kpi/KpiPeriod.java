package kz.eub.kpi.entity.kpi;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import kz.eub.kpi.entity.EQuarter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.util.UUID;

@JmixEntity
@Table(name = "KPI_KPI_PERIOD", indexes = {
        @Index(name = "IDX_KPI_KPI_PERIOD_UNQ", columnList = "YEAR_, QUARTER", unique = true)
})
@Entity(name = "kpi_KpiPeriod")
public class KpiPeriod {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @NotNull
    @Column(name = "YEAR_", nullable = false)
    private Integer year;

    @Column(name = "QUARTER", nullable = false)
    @NotNull
    private String quarter;

    public EQuarter getQuarter() {
        return quarter == null ? null : EQuarter.fromId(quarter);
    }

    public void setQuarter(EQuarter quarter) {
        this.quarter = quarter == null ? null : quarter.getId();
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"quarter", "year"})
    public String getInstanceName() {
        return String.format("%s %s", quarter, year);
    }
}