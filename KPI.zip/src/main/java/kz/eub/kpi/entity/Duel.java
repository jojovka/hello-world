package kz.eub.kpi.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;
import java.util.List;

@JmixEntity
@Table(name = "KPI_DUEL", schema = "probonus")
@Entity(name = "kpi_Duel")
public class Duel {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private Integer id;

    @Column(name = "POINTS")
    private Integer points;

    @InstanceName
    @Column(name = "TITLE")
    private String title;

    @Column(name = "TIME_DURATION")
    @Temporal(TemporalType.TIME)
    private Date timeDuration;

    @Column(name = "TYPE")
    private Boolean type;

    @Column(name = "STATUS")
    private Boolean status;

    @Column(name = "PLAYED")
    private Integer played;

    @Column(name = "QUESTION_COUNT")
    private Integer questionCount;

    @OneToMany(mappedBy = "duel")
    private List<DuelQuestion> questions;

    public Integer getPoints() {
        return points;
    }

    public void setPoints(Integer points) {
        this.points = points;
    }

    public List<DuelQuestion> getQuestions() {
        return questions;
    }

    public void setQuestions(List<DuelQuestion> questions) {
        this.questions = questions;
    }

    public Boolean getType() {
        return type;
    }

    public void setType(Boolean type) {
        this.type = type;
    }

    public Date getTimeDuration() {
        return timeDuration;
    }

    public void setTimeDuration(Date timeDuration) {
        this.timeDuration = timeDuration;
    }

    public Integer getQuestionCount() {
        return questionCount;
    }

    public void setQuestionCount(Integer questionCount) {
        this.questionCount = questionCount;
    }

    public Integer getPlayed() {
        return played;
    }

    public void setPlayed(Integer played) {
        this.played = played;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}