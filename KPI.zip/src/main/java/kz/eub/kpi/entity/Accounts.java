package kz.eub.kpi.entity;

import io.jmix.core.DeletePolicy;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;

@JmixEntity
@Table(name = "accounts", schema = "probonus")
@Entity(name = "kpi_Accounts")
public class Accounts {


    @JmixGeneratedValue
    @Column(name = "id", nullable = false)
    @Id
    private Integer id;

    @OnDeleteInverse(DeletePolicy.UNLINK)
    @JoinColumn(name = "EMPLOYEE_ID")
    @OneToOne(fetch = FetchType.LAZY)
    private Employee employee;

    @Column(name = "state_id")
    private Integer stateId;

    @Column(name = "identity_property")
    private String identityProperty;

    @Column(name = "credential_property")
    private String credentialProperty;

    @Column(name = "email")
    private String email;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Composition
    @JoinColumn(name = "profile_id")
    @OneToOne(fetch = FetchType.LAZY)
    private AccountProfiles profileId;

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }


    public Accounts() {
    }
    public Accounts(Integer id) {
        this.id = id;
    }

    public AccountProfiles getProfileId() {
        return profileId;
    }

    public void setProfileId(AccountProfiles profileId) {
        this.profileId = profileId;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCredentialProperty() {
        return credentialProperty;
    }

    public void setCredentialProperty(String credentialProperty) {
        this.credentialProperty = credentialProperty;
    }

    public String getIdentityProperty() {
        return identityProperty;
    }

    public void setIdentityProperty(String identityProperty) {
        this.identityProperty = identityProperty;
    }

    public Integer getStateId() {
        return stateId;
    }

    public void setStateId(Integer stateId) {
        this.stateId = stateId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}