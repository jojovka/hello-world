package kz.eub.kpi.entity.kpi;

import io.jmix.appsettings.defaults.AppSettingsDefaultInt;
import io.jmix.appsettings.entity.AppSettingsEntity;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "KPI_KPI_CARD_SETTINGS")
@Entity(name = "kpi_KpiCardSettings")
public class KpiCardSettings extends AppSettingsEntity {
    @JmixGeneratedValue
    @Column(name = "UUID")
    private UUID uuid;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @AppSettingsDefaultInt(31)
    @Column(name = "ENABLE_CREATION_DAYS_TO_NEXT_Q")
    private Integer enableCreationDaysToNextQuarter;

    @AppSettingsDefaultInt(45)
    @Column(name = "ENBL_CREAT_DAYS_FROM_CUR_Q")
    private Integer enableCreationDaysFromCurrentQuarter;

    @AppSettingsDefaultInt(45)
    @Column(name = "ENBL_SUMMARY_DAYS_BFR_NXT_Q")
    private Integer enableSummaryDaysBeforeNextQuarter;

    @AppSettingsDefaultInt(15)
    @Column(name = "ENBL_SUMMARY_DAYS_AFTR_NXT_Q")
    private Integer enableSummaryDaysAfterNextQuarter;

    public Integer getEnableSummaryDaysBeforeNextQuarter() {
        return enableSummaryDaysBeforeNextQuarter;
    }

    public void setEnableSummaryDaysBeforeNextQuarter(Integer enableSummaryDaysBefore) {
        this.enableSummaryDaysBeforeNextQuarter = enableSummaryDaysBefore;
    }

    public Integer getEnableSummaryDaysAfterNextQuarter() {
        return enableSummaryDaysAfterNextQuarter;
    }

    public void setEnableSummaryDaysAfterNextQuarter(Integer enableSummaryDaysUntil) {
        this.enableSummaryDaysAfterNextQuarter = enableSummaryDaysUntil;
    }

    public Integer getEnableCreationDaysFromCurrentQuarter() {
        return enableCreationDaysFromCurrentQuarter;
    }

    public void setEnableCreationDaysFromCurrentQuarter(Integer enableCreationDaysFromCurrentQuarter) {
        this.enableCreationDaysFromCurrentQuarter = enableCreationDaysFromCurrentQuarter;
    }

    public Integer getEnableCreationDaysToNextQuarter() {
        return enableCreationDaysToNextQuarter;
    }

    public void setEnableCreationDaysToNextQuarter(Integer enableCreationDaysToNextQuarter) {
        this.enableCreationDaysToNextQuarter = enableCreationDaysToNextQuarter;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public UUID getUuid() {
        return uuid;
    }

    public void setUuid(UUID uuid) {
        this.uuid = uuid;
    }
}