package kz.eub.kpi.entity;

import io.jmix.core.FileRef;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;

@JmixEntity
@Table(name = "KPI_COMPETITION", schema = "probonus", indexes = {
        @Index(name = "IDX_KPI_COMPETITION_POSITION", columnList = "POSITION"),
        @Index(name = "IDX_KPI_COMPETITION_BRANCH", columnList = "BRANCH")
})
@Entity(name = "kpi_Competition")
public class Competition {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private Integer id;

    @Column(name = "PARAMETER_RATING")
    private Boolean parameterRating;

    @Column(name = "PARAMETER_CREDIT")
    private Boolean parameterCredit;

    @Column(name = "TITLE")
    private String title;

    @InstanceName
    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "DATE_START")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateStart;

    @Column(name = "DATE_END")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateEnd;

    @Column(name = "TYPE")
    private String type;

    @Column(name = "POSITION")
    private String position;

    @Column(name = "BRANCH")
    private String branch;

    @Column(name = "COEFFICIENT")
    private Integer coefficient;

    @Column(name = "AKTIV_CARD")
    private Integer aktivCard;

    @Column(name = "SLOGAN")
    private String slogan;

    @Column(name = "IMAGE", length = 1024)
    private FileRef image;

    @Column(name = "STATUS")
    private Boolean status;

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getBranch() {
        return branch;
    }

    public Boolean getParameterCredit() {
        return parameterCredit;
    }

    public void setParameterCredit(Boolean parameterCredit) {
        this.parameterCredit = parameterCredit;
    }

    public Boolean getParameterRating() {
        return parameterRating;
    }

    public void setParameterRating(Boolean parameterRating) {
        this.parameterRating = parameterRating;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getPosition() {
        return position;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public FileRef getImage() {
        return image;
    }

    public void setImage(FileRef image) {
        this.image = image;
    }

    public String getSlogan() {
        return slogan;
    }

    public void setSlogan(String slogan) {
        this.slogan = slogan;
    }

    public Integer getAktivCard() {
        return aktivCard;
    }

    public void setAktivCard(Integer aktivCard) {
        this.aktivCard = aktivCard;
    }

    public Integer getCoefficient() {
        return coefficient;
    }

    public void setCoefficient(Integer coefficient) {
        this.coefficient = coefficient;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getDateEnd() {
        return dateEnd;
    }

    public void setDateEnd(Date dateEnd) {
        this.dateEnd = dateEnd;
    }

    public Date getDateStart() {
        return dateStart;
    }

    public void setDateStart(Date dateStart) {
        this.dateStart = dateStart;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}