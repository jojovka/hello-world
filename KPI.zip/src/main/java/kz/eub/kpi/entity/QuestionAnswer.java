package kz.eub.kpi.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@JmixEntity
@Table(name = "KPI_QUESTION_ANSWER", schema = "probonus", indexes = {
        @Index(name = "IDX_KPIQUESTIONAN_DUELQUESTION", columnList = "DUEL_QUESTION_ID")
})
@Entity(name = "kpi_QuestionAnswer")
public class QuestionAnswer {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private Integer id;

    @Column(name = "ANSWER_TITLE")
    private String answerTitle;

    @Column(name = "IS_CORRECT")
    private Boolean isCorrect;

    @JoinColumn(name = "DUEL_QUESTION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DuelQuestion duelQuestion;

    public DuelQuestion getDuelQuestion() {
        return duelQuestion;
    }

    public void setDuelQuestion(DuelQuestion duelQuestion) {
        this.duelQuestion = duelQuestion;
    }

    public Boolean getIsCorrect() {
        return isCorrect;
    }

    public void setIsCorrect(Boolean isCorrect) {
        this.isCorrect = isCorrect;
    }

    public String getAnswerTitle() {
        return answerTitle;
    }

    public void setAnswerTitle(String answerTitle) {
        this.answerTitle = answerTitle;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}