package kz.eub.kpi.entity;

import io.jmix.core.FileRef;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

@JmixEntity
@Table(name = "KPI_DUEL_QUESTION", schema = "probonus", indexes = {
        @Index(name = "IDX_KPI_DUEL_QUESTION_DUEL", columnList = "DUEL_ID")
})
@Entity(name = "kpi_DuelQuestion")
public class DuelQuestion {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private Integer id;

    @Column(name = "IMAGE", length = 1024)
    private FileRef image;

    @Column(name = "QUESTION_TITLE")
    private String questionTitle;

    @JoinColumn(name = "DUEL_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Duel duel;

    @OneToMany(mappedBy = "duelQuestion")
    private List<QuestionAnswer> answers;

    public List<QuestionAnswer> getAnswers() {
        return answers;
    }

    public void setAnswers(List<QuestionAnswer> answers) {
        this.answers = answers;
    }

    public Duel getDuel() {
        return duel;
    }

    public void setDuel(Duel duel) {
        this.duel = duel;
    }

    public String getQuestionTitle() {
        return questionTitle;
    }

    public void setQuestionTitle(String questionTitle) {
        this.questionTitle = questionTitle;
    }

    public FileRef getImage() {
        return image;
    }

    public void setImage(FileRef image) {
        this.image = image;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}