package kz.eub.kpi.entity.kpi;

import io.jmix.core.metamodel.annotation.JmixEntity;
import kz.eub.kpi.entity.Application;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@JmixEntity
@Table(name = "KPI_KPI_APPLICATION")
@Entity(name = "kpi_KpiApplication")
@PrimaryKeyJoinColumn(name = "ID")
@DiscriminatorValue("KPI_APPLICATION")
public class KpiApplication extends Application {

}