package kz.eub.kpi.entity.kpi;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum EKpiGoalAssessmentType implements EnumClass<String> {

    MORE_IS_BETTER("MORE_IS_BETTER"),
    LESS_IS_BETTER("LESS_IS_BETTER"),
    EQUALS("EQUALS");

    private String id;

    EKpiGoalAssessmentType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static EKpiGoalAssessmentType fromId(String id) {
        for (EKpiGoalAssessmentType at : EKpiGoalAssessmentType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}