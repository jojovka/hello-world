package kz.eub.kpi.entity;

import io.jmix.ui.screen.ScreenOptions;

import javax.swing.*;
import java.util.Date;
import java.util.UUID;

public class RatingUserOptions implements ScreenOptions {

    private Integer accId;
    private String fio;
    private Double points;
    private Date dateStart;
    private Date dateEnd;

    private Integer typeId;

    private UUID uuid;
    public RatingUserOptions(Integer accountId, String fio, Double points,
                             Date dateStart, Date dateEnd, Integer typeId) {
        this.accId = accountId;
        this.fio = fio;
        this.points = points;
        this.dateStart = dateStart;
        this.dateEnd = dateEnd;
        this.typeId = typeId;
    }

    public RatingUserOptions(UUID uuid) {
        this.uuid = uuid;
    }

    public Integer getAccountId() {
        return accId;
    }

    public String getFio() {
        return fio;
    }

    public Double getPoints() {
        return points;
    }

    public Date getDateStart() {
        return dateStart;
    }

    public Date getDateEnd() {
        return dateEnd;
    }

    public Integer getTypeId() {
        return typeId;
    }

    public UUID getUuid() {return uuid; }

}
