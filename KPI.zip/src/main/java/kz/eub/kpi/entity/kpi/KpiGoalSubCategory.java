package kz.eub.kpi.entity.kpi;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.util.UUID;

@JmixEntity
@Table(name = "KPI_KPI_GOAL_SUB_CATEGORY")
@Entity(name = "kpi_KpiGoalSubCategory")
public class KpiGoalSubCategory {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @NotNull
    @Column(name = "CATEGORY", nullable = false)
    private String category;

    @NotNull
    @Column(name = "CODE", nullable = false)
    private String code;

    @NotNull
    @InstanceName
    @Column(name = "NAME", nullable = false)
    private String name;

    @Column(name = "INFO")
    @Lob
    private String info;

    public void setCategory(EKpiGoalCategory category) {
        this.category = category == null ? null : category.getId();
    }

    public EKpiGoalCategory getCategory() {
        return category == null ? null : EKpiGoalCategory.fromId(category);
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}