package kz.eub.kpi.entity;

import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@JmixEntity
@Table(name = "KPI_STAFF_APPLICATION")
@Entity(name = "kpi_StaffApplication")
@PrimaryKeyJoinColumn(name = "ID")
@DiscriminatorValue("STAFF_APPLICATION")
public class StaffApplication extends Application {



}