package kz.eub.kpi.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;

@JmixEntity
@Table(name = "point_user", schema = "probonus")
@Entity(name = "kpi_PointUser")
public class PointUser {
    @JmixGeneratedValue
    @Column(name = "id", nullable = false)
    @Id
    private Integer id;

    @Column(name = "account_id")
    private Integer accountId;

    @Column(name = "point_type")
    private Integer pointType;

    @Column(name = "type_id")
    private Integer typeId;

    @Column(name = "plan")
    private Double plan;

    @Column(name = "value")
    private Double value;

    @Column(name = "ratio")
    private Double ratio;

    @Column(name = "entity_class")
    private String entityClass;

    @Column(name = "entity_id")
    private Integer entityId;

    @Column(name = "AUDIT_ID")
    private Long auditId;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_at")
    private Date createdAt;

    @InstanceName
    @Column(name = "description", length = 1024)
    private String description;

    public void setPlan(Double plan) {
        this.plan = plan;
    }

    public Double getPlan() {
        return plan;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public Double getValue() {
        return value;
    }

    public void setRatio(Double ratio) {
        this.ratio = ratio;
    }

    public Double getRatio() {
        return ratio;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    public Integer getTypeId() {
        return typeId;
    }

    public void setEntityId(Integer entityId) {
        this.entityId = entityId;
    }

    public Integer getEntityId() {
        return entityId;
    }

    public void setAuditId(Long auditId) {
        this.auditId = auditId;
    }

    public Long getAuditId() {
        return auditId;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    public Integer getAccountId() {
        return accountId;
    }


    public void setPointType(Integer pointType) {
        this.pointType = pointType;
    }

    public Integer getPointType() {
        return pointType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEntityClass() {
        return entityClass;
    }

    public void setEntityClass(String entityClass) {
        this.entityClass = entityClass;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}