package kz.eub.kpi.entity;

import io.jmix.core.FileRef;
import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;
import kz.eub.kpi.entity.kpi.IntermediateAssessmentMeeting;
import kz.eub.kpi.entity.kpi.KpiCompetence;
import kz.eub.kpi.entity.kpi.KpiEmplDevPlan;
import kz.eub.kpi.entity.kpi.KpiResult;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import java.util.Date;
import java.util.List;

@Table(name = "kpi_Employee", indexes = {
        @Index(name = "IDX_KPI_EMPLOYEE_SUPERVISOR", columnList = "SUPERVISOR_ID"),
        @Index(name = "IDX_KPI_EMPLOYEE_LEADER", columnList = "LEADER_ID"),
        @Index(name = "IDX_KPI_EMPLOYEE_ORG_UNIT", columnList = "ORG_UNIT_ID"),
        @Index(name = "IDX_KPI_EMPLOYEE_DEPARTMENT", columnList = "DEPARTMENT_ID"),
        @Index(name = "IDX_KPI_EMPLOYEE_GROUP_TYPE", columnList = "GROUP_TYPE_ID"),
        @Index(name = "IDX_KPIEMPLOYEE_FUNCTIONALMANA", columnList = "FUNCTIONAL_MANAGER_ID")
})
@JmixEntity
@Entity(name = "kpi_Employee")
@DiscriminatorValue("EMPLOYEE")
@PrimaryKeyJoinColumn(name = "id")
public class Employee extends User implements Comparable<Employee> {
    @Column(name = "IIN", length = 60)
    private String iin;

    @Column(name = "DEP_NAME")
    private String depName;

    @Column(name = "POS_NAME")
    private String posName;

    @Column(name = "BRANCH_NAME")
    private String branchName;

    @JoinColumn(name = "DEPARTMENT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictDepartment department;

    @JoinColumn(name = "ORG_UNIT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictDepartment orgUnit;

    @Column(name = "HIRE_DATE")
    @Temporal(TemporalType.DATE)
    private Date hireDate;

    @Column(name = "START_DATE")
    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Column(name = "END_DATE")
    @Temporal(TemporalType.DATE)
    private Date endDate;

    @Column(name = "BIRTH_DATE")
    @Temporal(TemporalType.DATE)
    private Date birthDate;

    @JoinColumn(name = "POSITION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictPosition position;

    @JoinColumn(name = "SUPERVISOR_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Employee supervisor;

    @JoinColumn(name = "LEADER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Employee leader;

    @JoinColumn(name = "FUNCTIONAL_MANAGER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Employee functionalManager;

    @Column(name = "GENDER")
    private String gender;

    @Column(name = "GRADE")
    private String grade;

    @Column(name = "PHOTO", length = 1024)
    private FileRef photo;

    @Column(name = "COMMENT_")
    private String comment;

    @Composition
    @OneToMany(mappedBy = "employee")
    private List<KpiCompetence> competencies;

    @Composition
    @OneToMany(mappedBy = "employee")
    private List<KpiEmplDevPlan> devPlans;

    @Composition
    @OneToMany(mappedBy = "employee")
    private List<IntermediateAssessmentMeeting> interAssessmentMeetings;

    @JoinColumn(name = "GROUP_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private EmployeeGroupType groupType;

    @Column(name = "PAYROLL_NUMBER", length = 24)
    protected String payrollNumber;

    @JmixProperty
    @Transient
    private KpiResult currentKpiResult;

    public Employee getFunctionalManager() {
        return functionalManager;
    }

    public void setFunctionalManager(Employee functionalManager) {
        this.functionalManager = functionalManager;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public String getPosName() {
        return posName;
    }

    public void setPosName(String posName) {
        this.posName = posName;
    }

    public String getDepName() {
        return depName;
    }

    public void setDepName(String depName) {
        this.depName = depName;
    }

    public Date getHireDate() {
        return hireDate;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    public String getPayrollNumber() {
        return payrollNumber;
    }


    public void setPayrollNumber(String payrollNumber) {
        this.payrollNumber = payrollNumber;
    }

    public EmployeeGroupType getGroupType() {
        return groupType;
    }

    public void setGroupType(EmployeeGroupType groupType) {
        this.groupType = groupType;
    }

    public void setInterAssessmentMeetings(List<IntermediateAssessmentMeeting> interAssessmentMeetings) {
        this.interAssessmentMeetings = interAssessmentMeetings;
    }

    public List<IntermediateAssessmentMeeting> getInterAssessmentMeetings() {
        return interAssessmentMeetings;
    }

    public List<KpiEmplDevPlan> getDevPlans() {
        return devPlans;
    }

    public void setDevPlans(List<KpiEmplDevPlan> devPlans) {
        this.devPlans = devPlans;
    }

    public List<KpiCompetence> getCompetencies() {
        return competencies;
    }

    public void setCompetencies(List<KpiCompetence> competencies) {
        this.competencies = competencies;
    }

    public KpiResult getCurrentKpiResult() {
        return currentKpiResult;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public DictDepartment getDepartment() {
        return department;
    }

    public void setDepartment(DictDepartment department) {
        this.department = department;
    }

    public DictDepartment getOrgUnit() {
        return orgUnit;
    }

    public void setOrgUnit(DictDepartment organizationUnit) {
        this.orgUnit = organizationUnit;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public Employee getLeader() {
        return leader;
    }

    public void setLeader(Employee leader) {
        this.leader = leader;
    }


    public EGender getGender() {
        return gender == null ? null : EGender.fromId(gender);
    }

    public void setGender(EGender gender) {
        this.gender = gender == null ? null : gender.getId();
    }

    public Employee getSupervisor() {
        return supervisor;
    }

    public void setSupervisor(Employee supervisor) {
        this.supervisor = supervisor;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getIin() {
        return iin;
    }

    public void setIin(String iin) {
        this.iin = iin;
    }

    public DictPosition getPosition() {
        return position;
    }

    public void setPosition(DictPosition position) {
        this.position = position;
    }

    public FileRef getPhoto() {
        return photo;
    }

    public void setPhoto(FileRef photo) {
        this.photo = photo;
    }


    @Override
    public int compareTo(Employee e2) {
        if (fullName == null)  {
            if (e2.getFullName() != null)
                return 1;
            else
                return 0;
        }
        if (e2.getFullName() == null) return -1;
        return fullName.compareTo(e2.getFullName());
    }

}