package kz.eub.kpi.entity.kpi;

import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import kz.eub.kpi.entity.DictBusiness;
import kz.eub.kpi.entity.Unit;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "KPI_KPI_GOAL_DICT", indexes = {
        @Index(name = "IDX_KPI_KPI_GOAL_DICT_BUSINESS", columnList = "BUSINESS_ID")
})
@Entity(name = "kpi_KpiGoalDict")
public class KpiGoalDict {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @NotNull
    @Column(name = "CATEGORY", nullable = false)
    private String category;

    @JoinColumn(name = "SUB_CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private KpiGoalSubCategory subCategory;

    @NotNull
    @Column(name = "GOAL", nullable = false)
    private String name;

    @Lob
    @Column(name = "GOAL_DESCRIPTION")
    private String goalDescription;

    @JoinColumn(name = "UNIT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Unit unit;

    @Column(name = "ASSESSMENT_METHOD")
    private String assessmentMethod;

    @Column(name = "SOURCE")
    private String dataSource;

    @Lob
    @Column(name = "INFO")
    private String info;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @JoinColumn(name = "BUSINESS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictBusiness business;

    public DictBusiness getBusiness() {
        return business;
    }

    public void setBusiness(DictBusiness business) {
        this.business = business;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }

    public String getDataSource() {
        return dataSource;
    }

    public EKpiGoalCategory getCategory() {
        return category == null ? null : EKpiGoalCategory.fromId(category);
    }

    public void setCategory(EKpiGoalCategory category) {
        this.category = category == null ? null : category.getId();
    }

    public void setSubCategory(KpiGoalSubCategory subCategory) {
        this.subCategory = subCategory;
    }

    public KpiGoalSubCategory getSubCategory() {
        return subCategory;
    }

    public void setAssessmentMethod(EKpiGoalAssessmentType assessmentMethod) {
        this.assessmentMethod = assessmentMethod == null ? null : assessmentMethod.getId();
    }

    public EKpiGoalAssessmentType getAssessmentMethod() {
        return assessmentMethod == null ? null : EKpiGoalAssessmentType.fromId(assessmentMethod);
    }

    public void setUnit(Unit unit) {
        this.unit = unit;
    }

    public Unit getUnit() {
        return unit;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getGoalDescription() {
        return goalDescription;
    }

    public void setGoalDescription(String goalDescription) {
        this.goalDescription = goalDescription;
    }

    public String getName() {
        return name;
    }

    public void setName(String goal) {
        this.name = goal;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"goalDescription"})
    public String getInstanceName() {
        return String.format("%s", name);
    }
}