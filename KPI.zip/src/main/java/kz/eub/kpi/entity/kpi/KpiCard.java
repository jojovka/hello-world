package kz.eub.kpi.entity.kpi;

import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@JmixEntity
@Table(name = "KPI_KPI_CARD", indexes = {
        @Index(name = "IDX_KPI_KPI_CARD_PERIOD", columnList = "PERIOD_ID")
})
@DiscriminatorValue("KPI_CARD")
@PrimaryKeyJoinColumn(name = "ID")
@Entity(name = "kpi_KpiCard")
public class KpiCard extends KpiApplication {

    public static final String ROUTE = "kpicard";

    public static final String PROCESS_DEF_KEY_APPROVAL = "kpi-card-approval";

    public static final String PROCESS_DEF_KEY_ASSESSMENT = "kpi-card-assessment";

    public static final int MIN_ALLOWED_GOALS = 3;

    public static final int MAX_ALLOWED_GOALS = 7;

    public static final String REP_ENTITY_REPORT_CODE = "KPI_CARD_ENTITY_REPORT";

    public static final String REP_EXPORT_KPI_CARDS_LIST_CODE = "kpi-cards-export";

    public static final String REP_ENTITY_DEFAULT_TEMPLATE_CODE = "DEFAULT";


    @JoinColumn(name = "PERIOD_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private KpiPeriod period;

    @Composition
    @OneToMany(mappedBy = "kpiCard", cascade = CascadeType.ALL)
    private List<KpiGoal> kpiGoals;

    @Column(name = "TOTAL_KPI", precision = 19, scale = 2)
    private BigDecimal totalKpi;

    @Column(name = "STAGE")
    private String stage;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public EKpiCardStage getStage() {
        return stage == null ? null : EKpiCardStage.fromId(stage);
    }

    public void setStage(EKpiCardStage stage) {
        this.stage = stage == null ? null : stage.getId();
    }

    public BigDecimal getTotalKpi() {
        return totalKpi;
    }

    public void setTotalKpi(BigDecimal totalKpi) {
        this.totalKpi = totalKpi;
    }

    public KpiPeriod getPeriod() {
        return period;
    }

    public void setPeriod(KpiPeriod period) {
        this.period = period;
    }

    public List<KpiGoal> getKpiGoals() {
        return kpiGoals;
    }

    public void setKpiGoals(List<KpiGoal> kpiGoals) {
        this.kpiGoals = kpiGoals;
    }

    @Override
    public String getName() {
        return "Карта КПЭ";
    }

    @Override
    public String getRouteUri() {
        return ROUTE;
    }
}