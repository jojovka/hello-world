package kz.eub.kpi.entity.kpi;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.kpi.EKpiGoalStatus;
import kz.eub.kpi.entity.kpi.KpiGoal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "KPI_KPI_GOAL_REVIEW_RESULT", indexes = {
        @Index(name = "IDX_KPIKPIGOALREVIEWRE_KPIGOAL", columnList = "KPI_GOAL_ID"),
        @Index(name = "IDX_KPIKPIGOALREVIEWR_REVIEWER", columnList = "REVIEWER_ID")
})
@Entity(name = "kpi_KpiGoalReviewResult")
public class KpiGoalReviewResult {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "KPI_GOAL_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private KpiGoal kpiGoal;

    @NotNull
    @Column(name = "DATE_", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date date;

    @InstanceName
    @Column(name = "TITLE")
    private String title;

    @JoinColumn(name = "REVIEWER_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Employee reviewer;

    @NotNull
    @Column(name = "STATUS", nullable = false)
    private String status;

    @Lob
    @Column(name = "INFO")
    private String info;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public EKpiGoalStatus getStatus() {
        return status == null ? null : EKpiGoalStatus.fromId(status);
    }

    public void setStatus(EKpiGoalStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public Employee getReviewer() {
        return reviewer;
    }

    public void setReviewer(Employee reviewer) {
        this.reviewer = reviewer;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public KpiGoal getKpiGoal() {
        return kpiGoal;
    }

    public void setKpiGoal(KpiGoal kpiGoal) {
        this.kpiGoal = kpiGoal;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}