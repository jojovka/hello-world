package kz.eub.kpi.entity;

import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@JmixEntity
@Table(name = "KPI_UNIT")
@Entity(name = "kpi_Unit")
public class Unit {

    public static final String UNIT_WDAY = "WDAY";
    public static final String UNIT_PCS = "PCS";
    public static final String UNIT_PERCENT = "PERCENT";

    public static final String UNIT_MONEY = "MONEY";
    public static final String UNIT_OTHER = "OTHER";

    @Column(name = "ID", nullable = false, length = 10)
    @Id
    private String id;

    @InstanceName
    @Column(name = "NAME")
    private String name;

    @Column(name = "CODE", length = 20)
    private String code;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}