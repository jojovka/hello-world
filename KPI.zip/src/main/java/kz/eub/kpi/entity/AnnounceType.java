package kz.eub.kpi.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum AnnounceType implements EnumClass<String> {

    WARNING("WARNING"),
    SUCCESS("SUCCESS"),
    COMMENT("COMMENT");

    private String id;

    AnnounceType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static AnnounceType fromId(String id) {
        for (AnnounceType at : AnnounceType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}