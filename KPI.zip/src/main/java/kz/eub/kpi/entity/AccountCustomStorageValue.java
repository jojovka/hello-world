package kz.eub.kpi.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@JmixEntity
@Table(name = "KPI_ACCOUNT_CUSTOM_STORAGE_VAL")
@Entity(name = "kpi_AccountCustomStorageValue")
public class AccountCustomStorageValue {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private Integer id;

    @Column(name = "OUTLET")
    private String outlet;

    @Column(name = "REGION")
    private String region;

    @Column(name = "POSITION_")
    private String position;

    @Column(name = "DEPARTMENT")
    private String department;

    @Column(name = "KPI_IMPORT_DATE")
    private String kpi_import_date;

    public String getKpi_import_date() {
        return kpi_import_date;
    }

    public void setKpi_import_date(String kpi_import_date) {
        this.kpi_import_date = kpi_import_date;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getOutlet() {
        return outlet;
    }

    public void setOutlet(String outlet) {
        this.outlet = outlet;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}