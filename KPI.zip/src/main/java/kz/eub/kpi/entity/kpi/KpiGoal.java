package kz.eub.kpi.entity.kpi;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.Employee;
import kz.eub.kpi.entity.Unit;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "KPI_KPI_GOAL", indexes = {
        @Index(name = "IDX_KPIGOAL_UNIT_ID", columnList = "UNIT_ID"),
        @Index(name = "IDX_KPIGOAL_EMPLOYEE_ID", columnList = "EMPLOYEE_ID"),
        @Index(name = "IDX_KPIGOAL_DEPARTMENT_ID", columnList = "DEPARTMENT_ID"),
        @Index(name = "IDX_KPI_KPI_GOAL_PERIOD", columnList = "PERIOD_ID"),
        @Index(name = "IDX_KPI_KPI_GOAL_APPLICATION", columnList = "KPI_CARD_ID"),
        @Index(name = "IDX_KPI_KPI_GOAL_SUB_CATEGORY", columnList = "SUB_CATEGORY_ID"),
        @Index(name = "IDX_KPI_KPI_GOAL_GOAL_DICT", columnList = "GOAL_DICT_ID")
})
@Entity(name = "kpi_KpiGoal")
public class KpiGoal {
    public static final String SEQUENCE_NAME = "kpiGoal";

    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "PERIOD_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private KpiPeriod period;

    @JoinColumn(name = "GOAL_DICT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private KpiGoalDict goalDict;

    @Composition
    @OneToMany(mappedBy = "kpiGoal", cascade = CascadeType.ALL)
    private List<KpiGoalAttachment> attachments;

    @JoinColumn(name = "KPI_CARD_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private KpiCard kpiCard;

    @Column(name = "SN", length = 24)
    private String sn;

    @Lob
    @InstanceName
    @Column(name = "NAME")
    private String name;

    @Column(name = "KPI_DESCRIPTION")
    @Lob
    private String kpiDescription;

    @JoinColumn(name = "UNIT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Unit unit;

    @Column(name = "CATEGORY")
    private String category;

    @JoinColumn(name = "SUB_CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private KpiGoalSubCategory subCategory;

    @Column(name = "ASSESSMENT_TYPE")
    private String assessmentType;

    @JoinColumn(name = "EMPLOYEE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Employee employee;

    @JoinColumn(name = "DEPARTMENT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictDepartment department;

    @Column(name = "DATA_SOURCE")
    private String dataSource;

    @DecimalMin(message = "{msg://kz.eub.kpi.entity.kpi/KpiGoal.weight.validation.DecimalMin}", value = "5")
    @NotNull(message = "{msg://kz.eub.kpi.entity.kpi/KpiGoal.weight.validation.NotNull}")
    @Positive(message = "{msg://kz.eub.kpi.entity.kpi/KpiGoal.weight.validation.Positive}")
    @Column(name = "WEIGHT", precision = 19, scale = 2)
    private BigDecimal weight;

    @Column(name = "PLAN_", precision = 19, scale = 2)
    private BigDecimal plan;

    @Column(name = "PLAN_DATE")
    @Temporal(TemporalType.DATE)
    private Date planDate;

    @Column(name = "FACT", precision = 19, scale = 2)
    private BigDecimal fact;

    @Column(name = "FACT_DATE")
    @Temporal(TemporalType.DATE)
    private Date factDate;

    @Column(name = "STATUS")
    private String status;

    @Composition
    @OneToMany(mappedBy = "kpiGoal", cascade = CascadeType.ALL)
    private List<KpiGoalReviewResult> reviewResults;

    @Composition
    @OneToMany(mappedBy = "goal", cascade = CascadeType.ALL)
    private List<KpiGoalComment> comments;

    @Column(name = "PROGRESS", precision = 19, scale = 2)
    private BigDecimal progress;

    @Column(name = "EFFICIENCY", precision = 19, scale = 2)
    @DecimalMax(message = "{msg://kz.eub.kpi.entity.kpi/KpiGoal.efficiency.validation.DecimalMax}", value = "150")
    private BigDecimal efficiency;

    @Lob
    @Column(name = "INFO")
    private String info;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @JmixProperty
    @Transient
    private String planStr;

    @JmixProperty
    @Transient
    private String factStr;

    @JmixProperty
    @Transient
    private String comment;

    public KpiGoalDict getGoalDict() {
        return goalDict;
    }

    public void setGoalDict(KpiGoalDict goalDict) {
        this.goalDict = goalDict;
    }

    public KpiGoalSubCategory getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(KpiGoalSubCategory subCategory) {
        this.subCategory = subCategory;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getKpiDescription() {
        return kpiDescription;
    }

    public void setKpiDescription(String kpiDescription) {
        this.kpiDescription = kpiDescription;
    }

    public String getFactStr() {
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
        return (unit != null
                && unit.getId().equals(Unit.UNIT_WDAY))
                ? (factDate != null) ? format.format(factDate) : ""
                : (fact != null) ? "" + fact : "";
    }

    public void setFactStr(String factStr) {
        this.factStr = factStr;
    }

    public List<KpiGoalComment> getComments() {
        return comments;
    }

    public void setComments(List<KpiGoalComment> comments) {
        this.comments = comments;
    }

    public EKpiGoalAssessmentType getAssessmentType() {
        return assessmentType == null ? null : EKpiGoalAssessmentType.fromId(assessmentType);
    }

    public void setAssessmentType(EKpiGoalAssessmentType assessmentType) {
        this.assessmentType = assessmentType == null ? null : assessmentType.getId();
    }

    public String getPlanStr() {
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
        return (unit != null
                && unit.getId().equals(Unit.UNIT_WDAY))
                ? (planDate != null) ? format.format(planDate) : ""
                : (plan != null) ? "" + plan : "";
    }

    public void setPlanStr(String planStr) {
        this.planStr = planStr;
    }

    public Date getFactDate() {
        return factDate;
    }

    public void setFactDate(Date factDate) {
        this.factDate = factDate;
    }

    public Date getPlanDate() {
        return planDate;
    }

    public void setPlanDate(Date planDate) {
        this.planDate = planDate;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public List<KpiGoalReviewResult> getReviewResults() {
        return reviewResults;
    }

    public void setReviewResults(List<KpiGoalReviewResult> reviews) {
        this.reviewResults = reviews;
    }

    public List<KpiGoalAttachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<KpiGoalAttachment> attachments) {
        this.attachments = attachments;
    }

    public void setKpiCard(KpiCard kpiCard) {
        this.kpiCard = kpiCard;
    }

    public KpiCard getKpiCard() {
        return kpiCard;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public EKpiGoalStatus getStatus() {
        return status == null ? null : EKpiGoalStatus.fromId(status);
    }

    public void setStatus(EKpiGoalStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public BigDecimal getProgress() {
        return progress;
    }

    public void setProgress(BigDecimal progress) {
        this.progress = progress;
    }

    public String getDataSource() {
        return dataSource;
    }

    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }

    public KpiPeriod getPeriod() {
        return period;
    }

    public void setPeriod(KpiPeriod period) {
        this.period = period;
    }

    public EKpiGoalCategory getCategory() {
        return category == null ? null : EKpiGoalCategory.fromId(category);
    }

    public void setCategory(EKpiGoalCategory category) {
        this.category = category == null ? null : category.getId();
    }

    public DictDepartment getDepartment() {
        return department;
    }

    public void setDepartment(DictDepartment department) {
        this.department = department;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public BigDecimal getEfficiency() {
        return efficiency;
    }

    public void setEfficiency(BigDecimal efficiency) {
        this.efficiency = efficiency;
    }

    public BigDecimal getFact() {
        return fact;
    }

    public void setFact(BigDecimal fact) {
        this.fact = fact;
    }

    public BigDecimal getPlan() {
        return plan;
    }

    public void setPlan(BigDecimal plan) {
        this.plan = plan;
    }

    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    public Unit getUnit() {
        return unit;
    }

    public void setUnit(Unit unit) {
        this.unit = unit;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}