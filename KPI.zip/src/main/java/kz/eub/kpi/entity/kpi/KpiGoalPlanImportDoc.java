package kz.eub.kpi.entity.kpi;

import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.JmixEntity;
import kz.eub.kpi.entity.Application;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.util.List;

@DiscriminatorValue("KPI_PLAN_IMPORT")
@JmixEntity
@Table(name = "KPI_KPI_GOAL_PLAN_IMPORT_DOC", indexes = {
        @Index(name = "IDX_KPIKPIGOALPLANIMPOR_PERIOD", columnList = "PERIOD_ID")
})
@Entity(name = "kpi_KpiGoalPlanImportDoc")
@PrimaryKeyJoinColumn(name = "ID", referencedColumnName = "ID")
public class KpiGoalPlanImportDoc extends Application {

    public static final String ROUTE = "goalPlanImport";

    @JoinColumn(name = "PERIOD_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private KpiPeriod period;

    @NotNull
    @Column(name = "CATEGORY", nullable = false)
    private String category;

    @Composition
    @OneToMany(mappedBy = "goalImportDoc", cascade = CascadeType.ALL)
    private List<KpiGoalDictPlan> goalDictPlans;

    public List<KpiGoalDictPlan> getGoalDictPlans() {
        return goalDictPlans;
    }

    public void setGoalDictPlans(List<KpiGoalDictPlan> goalDictPlans) {
        this.goalDictPlans = goalDictPlans;
    }

    public EKpiGoalCategory getCategory() {
        return category == null ? null : EKpiGoalCategory.fromId(category);
    }

    public void setCategory(EKpiGoalCategory category) {
        this.category = category == null ? null : category.getId();
    }

    public KpiPeriod getPeriod() {
        return period;
    }

    public void setPeriod(KpiPeriod period) {
        this.period = period;
    }

    @Override
    public String getName() {
        return "Импорт плановых показателей финансовых целей";
    }
}