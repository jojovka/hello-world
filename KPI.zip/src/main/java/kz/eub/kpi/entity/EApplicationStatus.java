package kz.eub.kpi.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum EApplicationStatus implements EnumClass<String> {

    NEW("NEW"),
    PROCESSING("PROCESSING"),
    PROCESSED("PROCESSED"),
    CREATED("CREATED"),
    APPROVAL("APPROVAL"),
    ADJUSTMENT("ADJUSTMENT"),
    SIGNING("SIGNING"),
    EXECUTION("EXECUTION"),
    REJECTED("REJECTED"),
    APPROVED("APPROVED"),
    APPROVED_WITH_REMARK("APPROVED_WITH_REMARK"),
    SUPERVISOR_APPROVAL("SUPERVISOR_APPROVAL"),
    LEADER_APPROVAL("LEADER_APPROVAL"),
    HR_APPROVAL("HR_APPROVAL"),
    FD_APPROVAL("FD_APPROVAL"),
    EXECUTED("EXECUTED"),
    ADDITIONAL_APPROVAL("ADDITIONAL_APPROVAL"),
    HQ_APPROVAL("HQ_APPROVAL"),
    SPD_APPROVAL("SPD_APPROVAL"),
    AGREED("AGREED"),
    REVOKED("REVOKED"),
    CALCULATING("CALCULATING"),
    WAITING_FOR_PERIOD("WAITING_FOR_PERIOD"),
    DRAFT("DRAFT"),
    COMPLETED("COMPLETED"),
    FUNC_MANAGER_APPROVAL("FUNC_MANAGER_APPROVAL");

    private String id;

    EApplicationStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static EApplicationStatus fromId(String id) {
        for (EApplicationStatus at : EApplicationStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}