package kz.eub.kpi.entity.kpi;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum EKpiGoalStatus implements EnumClass<String> {

    APPROVED("APPROVED"),
    REJECTED("REJECTED");

    private String id;

    EKpiGoalStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static EKpiGoalStatus fromId(String id) {
        for (EKpiGoalStatus at : EKpiGoalStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}