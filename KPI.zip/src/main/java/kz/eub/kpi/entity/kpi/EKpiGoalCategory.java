package kz.eub.kpi.entity.kpi;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum EKpiGoalCategory implements EnumClass<String> {

    FINANCIAL_GOAL("FINANCIAL_GOAL"),
    PROJECT_GOAL("PROJECT_GOAL"),
    INDIVIDUAL_GOAL("INDIVIDUAL_GOAL"),
    DEPARTMENT_GOAL("DEPARTMENT_GOAL"),
    GVK_GOAL("GVK_GOAL");

    private String id;

    EKpiGoalCategory(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static EKpiGoalCategory fromId(String id) {
        for (EKpiGoalCategory at : EKpiGoalCategory.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}