package kz.eub.kpi.entity.kpi;

import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.JmixEntity;
import kz.eub.kpi.entity.Application;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import java.util.List;

@DiscriminatorValue("KPI_FACT_IMPORT")
@JmixEntity
@Table(name = "KPI_KPI_GOAL_FACT_IMPORT_DOC", indexes = {
        @Index(name = "IDX_KPIKPIGOALFACTIMPOR_PERIOD", columnList = "PERIOD_ID")
})
@Entity(name = "kpi_KpiGoalFactImport")
@PrimaryKeyJoinColumn(name = "ID", referencedColumnName = "ID")
public class KpiGoalFactImportDoc extends Application {

    public static final String ROUTE = "goalFactImport";

    @JoinColumn(name = "PERIOD_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private KpiPeriod period;

    @Column(name = "CATEGORY")
    private String category;

    @Composition
    @OneToMany(mappedBy = "goalImportDoc", cascade = CascadeType.ALL)
    private List<KpiGoalDictFact> goalDictFacts;

    public EKpiGoalCategory getCategory() {
        return category == null ? null : EKpiGoalCategory.fromId(category);
    }

    public void setCategory(EKpiGoalCategory category) {
        this.category = category == null ? null : category.getId();
    }

    public List<KpiGoalDictFact> getGoalDictFacts() {
        return goalDictFacts;
    }

    public void setGoalDictFacts(List<KpiGoalDictFact> goalDictFacts) {
        this.goalDictFacts = goalDictFacts;
    }

    public KpiPeriod getPeriod() {
        return period;
    }

    public void setPeriod(KpiPeriod period) {
        this.period = period;
    }

    @Override
    public String getName() {
        return "Импорт фактических показателей финансовых целей";
    }
}