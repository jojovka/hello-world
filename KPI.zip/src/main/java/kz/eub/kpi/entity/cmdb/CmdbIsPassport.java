package kz.eub.kpi.entity.cmdb;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import kz.eub.kpi.entity.DictDepartment;
import kz.eub.kpi.entity.Employee;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "KPI_CMDB_IS_PASSPORT", indexes = {
        @Index(name = "IDX_CMDBISPASSPORT", columnList = "CRITICALITY_CLASS_ID"),
        @Index(name = "IDX_CMDBISPASSPORT", columnList = "BUS_OWNER_DEP_ID"),
        @Index(name = "IDX_CMDBISPASSPORT", columnList = "BUS_OWNER_EMP_ID"),
        @Index(name = "IDX_CMDBISPASSPORT", columnList = "IT_OWNER_DEP_ID"),
        @Index(name = "IDX_CMDBISPASSPORT", columnList = "APP_SUPPORT_DEP_ID"),
        @Index(name = "IDX_CMDBISPASSPORT", columnList = "DB_SUPPORT_DEP_ID"),
        @Index(name = "IDX_CMDBISPASSPORT", columnList = "IT_OWNER_EMP_ID")
})
@Entity(name = "kpi_CmdbIsPassport")
public class CmdbIsPassport {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @Column(name = "NAME_SHORT")
    private String nameShort;

    @Column(name = "NAME_LONG", length = 1024)
    private String nameLong;

    @JoinColumn(name = "CRITICALITY_CLASS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CmdbCriticalityClass criticalityClass;

    @JoinColumn(name = "BUS_OWNER_DEP_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictDepartment busOwnerDep;

    @JoinColumn(name = "BUS_OWNER_EMP_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Employee busOwnerEmp;

    @JoinColumn(name = "IT_OWNER_DEP_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictDepartment itOwnerDep;

    @JoinColumn(name = "IT_OWNER_EMP_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Employee itOwnerEmp;

    @JoinColumn(name = "APP_SUPPORT_DEP_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictDepartment appSupportDep;

    @JoinColumn(name = "DB_SUPPORT_DEP_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DictDepartment dbSupportDep;

    @Column(name = "PROD_INTRO_DATE")
    @Temporal(TemporalType.DATE)
    private Date prodIntroDate;

    @Column(name = "RETIREMENT_DATE")
    @Temporal(TemporalType.DATE)
    private Date retirementDate;

    @InstanceName
    @Column(name = "DESCRIPTION")
    @Lob
    private String description;

    @Composition
    @OneToMany(mappedBy = "isPassport")
    private List<CmdbAttachment> attachments;

    public List<CmdbAttachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<CmdbAttachment> attachments) {
        this.attachments = attachments;
    }

    public Employee getItOwnerEmp() {
        return itOwnerEmp;
    }

    public void setItOwnerEmp(Employee itOwnerEmp) {
        this.itOwnerEmp = itOwnerEmp;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getRetirementDate() {
        return retirementDate;
    }

    public void setRetirementDate(Date retirementDate) {
        this.retirementDate = retirementDate;
    }

    public Date getProdIntroDate() {
        return prodIntroDate;
    }

    public void setProdIntroDate(Date introDate) {
        this.prodIntroDate = introDate;
    }

    public DictDepartment getDbSupportDep() {
        return dbSupportDep;
    }

    public void setDbSupportDep(DictDepartment dbSupportDep) {
        this.dbSupportDep = dbSupportDep;
    }

    public DictDepartment getAppSupportDep() {
        return appSupportDep;
    }

    public void setAppSupportDep(DictDepartment appSupport) {
        this.appSupportDep = appSupport;
    }

    public DictDepartment getItOwnerDep() {
        return itOwnerDep;
    }

    public void setItOwnerDep(DictDepartment itOwnerDep) {
        this.itOwnerDep = itOwnerDep;
    }

    public Employee getBusOwnerEmp() {
        return busOwnerEmp;
    }

    public void setBusOwnerEmp(Employee ownerEmployee) {
        this.busOwnerEmp = ownerEmployee;
    }

    public DictDepartment getBusOwnerDep() {
        return busOwnerDep;
    }

    public void setBusOwnerDep(DictDepartment businessOwner) {
        this.busOwnerDep = businessOwner;
    }

    public CmdbCriticalityClass getCriticalityClass() {
        return criticalityClass;
    }

    public void setCriticalityClass(CmdbCriticalityClass criticalityClass) {
        this.criticalityClass = criticalityClass;
    }

    public String getNameLong() {
        return nameLong;
    }

    public void setNameLong(String nameLong) {
        this.nameLong = nameLong;
    }

    public String getNameShort() {
        return nameShort;
    }

    public void setNameShort(String nameShort) {
        this.nameShort = nameShort;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}