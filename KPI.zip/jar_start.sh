sudo systemctl stop employ360.service
rm -rf /u01/jmx/kpi/*.jar
cp /u01/jmx/jmxuser/_work/2/s/build/libs/*.jar /u01/jmx/kpi/
sudo systemctl start employ360.service