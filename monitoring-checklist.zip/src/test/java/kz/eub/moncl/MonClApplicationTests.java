package kz.eub.moncl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonClApplicationTests {

	@Test
	void contextLoads() {
	}

}
