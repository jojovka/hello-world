package kz.eub.moncl.app.service;

import io.jmix.core.DataManager;
import io.jmix.securitydata.entity.RoleAssignmentEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Service("mcl_UserService")
public class UserService {
    @PersistenceContext
    private EntityManager em;

    @Autowired
    protected DataManager dataManager;

    public boolean checkUserExistsByUsername(String username) {
        return em.createNativeQuery("select u.id from mcl_user u " +
                        "where u.username = ?")
                .setParameter(1, username)
                .getResultList()
                .size() > 0;
    }

    public boolean isManager(String username){
        return dataManager.load(RoleAssignmentEntity.class)
                .query("select r from sec_RoleAssignmentEntity r where r.username = :username and r.roleCode = :roleCode")
                .parameter("username", username)
                .parameter("roleCode", "manager")
                .optional()
                .isPresent();
    }

    public boolean isStandartUser(String username){
        return dataManager.load(RoleAssignmentEntity.class)
                .query("select r from sec_RoleAssignmentEntity r where r.username = :username and r.roleCode = :roleCode")
                .parameter("username", username)
                .parameter("roleCode", "standart-role")
                .optional()
                .isPresent();
    }
}
