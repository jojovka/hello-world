package kz.eub.moncl.app.service;


import io.jmix.core.DataManager;
import kz.eub.moncl.entity.PlannedWork;
import kz.eub.moncl.entity.EReportCyclicity;
import kz.eub.moncl.entity.EReportStatus;
import kz.eub.moncl.entity.TaskTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.temporal.ChronoField;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;

@Service("mcl_TaskTemplateService")
public class TaskTemplateService {
    @Autowired
    private DataManager dataManager;
    @PersistenceContext
    private EntityManager em;

    public void transferDataJob() {
        String sql = "select e from mcl_TaskTemplate e";
        TypedQuery<TaskTemplate> query = em.createQuery(sql, TaskTemplate.class);
        List<TaskTemplate> taskTemplates = query.getResultList();

        selectNeededTasks(taskTemplates);
    }

    public void selectNeededTasks(List<TaskTemplate> items) {
        LocalDate currentDate = LocalDate.now();
        int numberOfDaysInMonth = getNumberOfDaysInMonth(currentDate.getYear(), currentDate.getMonthValue());
        LocalDate lastDayofCurrentMonth = LocalDate.now().with(TemporalAdjusters.lastDayOfMonth());
        LocalDate lastWorkDayCurrentMonth = getLastWorkingDayOfMonth(lastDayofCurrentMonth);

        List<TaskTemplate> filteredItems = new ArrayList<>();
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getCyclicity() == null && items.get(i).getAppointmentDate() != null) {
                filteredItems.add(items.get(i));
            } else if (items.get(i).getCyclicity().equals(EReportCyclicity.EVERY_WORK_DAY)) {
                if (currentDate.getDayOfWeek().getValue() == 1
                        || currentDate.getDayOfWeek().getValue() == 2
                        || currentDate.getDayOfWeek().getValue() == 3
                        || currentDate.getDayOfWeek().getValue() == 4
                        || currentDate.getDayOfWeek().getValue() == 5) {
                    filteredItems.add(items.get(i));
                }
            } else if (items.get(i).getCyclicity().equals(EReportCyclicity.EVERY_DAY)) {
                filteredItems.add(items.get(i));
            } else if (items.get(i).getCyclicity().equals(EReportCyclicity.EVERY_MONDAY_OF_WEEK)) {
                if (currentDate.getDayOfWeek().getValue() == 1) {
                    filteredItems.add(items.get(i));
                }
            } else if (items.get(i).getCyclicity().equals(EReportCyclicity.EVERY_PENULT_WORK_DAY_OF_MONTH)) {
                if (currentDate.getDayOfMonth() == numberOfDaysInMonth - 1) {
                    filteredItems.add(items.get(i));
                }
            } else if (items.get(i).getCyclicity().equals(EReportCyclicity.EVERY_LAST_WORK_DAY_OF_MONTH)) {
                if (currentDate.equals(lastWorkDayCurrentMonth)) {
                    filteredItems.add(items.get(i));
                }
            } else if (items.get(i).getCyclicity().equals(EReportCyclicity.EVERY_LAST_DAY_OF_MONTH)) {
                if (currentDate.equals(lastDayofCurrentMonth)) {
                    filteredItems.add(items.get(i));
                }
            }
        }

        for (int i = 0; i < filteredItems.size(); i++) {
            initPlannedWork(filteredItems, i);
        }
    }

    private PlannedWork initPlannedWork(List<TaskTemplate> filteredItems, int i) {
        PlannedWork item = dataManager.create(PlannedWork.class);
        item.setSystemName(filteredItems.get(i).getSystemName());
        item.setTaskName(filteredItems.get(i).getTaskName());
        item.setPriority(filteredItems.get(i).getPriority());
        item.setScheduledStartTime(filteredItems.get(i).getScheduledStartTime());
        item.setScheduledEndTime(filteredItems.get(i).getScheduledEndTime());
        item.setStatus(EReportStatus.APPOINTED);
        item.setPlannedWorkDescription(filteredItems.get(i).getTaskDescription());
        if (filteredItems.get(i).getAppointmentDate() != null && filteredItems.get(i).getCyclicity() == null) {
            item.setDate(filteredItems.get(i).getAppointmentDate());
            item.setScheduledStartDateTime(filteredItems.get(i).getAppointmentDate().atTime(filteredItems.get(i).getScheduledStartTime()));
            item.setScheduledEndDateTime(filteredItems.get(i).getAppointmentDate().atTime(filteredItems.get(i).getScheduledEndTime()));
        } else {
            item.setDate(LocalDate.now());
            item.setScheduledStartDateTime(LocalDate.now().atTime(filteredItems.get(i).getScheduledStartTime()));
            item.setScheduledEndDateTime(LocalDate.now().atTime(filteredItems.get(i).getScheduledEndTime()));
        }
        return dataManager.save(item);
    }

    public static int getNumberOfDaysInMonth(int year, int month) {
        YearMonth yearMonthObject = YearMonth.of(year, month);
        return yearMonthObject.lengthOfMonth();
    }

    public static LocalDate getLastWorkingDayOfMonth(LocalDate lastDayOfMonth) {
        LocalDate lastWorkingDayofMonth;
        switch (DayOfWeek.of(lastDayOfMonth.get(ChronoField.DAY_OF_WEEK))) {
            case SATURDAY:
                lastWorkingDayofMonth = lastDayOfMonth.minusDays(1);
                break;
            case SUNDAY:
                lastWorkingDayofMonth = lastDayOfMonth.minusDays(2);
                break;
            default:
                lastWorkingDayofMonth = lastDayOfMonth;
        }
        return lastWorkingDayofMonth;
    }
}
