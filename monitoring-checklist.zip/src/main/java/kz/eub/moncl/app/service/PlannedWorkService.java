package kz.eub.moncl.app.service;

import io.jmix.core.DataManager;
//import kz.eub.moncl.entity.DisposableTask;
import kz.eub.moncl.entity.EReportStatus;
import kz.eub.moncl.entity.GeneralReports;
import kz.eub.moncl.entity.PlannedWork;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

@Service("mcl_PlannedWorkService")
public class PlannedWorkService {
    @Autowired
    private DataManager dataManager;
    @PersistenceContext
    private EntityManager em;


    public GeneralReports setFinishedPlannedWorkToReport(PlannedWork itemPlannedWork){
        long delayedTimeMinutes = ChronoUnit.MINUTES.between(itemPlannedWork.getActualStartTime(), itemPlannedWork.getActualEndTime());
        GeneralReports itemGeneralReport = dataManager.create(GeneralReports.class);
        itemGeneralReport.setDate(itemPlannedWork.getDate());
        itemGeneralReport.setSystemName(itemPlannedWork.getSystemName());
        itemGeneralReport.setTaskName(itemPlannedWork.getTaskName());
        itemGeneralReport.setPriority(itemPlannedWork.getPriority());
        itemGeneralReport.setScheduledStartTime(itemPlannedWork.getScheduledStartTime());
        itemGeneralReport.setScheduledEndTime(itemPlannedWork.getScheduledEndTime());
        itemGeneralReport.setActualStartTime(itemPlannedWork.getActualStartTime());
        itemGeneralReport.setActualEndTime(itemPlannedWork.getActualEndTime());
        itemGeneralReport.setComment(itemPlannedWork.getComment());
        LocalDateTime dateActualFinish = LocalDate.now().atTime(itemPlannedWork.getActualEndTime());
        long noAllOfDays = itemPlannedWork.getScheduledEndDateTime().until(dateActualFinish, ChronoUnit.DAYS);
        long noOfAllHours = itemPlannedWork.getScheduledEndDateTime().until(dateActualFinish, ChronoUnit.HOURS);
        long noOfAllMinutes = itemPlannedWork.getScheduledEndDateTime().until(dateActualFinish, ChronoUnit.MINUTES);
        long noOfMinutes = noOfAllMinutes - (noAllOfDays * 24 * 60) - (noOfAllHours % 24 * 60);
        itemGeneralReport.setDelayTimeAmountHours(noAllOfDays + " д. " + noOfAllHours % 24 + " ч. " + noOfMinutes  + " мин.");
        itemGeneralReport.setDelayTimeAmountMinutes(delayedTimeMinutes);
        itemGeneralReport.setStatus(itemPlannedWork.getStatus());
        itemGeneralReport.setFullName(itemPlannedWork.getFullName());
        return dataManager.save(itemGeneralReport);
    }

    public String getNumOfGreenTasks(){
        LocalDate localDate = LocalDate.now();
        LocalTime localTime = LocalTime.now();
        return String.valueOf(em.createNativeQuery("select p from MCL_PLANNED_WORK as p where (p.date_= ? and ? > p.scheduled_start_time and ? < p.scheduled_end_time and (p.status = ? or p.status = ?)) or (p.date_ = ? and ? > p.scheduled_end_time and (p.status = ? or p.status = ?)) or (p.date_ < ? and (p.status = ? or p.status = ?))")
                .setParameter(1, localDate)
                .setParameter(2, localTime)
                .setParameter(3, localTime)
                .setParameter(4, EReportStatus.APPOINTED)
                .setParameter(5, EReportStatus.IN_PROCESS)
                .setParameter(6, localDate)
                .setParameter(7, localTime)
                .setParameter(8, EReportStatus.APPOINTED)
                .setParameter(9, EReportStatus.IN_PROCESS)
                .setParameter(10, localDate)
                .setParameter(11, EReportStatus.APPOINTED)
                .setParameter(12, EReportStatus.IN_PROCESS)
                .getResultList()
                .size());
    }
}
