package kz.eub.moncl.security;

import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import kz.eub.moncl.entity.DisposableTaskDTO;
import kz.eub.moncl.entity.GeneralReports;
import kz.eub.moncl.entity.PlannedWork;
import kz.eub.moncl.entity.User;

import javax.annotation.Nonnull;

@Nonnull
@ResourceRole(name = "StandartRole", code = "standart-role")
public interface StandartRole {
    @MenuPolicy(menuIds = {"mcl_PlannedWork.browse", "mcl_GrafanaScreen", "plannedWork"})
    @ScreenPolicy(screenIds = {"mcl_PlannedWork.browse", "mcl_GrafanaScreen", "mcl_UserRole.browse", "mcl_PlannedWork.edit", "plannedWork"})
    void screens();

    @EntityAttributePolicy(entityClass = PlannedWork.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = PlannedWork.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE, EntityPolicyAction.DELETE})
    void plannedWork();

    @EntityAttributePolicy(entityClass = User.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    void user();

    @EntityPolicy(entityClass = GeneralReports.class, actions = EntityPolicyAction.CREATE)
    void generalReports();

    @EntityAttributePolicy(entityClass = DisposableTaskDTO.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DisposableTaskDTO.class, actions = EntityPolicyAction.ALL)
    void disposableTaskDTO();
}