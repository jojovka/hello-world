package kz.eub.moncl.security;

import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.securitydata.entity.RoleAssignmentEntity;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;
import kz.eub.moncl.entity.DisposableTaskDTO;
import kz.eub.moncl.entity.GeneralReports;
import kz.eub.moncl.entity.PlannedWork;
import kz.eub.moncl.entity.TaskTemplate;
import kz.eub.moncl.entity.User;

import javax.annotation.Nonnull;

@Nonnull
@ResourceRole(name = "Manager", code = "manager")
public interface ManagerRole {
    @MenuPolicy(menuIds = {"mcl_TaskTemplate.browse", "mcl_GeneralReports.browse", "mcl_PlannedWork.browse", "mcl_GrafanaScreen", "mcl_UserRole.browse", "plannedWork", "taskTemplate"})
    @ScreenPolicy(screenIds = {"mcl_TaskTemplate.browse", "mcl_GeneralReports.browse", "mcl_PlannedWork.browse", "mcl_GrafanaScreen", "mcl_UserRole.browse", "mcl_GeneralReports.edit", "mcl_TaskTemplate.edit", "mcl_PlannedWork.edit", "plannedWork", "taskTemplate"})
    void screens();

    @EntityAttributePolicy(entityClass = GeneralReports.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = GeneralReports.class, actions = EntityPolicyAction.ALL)
    void generalReports();

    @EntityAttributePolicy(entityClass = PlannedWork.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = PlannedWork.class, actions = EntityPolicyAction.ALL)
    void plannedWork();

    @EntityAttributePolicy(entityClass = TaskTemplate.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = TaskTemplate.class, actions = EntityPolicyAction.ALL)
    void taskTemplate();

    @EntityAttributePolicy(entityClass = User.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = User.class, actions = EntityPolicyAction.ALL)
    void user();

    @EntityAttributePolicy(entityClass = RoleAssignmentEntity.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = RoleAssignmentEntity.class, actions = EntityPolicyAction.ALL)
    void roleAssignment();

    @EntityAttributePolicy(entityClass = DisposableTaskDTO.class, attributes = "*", action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = DisposableTaskDTO.class, actions = EntityPolicyAction.ALL)
    void disposableTaskDTO();
}