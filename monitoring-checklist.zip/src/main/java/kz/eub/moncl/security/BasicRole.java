package kz.eub.moncl.security;

import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.securityui.role.annotation.ScreenPolicy;

import javax.annotation.Nonnull;

@Nonnull
@ResourceRole(name = "BasicRole", code = "basic-role")
public interface BasicRole {
    @ScreenPolicy(screenIds = "mcl_LoginScreen")
    void screens();
}