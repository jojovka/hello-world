package kz.eub.moncl.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum EReportStatus implements EnumClass<Integer> {

    APPOINTED(1),
    IN_PROCESS(2),
    FINISHED(3);

    private Integer id;

    EReportStatus(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static EReportStatus fromId(Integer id) {
        for (EReportStatus at : EReportStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}