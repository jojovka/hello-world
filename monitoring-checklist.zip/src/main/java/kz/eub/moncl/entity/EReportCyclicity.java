package kz.eub.moncl.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum EReportCyclicity implements EnumClass<Integer> {

    EVERY_WORK_DAY(1),
    EVERY_DAY(2),
    EVERY_MONDAY_OF_WEEK(3),
    EVERY_PENULT_WORK_DAY_OF_MONTH(5),
    EVERY_LAST_WORK_DAY_OF_MONTH(6),
    EVERY_LAST_DAY_OF_MONTH(7);

    private Integer id;

    EReportCyclicity(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static EReportCyclicity fromId(Integer id) {
        for (EReportCyclicity at : EReportCyclicity.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}