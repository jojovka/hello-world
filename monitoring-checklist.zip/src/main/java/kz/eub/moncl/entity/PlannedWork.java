package kz.eub.moncl.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.UUID;

@JmixEntity
@Table(name = "MCL_PLANNED_WORK")
@Entity(name = "mcl_PlannedWork")
public class PlannedWork {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @Column(name = "DATE_")
    private LocalDate date;

    @Column(name = "SYSTEM_NAME", nullable = false)
    @NotNull
    private String systemName;

    @Column(name = "TASK_NAME", nullable = false)
    @NotNull
    private String taskName;

    @Column(name = "PRIORITY", nullable = false)
    @NotNull
    private Integer priority;

    @Column(name = "SCHEDULED_START_TIME", nullable = false)
    @NotNull
    private LocalTime scheduledStartTime;

    @Column(name = "SCHEDULED_END_TIME", nullable = false)
    @NotNull
    private LocalTime scheduledEndTime;

    @Column(name = "SCHEDULED_START_DATE_TIME")
    private LocalDateTime scheduledStartDateTime;

    @Column(name = "ACTUAL_END_DATE_TIME")
    private LocalDateTime scheduledEndDateTime;

    @Column(name = "ACTUAL_START_TIME")
    private LocalTime actualStartTime;

    @Column(name = "ACTUAL_END_TIME")
    private LocalTime actualEndTime;

    @Column(name = "COMMENT_")
    @Lob
    private String comment;

    @Column(name = "STATUS")
    private Integer status;

    @Column(name = "FULL_NAME")
    private String fullName;

    @Column(name = "PLANNED_WORK_DESCRIPTION")
    @Lob
    private String plannedWorkDescription;

    public String getPlannedWorkDescription() {
        return plannedWorkDescription;
    }

    public void setPlannedWorkDescription(String plannedWorkDescription) {
        this.plannedWorkDescription = plannedWorkDescription;
    }

    public LocalDateTime getScheduledStartDateTime() {
        return scheduledStartDateTime;
    }

    public void setScheduledStartDateTime(LocalDateTime scheduledStartDateTime) {
        this.scheduledStartDateTime = scheduledStartDateTime;
    }

    public LocalDateTime getScheduledEndDateTime() {
        return scheduledEndDateTime;
    }

    public void setScheduledEndDateTime(LocalDateTime actualEndDateTime) {
        this.scheduledEndDateTime = actualEndDateTime;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public EReportStatus getStatus() {
        return status == null ? null : EReportStatus.fromId(status);
    }

    public void setStatus(EReportStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public LocalTime getActualEndTime() {
        return actualEndTime;
    }

    public void setActualEndTime(LocalTime actualEndTime) {
        this.actualEndTime = actualEndTime;
    }

    public LocalTime getActualStartTime() {
        return actualStartTime;
    }

    public void setActualStartTime(LocalTime actualStartTime) {
        this.actualStartTime = actualStartTime;
    }

    public LocalTime getScheduledEndTime() {
        return scheduledEndTime;
    }

    public void setScheduledEndTime(LocalTime scheduledEndTime) {
        this.scheduledEndTime = scheduledEndTime;
    }

    public LocalTime getScheduledStartTime() {
        return scheduledStartTime;
    }

    public void setScheduledStartTime(LocalTime scheduledStartTime) {
        this.scheduledStartTime = scheduledStartTime;
    }

    public EReportPriority getPriority() {
        return priority == null ? null : EReportPriority.fromId(priority);
    }

    public void setPriority(EReportPriority priority) {
        this.priority = priority == null ? null : priority.getId();
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getSystemName() {
        return systemName;
    }

    public void setSystemName(String systemName) {
        this.systemName = systemName;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}