package kz.eub.moncl.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum EReportPriority implements EnumClass<Integer> {

    MEDIUM(1),
    HIGH(2),
    HIGHEST(3);

    private Integer id;

    EReportPriority(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static EReportPriority fromId(Integer id) {
        for (EReportPriority at : EReportPriority.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}