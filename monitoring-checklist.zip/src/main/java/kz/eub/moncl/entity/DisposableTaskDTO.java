package kz.eub.moncl.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.JmixEntity;

import java.util.UUID;

@JmixEntity(name = "mcl_DisposableTaskDTO")
public class DisposableTaskDTO {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    private Integer triggerId;

    private String hostsName;

    private String itemsName;

    private String itemsLastValue;

    private Integer priority;

    private String comments;

    public void setPriority(EReportPriority priority) {
        this.priority = priority == null ? null : priority.getId();
    }

    public EReportPriority getPriority() {
        return priority == null ? null : EReportPriority.fromId(priority);
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getItemsLastValue() {
        return itemsLastValue;
    }

    public void setItemsLastValue(String itemsLastValue) {
        this.itemsLastValue = itemsLastValue;
    }

    public String getItemsName() {
        return itemsName;
    }

    public void setItemsName(String itemsName) {
        this.itemsName = itemsName;
    }

    public String getHostsName() {
        return hostsName;
    }

    public void setHostsName(String hostsName) {
        this.hostsName = hostsName;
    }

    public Integer getTriggerId() {
        return triggerId;
    }

    public void setTriggerId(Integer triggerId) {
        this.triggerId = triggerId;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}