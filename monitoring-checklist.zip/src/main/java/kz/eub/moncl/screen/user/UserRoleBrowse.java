package kz.eub.moncl.screen.user;

import io.jmix.core.DataManager;
import io.jmix.security.role.assignment.RoleAssignmentRoleType;
import io.jmix.securitydata.entity.RoleAssignmentEntity;
import io.jmix.ui.Notifications;
import io.jmix.ui.UiComponents;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.component.Label;
import io.jmix.ui.screen.*;
import kz.eub.moncl.app.service.UserService;
import kz.eub.moncl.entity.User;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;

@UiController("mcl_UserRole.browse")
@UiDescriptor("user-role-browse.xml")
@LookupComponent("usersTable")
public class UserRoleBrowse extends StandardLookup<User> {
    @Autowired
    protected DataManager dataManager;
    @Autowired
    private GroupTable<User> usersTable;
    @Autowired
    private Notifications notifications;

    @Autowired
    private UserService userService;
    @Autowired
    protected UiComponents uiComponents;


    @Subscribe
    public void onInit(InitEvent event) {
        usersTable.addGeneratedColumn("userRoles", entity -> {
            Label<String> label = uiComponents.create(Label.TYPE_STRING);
            boolean isManager = userService.isManager(entity.getUsername());
            boolean isStandartUser = userService.isStandartUser(entity.getUsername());
            if (isStandartUser && isManager){
                label.setValue("Менеджер, дежурный");
                return label;
            } else if (isStandartUser) {
                label.setValue("Дежурный");
                return label;
            } else if (isManager) {
                label.setValue("Менеджер");
                return label;
            } else {
                return null;
            }
        });
    }

    @Subscribe("makeManagerBtn")
    public void onMakeManagerBtnClick(Button.ClickEvent event) {
        User user = usersTable.getSingleSelected();
        RoleAssignmentEntity roleAssignment = dataManager.create(RoleAssignmentEntity.class);
        if (user != null) {
            boolean hasRole = dataManager.load(RoleAssignmentEntity.class)
                    .query("select r from sec_RoleAssignmentEntity r where r.username = :username and r.roleCode = :roleCode")
                    .parameter("username", user.getUsername())
                    .parameter("roleCode", "manager")
                    .optional()
                    .isPresent();
            if (!hasRole) {
                roleAssignment.setUsername(user.getUsername());
                roleAssignment.setRoleCode("manager");
                roleAssignment.setRoleType(RoleAssignmentRoleType.RESOURCE);
                dataManager.save(roleAssignment);
                notifications.create(Notifications.NotificationType.WARNING)
                        .withCaption("Пользователю присвоена роль Менеджера")
                        .show();
            } else {
                notifications.create(Notifications.NotificationType.ERROR)
                        .withCaption("Ошибка")
                        .withDescription("Пользователь уже имеет роль Менеджера")
                        .show();
            }
        }
    }

    @Subscribe("makeUserBtn")
    public void onMakeUserBtnClick(Button.ClickEvent event) {
        User user = usersTable.getSingleSelected();
        RoleAssignmentEntity roleAssignment = dataManager.create(RoleAssignmentEntity.class);
        if (user != null) {
            boolean hasRole = dataManager.load(RoleAssignmentEntity.class)
                    .query("select r from sec_RoleAssignmentEntity r where r.username = :username and r.roleCode = :roleCode")
                    .parameter("username", user.getUsername())
                    .parameter("roleCode", "standart-role")
                    .optional()
                    .isPresent();
            if (!hasRole) {
                roleAssignment.setUsername(user.getUsername());
                roleAssignment.setRoleCode("standart-role");
                roleAssignment.setRoleType(RoleAssignmentRoleType.RESOURCE);
                dataManager.save(roleAssignment);
                notifications.create(Notifications.NotificationType.WARNING)
                        .withCaption("Пользователю присвоена роль Дежурного")
                        .show();
            } else {
                notifications.create(Notifications.NotificationType.ERROR)
                        .withCaption("Ошибка")
                        .withDescription("Пользователь уже имеет роль Дежурного")
                        .show();
            }
        }
    }

    @Subscribe("undoManagerBtn")
    public void onUndoManagerBtnClick(Button.ClickEvent event) {
        User user = usersTable.getSingleSelected();
        if (user != null){
            Optional<RoleAssignmentEntity> roleAssignmentOptional = dataManager.load(RoleAssignmentEntity.class)
                    .query("select r from sec_RoleAssignmentEntity r where r.username = :username and r.roleCode = :roleCode")
                    .parameter("username", user.getUsername())
                    .parameter("roleCode", "manager")
                    .optional();

            if (roleAssignmentOptional.isPresent()){
                RoleAssignmentEntity roleAssignment = roleAssignmentOptional.get();
                dataManager.remove(roleAssignment);
                notifications.create(Notifications.NotificationType.WARNING)
                        .withCaption("У пользователя отменена роль Менеджера")
                        .show();
            } else {
                notifications.create(Notifications.NotificationType.ERROR)
                        .withCaption("Ошибка")
                        .withDescription("Пользователь не имеет роли Менеджера")
                        .show();
            }
        }
    }

    @Subscribe("undoUserBtn")
    public void onUndoUserBtnClick(Button.ClickEvent event) {
        User user = usersTable.getSingleSelected();
        if (user != null){
            Optional<RoleAssignmentEntity> roleAssignmentOptional = dataManager.load(RoleAssignmentEntity.class)
                    .query("select r from sec_RoleAssignmentEntity r where r.username = :username and r.roleCode = :roleCode")
                    .parameter("username", user.getUsername())
                    .parameter("roleCode", "standart-role")
                    .optional();

            if (roleAssignmentOptional.isPresent()){
                RoleAssignmentEntity roleAssignment = roleAssignmentOptional.get();
                dataManager.remove(roleAssignment);
                notifications.create(Notifications.NotificationType.WARNING)
                        .withCaption("У пользователя отменена роль Дежурного")
                        .show();
            } else {
                notifications.create(Notifications.NotificationType.ERROR)
                        .withCaption("Ошибка")
                        .withDescription("Пользователь не имеет роли Дежурного")
                        .show();
            }
        }

    }






}