package kz.eub.moncl.screen.plannedwork;

import io.jmix.ui.screen.*;
import kz.eub.moncl.app.service.PlannedWorkService;
import kz.eub.moncl.entity.PlannedWork;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("mcl_PlannedWork.edit")
@UiDescriptor("planned-work-edit.xml")
@EditedEntityContainer("plannedWorkDc")
public class PlannedWorkEdit extends StandardEditor<PlannedWork> {
    @Autowired
    private PlannedWorkService plannedWorkService;

    @Subscribe
    public void onAfterCommitChanges(AfterCommitChangesEvent event) {
        plannedWorkService.setFinishedPlannedWorkToReport(getEditedEntity());
    }

}