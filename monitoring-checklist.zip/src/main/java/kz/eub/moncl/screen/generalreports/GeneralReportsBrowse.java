package kz.eub.moncl.screen.generalreports;

import io.jmix.ui.component.DataGrid;
import io.jmix.ui.component.Filter;
import io.jmix.ui.screen.*;
import kz.eub.moncl.entity.GeneralReports;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("mcl_GeneralReports.browse")
@UiDescriptor("general-reports-browse.xml")
@LookupComponent("generalReportsesTable")
public class GeneralReportsBrowse extends StandardLookup<GeneralReports> {
    @Autowired
    private DataGrid<GeneralReports> generalReportsesTable;

    @Subscribe
    public void onInit(InitEvent event) {
        generalReportsesTable.getColumnNN("priority")
                .setStyleProvider(generalReports -> {
                    switch (generalReports.getPriority()) {
                        case MEDIUM:
                            return "low-priority";
                        case HIGH:
                            return "mid-priority";
                        case HIGHEST:
                            return "high-priority";
                        default:
                            return null;
                    }
                });
    }


}