package kz.eub.moncl.screen.user;

import kz.eub.moncl.entity.User;
import io.jmix.ui.navigation.Route;
import io.jmix.ui.screen.*;

@UiController("mcl_User.browse")
@UiDescriptor("user-browse.xml")
@LookupComponent("usersTable")
@Route("users")
@PrimaryLookupScreen(User.class)
public class UserBrowse extends StandardLookup<User> {
}