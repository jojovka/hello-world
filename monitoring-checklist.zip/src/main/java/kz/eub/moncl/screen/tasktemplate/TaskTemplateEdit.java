package kz.eub.moncl.screen.tasktemplate;

import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.DateField;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.screen.*;
import kz.eub.moncl.entity.EReportCyclicity;
import kz.eub.moncl.entity.TaskTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;

@UiController("mcl_TaskTemplate.edit")
@UiDescriptor("task-template-edit.xml")
@EditedEntityContainer("taskTemplateDc")
public class TaskTemplateEdit extends StandardEditor<TaskTemplate> {
    @Autowired
    private ComboBox<EReportCyclicity> cyclicityField;
    @Autowired
    private DateField<LocalDate> appointmentDateField;

    @Subscribe("cyclicityField")
    public void onCyclicityFieldValueChange(HasValue.ValueChangeEvent<EReportCyclicity> event) {
        if (cyclicityField.getValue() != null) {
            appointmentDateField.setEnabled(false);
        } else if (cyclicityField.getValue() == null) {
            appointmentDateField.setEnabled(true);
        }
    }

    @Subscribe("appointmentDateField")
    public void onAppointmentDateFieldValueChange(HasValue.ValueChangeEvent<LocalDate> event) {
        if (appointmentDateField.getValue() != null) {
            cyclicityField.setEnabled(false);
        } else if (appointmentDateField.getValue() == null) {
            cyclicityField.setEnabled(true);
        }

    }


}