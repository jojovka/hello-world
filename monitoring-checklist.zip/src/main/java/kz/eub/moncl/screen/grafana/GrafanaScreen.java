package kz.eub.moncl.screen.grafana;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("mcl_GrafanaScreen")
@UiDescriptor("grafana-screen.xml")
public class GrafanaScreen extends Screen {
}