package kz.eub.moncl.screen.main;

import com.vaadin.ui.UI;
import io.jmix.core.security.SystemAuthenticator;
import io.jmix.ui.ScreenTools;
import io.jmix.ui.component.AppWorkArea;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.Window;
import io.jmix.ui.component.mainwindow.Drawer;
import io.jmix.ui.component.mainwindow.SideMenu;
import io.jmix.ui.icon.JmixIcon;
import io.jmix.ui.navigation.Route;
import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.Subscribe;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiControllerUtils;
import io.jmix.ui.screen.UiDescriptor;
import kz.eub.moncl.app.service.PlannedWorkService;
import kz.eub.moncl.app.service.TaskTemplateService;
import kz.eub.moncl.screen.plannedwork.PlannedWorkBrowse;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Timer;
import java.util.TimerTask;

@UiController("mcl_MainScreen")
@UiDescriptor("main-screen.xml")
@Route(path = "main", root = true)
public class MainScreen extends Screen implements Window.HasWorkArea {
    private static final Logger log = org.slf4j.LoggerFactory.getLogger(PlannedWorkBrowse.class);

    @Autowired
    private ScreenTools screenTools;

    @Autowired
    private AppWorkArea workArea;
    @Autowired
    private Drawer drawer;
    @Autowired
    private Button collapseDrawerButton;
    @Autowired
    private SideMenu sideMenu;
    @Autowired
    private TaskTemplateService taskTemplateService;
    @Autowired
    private PlannedWorkService plannedWorkService;
    @Autowired
    private SystemAuthenticator systemAuthenticator;
    private UI currentUI;
    private Timer timer;

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        updateMyTasksBadge();
    }

    public void updateMyTasksBadge() {
        currentUI = UI.getCurrent();
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                systemAuthenticator.withSystem(()->{
                    log.info("Starting update Menu UI...");
                    currentUI.access(() ->{
                        SideMenu.MenuItem myTasks = sideMenu.getMenuItem("plannedWork");
                        if (myTasks == null) return;
                        myTasks.setBadgeText(plannedWorkService.getNumOfGreenTasks());
                        currentUI.getCurrent().push();
                    });
                    log.info("finished update Menu UI");
                    return null;
                });
            }
        }, 0, 5000);
    }


    @Override
    public AppWorkArea getWorkArea() {
        return workArea;
    }

    @Subscribe("collapseDrawerButton")
    private void onCollapseDrawerButtonClick(Button.ClickEvent event) {
        drawer.toggle();
        if (drawer.isCollapsed()) {
            collapseDrawerButton.setIconFromSet(JmixIcon.CHEVRON_RIGHT);
        } else {
            collapseDrawerButton.setIconFromSet(JmixIcon.CHEVRON_LEFT);
        }
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        screenTools.openDefaultScreen(
                UiControllerUtils.getScreenContext(this).getScreens());

        screenTools.handleRedirect();
    }
}
