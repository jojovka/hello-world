package kz.eub.moncl.screen.generalreports;

import io.jmix.ui.screen.*;
import kz.eub.moncl.entity.GeneralReports;

@UiController("mcl_GeneralReports.edit")
@UiDescriptor("general-reports-edit.xml")
@EditedEntityContainer("generalReportsDc")
public class GeneralReportsEdit extends StandardEditor<GeneralReports> {
}