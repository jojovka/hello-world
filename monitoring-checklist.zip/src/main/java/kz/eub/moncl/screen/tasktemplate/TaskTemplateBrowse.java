package kz.eub.moncl.screen.tasktemplate;

import io.jmix.ui.component.Button;
import io.jmix.ui.component.DataGrid;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.*;
import kz.eub.moncl.app.service.TaskTemplateService;
import kz.eub.moncl.entity.TaskTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@UiController("mcl_TaskTemplate.browse")
@UiDescriptor("task-template-browse.xml")
@LookupComponent("taskTemplatesTable")
public class TaskTemplateBrowse extends StandardLookup<TaskTemplate> {
    @Autowired
    private CollectionContainer<TaskTemplate> taskTemplatesDc;
    @Autowired
    private TaskTemplateService taskTemplateService;

    @Autowired
    private DataGrid<TaskTemplate> taskTemplatesTable;

    @Subscribe
    public void onInit(InitEvent event) {
        taskTemplatesTable.getColumnNN("priority")
                .setStyleProvider(taskTemplate -> {
                    switch (taskTemplate.getPriority()) {
                        case MEDIUM:
                            return "low-priority";
                        case HIGH:
                            return "mid-priority";
                        case HIGHEST:
                            return "high-priority";
                        default:
                            return null;
                    }
                });
    }
}